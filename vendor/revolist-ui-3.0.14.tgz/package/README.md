# RevoGrid shared UI

Shared controls for Grid Pro, Pivot, Charts, Gantt, Scheduler, Kanban and standalone examples. The workspace uses source exports; `pnpm pack:public` prepares an independently installable, ESM distribution with JavaScript, declarations, CSS and Angular partial-compilation metadata. Preparing the archive does not publish it to a registry. Public availability does not change the existing Commercial license.

## Entry points

```ts
// No grid or global browser state required at import time.
// Preact is the required shared rendering peer.
import {
  DialogController,
  PopoverController,
  attachMenuKeyboard,
} from '@revolist/ui/native';

// Optional Preact rendering adapters.
import { Button, Switch, Calendar, DateRangePicker } from '@revolist/ui/preact';

// Import once in a product's styles entry.
import '@revolist/ui/styles.scss';
```

The root entry is the native entry. `tokens.scss` exposes tokens separately. The distribution preserves the existing exported subpaths. Import only declared package exports; unexported implementation files are not an API.

## Component catalog

| Family            | Components                                                                                                              |
| ----------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Actions           | Button, IconButton, ToggleButton, ButtonGroup, Icon                                                                     |
| Binary and choice | Checkbox, Switch, RadioGroup, ChoiceChips                                                                               |
| Navigation        | SegmentedControl, Tabs, TabPanel, Listbox, ListboxOption                                                                |
| Fields            | TextInput, Textarea, SearchInput, NumberInput, NumberStepper, NativeSelect                                              |
| Selection         | Dropdown, Combobox, MultiSelect, Chip, RemovableChip, ResourcePicker                                                    |
| Numeric ranges    | TimelineTrack, Slider, RangeSlider; native scalar-slider/counter adapters                                                              |
| Dates             | Calendar and its header/day/month/year parts, DateInput, TimeInput, DateTimeInput, DatePicker, DateRangePicker          |
| Appearance        | ColorPalette, ColorPicker, Avatar                                                                                       |
| Forms             | FormField, FieldHint, FieldError, FormSection, Disclosure, DisclosureSummary                                            |
| Surfaces          | Dialog, DialogHeader, DialogBody, DialogFooter, ConfirmDialog, Popover, Tooltip, Menu, MenuItem, MenuSeparator, Submenu |
| Composition       | Toolbar, ToolbarGroup, ToolbarSeparator, SplitLayout, Pane, Panel, ResizeHandle                                         |
| Feedback          | Badge, CountBadge, StatusBadge, Alert, FeedbackPanel, Spinner, LoadingOverlay, EmptyState                               |
| Indicators        | Pagination, ProgressBar, CircularProgress, Rating                                                                       |

Native controllers own lifecycle, keyboard interaction, portal placement and cleanup. Preact adapters own rendered state, while product adapters own grid integration. Exported native rendering helpers accept the host's element factory so Charts can keep its existing DOM renderer.

See [OWNERSHIP.md](./OWNERSHIP.md) for implementation/style owners, renderer contracts and intentional product adapters.

## Ownership and compatibility

- UI does not import Core, Pro, or another product. Dates and working-calendar calculations stay in `@revolist/dates`.
- Existing Pro exports and leaf modules forward to the shared owner. Grid edit events, focus preservation, popup coordination, remote loading and cell/column types stay in Pro adapters.
- Task/card/event editors, working-calendar editors, Pivot configurators and chart inspectors remain product compositions.
- Controlled inputs receive values and callbacks. Date controls use civil date/native input strings; products retain timezone conversion, storage and validation policy.
- Sliders distinguish live input and commit callbacks. Popup/dialog handles have explicit teardown, and returned cleanup functions release listeners.
- `--rv-ui-*` variables define semantic surfaces, text, focus and control tokens. Existing classes and legacy feature variable overrides remain supported.
- Use the separate native entry in Charts. Importing the Preact barrel in Charts would violate the dependency boundary.

## Gallery and checks

The standalone gallery app lives in [`apps/ui-gallery`](../../apps/ui-gallery). Run `pnpm dev:ui` from the repository root, or `pnpm dev` from that app directory.

```sh
pnpm --filter @revolist/ui-gallery dev
pnpm --filter @revolist/ui-gallery build
pnpm --filter @revolist/ui lint
pnpm --filter @revolist/ui test
pnpm --filter @revolist/ui-gallery test:browser
```

The gallery shows default, compact, disabled, selected, mixed, invalid, read-only, loading, light/dark and RTL examples. The Chromium suite uses the built gallery and covers keyboard controls, nested overlays, focus return, multiple picker instances and narrow layouts. CI runs UI unit tests in the remaining-package group and browser tests alongside the existing Chromium integration job.

Colocated owner tests cover extracted implementations. Pro keeps consumer integration tests for its event adapters and compatibility exports. The build tooling bundles UI declarations into each product's `_shared/ui` directory so published types do not depend on this private workspace package.

The gallery also demonstrates filter building blocks without a grid: distribution charts with range brushes, generic option rows, weekly time grids and legends, inline field groups and highlighted text inputs. Import these from the Preact entry; consuming products supply data, localized text and domain policy.

Grid-backed selection and filter policy belong to Pro.

Compact `BarChart`, `LineChart` and `AreaChart` render independently of brush controls or grid instances. Import them from `@revolist/ui/preact` or their leaf entries (`@revolist/ui/bar-chart`, `@revolist/ui/line-chart`, `@revolist/ui/area-chart`). They accept explicit `data`, `ariaLabel`, height, selection flags and tooltip content. `DistributionChart` preserves the existing type-switching contract; `BrushRange` remains the slider composition. The gallery includes separate bar and line cards.

Field configurators use `FieldLibrary`, `FieldLibraryList`, `FieldGroup`, `FieldGroupHeading`, `FieldList`, `FieldRow`, `FieldItem`, and `FieldContent` from `@revolist/ui/field-configurator` (also in the Preact entry). They provide native disclosure, row structure and slots, not field metadata or query policy. Pivot compatibility exports delegate here; Pivot owns search policy, axis assignment, ordering and selection state.

### Interactive timeline track

`TimelineTrack` from `@revolist/ui/timeline-track` (also exported through `preact`) renders controlled `{ id, event: { start, end, label? } }` rows. Supply a finite increasing `range`, optional selected ID and label callbacks, `onSelect`, and `onEventChange`. Event changes preserve extra event metadata. The component owns pointer movement, edge resizing, ArrowLeft/ArrowRight edits, selection presentation and range labels; consumers own draft validation, storage and commits. Import the common styles entry once. The Sliders gallery includes an interactive example.

### Editable dialogs and standard actions

Compose `EditableDialogHeader`, `DialogBody`, and `DialogActionFooter` inside `DialogForm`. These parts are exported from `@revolist/ui/dialog/dialog.parts` and `@revolist/ui/preact`; they preserve the consumer's native dialog lifecycle and form callbacks. Scheduler, Kanban and Gantt use this composition.

The header accepts `titleId`, controlled `title`/`inputProps`, an accessible `inputLabel`, optional dialog `name` and description, and a close callback/label. Use `inputProps={false}` for a static heading. Native disabled/readonly semantics pass through.

The footer shows standard Cancel and submit Save actions by default. `cancel`, `save`, `deleteAction`, and `reset` accept labels and native button attributes/callbacks; set any action to `false` to hide it. Delete and Reset are opt-in and default to `type="button"`, so they never accidentally submit. `start` and `end` accept custom content on each side; `children` adds validation or other content above the action panel. Product translations and permissions remain explicit. See the Dialogs and floating surfaces gallery example for all actions, custom slots and hidden defaults.

### Selection lists

`Listbox`, `ListboxOption`, and `ListboxGroup` are available from `@revolist/ui/selection-list` and the Preact entry. Options support `icon`, `label`, and `description` directly, or arbitrary children for custom content. Groups add visible headings and accessible group labels. List selection and ArrowUp/ArrowDown/Home/End handling share one owner, including disabled-option skipping. Plain text, rich and grouped variants are demonstrated together in the Selection list gallery example. Format Cells consumes this same option API; it has no separate selection-list implementation. Existing EditorList and content-wrapper imports remain compatible.

### Interface colors

See [Colors and usage](COLORS.md) for semantic roles, theming, and compatibility overrides. The gallery header links to the independent Colors page (`?page=colors`).

Built-in product defaults live in named `src/color-palette/*-palettes.ts` modules. The Colors page shows each palette's values, usage, and consumers. Products import purpose-specific constants or the generated `@revolist/ui/palettes.scss` lookup; run `pnpm --filter @revolist/ui generate:palettes` after changing definitions. `check:palettes` verifies the generated source is current.

## Accessibility

See [Accessibility review and integration requirements](ACCESSIBILITY.md) for tested coverage, remaining gaps, and consumer responsibilities. Automated gallery checks are part of the shared UI browser suite.

## Motion

See [Shared UI motion](MOTION.md) for the component review, timings, and disable policy. Add `data-rv-ui-motion="off"` to the document or a region to disable motion; OS reduced motion is always respected. The gallery includes a Motion selector.

### Busy buttons

`Button`, `IconButton`, `ToggleButton`, `SvgButton` and `ButtonControl` accept `busy?: boolean`. Set `busy` while an action is pending, then clear it when the action completes (including failure). A loading ring appears, the accessible name stays intact, and native disabling blocks clicks, keyboard activation and form submission. Busy buttons retain their normal variant colors; an explicit `disabled` prop still takes precedence visually and remains disabled after busy clears. The same option is supported by `createControl(document, 'button', { busy: true })`.

```tsx
<Button variant="primary" busy={saving} onClick={save}>Save changes</Button>
```

The ring inherits the button text color. Motion Off (`data-rv-ui-motion="off"`) and `prefers-reduced-motion` keep the loading ring visible without spinning. Busy state is controlled by the caller; it does not start or finish an asynchronous task itself.

## Standalone framework controls

Import `@revolist/ui/styles.css` once for compiled standard styles. The public build bundles private date/chart utilities; customers do not need private workspace packages or a TypeScript/Sass source compiler. Preact is required by the shared rendering layer; React and Angular are optional peers used only by their adapter subpaths.

```ts
import { createControl, applyControlPresentation } from '@revolist/ui';
import { ButtonControl, Input, Select, TextArea } from '@revolist/ui/react-control';
import { vRvControl } from '@revolist/ui/vue-control'; // <button v-rv-control>
import { UiControlDirective } from '@revolist/ui/angular-control'; // standalone imports; <button rvControl>
import { rvControl } from '@revolist/ui/svelte-control'; // <button use:rvControl>
import '@revolist/ui/styles.css';
```

Each adapter preserves native elements, events, values and form bindings. React controls forward native refs. Vue and Angular directives and the Svelte action retain native refs and bindings. `applyControlPresentation(root)` handles existing static toolbar HTML; call it after replacing that HTML or changing a control type.

## Build and release preparation

Run `pnpm --dir packages/ui pack:public` from the monorepo, then `pnpm --dir packages/ui test:public`. The generated public package is `dist/`, and the archive is `artifacts/revolist-ui-<version>.tgz`. The workspace manifest intentionally remains private; the generated distribution manifest declares public access and contains no workspace dependencies.

Before publication, standalone repositories consume an identical archive in their own `vendor/` directory using relative `file:` dependencies and a lockfile generated against that real archive. These paths are portable with the cloned repository. Include its vendor archive when copying a starter out of that repository. After an authorized registry release, dependencies can switch to the published version and locks can be regenerated from the registry. Do not substitute unverified registry URLs or integrity values for the prepared archive.

Publication is a separate operation: publish the tested archive itself, preserving its bytes. No build or preparation script publishes automatically.
