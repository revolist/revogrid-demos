import { createPreactElement as e } from "../preact-mount.js";
import { renderControl as t } from "../control-presentation.js";
import { ButtonControl as n } from "../native-control.js";
import { h as r } from "preact";
import { jsx as i } from "preact/jsx-runtime";
//#region src/native-controls.view.tsx
function a(e, t) {
	return e("div", {
		class: t.className ?? "rv-spinner",
		role: "status",
		"aria-label": t.label,
		ref: t.ref
	}, t.showSpinner ? [e("span", {
		class: "rv-spinner__ring",
		"aria-hidden": "true"
	})] : []);
}
function o(t, r) {
	return e(t, /* @__PURE__ */ i(n, {
		unstyled: !0,
		type: "button",
		class: r.className ?? "rv-btn",
		"aria-label": r.label,
		disabled: !!r.disabled,
		onClick: r.onClick,
		children: r.text ?? r.label
	}));
}
function s(e, t) {
	return e("button", {
		type: "button",
		role: "menuitem",
		disabled: t.disabled,
		tabIndex: -1,
		"aria-haspopup": t.submenu ? "menu" : void 0,
		style: t.style,
		onClick: () => {
			t.disabled || t.onActivate();
		}
	}, [t.label, t.submenu ? e("span", {
		"aria-hidden": "true",
		style: "float:inline-end;margin-inline-start:16px"
	}, "›") : null]);
}
function c(e, t, n = Math.max(0, Math.floor(t))) {
	let r = Math.round(t);
	return Array.from({ length: Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0 }, (t, n) => e("span", { class: n < r ? "star filled-star" : "star empty-star" }));
}
function l(e, t) {
	let n = (e) => t.max > t.min ? Math.max(0, Math.min(100, (e - t.min) / (t.max - t.min) * 100)) : 0;
	return e("div", { class: `revo-slider ${t.thresholdClassNames ?? ""}` }, [e("div", { class: `revo-slider-container ${t.thresholdClassNames ?? ""}` }, [
		e("div", {
			class: "revo-slider-fill",
			style: { width: `${n(t.value)}%` }
		}),
		e("input", {
			class: "revo-slider-input rv-single-slider",
			style: { "--rv-single-slider-value": `${n(t.value)}%` },
			type: "range",
			min: t.min,
			max: t.max,
			step: t.step,
			value: t.value,
			"aria-label": t.label,
			"aria-valuetext": String(t.displayValue ?? t.value),
			onInput: (e) => {
				let r = e.target;
				r.style.setProperty("--rv-single-slider-value", `${n(Number(r.value))}%`);
				let i = r.closest(".revo-slider")?.querySelector(".revo-slider-value"), a = String(t.formatValue?.(Number(r.value)) ?? Number(r.value));
				r.setAttribute("aria-valuetext", a), i && (i.textContent = a);
			},
			onChange: (e) => t.onChange(Number(e.target.value), e),
			onMouseDown: t.onMouseDown
		}),
		...(t.thresholds ?? []).map((t) => e("div", {
			class: `revo-slider-threshold ${t.className}`,
			style: { left: `${n(t.value)}%` }
		}))
	]), ...t.hideValue ? [] : [e("span", { class: `revo-slider-value rv-badge rv-badge--inline ${t.thresholdClassNames ?? ""}` }, t.displayValue ?? t.value)]]);
}
function u(e, n) {
	let r = (r, i, a) => t(e, "button", {
		class: {
			"revo-counter-button": !0,
			"revo-counter-button-disabled": i
		},
		type: "button",
		"aria-label": r < 0 ? n.decreaseLabel ?? "Decrease value" : n.increaseLabel ?? "Increase value",
		disabled: i,
		onMouseDown: n.onMouseDown,
		onClick: (e) => {
			i || n.onChange(Math.min(n.max, Math.max(n.min, n.value + r)), e);
		}
	}, a);
	return e("div", { class: "revo-counter" }, [
		r(-n.step, n.value <= n.min, "-"),
		...n.hideValue ? [] : [e("span", { class: "revo-counter-value" }, String(n.value))],
		r(n.step, n.value >= n.max, "+")
	]);
}
//#endregion
//#region src/alert.tsx
function d(e, { children: t, tone: n = "neutral", label: r, icon: i, title: a, description: o, actions: s, className: c = "", class: l = "", ...u }) {
	let d = (t, n, ...r) => e(t, n, r);
	return /* @__PURE__ */ d("div", {
		...u,
		class: `rv-alert rv-alert--${n}${i ? " rv-alert--with-icon" : ""}${s ? " rv-alert--with-actions" : ""} ${c} ${l}`.trim(),
		role: n === "danger" ? "alert" : "status",
		"aria-label": r ?? u["aria-label"]
	}, i && /* @__PURE__ */ d("span", {
		class: "rv-alert__icon",
		"aria-hidden": "true"
	}, i), /* @__PURE__ */ d("div", { class: "rv-alert__content" }, a && /* @__PURE__ */ d("div", { class: "rv-alert__title" }, a), o && /* @__PURE__ */ d("div", { class: "rv-alert__description" }, o), t), s && /* @__PURE__ */ d("div", { class: "rv-alert__actions" }, s));
}
function f(e) {
	return d(r, e);
}
//#endregion
export { a, l as c, u as i, d as n, s as o, o as r, c as s, f as t };
