import { createControlId as e } from "../core/control-id.js";
import { ButtonControl as t, Select as n } from "../native-control.js";
import { DEFAULT_CALENDAR_TRANSLATIONS as r } from "../calendar/translations.js";
import { a as i, n as a } from "./iso-B0YHBK7m.js";
import { a as o, c as s, d as c, f as l, l as u, n as d, p as f, r as p, s as m, t as h, u as g } from "./model-mPO2tG2f.js";
import { n as _, t as ee } from "./header-ChgiwXiD.js";
import { CalendarMonthGrid as te } from "../calendar/month-grid.js";
import { CalendarYearGrid as ne } from "../calendar/year-grid.js";
import { jsx as v, jsxs as y } from "preact/jsx-runtime";
import { useMemo as b, useRef as x, useState as S } from "preact/hooks";
//#region src/calendar/caption.tsx
function re({ month: e, system: t, locale: r, layout: i, start: a, end: o, disabled: s, labels: d, onChange: f }) {
	let p = u(e, t), h = c(e, t), _ = b(() => {
		let n = u(e, t)[0], r = a ? u(a, t)[0] : m(n, -600, t), i = o ? u(o, t)[0] : m(n, 120, t), s = [];
		for (let e = r; e <= i; e = m(e, 12, t)) s.push(e);
		return s.includes(n) || s.push(n), s.sort();
	}, [
		e,
		t,
		a,
		o
	]);
	return /* @__PURE__ */ y("div", {
		class: "revo-calendar__caption",
		children: [i === "dropdown-years" ? /* @__PURE__ */ v("span", { children: g(e, r, { month: "long" }, t) }) : /* @__PURE__ */ v(n, {
			"aria-label": d.chooseMonth,
			disabled: s,
			value: String(h.month),
			onChange: (e) => f(p[Number(e.currentTarget.value) - 1]),
			children: p.map((e, n) => /* @__PURE__ */ v("option", {
				value: String(n + 1),
				disabled: !!(a && e < l(a, t) || o && e > l(o, t)),
				children: g(e, r, { month: "short" }, t)
			}, e))
		}), i === "dropdown-months" ? /* @__PURE__ */ v("span", { children: g(e, r, { year: "numeric" }, t) }) : /* @__PURE__ */ v(n, {
			"aria-label": d.chooseYear,
			disabled: s,
			value: p[0],
			onChange: (e) => {
				let n = e.currentTarget.value, r = m(n, h.month - 1, t);
				a && r < l(a, t) && (r = l(a, t)), o && r > l(o, t) && (r = l(o, t)), f(r);
			},
			children: _.map((e) => /* @__PURE__ */ v("option", {
				value: e,
				children: g(e, r, { year: "numeric" }, t)
			}, e))
		})]
	});
}
//#endregion
//#region src/calendar/calendar.tsx
var ie = "2026-08-02";
function C({ locale: n = "en-US", weekStartsOn: c = 1, showOutsideDays: u = !1, allowOutsideMonthSelection: C = !1, fixedWeeks: ae = !0, showTodayButton: oe = !1, showHeader: se = !0, showNavigation: w = !0, showPreviousButton: ce = w, showNextButton: le = w, showMonthLabel: ue = !0, showWeekdays: de = !0, enableYearView: T = !0, translations: fe = {}, ...E }) {
	let [D] = S(() => e("rv-calendar-feedback")), O = E.calendarSystem ?? "gregory", k = Math.max(1, Math.min(12, Math.trunc(E.numberOfMonths || 1))), A = b(() => {
		let e = E.views ? [...new Set(E.views.filter((e) => e === "month" || e === "year"))] : T ? ["month", "year"] : ["month"];
		return e.length ? e : ["month"];
	}, [E.views, T]), [j, pe] = S(E.defaultView && A.includes(E.defaultView) ? E.defaultView : A[0]), M = A.includes(j) ? j : A[0], N = l(E.month, O), P = b(() => Array.from({ length: k }, (e, t) => m(N, t, O)), [
		N,
		k,
		O
	]), me = E.reverseMonths ? [...P].reverse() : P, he = b(() => Array.from({ length: 7 }, (e, t) => f(ie, (c + t) % 7)), [c]), F = E.referenceDate ?? (E.referenceInstant ? a(E.referenceInstant, E.timeZone ?? "UTC") : void 0), I = x(/* @__PURE__ */ new Map()), L = x(!1), R = {
		...r,
		...fe
	}, z = (e) => p(e, {
		minDate: E.minDate,
		maxDate: E.maxDate,
		isMonthDisabled: E.isMonthDisabled,
		calendarSystem: O
	}), B = [E.startMonth, E.minDate].filter((e) => !!e).map((e) => l(e, O)).sort().at(-1), V = [E.endMonth, E.maxDate].filter((e) => !!e).map((e) => l(e, O)).sort().at(0), H = (e) => !!(E.disableNavigation || z(e) || B && e < B || V && e > V), U = (e, t = k) => {
		let n = V ? m(V, 1 - t, O) : void 0;
		return n && B && n < B && (n = B), n && e > n && (e = n), B && e < B && (e = B), e;
	}, W = /* @__PURE__ */ new Map(), G = (e) => {
		let t = W.get(e);
		if (t !== void 0) return t;
		let n = z(l(e, O)) || d(e, {
			minDate: E.minDate,
			maxDate: E.maxDate,
			isDisabled: E.isDateDisabled
		});
		return W.set(e, n), n;
	}, ge = P.includes(l(E.focusedDate, O)) && !G(E.focusedDate) ? E.focusedDate : P.flatMap((e) => h(e, c, !1, O)).find((e) => P.includes(l(e, O)) && !G(e)) ?? E.focusedDate, K = (e) => {
		e !== M && A.includes(e) && (pe(e), E.onViewChange?.(e));
	}, q = (e, t = E.onSelect) => {
		if (G(e)) return E.onInvalidSelection?.(R.invalidSelection, e), !1;
		let n = E.validateSelection?.(e, {
			month: N,
			view: M,
			selection: E.selection,
			preview: E.preview,
			referenceDate: F
		});
		return n === !1 || typeof n == "string" ? (E.onInvalidSelection?.(typeof n == "string" ? n : R.invalidSelection, e), !1) : (t(e), !0);
	}, _e = (e, t) => {
		t ? I.current.set(e, t) : I.current.delete(e), t && L.current && e === E.focusedDate && (L.current = !1, queueMicrotask(() => t.focus()));
	}, ve = (e, t) => {
		let n = E.dir ?? (e.currentTarget.ownerDocument.defaultView?.getComputedStyle(e.currentTarget).direction === "rtl" ? "rtl" : "ltr"), r = o({
			date: t,
			key: e.key,
			shiftKey: e.shiftKey,
			weekStartsOn: c,
			minDate: E.minDate,
			maxDate: E.maxDate,
			isDisabled: G,
			dir: n,
			calendarSystem: O
		});
		if (!r) return;
		e.preventDefault();
		let i = l(r, O);
		(P.includes(i) || !H(i)) && (L.current = !0, P.includes(i) || E.onMonthChange(U(i)), E.onFocusedDateChange(r), queueMicrotask(() => {
			let e = I.current.get(r);
			e && (L.current = !1, e.focus());
		}));
	}, J = (e) => E.formatMonth?.(e, n) ?? g(e, n, {
		month: "long",
		year: "numeric"
	}, O), Y = M === "year", ye = Y ? 12 : E.pagedNavigation ? k : 1, X = U(m(N, -ye, O), Y ? 1 : k), Z = U(m(N, ye, O), Y ? 1 : k), Q = (e, t = Y ? 1 : k) => {
		let n = U(e, t);
		H(n) || E.onMonthChange(n);
	}, $ = (e) => {
		q(e, E.onPresetSelect ?? E.onSelect) && (E.onMonthChange(U(l(e, O))), E.onFocusedDateChange(e), K("month"));
	};
	return /* @__PURE__ */ y("div", {
		class: `revo-calendar${E.showWeekNumber ? " revo-calendar--week-numbers" : ""}${E.className ? ` ${E.className}` : ""}`,
		dir: E.dir,
		style: E.cellSize ? { "--revo-calendar-cell-size": `${Math.max(24, E.cellSize)}px` } : void 0,
		children: [
			/* @__PURE__ */ v("div", {
				class: "revo-calendar__months",
				children: (Y ? [N] : me).map((e, t) => /* @__PURE__ */ y("section", {
					class: "revo-calendar__month-panel",
					children: [se && /* @__PURE__ */ v(ee, {
						label: Y ? g(e, n, { year: "numeric" }, O) : J(e),
						previousLabel: Y ? R.previousYear : R.previousMonth,
						nextLabel: Y ? R.nextYear : R.nextMonth,
						caption: !Y && E.captionLayout && E.captionLayout !== "label" ? /* @__PURE__ */ v(re, {
							month: e,
							system: O,
							locale: n,
							layout: E.captionLayout,
							start: B,
							end: V,
							disabled: E.disableNavigation,
							labels: R,
							onChange: (t) => Q(m(t, -P.indexOf(e), O))
						}) : void 0,
						labelAction: !E.disableNavigation && !Y && A.includes("year") ? {
							ariaLabel: `${R.chooseMonth}: ${J(e)}`,
							onClick: () => K("year")
						} : void 0,
						showLabel: ue,
						showPrevious: ce && t === 0,
						showNext: le && t === (Y ? 0 : k - 1),
						previousDisabled: X >= N || H(X),
						nextDisabled: Z <= N || H(Z),
						onPrevious: () => Q(X),
						onNext: () => Q(Z)
					}), Y ? /* @__PURE__ */ v(ne, {
						month: N,
						system: O,
						referenceDate: F,
						minDate: E.minDate,
						maxDate: E.maxDate,
						isMonthDisabled: E.isMonthDisabled,
						locale: n,
						ariaLabel: `${R.chooseMonth} ${g(N, n, { year: "numeric" }, O)}`,
						onEscape: () => K("month"),
						onSelect: (e) => {
							Q(e, k), K("month");
						}
					}) : /* @__PURE__ */ y("div", {
						class: "revo-calendar__calendar",
						role: "grid",
						"aria-label": `${J(e)} ${R.calendar}`,
						children: [de && /* @__PURE__ */ v(_, {
							dates: he,
							locale: n,
							format: E.formatWeekday ?? ((e, t) => g(e, t, { weekday: /^(fa|ar)(-|$)/.test(t) ? "narrow" : "short" }, O)),
							weekNumberLabel: E.showWeekNumber ? R.weekNumber : void 0
						}), /* @__PURE__ */ v(te, {
							dates: h(e, c, ae, O),
							month: e,
							system: O,
							visibleMonths: P,
							focusedDate: ge,
							referenceDate: F,
							selection: E.selection,
							selectedDates: E.selectedDates,
							preview: E.preview,
							previewInvalid: E.previewInvalid,
							previewDescriptionId: E.previewDescription ? D : void 0,
							showOutsideDays: u,
							allowOutsideMonthSelection: C,
							dayClassName: E.dayClassName,
							renderDay: E.renderDay ?? ((e) => g(e, n, { day: "numeric" }, O)),
							isDisabled: G,
							formatDayLabel: (e) => E.formatDayLabel?.(e, n) ?? g(e, n, {
								weekday: "long",
								month: "long",
								day: "numeric",
								year: "numeric"
							}, O),
							weekNumber: E.showWeekNumber ? (e) => {
								let t = s(E.weekNumbering === "local" ? e : f(e, (4 - i(e) + 7) % 7), E.weekNumbering === "local" ? c : 1, E.weekNumbering === "local" ? 1 : 4, E.weekNumbering === "local" ? O : "gregory");
								return E.formatWeekNumber?.(t) ?? new Intl.NumberFormat(n).format(t);
							} : void 0,
							weekNumberLabel: R.weekNumber,
							setDayRef: _e,
							onFocus: E.onFocusedDateChange,
							onPreview: (e) => E.onPreviewDateChange?.(e),
							onKeyDown: ve,
							onSelect: q
						})]
					})]
				}, e))
			}),
			E.presets?.length ? /* @__PURE__ */ v("div", {
				class: "revo-calendar__presets",
				children: E.presets.map((e) => /* @__PURE__ */ v(t, {
					disabled: G(e.date),
					onClick: () => $(e.date),
					children: e.label
				}, e.label))
			}) : null,
			oe && F && /* @__PURE__ */ v("button", {
				type: "button",
				class: "revo-calendar__today",
				disabled: G(F),
				onClick: () => $(F),
				children: R.today
			}),
			E.previewDescription !== void 0 && /* @__PURE__ */ v("p", {
				id: D,
				class: "revo-calendar__feedback",
				role: "status",
				"aria-live": "polite",
				"aria-atomic": "true",
				children: E.previewDescription
			}),
			E.footer && /* @__PURE__ */ v("div", {
				class: "revo-calendar__footer",
				children: E.footer
			})
		]
	});
}
//#endregion
export { C as t };
