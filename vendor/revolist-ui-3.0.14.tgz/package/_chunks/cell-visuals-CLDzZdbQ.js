import { controlClassName as e } from "../control-presentation.js";
import { renderProgressBar as t } from "../progress/bar.js";
//#region src/cell-visuals/presentation.ts
function n(e, n) {
	return e("div", { class: "progress-line-container" }, [t(e, {
		value: n.percent,
		className: "progress-line-background",
		fillClass: {
			"progress-line-bar": !0,
			...n.classes
		},
		ariaLabel: n.label
	}), e("span", { class: "progress-line-label" }, n.label)]);
}
function r(t, n) {
	return t("div", { class: e("progress-line-cell", n.classes) }, [
		t("div", {
			class: "cell-value",
			dir: "auto"
		}, n.label),
		t("div", {
			class: "progress-line-bar",
			style: { width: `${n.percent}%` }
		}),
		t("div", {
			class: "progress-line-bar-shadow",
			style: { width: `${n.percent}%` }
		}),
		t("div", { class: "progress-line-background" })
	]);
}
function i(t, n) {
	let { value: r } = n;
	return r == null || typeof r == "string" && !r.trim() ? "" : t("div", {
		class: e("badge-cell", {
			default: n.isDefault ?? !n.backgroundColor,
			rectangular: n.rectangular
		}, n.classes),
		style: {
			"--badge-cell-value-background-color": n.backgroundColor ?? "#475569",
			"--badge-cell-value-color": n.color ?? "#ffffff"
		}
	}, String(r));
}
function a(t, n) {
	let { value: r, label: i } = n, a = r > 0 ? "positive" : r < 0 ? "negative" : "neutral";
	return t("div", { class: e("change-cell", n.classes) }, [t("div", { class: `change-${a}` }, [t("span", { class: "change-value" }, r < 0 ? `(${i})` : String(i)), ...r === 0 ? [] : [t("span", { class: "change-icon" }, r > 0 ? "▲" : "▼")]])]);
}
function o(e, t, n = {
	true: "True",
	false: "False"
}) {
	return e("div", { class: "thumb-cell" }, [e("div", {
		class: `thumb thumb-${t ? "up" : "down"}`,
		title: t ? n.true : n.false
	}, t ? "👍" : "👎")]);
}
function s(e, t) {
	return e("span", {
		class: `column-icon ${t.className}`,
		title: t.title,
		innerHTML: t.icon
	});
}
function c(e, t) {
	return e("div", { class: "column-type-container" }, [t.icon, e("span", { class: "column-label" }, t.label)]);
}
function l(e, t) {
	return e("ul", { class: "summary-percentage-content" }, t.map((t) => e("li", { class: `summary-percentage-item${t.other ? " summary-percentage-others" : ""}` }, `${t.label} (${t.count}) ${t.percentage}%`)));
}
function u(e, t) {
	return e("div", { class: "summary-aggregate-content" }, t.map((t) => e("div", { class: "summary-aggregate-item" }, t)));
}
//#endregion
//#region src/cell-visuals/sparkline.ts
function d(t, n) {
	let { value: r } = n, i = Array.isArray(r) ? Array.from(r).filter((e) => e == null || typeof e == "number" && Number.isFinite(e)).map((e) => e ?? null) : [], a = i.filter((e) => e !== null);
	if (a.length === 0) return t("div", { class: "sparkline-container" }, "");
	let o = typeof n.ariaLabel == "function" ? n.ariaLabel(a) : n.ariaLabel ?? i.join(", "), s = n.maxValue ?? Math.max(...a), c = n.minValue ?? Math.min(...a), l = s - c || 1, u = i.map((e) => e === null ? null : 20 - (e - c) / l * 20), d = [];
	for (let r = 0; r < u.length - 1; r++) {
		if (u[r] === null || u[r + 1] === null) continue;
		let a = r / (i.length - 1) * 100, o = u[r], s = (r + 1) / (i.length - 1) * 100, c = u[r + 1], l = n.classesForValue?.(i[r]) ?? {};
		d.push(t("line", {
			class: e("sparkline-segment", l),
			x1: a.toString(),
			y1: o.toString(),
			x2: s.toString(),
			y2: c.toString()
		}));
	}
	return t("div", {
		class: "sparkline-container",
		role: "img",
		"aria-label": o
	}, [t("svg", {
		class: "sparkline",
		viewBox: "0 0 100 20",
		xmlns: "http://www.w3.org/2000/svg"
	}, d)]);
}
//#endregion
//#region src/cell-visuals/mini-bars.ts
function f(t, n) {
	let { value: r } = n, i = Array.isArray(r) ? r : [];
	if (i.length === 0) return t("div", { class: "bar-chart-container" }, "");
	let a = n.maxValue ?? Math.max(...i), o = n.minValue ?? Math.min(...i), s = i.map((e) => (e - o) / (a - o || 1) * 100);
	return t("div", { class: "bar-chart-container" }, [t("div", { class: `bar-chart ${n.barPosition || "bottom"}` }, [...s.map((r, a) => {
		let o = n.classesForValue?.(r) ?? {};
		return t("div", {
			class: e("bar-chart-bar", o),
			style: {
				width: `${100 / i.length}%`,
				height: `${r}%`
			}
		});
	})])]);
}
//#endregion
//#region ../chart-utils/src/colors.ts
function p(e) {
	let t = /^#([\da-f]{6}|[\da-f]{3})$/i.exec(e.trim());
	if (!t) return;
	let n = t[1].length === 3 ? [...t[1]].map((e) => e.repeat(2)).join("") : t[1];
	return [
		Number.parseInt(n.slice(0, 2), 16),
		Number.parseInt(n.slice(2, 4), 16),
		Number.parseInt(n.slice(4, 6), 16)
	];
}
function m(e, t, n, r = .5) {
	if (t === n) return e === t ? r : +(e > n);
	if (e <= t) return 0;
	if (e >= n) return 1;
	let i = n - t, a = Math.max(Math.abs(t), Math.abs(n)), o = Number.isFinite(i) ? (e - t) / i : (e / a - t / a) / (n / a - t / a);
	return Math.min(1, Math.max(0, o));
}
function h(e, t, n) {
	let r = Math.min(1, Math.max(0, n));
	return `rgb(${e.map((e, n) => Math.round(e + (t[n] - e) * r)).join(", ")})`;
}
//#endregion
//#region src/cell-visuals/heatmap.ts
function g(e) {
	return e <= .5 ? `rgb(255, ${Math.round(e / .5 * 255)}, 0)` : `rgb(${Math.round(255 * ((1 - e) / .5))}, ${Math.round(150 + 105 * ((1 - e) / .5))}, 0)`;
}
function _(e) {
	return `rgb(0, ${Math.round(150 * e)}, ${Math.round(255 * e)})`;
}
function v(e, t, n, r, i) {
	let a = i.map(p);
	if (a.some((e) => !e)) return;
	let [o, s, c] = a;
	return e <= n ? h(o, s, m(e, t, n, 1)) : h(s, c, m(e, n, r, 1));
}
function y(e) {
	let t = e.match(/\d+/g)?.map(Number);
	if (!t || t.length !== 3) return "#000";
	let [n, r, i] = t;
	return (.2126 * n + .7152 * r + .0722 * i) / 255 > .5 ? "#000" : "#fff";
}
function b(e, t) {
	let { value: n } = t, r = t.minValue ?? 0, i = t.maxValue ?? 100, a = i - r || 1, o = t.colorMap ?? "heatmap", s = Number(n), c = Math.min(r, i), l = Math.max(r, i), u = Math.min(l, Math.max(c, t.midValue ?? c + (l - c) / 2)), d = Math.min(1, Math.max(0, (s - r) / a)), f = (t.lowColor && t.midColor && t.highColor ? v(s, c, u, l, [
		t.lowColor,
		t.midColor,
		t.highColor
	]) : void 0) ?? (o === "coldmap" ? _(d) : g(d));
	return e("div", {
		class: "heatmap-cell",
		style: {
			backgroundColor: f,
			color: y(f)
		}
	}, String(n));
}
//#endregion
//#region src/cell-visuals/timeline.ts
function x(e) {
	let t = `${e.start}–${e.end}`;
	return e.label ? `${e.label}: ${t}` : t;
}
function S(e, t = ", ") {
	return T(e).map(x).join(t);
}
function C(e, t, n) {
	let r = w(n), i = r.end - r.start;
	return t.flatMap((t, n) => {
		if (t.end < r.start || t.start > r.end) return [];
		let a = Math.max(r.start, t.start), o = Math.min(r.end, t.end), s = (a - r.start) / i * 100, c = (o - a) / i * 100;
		return [e("div", {
			class: "rv-timeline-event-bar",
			style: {
				left: `${s}%`,
				width: `${c}%`,
				position: "absolute"
			},
			"data-tooltip": x(t),
			"tooltip-position": "top",
			role: "img",
			"aria-label": x(t),
			key: n
		})];
	});
}
function w(e) {
	let t = e?.start, n = e?.end;
	return Number.isFinite(t) && Number.isFinite(n) && n > t ? {
		start: t,
		end: n
	} : {
		start: 0,
		end: 100
	};
}
function T(e) {
	return Array.isArray(e) ? e.filter((e) => !!e && typeof e == "object" && Number.isFinite(e.start) && Number.isFinite(e.end) && e.end >= e.start && (e.label === void 0 || typeof e.label == "string")) : [];
}
function E(e, t) {
	return typeof t == "function" ? t(e) : t || S(e);
}
function D(e, t) {
	let { value: n } = t, r = T(n);
	return e("div", {
		class: "rv-timeline-container",
		role: "img",
		"aria-label": E(r, t.ariaLabel) || void 0
	}, [e("div", { class: "rv-timeline-track" }, [e("div", { class: "rv-timeline-bar" }, []), ...C(e, r, t.range)])]);
}
//#endregion
//#region src/cell-visuals/pie.ts
function O(e, t) {
	return `hsl(${e / t * 360}, 70%, 50%)`;
}
function k(e) {
	return Array.isArray(e) && typeof e[0] == "number" ? e.map((t, n) => ({
		value: t,
		color: O(n, e.length),
		name: `Slice ${n + 1}`
	})) : Array.isArray(e) && typeof e[0] == "object" ? e : [];
}
function A(e = [], t, n) {
	if (!t) return;
	let r = k(e), i = r.reduce((e, t) => e + t.value, 0), a = 0, o = Math.min(t.width, t.height) / 2, s = t.getContext("2d");
	s && (s.clearRect(0, 0, t.width, t.height), s.font = n ?? "12px system-ui", s.textAlign = "center", s.textBaseline = "middle", r.forEach((e, n) => {
		let c = e.value / i * 2 * Math.PI;
		if (s.beginPath(), s.moveTo(t.width / 2, t.height / 2), s.arc(t.width / 2, t.height / 2, o, a, a + c), s.fillStyle = e.color || O(n, r.length), s.fill(), e.name) {
			s.fillStyle = "#ffffff";
			let n = t.width / 2 + Math.cos(a + c / 2) * (o / 2), r = t.height / 2 + Math.sin(a + c / 2) * (o / 2);
			s.fillText(e.name, n, r, o * .8);
		}
		a += c;
	}));
}
function j(e, t = [], n = {}) {
	return e("canvas", {
		class: "pie-chart-canvas",
		width: n.size ?? 64,
		height: n.size ?? 64,
		role: "img",
		"aria-label": n.ariaLabel ?? k(t).map((e) => `${e.name ?? "Slice"}: ${e.value}`).join(", "),
		ref: (e) => A(t, e, n.labelFont)
	});
}
//#endregion
export { f as a, i as c, l as d, n as f, s as h, b as i, a as l, o as m, S as n, d as o, r as p, D as r, u as s, j as t, c as u };
