import { Fragment as e, jsx as t, jsxs as n } from "preact/jsx-runtime";
import { useRef as r, useState as i } from "preact/hooks";
//#region src/distribution-chart/geometry.ts
function a(e) {
	let t = e.map(({ value: e }) => Number.isFinite(e) ? Math.max(0, e) : 0), n = Math.max(1, ...t);
	return {
		values: t,
		max: n,
		points: t.map((t, r) => ({
			x: e.length <= 1 ? 50 : r / (e.length - 1) * 100,
			y: 96 - t / n * 88
		}))
	};
}
function o(e, t) {
	return t === "step" ? `H ${e.x} V ${e.y}` : `L ${e.x} ${e.y}`;
}
function s(e, t, n = "linear") {
	return `M ${e.x} ${e.y} ${o(t, n)}`;
}
//#endregion
//#region src/distribution-chart/chart-frame.tsx
function c({ title: e, details: t = [] }) {
	return [e, ...t].filter(Boolean).join(". ");
}
function l({ title: r, details: i = [] }) {
	return /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("strong", { children: r }), i.map((e) => /* @__PURE__ */ t("span", { children: e }, e))] });
}
function u({ data: e, ariaLabel: o, variant: s, height: u = 72, className: d = "", showGrid: f = !1, showLabels: p = !1, showValues: m = !1, legend: h, formatValue: g = String, tooltip: _ = !0, tooltipIndicator: v = "none", renderTooltip: y, positions: b, renderDatum: x, children: S }) {
	let { values: C, max: w } = a(e), [T, E] = i(0), D = r([]), O = Math.min(T, Math.max(0, e.length - 1)), k = (t) => {
		if (!e.length) return;
		let n = Math.max(0, Math.min(t, e.length - 1));
		E(n), D.current[n]?.focus();
	};
	return /* @__PURE__ */ n("div", {
		class: `rv-distribution-chart rv-distribution-chart--${s} ${d}`.trim(),
		role: "group",
		"aria-label": o,
		"data-empty": e.length ? void 0 : "true",
		children: [
			/* @__PURE__ */ n("div", {
				class: "rv-distribution-chart__region",
				style: { height: `${Math.max(40, Math.min(240, u))}px` },
				children: [
					f && /* @__PURE__ */ t("div", {
						class: "rv-distribution-chart__grid",
						"aria-hidden": "true",
						children: [
							0,
							1,
							2,
							3,
							4
						].map((e) => /* @__PURE__ */ t("span", {}, e))
					}),
					S,
					/* @__PURE__ */ t("div", {
						class: "rv-distribution-chart__data",
						role: "list",
						children: e.map((r, i) => {
							let a = b?.[i], o = !a;
							return /* @__PURE__ */ n("span", {
								ref: (e) => {
									D.current[i] = e;
								},
								class: `rv-distribution-chart__datum${r.selected ? " is-selected" : ""}${o ? " is-bar" : " is-point"}`,
								role: "listitem",
								tabIndex: i === O ? 0 : -1,
								"aria-label": c(r.tooltip),
								style: o ? void 0 : {
									left: `${a.x}%`,
									top: `${a.y}%`
								},
								onFocus: () => E(i),
								onKeyDown: (t) => {
									t.key === "ArrowRight" || t.key === "ArrowDown" ? (t.preventDefault(), k(i + 1)) : t.key === "ArrowLeft" || t.key === "ArrowUp" ? (t.preventDefault(), k(i - 1)) : t.key === "Home" ? (t.preventDefault(), k(0)) : t.key === "End" && (t.preventDefault(), k(e.length - 1));
								},
								children: [
									x(r, i),
									m && /* @__PURE__ */ t("span", {
										class: "rv-distribution-chart__value",
										style: o ? {
											top: `${100 - Math.max(3, C[i] / w * 100)}%`,
											transform: "translate(-50%, -100%)"
										} : void 0,
										"aria-hidden": "true",
										children: g(r.value)
									}),
									_ && /* @__PURE__ */ n("span", {
										class: `rv-distribution-chart__tooltip rv-distribution-chart__tooltip--${v}`,
										role: "tooltip",
										children: [v !== "none" && /* @__PURE__ */ t("i", { "aria-hidden": "true" }), y ? y(r, i) : l(r.tooltip)]
									})
								]
							}, r.key);
						})
					})
				]
			}),
			p && /* @__PURE__ */ t("div", {
				class: `rv-distribution-chart__labels${s === "bar" ? " is-bar" : ""}`,
				"aria-hidden": "true",
				children: e.map((e) => /* @__PURE__ */ t("span", {
					title: e.tooltip.title,
					children: e.tooltip.title
				}, e.key))
			}),
			h && /* @__PURE__ */ n("div", {
				class: "rv-distribution-chart__legend",
				children: [/* @__PURE__ */ t("i", { "aria-hidden": "true" }), h]
			})
		]
	});
}
function d({ children: e }) {
	return /* @__PURE__ */ t("svg", {
		class: "rv-distribution-chart__plot",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: e
	});
}
//#endregion
export { s as i, d as n, a as r, u as t };
