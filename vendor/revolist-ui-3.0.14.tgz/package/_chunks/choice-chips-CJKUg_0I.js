import { ButtonControl as e } from "../native-control.js";
import { TooltipController as t } from "../surfaces.js";
import { SvgIcon as n } from "../icons/icon.js";
import { RemoveButton as r } from "../buttons/remove-button.js";
import { jsx as i, jsxs as a } from "preact/jsx-runtime";
import { useLayoutEffect as o, useRef as s } from "preact/hooks";
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/circle-info.svg?raw
var c = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM224 160a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm-8 64l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z\"/></svg>";
//#endregion
//#region src/choice-chips/index.tsx
function l({ value: e, options: t, onChange: n, ariaLabel: r, appearance: a = "soft", size: o = "medium", className: s = "", itemClassName: c = "", disabled: l = !1, testId: u }) {
	let f = Array.isArray(e) ? e : e === void 0 ? [] : [e];
	return /* @__PURE__ */ i("div", {
		class: `rv-choice-chips rv-choice-chips--${a} rv-choice-chips--${o} ${s}`.trim(),
		role: "group",
		"aria-label": r,
		"data-testid": u,
		children: t.map((e) => {
			let t = f.includes(e.value), r = l || !!e.disabled;
			return /* @__PURE__ */ i(d, {
				className: `${c} ${e.className ?? ""}`.trim(),
				style: e.style,
				color: e.color,
				selected: t,
				"aria-label": e.ariaLabel,
				title: e.title,
				disabled: r,
				"data-value": String(e.value),
				"data-testid": e.testId,
				onSelect: () => {
					r || n(e.value, e);
				},
				info: e.info,
				onRemove: e.onRemove,
				removeLabel: e.removeLabel,
				children: e.label
			}, String(e.value));
		})
	});
}
function u({ "data-tooltip": r, title: a, ref: l, ...u }) {
	let d = s(null), f = r ?? (typeof a == "object" ? a.value : a);
	return o(() => {
		if (!d.current || !f) return;
		let e = new t();
		return e.bind(d.current, f, { trigger: "click" }), () => e.destroy();
	}, [f]), /* @__PURE__ */ i(e, {
		...u,
		type: "button",
		ref: (e) => {
			d.current = e, typeof l == "function" ? l(e) : l && (l.current = e);
		},
		class: `rv-choice-chip-info ${u.className ?? u.class ?? ""}`.trim(),
		children: /* @__PURE__ */ i(n, {
			svg: c,
			size: 12
		})
	});
}
function d({ children: e, color: t, selected: n, onSelect: o, info: s, onRemove: c, removeLabel: l, removeClassName: u = "", className: d = "", disabled: f, ...p }) {
	let m = t ? typeof p.style == "string" ? `${p.style};--rv-choice-chip-color:${t}` : {
		...p.style,
		"--rv-choice-chip-color": t
	} : p.style;
	return !s && !c && o ? /* @__PURE__ */ i("button", {
		...p,
		style: m,
		"data-color": t ? "true" : void 0,
		type: "button",
		class: `rv-choice-chip ${d}`.trim(),
		"aria-pressed": n,
		disabled: f,
		onClick: o,
		children: e
	}) : /* @__PURE__ */ a("span", {
		class: `rv-choice-chip rv-choice-chip--composite ${d}`.trim(),
		role: p.role,
		style: m,
		"data-color": t ? "true" : void 0,
		"data-selected": n ? "true" : void 0,
		"aria-disabled": f || void 0,
		children: [
			o ? /* @__PURE__ */ i("button", {
				...p,
				type: "button",
				class: "rv-choice-chip-label",
				"aria-pressed": n,
				disabled: f,
				onClick: o,
				children: e
			}) : /* @__PURE__ */ i("span", {
				class: "rv-choice-chip-label",
				children: e
			}),
			s,
			c && /* @__PURE__ */ i(r, {
				compact: !0,
				className: u,
				disabled: typeof f == "object" ? f.value : f,
				locale: {
					title: l ?? "Remove",
					ariaLabel: l ?? "Remove"
				},
				onClick: c
			})
		]
	});
}
//#endregion
export { u as n, l as r, d as t };
