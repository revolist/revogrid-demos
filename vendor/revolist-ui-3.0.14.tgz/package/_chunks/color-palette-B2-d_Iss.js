import { n as e } from "./control-tooltip-DYksNy2m.js";
import { DEFAULT_COLOR_PALETTE_OPTIONS as t } from "../color-palette/palette.js";
import { jsx as n, jsxs as r } from "preact/jsx-runtime";
//#region src/color-palette/color-model.ts
function i(e) {
	if (!e) return;
	let t = e.trim().toLowerCase(), n = /^#([\da-f])([\da-f])([\da-f])$/i.exec(t);
	return n ? `#${n[1]}${n[1]}${n[2]}${n[2]}${n[3]}${n[3]}` : /^#[\da-f]{6}$/i.test(t) ? t : void 0;
}
function a(e) {
	if (![
		"ArrowRight",
		"ArrowDown",
		"ArrowLeft",
		"ArrowUp",
		"Home",
		"End"
	].includes(e.key)) return;
	let t = e.target, n = t.closest(".rv-color-palette"), r = Array.from(n?.querySelectorAll("button:not(:disabled)") ?? []);
	if (!r.length) return;
	let i = Math.max(0, r.indexOf(t)), a = e.key === "Home" ? 0 : e.key === "End" ? r.length - 1 : (i + (e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : -1) + r.length) % r.length;
	e.preventDefault(), r[a]?.focus();
}
//#endregion
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/check.svg?raw
var o = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 448 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M434.8 70.1c14.3 10.4 17.5 30.4 7.1 44.7l-256 352c-5.5 7.6-14 12.3-23.4 13.1s-18.5-2.7-25.1-9.3l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l101.5 101.5 234-321.7c10.4-14.3 30.4-17.5 44.7-7.1z\"/></svg>";
//#endregion
//#region src/color-palette/color-palette.tsx
function s({ value: e, options: i = t, ariaLabel: s, defaultLabel: l, colorAriaLabel: u, disabled: d = !1, includeDefault: f = !0, defaultDisabled: p = !1, onChange: m }) {
	let h = i.findIndex((t) => t.value === e && !t.disabled), g = i.findIndex((e) => !e.disabled), _ = f && !p, v = a;
	return /* @__PURE__ */ r("div", {
		class: "rv-color-palette",
		role: "radiogroup",
		"aria-label": s,
		children: [/* @__PURE__ */ n("div", {
			class: "rv-color-palette__swatches",
			children: i.map((t, r) => {
				let i = t.value === e, a = u(t);
				return /* @__PURE__ */ n(c, {
					type: "button",
					role: "radio",
					class: "rv-color-palette__swatch",
					"data-rv-color-palette-value": t.value,
					label: a,
					"aria-checked": i ? "true" : "false",
					disabled: d || t.disabled,
					tabIndex: !d && (r === h || h < 0 && (!_ || e !== null) && r === g) ? 0 : -1,
					style: { "--rv-color-palette-color": t.value },
					onKeyDown: v,
					onClick: () => m(t.value),
					children: i ? /* @__PURE__ */ n("span", {
						class: "rv-color-palette__check",
						"aria-hidden": "true",
						dangerouslySetInnerHTML: { __html: o }
					}) : null
				}, t.value);
			})
		}), f ? /* @__PURE__ */ r(c, {
			type: "button",
			role: "radio",
			class: "rv-color-palette__default",
			"data-rv-color-palette-default": "",
			"aria-checked": e === null ? "true" : "false",
			label: l,
			disabled: d || p,
			tabIndex: !d && !p && (e === null || g < 0) ? 0 : -1,
			onKeyDown: v,
			onClick: () => m(null),
			children: [e === null ? /* @__PURE__ */ n("span", {
				class: "rv-color-palette__default-check",
				"aria-hidden": "true",
				dangerouslySetInnerHTML: { __html: o }
			}) : null, /* @__PURE__ */ n("span", {
				class: "rv-color-palette__default-label",
				children: l
			})]
		}) : null]
	});
}
function c({ label: t, children: n, onKeyDown: i, disabled: a, ...o }) {
	let s = e(t, !0);
	return /* @__PURE__ */ r("button", {
		...o,
		disabled: a,
		"aria-label": t,
		...a ? {} : s.triggerProps,
		onKeyDown: (e) => {
			s.triggerProps.onKeyDown(e), e.defaultPrevented || i(e);
		},
		children: [n, s.tooltip]
	});
}
//#endregion
export { i as n, s as t };
