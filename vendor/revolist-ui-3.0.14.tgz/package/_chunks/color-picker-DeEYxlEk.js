import { createControlId as e } from "../core/control-id.js";
import { ButtonControl as t, Input as n } from "../native-control.js";
import { n as r, t as i } from "./color-palette-B2-d_Iss.js";
import { COLOR_PICKER_DEFAULT_COLOR as a } from "../color-palette/color-picker.constants.js";
import { t as o } from "./chevron-down-GbplLa6s.js";
import { jsx as s, jsxs as c } from "preact/jsx-runtime";
import { useEffect as l, useRef as u, useState as d } from "preact/hooks";
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/ban.svg?raw
var f = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M367.2 412.5L99.5 144.8c-22.4 31.4-35.5 69.8-35.5 111.2 0 106 86 192 192 192 41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3c22.4-31.4 35.5-69.8 35.5-111.2 0-106-86-192-192-192-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0z\"/></svg>", p = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M512 256c0 .9 0 1.8 0 2.7-.4 36.5-33.6 61.3-70.1 61.3L344 320c-26.5 0-48 21.5-48 48 0 3.4 .4 6.7 1 9.9 2.1 10.2 6.5 20 10.8 29.9 6.1 13.8 12.1 27.5 12.1 42 0 31.8-21.6 60.7-53.4 62-3.5 .1-7 .2-10.6 .2-141.4 0-256-114.6-256-256S114.6 0 256 0 512 114.6 512 256zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm0-96a32 32 0 1 0 0-64 32 32 0 1 0 0 64zM288 96a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm96 96a32 32 0 1 0 0-64 32 32 0 1 0 0 64z\"/></svg>";
//#endregion
//#region src/color-palette/color-picker.tsx
function m({ icon: e, className: t = "rv-format-icon rv-format-color-picker__icon" }) {
	return /* @__PURE__ */ s("span", {
		class: t,
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: e }
	});
}
function h({ label: h, value: g, defaultLabel: _, customLabel: v, customHexLabel: y, invalidColor: b, colorLabels: x, optional: S = !0, allowHexInput: C = !0, disabled: w = !1, onChange: T }) {
	let [E] = d(e), D = `rv-format-color-popover-${E}`, O = `rv-format-color-custom-${E}`, k = `rv-format-color-error-${E}`, A = `--rv-format-color-anchor-${E}`, j = u(null), [M, N] = d(!1), [P, F] = d(!1), [I, L] = d(g ?? a), [R, z] = d(!1);
	l(() => {
		L(g ?? a), z(!1);
	}, [g]);
	let B = (e) => {
		let t = r(e);
		t ? (z(!1), L(t), w || T(t)) : z(!0);
	}, V = () => j.current?.hidePopover?.();
	return l(() => {
		w && (V(), N(!1));
	}, [w]), /* @__PURE__ */ c("div", {
		class: "rv-format-color-picker",
		onKeyDownCapture: (e) => {
			e.key === "Escape" && j.current?.matches(":popover-open") && (e.preventDefault(), e.stopPropagation(), V());
		},
		children: [/* @__PURE__ */ c(t, {
			unstyled: !0,
			type: "button",
			class: "rv-format-color-picker__trigger",
			"aria-label": `${h}: ${g?.toUpperCase() ?? _}`,
			"aria-haspopup": "dialog",
			"aria-expanded": M,
			"aria-controls": D,
			title: h,
			disabled: w,
			popovertarget: D,
			style: `anchor-name: ${A}`,
			children: [
				/* @__PURE__ */ s("span", {
					class: `rv-format-color-picker__trigger-swatch${g ? "" : " rv-format-color-picker__trigger-swatch--empty"}`,
					style: g ? { backgroundColor: g } : void 0,
					children: g ? null : /* @__PURE__ */ s(m, {
						icon: f,
						className: "rv-format-color-picker__empty-icon"
					})
				}),
				/* @__PURE__ */ s("span", {
					class: "rv-format-color-picker__trigger-value",
					children: g?.toUpperCase() ?? _
				}),
				/* @__PURE__ */ s(m, { icon: o })
			]
		}), /* @__PURE__ */ c("div", {
			id: D,
			ref: j,
			class: "rv-format-color-picker__popover",
			role: "dialog",
			"aria-label": h,
			popover: "auto",
			style: `position-anchor: ${A}`,
			onToggle: (e) => N(e.currentTarget.matches(":popover-open")),
			children: [
				/* @__PURE__ */ s(i, {
					value: r(g) ?? g ?? null,
					ariaLabel: h,
					defaultLabel: _,
					colorAriaLabel: (e) => x[e.value] ?? e.label,
					includeDefault: S,
					disabled: w,
					onChange: (e) => {
						w || (T(e ?? void 0), V());
					}
				}),
				/* @__PURE__ */ c("div", {
					id: O,
					class: "rv-format-color-picker__custom-controls",
					"data-selection-only": !C || void 0,
					hidden: !P,
					children: [
						/* @__PURE__ */ s(n, {
							type: "color",
							disabled: w,
							class: "rv-format-color-picker__native",
							"aria-label": v,
							title: v,
							value: r(I) ?? a,
							onInput: (e) => B(e.currentTarget.value)
						}),
						C ? /* @__PURE__ */ s(n, {
							type: "text",
							disabled: w,
							class: "rv-control rv-format-color-picker__hex",
							inputMode: "text",
							maxLength: 7,
							"aria-label": y,
							"aria-invalid": R,
							"aria-describedby": R ? k : void 0,
							title: y,
							value: I.toUpperCase(),
							onInput: (e) => {
								L(e.currentTarget.value), R && z(!1);
							},
							onChange: (e) => B(e.currentTarget.value)
						}) : null,
						C && R ? /* @__PURE__ */ s("span", {
							id: k,
							class: "rv-format-color-picker__error",
							role: "alert",
							children: b
						}) : null
					]
				}),
				/* @__PURE__ */ c(t, {
					unstyled: !0,
					type: "button",
					class: "rv-format-color-picker__custom-action",
					disabled: w,
					"aria-expanded": P,
					"aria-controls": O,
					title: v,
					onClick: () => F((e) => !e),
					children: [/* @__PURE__ */ s(m, { icon: p }), v]
				})
			]
		})]
	});
}
//#endregion
export { h as t };
