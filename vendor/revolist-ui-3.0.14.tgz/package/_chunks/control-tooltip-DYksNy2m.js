import { calculateAnchoredPopoverPosition as e } from "../core/anchored-popover.js";
import { hideTopLayerPopup as t, showTopLayerPopup as n } from "../core/top-layer-popup.js";
import { createControlId as r } from "../core/control-id.js";
import { jsx as i } from "preact/jsx-runtime";
import { useCallback as a, useLayoutEffect as o, useRef as s, useState as c } from "preact/hooks";
//#region src/formatting/control-tooltip.tsx
var l = /* @__PURE__ */ new WeakMap();
function u(e, t = !1, n) {
	let [u] = c(() => r("rv-format-control-tooltip")), [f, p] = c(!1), m = s(null), h = s(!1), g = a(() => {
		let e = m.current?.ownerDocument;
		e && l.get(e) === g && l.delete(e), p(!1);
	}, []), _ = (e) => {
		m.current = e;
		let t = e.ownerDocument, n = l.get(t);
		n !== g && n?.(), l.set(t, g), p(!0);
	};
	return o(() => {
		if (!f) return;
		let e = m.current?.ownerDocument;
		if (!e) return;
		let t = e.defaultView, n = m.current?.closest("[popover]"), r = () => {
			n?.matches(":popover-open") || g();
		}, i = (e) => {
			m.current?.contains(e.target) || g();
		};
		return e.addEventListener("pointerdown", i, !0), e.addEventListener("scroll", g, !0), e.addEventListener("visibilitychange", g), t?.addEventListener("resize", g), t?.addEventListener("blur", g), n?.addEventListener("toggle", r), () => {
			e.removeEventListener("pointerdown", i, !0), e.removeEventListener("scroll", g, !0), e.removeEventListener("visibilitychange", g), t?.removeEventListener("resize", g), t?.removeEventListener("blur", g), n?.removeEventListener("toggle", r);
		};
	}, [f, g]), o(() => () => {
		let e = m.current?.ownerDocument;
		e && l.get(e) === g && l.delete(e);
	}, [g]), {
		id: u,
		triggerProps: {
			"aria-describedby": u,
			onFocus: (e) => {
				m.current = e.currentTarget, h.current || _(e.currentTarget);
			},
			onBlur: () => {
				h.current = !1, g();
			},
			onMouseEnter: (e) => _(e.currentTarget),
			onMouseLeave: g,
			onPointerDown: (e) => {
				m.current = e.currentTarget, h.current = !0, g();
			},
			onPointerCancel: g,
			onKeyDown: (e) => {
				e.key === "Escape" && f ? (e.preventDefault(), e.stopPropagation(), g()) : (e.key === "Enter" || e.key === " ") && g();
			}
		},
		tooltip: /* @__PURE__ */ i(d, {
			id: u,
			text: e,
			visible: f,
			anchor: t ? m.current : null,
			className: n?.className,
			placement: n?.placement
		})
	};
}
function d({ id: r, text: a, visible: c, anchor: l = null, className: u = "rv-format-control-tooltip", placement: d }) {
	let f = s(null);
	return o(() => {
		let r = f.current;
		if (!c || !l || !r) return;
		let i = n(r, "block"), a = l.ownerDocument.defaultView, o = e(l.getBoundingClientRect(), r.getBoundingClientRect(), {
			width: a?.innerWidth ?? 0,
			height: a?.innerHeight ?? 0
		}), s = l.getBoundingClientRect(), u = r.getBoundingClientRect(), p = s.top - u.height - 8;
		return Object.assign(r.style, {
			left: `${d === "above" ? Math.max(8, Math.min(s.left + (s.width - u.width) / 2, (a?.innerWidth ?? 0) - u.width - 8)) : o.left}px`,
			top: `${d === "above" && p >= 8 ? p : o.top}px`
		}), () => t(r, i);
	}, [
		c,
		l,
		d
	]), /* @__PURE__ */ i("span", {
		ref: f,
		id: r,
		class: u,
		role: "tooltip",
		"data-visible": c,
		style: l ? {
			position: "fixed",
			inset: "auto",
			margin: 0,
			transform: "none",
			positionAnchor: "auto",
			positionArea: "none",
			display: c ? "block" : "none",
			visibility: c ? "visible" : "hidden"
		} : void 0,
		children: a
	});
}
//#endregion
export { u as n, d as t };
