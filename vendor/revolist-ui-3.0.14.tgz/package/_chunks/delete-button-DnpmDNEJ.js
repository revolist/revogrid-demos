import { jsx as e } from "preact/jsx-runtime";
//#region src/icons/cancel.svg?raw
var t = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 384 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path fill=\"currentColor\" d=\"M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z\"/></svg>", n = ({ onClick: n, disabled: r, className: i, onMouseDown: a, onDblClick: o, locale: s = {
	title: "Remove",
	ariaLabel: "Remove"
} }) => /* @__PURE__ */ e("button", {
	onMouseDown: a,
	onDblClick: o,
	onClick: n,
	disabled: r,
	type: "button",
	title: s.title,
	"aria-label": s.ariaLabel,
	className: `rounded-lg flex focus:outline-none remove-btn rv-chip-remove${i ? ` ${i}` : ""}`,
	dangerouslySetInnerHTML: { __html: t }
});
//#endregion
export { t as n, n as t };
