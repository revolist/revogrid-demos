import { createPreactElement as e, releasePreactElement as t } from "../preact-mount.js";
import { ButtonControl as n, Input as r } from "../native-control.js";
import { t as i } from "./xmark-DD_PBvZI.js";
import { h as a } from "preact";
import { forwardRef as o } from "preact/compat";
import { Fragment as s, jsx as c, jsxs as l } from "preact/jsx-runtime";
//#region src/dialog/dialog-action-footer.view.tsx
function u({ cancel: e = {}, save: t = {}, deleteAction: r = !1, reset: i = !1, start: a, end: o, children: s, actionsClass: u = "", class: d = "", ...f }) {
	let p = (e, t, r, i = "", a = "button") => {
		if (t === !1) return null;
		let { label: o = r, class: s = "", ...l } = t;
		return /* @__PURE__ */ c(n, {
			type: a,
			...l,
			class: `rv-btn ${i} ${s}`,
			"data-dialog-action": e,
			children: o
		});
	};
	return /* @__PURE__ */ l("footer", {
		...f,
		class: `rv-dialog__footer rv-dialog__action-footer ${d}`,
		children: [s, /* @__PURE__ */ l("div", {
			class: "rv-dialog__action-panel",
			children: [/* @__PURE__ */ l("div", {
				class: "rv-dialog__action-start",
				children: [
					a,
					p("delete", r, "Delete", "rv-btn-danger-outline"),
					p("reset", i, "Reset")
				]
			}), /* @__PURE__ */ l("div", {
				class: `rv-dialog__actions ${u}`,
				children: [
					o,
					p("cancel", e, "Cancel"),
					p("save", t, "Save", "rv-btn-primary", "submit")
				]
			})]
		})]
	});
}
function d(e, t) {
	return /* @__PURE__ */ c(u, { ...t });
}
function f(n, r) {
	let i = e(n.ownerDocument, /* @__PURE__ */ c(u, { ...r }));
	return n.append(i), { destroy() {
		t(i);
	} };
}
//#endregion
//#region src/dialog/dialog.parts.tsx
var p = o(({ class: e = "", ...t }, n) => /* @__PURE__ */ c("header", {
	...t,
	ref: n,
	class: `rv-dialog__header ${e}`
}));
function m({ class: e = "", ...t }) {
	return /* @__PURE__ */ c("form", {
		...t,
		class: `rv-dialog__surface ${e}`
	});
}
var h = o(({ class: e = "", ...t }, n) => /* @__PURE__ */ c("div", {
	...t,
	ref: n,
	class: `rv-dialog__body ${e}`
})), g = o(({ class: e = "", ...t }, n) => /* @__PURE__ */ c("footer", {
	...t,
	ref: n,
	class: `rv-dialog__footer ${e}`
})), _ = o(({ class: e = "", ...t }, n) => /* @__PURE__ */ c("div", {
	...t,
	ref: n,
	class: `rv-dialog__actions ${e}`
}));
function v({ class: e = "", iconClass: t = "", ...r }) {
	return /* @__PURE__ */ c(n, {
		...r,
		type: "button",
		class: `rv-dialog__close ${e}`,
		children: /* @__PURE__ */ c("span", {
			class: `rv-dialog__close-icon ${t}`,
			"aria-hidden": "true",
			dangerouslySetInnerHTML: { __html: i }
		})
	});
}
var y = o(({ class: e = "", ...t }, n) => /* @__PURE__ */ c(r, {
	...t,
	ref: n,
	class: `rv-dialog__title-input ${e}`
})), b = o(({ titleId: e, title: t, name: n, description: r, inputLabel: i, titleHidden: a, headingClass: o = "", kickerClass: u = "", titleClass: d = "", inputProps: f, closeLabel: m, closeProps: h, onClose: g, class: _ = "", ...b }, x) => /* @__PURE__ */ l(p, {
	...b,
	ref: x,
	class: `rv-dialog__header--editable ${_}`,
	children: [/* @__PURE__ */ l("div", {
		class: `rv-dialog__heading ${o}`,
		children: [
			!a && n && /* @__PURE__ */ c("span", {
				class: `rv-dialog__kicker ${u}`,
				children: n
			}),
			!a && (f === !1 ? /* @__PURE__ */ c("h3", {
				id: e,
				class: `rv-dialog__title ${d}`,
				children: t
			}) : /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("h3", {
				id: e,
				class: `rv-dialog__sr-only ${d}`,
				children: t
			}), /* @__PURE__ */ c(y, {
				"aria-label": i,
				value: t,
				...f
			})] })),
			r && /* @__PURE__ */ c("div", {
				class: "rv-dialog__description",
				children: r
			})
		]
	}), g && /* @__PURE__ */ c(v, {
		...h,
		"aria-label": m,
		onClick: g
	})]
}));
function x(e) {
	return d(a, e);
}
//#endregion
export { g as a, y as c, f as d, d as f, v as i, b as l, _ as n, m as o, h as r, p as s, x as t, u };
