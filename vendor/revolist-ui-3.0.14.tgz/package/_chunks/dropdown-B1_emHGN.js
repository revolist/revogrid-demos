import { t as e } from "./chevron-down-GbplLa6s.js";
import { RemoveButton as t } from "../buttons/remove-button.js";
import { DropdownPopup as n } from "../dropdown/popup.js";
import { DropdownPopupContent as r } from "../dropdown/content.js";
import { h as i, render as a } from "preact";
import { jsx as o, jsxs as s } from "preact/jsx-runtime";
import { useEffect as c, useLayoutEffect as l, useMemo as u, useRef as d, useState as f } from "preact/hooks";
//#region src/dropdown/remote.ts
var p = {
	loading: "Loading…",
	empty: "No results found",
	error: "Unable to load options.",
	retry: "Retry",
	loadMore: "Load more",
	unavailable: (e) => `Unavailable (${String(e)})`
}, m = class {
	source;
	context;
	changed;
	text;
	settings;
	cache = /* @__PURE__ */ new Map();
	ids = [];
	items = [];
	query = "";
	cursor;
	seen = /* @__PURE__ */ new Set();
	searchAbort;
	resolveAbort;
	timer;
	generation = 0;
	resolution = 0;
	disposed = !1;
	loading = !1;
	searchFailed = !1;
	failedCursor;
	resolveFailed = !1;
	opened = !1;
	constructor(e, t, n, r = p, i = {}) {
		this.source = e, this.context = t, this.changed = n, this.text = r, this.settings = i;
	}
	remember(e) {
		for (let t of e) {
			if (typeof t.value != "string" && (typeof t.value != "number" || !Number.isFinite(t.value))) throw TypeError("Remote dropdown values must be finite numeric or string IDs.");
			this.cache.set(t.value, t);
		}
	}
	emit() {
		this.disposed || this.changed({
			items: [...this.items],
			selected: this.ids.map((e) => this.cache.get(e) ?? {
				value: e,
				label: this.text.unavailable(e),
				unresolved: !0
			}),
			loading: this.loading,
			error: this.searchFailed || this.resolveFailed,
			hasMore: this.cursor !== void 0
		});
	}
	setSelected(e, t = []) {
		this.remember(t), this.ids = [...new Set(e)], this.resolveAbort?.abort();
		let n = ++this.resolution, r = this.ids.filter((e) => !this.cache.has(e));
		if (this.resolveFailed = !1, this.emit(), !r.length || this.disposed) return;
		let i = this.resolveAbort = new AbortController();
		Promise.resolve().then(() => this.source.resolve({
			ids: r,
			signal: i.signal,
			context: this.context
		})).then((e) => {
			this.disposed || i.signal.aborted || n !== this.resolution || (this.remember(e), this.emit());
		}).catch(() => {
			this.disposed || i.signal.aborted || n !== this.resolution || (this.resolveFailed = !0, this.emit());
		});
	}
	search(e, t = !1) {
		this.disposed || (this.opened = !0, this.query = e, this.searchAbort?.abort(), clearTimeout(this.timer), ++this.generation, this.items = [], this.cursor = void 0, this.seen.clear(), this.loading = !0, this.searchFailed = !1, this.emit(), t ? this.page(void 0, this.generation) : this.timer = setTimeout(() => void this.page(void 0, this.generation), this.settings.debounceMs ?? 200));
	}
	async page(e, t) {
		if (this.disposed || t !== this.generation || this.seen.has(e)) return;
		this.seen.add(e), this.loading = !0, this.searchFailed = !1, this.emit();
		let n = this.searchAbort = new AbortController();
		try {
			let r = await this.source.search({
				query: this.query,
				cursor: e,
				pageSize: this.settings.pageSize ?? 50,
				signal: n.signal,
				context: this.context
			});
			if (this.disposed || n.signal.aborted || t !== this.generation) return;
			this.remember(r.items);
			let i = new Map(this.items.map((e) => [e.value, e]));
			r.items.forEach((e) => i.set(e.value, e)), this.items = [...i.values()], this.cursor = r.nextCursor ?? void 0, this.seen.has(this.cursor) && (this.cursor = void 0);
		} catch {
			if (this.disposed || n.signal.aborted || t !== this.generation) return;
			this.seen.delete(e), this.failedCursor = e, this.searchFailed = !0;
		} finally {
			!this.disposed && !n.signal.aborted && t === this.generation && (this.loading = !1, this.emit());
		}
	}
	loadMore() {
		!this.loading && !this.searchFailed && this.cursor !== void 0 && this.page(this.cursor, this.generation);
	}
	retry() {
		this.resolveFailed && this.setSelected(this.ids), this.searchFailed && this.opened && this.page(this.failedCursor, this.generation);
	}
	close() {
		this.opened = !1, this.searchAbort?.abort(), clearTimeout(this.timer), ++this.generation, this.loading = !1, this.emit();
	}
	destroy() {
		this.disposed = !0, this.close(), this.resolveAbort?.abort(), ++this.resolution;
	}
};
//#endregion
//#region src/dropdown/remote-hook.ts
function ee(e) {
	let t = u(() => ({
		...p,
		...e.remoteText
	}), [e.remoteText]), [n, r] = f({
		items: [],
		selected: [],
		loading: !1,
		error: !1,
		hasMore: !1
	}), i = d(), a = e.value === null || e.value === void 0 ? [] : Array.isArray(e.value) ? e.value : [e.value], o = JSON.stringify(a);
	return l(() => {
		if (!e.dataSource || e.disabled) {
			r({
				items: [],
				selected: [],
				loading: !1,
				error: !1,
				hasMore: !1
			});
			return;
		}
		let n = new m(e.dataSource, e.dataContext, r, t);
		return i.current = n, () => {
			n.destroy(), i.current === n && (i.current = void 0);
		};
	}, [
		e.dataSource,
		e.dataContext,
		e.disabled,
		t
	]), l(() => {
		i.current?.setSelected(a, e.source);
	}, [
		o,
		e.source,
		e.dataSource,
		e.dataContext,
		e.disabled,
		t
	]), c(() => {
		e.open ? i.current?.search(e.initialQuery, !0) : i.current?.close();
	}, [
		e.open,
		e.dataSource,
		e.dataContext,
		e.disabled,
		e.initialQuery,
		t
	]), {
		...n,
		text: t,
		search: (e) => i.current?.search(e),
		loadMore: () => i.current?.loadMore(),
		retry: () => i.current?.retry()
	};
}
//#endregion
//#region src/dropdown/index.tsx
var te = ({ options: e, className: t, renderValue: n }) => /* @__PURE__ */ o("span", {
	className: `selected-value ${t}`,
	children: n ? n(i, e[0]) : e[0].label
}), ne = ({ options: e, removeOption: n, className: r, renderValue: a, disabled: c, removeLabel: l }) => /* @__PURE__ */ o("div", {
	className: `selected-values ${r}`,
	children: e.map((e, r) => /* @__PURE__ */ s("span", {
		className: "selected-tag",
		children: [a ? a(i, e) : e.label, !c && !e.disabled && /* @__PURE__ */ o(t, {
			compact: !0,
			onClick: (t) => {
				t.stopPropagation(), n(e);
			},
			locale: {
				title: l?.(e.label) ?? `Remove ${e.label}`,
				ariaLabel: l?.(e.label) ?? `Remove ${e.label}`
			}
		})]
	}, r))
}), h = ({ className: t }) => /* @__PURE__ */ o("span", {
	className: `dropdown-arrow ${t}`,
	"aria-hidden": "true",
	dangerouslySetInnerHTML: { __html: e }
}), re = ({ placeholder: e, className: t }) => [/* @__PURE__ */ o("span", {
	className: `placeholder px-2 ${t}`,
	children: e
}), /* @__PURE__ */ o(h, { className: "mr-2" })];
function g({ source: e, dataSource: t, dataContext: a, remoteText: l, value: p, onChange: m, placeholder: g = "Select an option", disabled: _ = !1, name: v, id: y, className: ie = "", style: ae, config: b = {}, renderContent: x, renderOption: oe, renderValue: S, renderPlaceholder: C, renderSelectedValue: w, renderNoResults: se, onClose: T, beforeOutsideClose: E, environment: D }) {
	let { search: O = !1, searchPlaceholder: k = "Search...", closeOnClickOutside: A = !0, autoOpen: j = !1, multiSelect: M = !1, portalTarget: N, ariaLabel: P, ariaLabelledBy: F, ariaDescribedBy: I, popupClassName: L, maxHeight: R } = b, z = d(null), B = N ?? (b.topLayer ? z.current?.closest("revo-grid") : void 0) ?? (typeof document < "u" ? document.body : null), V = u(() => y || `dropdown-${Math.random().toString(36).substring(2, 9)}`, [y]), H = `${V}-listbox`, ce = `${V}-search`, U = `${V}-menu`, [W, G] = f(j && !_), [le, K] = f(!_ && (j || !!b.autoFocus)), q = d(j), J = b.theme ?? "default";
	c(() => {
		j && !q.current && !_ && (K(!0), G(!0)), q.current = j;
	}, [j, _]), c(() => {
		_ && W && (G(!1), T?.(!1));
	}, [_, W]);
	let Y = ee({
		dataSource: t,
		dataContext: a,
		remoteText: l,
		value: p,
		disabled: _,
		source: e,
		open: W,
		initialQuery: b.initialSearch ?? ""
	}), X = t ? [...new Map([...Y.selected, ...Y.items].map((e) => [e.value, e])).values()] : e, Z = u(() => {
		if (p === void 0) return [];
		if (M && Array.isArray(p)) return X.filter((e) => p.some((t) => JSON.stringify(t) === JSON.stringify(e.value)));
		{
			let e = X.find((e) => JSON.stringify(e.value) === JSON.stringify(p));
			return e ? [e] : [];
		}
	}, [
		p,
		X,
		M
	]), Q = () => {
		_ || G((e) => {
			let t = !e;
			return t && K(!0), t;
		});
	}, $ = (e = !1) => {
		G((t) => (t && T?.(e), !1));
	};
	c(() => {
		if (!W) return;
		let e = z.current;
		if (e) return D?.onOpen?.(e, $);
	}, [W]);
	let ue = (e) => {
		if (!(_ || e.disabled)) {
			if (M) {
				let t = Z.some((t) => JSON.stringify(t.value) === JSON.stringify(e.value)), n;
				n = t ? Z.filter((t) => JSON.stringify(t.value) !== JSON.stringify(e.value)) : [...Z, e], m && m(n.map((e) => e.value));
			} else m && m(e.value), $();
		}
	};
	return c(() => {
		if (!A || !W) return;
		let e = B?.ownerDocument ?? z.current?.ownerDocument ?? (typeof document < "u" ? document : void 0);
		if (!e) return;
		let t = (t) => {
			let n = e.getElementById(U), r = t.target;
			if (n && r && !n.contains(r) && z.current && !z.current.contains(r)) {
				if (E?.() === !1) {
					t.preventDefault(), t.stopImmediatePropagation();
					return;
				}
				$();
			}
		}, n = !!E;
		return e.addEventListener("pointerdown", t, n), () => {
			e.removeEventListener("pointerdown", t, n);
		};
	}, [
		A,
		W,
		U,
		B,
		E
	]), /* @__PURE__ */ s("div", {
		className: `dropdown-container ${ie} ${_ ? "disabled" : ""}`,
		style: ae,
		children: [
			/* @__PURE__ */ o("div", {
				ref: z,
				className: `dropdown-trigger ${W ? "open" : ""}`,
				role: "combobox",
				"aria-haspopup": x ? "dialog" : "listbox",
				"aria-expanded": W && !_,
				"aria-disabled": _,
				"aria-owns": H,
				"aria-controls": H,
				"aria-label": P,
				"aria-labelledby": F,
				"aria-describedby": I,
				tabIndex: _ ? -1 : 0,
				onClick: _ ? void 0 : Q,
				onKeyDown: (e) => {
					_ || e.target !== e.currentTarget || (W && e.key === "Escape" ? (e.preventDefault(), e.stopPropagation(), $()) : !W && (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") && (e.preventDefault(), e.stopPropagation(), Q()));
				},
				children: (() => {
					let e = [h({})];
					return w ? w(i, Z, e) : Z.length > 0 ? M ? [/* @__PURE__ */ o(ne, {
						options: Z,
						removeOption: ue,
						renderValue: S,
						disabled: _,
						removeLabel: b.removeLabel
					}), /* @__PURE__ */ o(h, { className: "mr-2" })] : [/* @__PURE__ */ o(te, {
						options: Z,
						renderValue: S
					}), /* @__PURE__ */ o(h, { className: "mr-2" })] : C ? C(i, g, e) : /* @__PURE__ */ o(re, { placeholder: g });
				})()
			}),
			W && !_ && /* @__PURE__ */ o(n, {
				onPointerRelease: D?.onPointerRelease,
				topLayer: b.topLayer,
				triggerRef: z,
				portalTarget: B,
				theme: J,
				dropdownMenuId: U,
				popupClassName: L,
				maxHeight: R,
				children: x ? x({
					id: H,
					close: $
				}) : /* @__PURE__ */ o(r, {
					options: t ? Y.items : X,
					selectedValues: t ? Y.selected : void 0,
					remote: t ? Y : void 0,
					value: p,
					onChange: (e) => {
						_ || m?.(e);
					},
					config: {
						...b,
						autoFocus: b.autoFocus || le
					},
					multiSelect: M,
					search: !!t || O,
					searchPlaceholder: k,
					listboxId: H,
					searchId: ce,
					renderOption: oe,
					renderNoResults: se,
					onClose: $,
					theme: J
				})
			}),
			v && /* @__PURE__ */ o("input", {
				type: "hidden",
				name: v,
				value: JSON.stringify(M ? Z.map((e) => e.value) : Z[0]?.value || "")
			})
		]
	});
}
var _ = (e, t) => {
	a(/* @__PURE__ */ o(g, { ...t }), e);
}, v = (e) => {
	a(null, e);
};
//#endregion
export { _ as n, v as r, g as t };
