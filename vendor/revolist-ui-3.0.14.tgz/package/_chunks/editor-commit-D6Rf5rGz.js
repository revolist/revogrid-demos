import { createContext as e } from "preact";
import { useContext as t, useLayoutEffect as n, useRef as r } from "preact/hooks";
//#region src/core/editor-commit.tsx
var i = e(void 0);
function a(e, a = !0) {
	let o = t(i), s = r(e);
	s.current = e, n(() => {
		if (a) return o?.(() => s.current());
	}, [o, a]);
}
//#endregion
export { a as n, i as t };
