import { calculateAnchoredPopoverPosition as e } from "../core/anchored-popover.js";
import { hideTopLayerPopup as t, showTopLayerPopup as n } from "../core/top-layer-popup.js";
import { createPreactElement as r, releasePreactElement as i } from "../preact-mount.js";
import { t as a } from "./editor-commit-D6Rf5rGz.js";
import { jsx as o } from "preact/jsx-runtime";
//#region src/core/editor-popup-position.ts
function s(t, n, r, i = 4, a = 8) {
	let o = Math.max(0, r.height - a - t.bottom - i), s = Math.max(0, t.top - a - i), c = n.height <= o || o >= s ? "below" : "above", l = c === "below" ? o : s, u = Math.min(n.height, l);
	return {
		...e(t, n, r, i, a),
		placementY: c,
		maxHeight: l,
		top: c === "below" ? t.bottom + i : t.top - u - i
	};
}
//#endregion
//#region src/core/editor-popup.tsx
var c = /* @__PURE__ */ new WeakMap();
function l(e, l, u) {
	let d = e.ownerDocument, f = d.defaultView;
	c.get(d)?.close();
	let p = !1, m, h = (e) => (m = e, () => {
		m === e && (m = void 0);
	}), g = () => {
		p || (p = !0, T.disconnect(), w?.disconnect(), d.removeEventListener("pointerdown", v, !0), d.removeEventListener("keydown", y, !0), d.removeEventListener("scroll", b, !0), f.removeEventListener("resize", g), t(x, S), i(x), x.remove(), c.get(d)?.element === x && c.delete(d), u.onClose?.(), e.isConnected && e.focus({ preventScroll: !0 }));
	}, _ = (e) => e ? x.contains(e) ? !0 : [...x.querySelectorAll("[aria-controls]")].some((t) => t.getAttribute("aria-controls")?.split(" ").some((t) => d.getElementById(t)?.contains(e))) : !1, v = (t) => {
		_(t.target) || e.contains(t.target) || (u.isAvailable && !u.isAvailable() ? g() : m?.() === !1 ? (t.preventDefault(), t.stopPropagation()) : g());
	}, y = (e) => {
		if (e.key === "Escape") {
			if (x.querySelector("[aria-expanded=\"true\"]")) return;
			e.preventDefault(), e.stopPropagation(), g();
		}
		if (e.key === "Tab" && x.contains(e.target)) {
			let t = [...x.querySelectorAll("button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),[contenteditable=\"true\"],[tabindex=\"0\"]")].filter((e) => e.tabIndex >= 0 && e.getClientRects().length), n = t[0], r = t.at(-1);
			e.shiftKey && d.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && d.activeElement === r && (e.preventDefault(), n?.focus());
		}
	}, b = (t) => {
		let n = t.target;
		_(n) || (n && (n.contains(e) || E?.contains(n)) ? C() : g());
	}, x = r(d, /* @__PURE__ */ o("div", {
		class: `rv-editor-popup ${u.className ?? ""}`,
		role: "dialog",
		"aria-label": u.label,
		onKeyDown: (e) => e.stopPropagation(),
		onKeyUp: (e) => e.stopPropagation(),
		onMouseDown: (e) => e.stopPropagation(),
		onClick: (e) => e.stopPropagation(),
		children: /* @__PURE__ */ o(a.Provider, {
			value: h,
			children: l(g)
		})
	}));
	(e.closest("dialog, [role=\"dialog\"], [role=\"menu\"]") ?? e.closest("revo-grid") ?? d.body).append(x);
	let S = n(x, "block"), C = () => {
		x.style.maxHeight = "";
		let t = s(e.getBoundingClientRect(), x.getBoundingClientRect(), {
			width: f.innerWidth,
			height: f.innerHeight
		});
		x.style.maxHeight = `${t.maxHeight}px`, x.style.left = `${t.left}px`, x.style.top = `${t.top}px`, x.dataset.placement = t.placementY;
	};
	C();
	let w = typeof f.ResizeObserver == "function" ? new f.ResizeObserver(C) : void 0;
	w?.observe(x), w?.observe(e);
	let T = new MutationObserver(() => {
		(!e.isConnected || !x.isConnected || u.isAvailable && !u.isAvailable()) && g();
	});
	T.observe(d.body, {
		childList: !0,
		subtree: !0
	});
	let E = e.closest("revo-grid");
	E && u.isAvailable && T.observe(E, { attributes: !0 }), d.addEventListener("pointerdown", v, !0), d.addEventListener("keydown", y, !0), d.addEventListener("scroll", b, !0), f.addEventListener("resize", g);
	let D = {
		element: x,
		close: g
	};
	return c.set(d, D), x.querySelector("[autofocus],input,textarea,button,[tabindex=\"0\"]")?.focus({ preventScroll: !0 }), D;
}
//#endregion
export { l as t };
