import { t as e } from "./chevron-down-GbplLa6s.js";
import { t } from "./icons-Ci5mADVc.js";
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/chevron-up.svg?raw
var n = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 448 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M201.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L224 173.3 54.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z\"/></svg>";
//#endregion
//#region src/status-feedback/header.ts
function r(e) {
	let t = e.some((e) => e.tone === "danger") ? "danger" : e.some((e) => e.tone === "warning") ? "warning" : "neutral";
	return {
		tone: t,
		busy: t === "neutral" && e.some((e) => e.busy)
	};
}
function i(i, a, o, s, c) {
	let { title: l, items: u, localeText: d, popover: f } = a, p = o ? a.expandLabel ?? d?.expand ?? "Expand activity" : a.collapseLabel ?? d?.collapse ?? "Collapse activity", m = r(u);
	return i("div", {
		class: "rv-status-feedback__header",
		"aria-live": o ? "polite" : void 0,
		"aria-atomic": o ? "true" : void 0
	}, [
		o ? t(i, m.tone, m.busy) : null,
		i("h3", { class: "rv-status-feedback__heading" }, l),
		i("span", {
			class: "rv-count rv-status-feedback__count",
			"aria-label": d?.countLabel?.(u.length),
			"aria-hidden": !o && !d?.countLabel ? "true" : void 0
		}, d?.formatCount?.(u.length) ?? String(u.length)),
		s ? i("button", {
			type: "button",
			class: "rv-btn-ghost rv-status-feedback__toggle",
			"aria-label": p,
			title: p,
			"aria-expanded": String(!o),
			"aria-controls": f ? `${f.id}-items` : void 0,
			onClick: (e) => {
				e.stopPropagation(), c(!o, e);
			}
		}, i("span", {
			class: "rv-status-feedback__icon",
			"aria-hidden": "true",
			innerHTML: o ? n : e
		})) : null
	]);
}
//#endregion
export { i as t };
