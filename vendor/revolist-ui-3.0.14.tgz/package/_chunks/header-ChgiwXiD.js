import { t as e } from "./chevron-right-sxHQMSkq.js";
import { jsx as t, jsxs as n } from "preact/jsx-runtime";
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/chevron-left.svg?raw
var r = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z\"/></svg>";
//#endregion
//#region src/calendar/header.tsx
function i({ label: i, previousLabel: a, nextLabel: o, labelAction: s, caption: c, showLabel: l = !0, showPrevious: u = !0, showNext: d = !0, previousDisabled: f = !1, nextDisabled: p = !1, onPrevious: m, onNext: h }) {
	return /* @__PURE__ */ n("header", {
		class: "revo-calendar__header",
		children: [
			u ? /* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": a,
				disabled: f,
				onClick: m,
				children: /* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					dangerouslySetInnerHTML: { __html: r }
				})
			}) : /* @__PURE__ */ t("span", { "aria-hidden": "true" }),
			l && c ? c : l && s ? /* @__PURE__ */ t("button", {
				type: "button",
				class: "revo-calendar__month-label revo-calendar__month-label-button",
				"aria-label": s.ariaLabel,
				onClick: s.onClick,
				children: /* @__PURE__ */ t("span", {
					"aria-live": "polite",
					children: i
				})
			}) : l ? /* @__PURE__ */ t("strong", {
				class: "revo-calendar__month-label",
				"aria-live": "polite",
				children: i
			}) : /* @__PURE__ */ t("span", { "aria-hidden": "true" }),
			d ? /* @__PURE__ */ t("button", {
				type: "button",
				"aria-label": o,
				disabled: p,
				onClick: h,
				children: /* @__PURE__ */ t("span", {
					"aria-hidden": "true",
					dangerouslySetInnerHTML: { __html: e }
				})
			}) : /* @__PURE__ */ t("span", { "aria-hidden": "true" })
		]
	});
}
function a({ dates: e, locale: r, format: i, weekNumberLabel: a }) {
	return /* @__PURE__ */ n("div", {
		class: "revo-calendar__weekdays",
		role: "row",
		children: [a && /* @__PURE__ */ t("span", {
			role: "columnheader",
			"aria-label": a,
			children: "#"
		}), e.map((e) => /* @__PURE__ */ t("span", {
			role: "columnheader",
			children: i(e, r)
		}, e))]
	});
}
//#endregion
export { a as n, i as t };
