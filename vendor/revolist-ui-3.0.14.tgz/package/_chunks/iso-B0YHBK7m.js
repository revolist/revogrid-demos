//#region ../dates/src/iso.ts
var e = /^\d{4}-\d{2}-\d{2}$/, t = /^\d{4}-\d{2}-\d{2}T/;
function n(t) {
	return e.test(t) ? /* @__PURE__ */ new Date(`${t}T00:00:00Z`) : new Date(t);
}
function r(e) {
	return t.test(e);
}
function i(e) {
	return (typeof e == "string" ? n(e) : e).getUTCDay();
}
function a(e) {
	return e.toISOString().slice(0, 10);
}
var o = /* @__PURE__ */ new Map();
function s(e, t) {
	let n = o.get(t);
	n || (n = new Intl.DateTimeFormat("en-US", {
		timeZone: t,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}), o.set(t, n));
	let r = new Map(n.formatToParts(e).map((e) => [e.type, e.value]));
	return `${r.get("year").padStart(4, "0")}-${r.get("month")}-${r.get("day")}`;
}
function c(e) {
	let t = /* @__PURE__ */ new Date(0);
	return t.setUTCFullYear(e.getFullYear(), e.getMonth(), e.getDate()), t.setUTCHours(0, 0, 0, 0), a(t);
}
function l(e) {
	return e.toISOString();
}
function u(t) {
	if (!t || !e.test(t)) return !1;
	let r = n(t);
	return Number.isFinite(r.getTime()) && a(r) === t;
}
//#endregion
export { i as a, n as c, c as i, s as n, r as o, l as r, u as s, a as t };
