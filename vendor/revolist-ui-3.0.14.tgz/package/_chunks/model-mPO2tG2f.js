import { a as e, c as t, o as n, r, t as i } from "./iso-B0YHBK7m.js";
var a = 864e5;
function o(e, o) {
	let s = t(e);
	return s.setTime(s.getTime() + o * a), n(e) ? r(s) : i(s);
}
function s(e, n) {
	return Math.round((t(n).getTime() - t(e).getTime()) / a);
}
function c(e, n) {
	return t(e).getTime() - t(n).getTime();
}
function l() {
	return i(/* @__PURE__ */ new Date());
}
//#endregion
//#region ../dates/src/display-calendar.ts
var u = /* @__PURE__ */ new Map();
function d(e, t, n) {
	let r = JSON.stringify([
		e,
		t,
		n
	]), i = u.get(r);
	if (!i) {
		if (i = new Intl.DateTimeFormat(e, {
			...n,
			calendar: t,
			timeZone: "UTC"
		}), i.resolvedOptions().calendar !== t) throw RangeError(`Unsupported calendar: ${t}`);
		u.set(r, i);
	}
	return i;
}
function f(e, n, r, i = "gregory") {
	return d(n, i, r).format(t(e));
}
function p(e, n = "gregory") {
	if (n === "gregory") {
		let n = t(e);
		return {
			year: n.getUTCFullYear(),
			month: n.getUTCMonth() + 1,
			day: n.getUTCDate()
		};
	}
	let r = d("en-US-u-nu-latn", n, {
		year: "numeric",
		month: "numeric",
		day: "numeric"
	}).formatToParts(t(e)), i = (e) => Number(r.find((t) => t.type === e)?.value);
	return {
		year: i("year"),
		month: i("month"),
		day: i("day")
	};
}
function m(e, t = "gregory") {
	return o(e, 1 - p(e, t).day);
}
function h(e, t, n = "gregory", r = !1) {
	if (!Number.isInteger(t) || Math.abs(t) > 12e3) throw RangeError("Month offset must be an integer within 12000 months.");
	let i = m(e, n);
	for (let e = 0; e < Math.abs(t); e++) i = m(o(i, t > 0 ? 32 : -1), n);
	if (!r) return i;
	let a = s(i, m(o(i, 32), n));
	return o(i, Math.min(p(e, n).day, a) - 1);
}
function g(e, t = "gregory") {
	return o(h(e, 1, t), -1);
}
function _(e, t = "gregory") {
	let n = h(e, 1 - p(e, t).month, t);
	return Array.from({ length: 12 }, (e, r) => h(n, r, t));
}
function v(t, n = 1, r = 4, i = "gregory") {
	let a = (t) => {
		let i = o(t, r - 1);
		return o(i, -((e(i) - n + 7) % 7));
	}, c = _(t, i)[0];
	return t < a(c) ? c = h(c, -12, i) : t >= a(h(c, 12, i)) && (c = h(c, 12, i)), Math.floor(s(a(c), t) / 7) + 1;
}
//#endregion
//#region src/calendar/model.ts
function y(t, n, r = !0, i = "gregory") {
	let a = m(t, i), s = o(a, -((e(a) - n + 7) % 7)), c = g(a, i), l = [];
	for (let e = s; e <= c || l.length % 7; e = o(e, 1)) l.push(e);
	if (!r || l.length >= 42) return l;
	let u = [...l];
	for (; u.length < 42;) u.push(o(u[u.length - 1], 1));
	return u;
}
function b(e, t) {
	return c(e, t) <= 0 ? {
		from: e,
		to: t
	} : {
		from: t,
		to: e
	};
}
function x(e, t) {
	return !!t && c(e, t.from) >= 0 && c(e, t.to) <= 0;
}
function S(e, t) {
	return !!(t.minDate && c(e, t.minDate) < 0 || t.maxDate && c(e, t.maxDate) > 0 || t.isDisabled?.(e));
}
function C(e, t) {
	let n = m(e, t.calendarSystem);
	return !!(t.minDate && c(g(n, t.calendarSystem), t.minDate) < 0 || t.maxDate && c(n, t.maxDate) > 0 || t.isMonthDisabled?.(n));
}
function w(t) {
	let { date: n, key: r, shiftKey: i, weekStartsOn: a } = t, s = (e(n) - a + 7) % 7, c, l = 0;
	if (r === "ArrowLeft" && ([c, l] = t.dir === "rtl" ? [o(n, 1), 1] : [o(n, -1), -1]), r === "ArrowRight" && ([c, l] = t.dir === "rtl" ? [o(n, -1), -1] : [o(n, 1), 1]), r === "ArrowUp" && ([c, l] = [o(n, -7), -7]), r === "ArrowDown" && ([c, l] = [o(n, 7), 7]), r === "Home" && ([c, l] = [o(n, -s), 1]), r === "End" && ([c, l] = [o(n, 6 - s), -1]), r === "PageUp" && ([c, l] = [h(n, i ? -12 : -1, t.calendarSystem, !0), -1]), r === "PageDown" && ([c, l] = [h(n, i ? 12 : 1, t.calendarSystem, !0), 1]), c) {
		for (let e = 0; e < 3660 && S(c, t); e++) c = o(c, l);
		return S(c, t) ? void 0 : c;
	}
}
//#endregion
export { w as a, v as c, p as d, m as f, l as h, x as i, _ as l, s as m, S as n, b as o, o as p, C as r, h as s, y as t, f as u };
