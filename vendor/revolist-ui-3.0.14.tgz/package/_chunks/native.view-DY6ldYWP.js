import { createPreactElement as e } from "../preact-mount.js";
import { controlClassName as t, renderControl as n } from "../control-presentation.js";
import { h as r } from "preact";
import { jsx as i } from "preact/jsx-runtime";
//#region src/search-input/native.view.tsx
function a(e, r) {
	let { shortcut: i, hideIcon: a, inputAttributes: o = {} } = r;
	return e("div", {
		class: t("rv-search-input", a && "rv-search-input--no-icon", i === void 0 && "rv-search-input--no-shortcut", r.rootClassName),
		"data-testid": r.testId
	}, !a && e("span", {
		class: t("rv-search-input-icon", r.iconClassName),
		"aria-hidden": "true"
	}, r.icon), r.leading, n(e, "input", {
		type: "search",
		...o,
		class: t(r.inputClassName, o.class)
	}), i !== void 0 && e("span", { class: t("rv-search-input-shortcut", r.shortcutClassName) }, i), r.trailing);
}
function o(t, n) {
	let o = e(t, a(r, {
		...n,
		icon: /* @__PURE__ */ i("span", { dangerouslySetInnerHTML: { __html: n.iconSvg } })
	}));
	return {
		root: o,
		input: o.querySelector("input")
	};
}
//#endregion
export { a as n, o as t };
