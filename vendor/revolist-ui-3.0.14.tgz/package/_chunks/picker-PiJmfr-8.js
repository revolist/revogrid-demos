import { ButtonControl as e } from "../native-control.js";
import { DEFAULT_CALENDAR_TRANSLATIONS as t } from "../calendar/translations.js";
import { n } from "./iso-B0YHBK7m.js";
import { f as r, h as i, m as a, o, p as s } from "./model-mPO2tG2f.js";
import { t as c } from "./calendar-CdXe5aOT.js";
import { Fragment as l, jsx as u, jsxs as d } from "preact/jsx-runtime";
import { useState as f } from "preact/hooks";
//#region src/calendar/picker.tsx
function p(p) {
	let { selected: m, onSelectionChange: ee, presets: h, mode: g = "single", min: _ = 0, max: v = Infinity, required: y = !1, excludeDisabled: b = !1, month: x, defaultMonth: S, onMonthChange: C, ...w } = p, T = typeof m == "string" ? m : Array.isArray(m) ? m[0] : m?.from, [E, D] = f(S ?? T ?? p.referenceDate ?? i()), [O, k] = f(T ?? E), [A, j] = f(), [M, N] = f(), P = (e) => {
		j(e), N(void 0);
	}, F = x ?? E, I = p.views?.filter((e) => e === "month" || e === "year"), L = I?.length ? I : p.views || p.enableYearView === !1 ? ["month"] : ["month", "year"], [R, z] = f(p.defaultView && L.includes(p.defaultView) ? p.defaultView : L[0]), B = L.includes(R) ? R : L[0], V = (e) => {
		D(e), P(), C?.(e);
	}, H = p.translations?.invalidSelection ?? t.invalidSelection, U = (e, t = H) => {
		j(e), N(t), p.onInvalidSelection?.(t, e);
	}, W = (e) => !!(p.minDate && e < p.minDate || p.maxDate && e > p.maxDate || p.isDateDisabled?.(e) || p.isMonthDisabled?.(r(e, p.calendarSystem))), G = (e) => {
		if (!e.to) return !W(e.from);
		let t = a(e.from, e.to);
		if (t < _ || t > v || t < 0 || W(e.from) || W(e.to)) return !1;
		if (b) {
			if (t > 366e3) return !1;
			for (let t = e.from; t <= e.to; t = s(t, 1)) if (W(t)) return !1;
		}
		return !0;
	}, K = (e) => {
		if (p.mode === "multiple") {
			let t = p.selected ?? [], n = t.includes(e), r = n ? t.filter((t) => t !== e) : [...t, e];
			if (n && r.length < Math.max(_, +!!y) || r.length > v) {
				U(e);
				return;
			}
			p.onSelectionChange(r);
		} else if (p.mode === "range") {
			let t = p.selected;
			if (!t || t.to) {
				p.onSelectionChange({ from: e }), P();
				return;
			}
			let n = o(t.from, e);
			if (!G(n)) {
				b && a(n.from, n.to) >= _ && a(n.from, n.to) <= v && p.onSelectionChange({ from: e }), U(e);
				return;
			}
			p.onSelectionChange(n), P();
		} else p.onSelectionChange(p.selected === e && !y ? void 0 : e);
	}, q = p.mode === "range" ? p.selected : void 0, J = typeof m == "string" ? {
		from: m,
		to: m
	} : q ? {
		from: q.from,
		to: q.to ?? q.from
	} : void 0, Y = q && !q.to && A ? o(q.from, A) : void 0, X = (e) => {
		let t = p.validateSelection?.(e, {
			month: r(F, p.calendarSystem),
			view: B,
			selection: J,
			preview: Y,
			referenceDate: p.referenceDate ?? (p.referenceInstant ? n(p.referenceInstant, p.timeZone ?? "UTC") : void 0)
		});
		if (t === !1 || typeof t == "string") return typeof t == "string" ? t : H;
	}, Z = Y && !G(Y) ? H : void 0, Q = M ?? Z, $ = (e) => {
		let t = X(e);
		return !t || (U(e, t), !1);
	}, te = (e) => {
		let t = e.selection, n;
		if (p.mode === "multiple") {
			if (!Array.isArray(t) || t.length < Math.max(_, +!!y) || t.length > v || t.some(W)) return;
			let e = [...new Set(t)];
			if (e.length < Math.max(_, +!!y) || !e.every($)) return;
			p.onSelectionChange(e), n = e[0] ?? F;
		} else if (p.mode === "range") {
			if (!t?.from || !G(t) || !$(t.from) || t.to && !$(t.to)) return;
			p.onSelectionChange(t), n = t.from;
		} else {
			if (typeof t != "string" || W(t) || !$(t)) return;
			p.onSelectionChange(t), n = t;
		}
		k(n), V(r(n, p.calendarSystem)), P();
	};
	return /* @__PURE__ */ u(c, {
		...w,
		onViewChange: (e) => {
			z(e), P(), p.onViewChange?.(e);
		},
		month: F,
		focusedDate: O,
		onFocusedDateChange: k,
		onMonthChange: V,
		selection: J,
		selectedDates: p.mode === "multiple" ? p.selected : void 0,
		preview: Y,
		previewInvalid: !!(Y && Q),
		previewDescription: g === "range" ? Q ?? "" : void 0,
		onInvalidSelection: (e, t) => U(t, e),
		fixedWeeks: p.fixedWeeks ?? !1,
		showOutsideDays: p.showOutsideDays ?? !0,
		allowOutsideMonthSelection: p.allowOutsideMonthSelection ?? !0,
		onPresetSelect: (e) => {
			if (p.mode === "multiple") {
				let t = p.selected ?? [];
				if (t.includes(e)) return;
				if (t.length >= v) {
					U(e);
					return;
				}
				p.onSelectionChange([...t, e]);
			} else p.mode === "range" ? p.onSelectionChange({ from: e }) : p.onSelectionChange(e);
		},
		onSelect: K,
		onPreviewDateChange: P,
		footer: h?.length || p.footer ? /* @__PURE__ */ d(l, { children: [h?.length ? /* @__PURE__ */ u("div", {
			class: "revo-calendar__presets",
			children: h.map((t) => /* @__PURE__ */ u(e, {
				onClick: () => te(t),
				children: t.label
			}, t.label))
		}) : null, p.footer] }) : void 0
	});
}
//#endregion
export { p as t };
