import { ButtonControl as e } from "../native-control.js";
import { fieldDropIndex as t, fieldListDropIndex as n } from "../field-reorder.js";
import { createElement as r } from "preact";
import { jsx as i, jsxs as a } from "preact/jsx-runtime";
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/grip-vertical.svg?raw
var o = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M128 40c0-22.1-17.9-40-40-40L40 0C17.9 0 0 17.9 0 40L0 88c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48zm0 192c0-22.1-17.9-40-40-40l-48 0c-22.1 0-40 17.9-40 40l0 48c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48zM0 424l0 48c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48c0-22.1-17.9-40-40-40l-48 0c-22.1 0-40 17.9-40 40zM320 40c0-22.1-17.9-40-40-40L232 0c-22.1 0-40 17.9-40 40l0 48c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48zM192 232l0 48c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48c0-22.1-17.9-40-40-40l-48 0c-22.1 0-40 17.9-40 40zM320 424c0-22.1-17.9-40-40-40l-48 0c-22.1 0-40 17.9-40 40l0 48c0 22.1 17.9 40 40 40l48 0c22.1 0 40-17.9 40-40l0-48z\"/></svg>";
//#endregion
//#region src/reorder-list.tsx
function s({ items: e, itemKey: o, renderItem: s, renderHandle: c, itemAttributes: l, className: u = "", rowClassName: d = "", endClassName: f = "", draggedKey: p, dropIndex: m, empty: h, onDragOver: g, onDrop: _ }) {
	let v = (e, n) => {
		let r = e.currentTarget.getBoundingClientRect();
		return t(e.clientY, r.top, r.height, n, m ?? null);
	}, y = (t) => {
		let r = t.currentTarget;
		if (t.target.closest(".rv-reorder-drop-end")?.parentElement === r) return e.length;
		let i = Array.from(r.querySelectorAll(":scope > .rv-reorder-row"));
		return n(t.clientY, i.map((e) => e.getBoundingClientRect()), m ?? null, e.length);
	};
	return /* @__PURE__ */ a("div", {
		class: `rv-reorder-list ${u}${m === e.length ? " drop-at-end" : ""}`,
		onDragOver: (e) => {
			e.target.closest(".rv-reorder-row")?.parentElement !== e.currentTarget && (e.stopPropagation(), g(e, y(e)));
		},
		onDrop: (e) => {
			e.target.closest(".rv-reorder-row")?.parentElement !== e.currentTarget && (e.stopPropagation(), _(e, y(e)));
		},
		children: [
			!e.length && h,
			e.map((e, t) => /* @__PURE__ */ r("div", {
				...l?.(e, t),
				key: o(e),
				class: `rv-reorder-row ${typeof d == "function" ? d(e, t) : d}${p === o(e) ? " dragging" : ""}${m === t ? " drop-before" : ""}`,
				onDragOver: (e) => {
					e.stopPropagation(), g(e, v(e, t));
				},
				onDrop: (e) => {
					e.stopPropagation(), _(e, v(e, t));
				}
			}, c?.(e, t), s(e, t))),
			/* @__PURE__ */ i("div", {
				class: `rv-reorder-drop-end ${f}`,
				"aria-hidden": "true"
			})
		]
	});
}
function c({ className: t = "", children: n, ...r }) {
	return /* @__PURE__ */ a(e, {
		type: "button",
		...r,
		class: `rv-btn-ghost rv-reorder-handle ${t}`,
		children: [/* @__PURE__ */ i("span", {
			"aria-hidden": "true",
			dangerouslySetInnerHTML: { __html: o }
		}), n]
	});
}
//#endregion
export { s as n, c as t };
