/** Shared finite RGB interpolation for chart renderers. */
export type RgbColor = readonly [number, number, number];
export declare function parseHexColor(value: string): RgbColor | undefined;
/** Clamped ratio, using normalized coordinates when a finite domain span overflows. */
export declare function normalizeColorValue(value: number, start: number, end: number, singletonRatio?: number): number;
export declare function interpolateRgb(start: RgbColor, end: RgbColor, ratio: number): string;
