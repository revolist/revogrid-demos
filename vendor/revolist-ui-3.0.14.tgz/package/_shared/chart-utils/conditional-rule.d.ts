export interface ConditionalRule {
    operator: 'gt' | 'lt' | 'between' | 'equal' | 'contains';
    value?: unknown;
    min?: unknown;
    max?: unknown;
    caseSensitive?: boolean;
}
export declare function evaluateConditionalRule(value: unknown, rule: ConditionalRule): boolean;
