export interface DelimitedFormatOptions {
    columnDelimiter: string;
    rowDelimiter: string;
}
export declare function encodeDelimitedCell(value: unknown, options: DelimitedFormatOptions, force?: boolean, beforeEncode?: (serialized: string, quoted: boolean) => void): string;
