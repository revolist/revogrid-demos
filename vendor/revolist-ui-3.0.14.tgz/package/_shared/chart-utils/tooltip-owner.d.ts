/** Showing a tooltip retires the previous presenter, including its timers/ARIA. */
export declare function claimTooltip(document: Document, owner: object, dismiss: () => void): void;
/** A delayed hide or destroyed presenter must never release a newer owner. */
export declare function releaseTooltip(document: Document, owner: object): void;
