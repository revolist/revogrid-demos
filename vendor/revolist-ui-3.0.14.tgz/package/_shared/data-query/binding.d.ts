import type { QueryObserverOptions } from '@tanstack/query-core';
import type { ReadBinding, ReadIntent, ReadPort, ReadProvider } from './contracts.js';
import type { DataQueryScope, ReadValue } from './source.js';
import { type NativeReadOptions } from './load-options.js';
export interface QueryRead<Request, Result> {
    readonly source: DataQueryScope;
    readonly resource: string;
    readonly operation: string;
    /** Semantic request only: no AbortSignal, transport request ID or component ID. */
    readonly request: Request;
    readonly read: ReadProvider<Request, Result>;
    readonly observerOptions?: NativeReadOptions;
    /** Product-owned bounded transport copying; omit for structured cloning. */
    readonly materialize?: (data: Result) => Result;
}
export interface BindingOptions<Result> {
    /** Explicitly fetch before delivering cached data, independently of mount/freshness policy. */
    readonly force?: boolean;
    readonly port: ReadPort<Result>;
    /** Default structuredClone supports cloneable transport data, including nested values. */
    readonly materialize?: (data: Result) => Result;
    /** Optional product revision/completeness check; returning false suppresses hydration. */
    readonly canHydrate?: (data: Result) => boolean;
}
export declare function claimReadOwner(owner: object): () => void;
export declare function observerPolicy<FnData, Data = FnData>(source: DataQueryScope, options?: NativeReadOptions): Pick<QueryObserverOptions<FnData, unknown, Data, Data>, keyof NativeReadOptions | 'placeholderData' | 'initialData' | 'select' | 'notifyOnChangeProps'>;
export declare function queryOptions<Request, Result>(definition: QueryRead<Request, Result>): QueryObserverOptions<ReadValue<Result>, unknown>;
export declare function bindQuery<Request, Result>(initial: QueryRead<Request, Result>, options: BindingOptions<Result>): ReadBinding<QueryRead<Request, Result>>;
/** Connect a product-owned request subscription; dispose stops only this subscription. */
export declare function bindQueryIntent<Request, Result>(intent: ReadIntent<Request>, describe: (request: Request) => QueryRead<Request, Result>, options: BindingOptions<Result>): ReadBinding<QueryRead<Request, Result>>;
