import type { RemoteBlockController, RemoteBlockPort } from './contracts.js';
import type { ReadProvider, ReadStatus } from './contracts.js';
import type { DataQueryScope } from './source.js';
import type { NativeReadOptions } from './load-options.js';
/** Providers must order offsets deterministically, with a unique tie-breaker. */
export type BlockConsistency<Result> = {
    readonly mode: 'eventual';
    readonly reload: 'sequence' | 'route';
} | {
    readonly mode: 'snapshot';
    readonly revision: string;
    readonly getRevision: (result: Result) => string;
};
export interface BlockQueryOptions<Request, Result> {
    readonly source?: DataQueryScope;
    /** Internal uncached transport mode; no QueryClient or observers. */
    readonly uncached?: boolean;
    readonly concurrency?: number;
    readonly read: ReadProvider<Request, Result>;
    readonly consistency: BlockConsistency<Result>;
    readonly resource?: string;
    readonly observerOptions?: NativeReadOptions;
    /** Semantic key normalization only. The provider still receives its original typed request. */
    readonly keyRequest?: (request: Request) => unknown;
    /** Application-owned pending proposals, applied only to detached data. */
    readonly reconcile?: (result: Result, request: Request) => Result;
    readonly onStatus?: (request: Request, status: ReadStatus) => void;
}
/** Subscription registry: cached reads use Query; bypass keeps only live operations. */
export declare function createBlockQueries<Request, Result>(port: RemoteBlockPort<Request, Result>, options: BlockQueryOptions<Request, Result>, operation: string): RemoteBlockController<Request>;
