import type { CommandEnvelope, CommandReceipt } from './contracts.js';
export type CommandProvider<Command, Changes, Revision = string, Conflict = Changes> = (envelope: CommandEnvelope<Command, Revision>, context: {
    readonly signal: AbortSignal;
}) => CommandReceipt<Changes, Revision, Conflict> | Promise<CommandReceipt<Changes, Revision, Conflict>>;
export interface CommandState<Changes, Revision = string, Conflict = Changes> {
    readonly status: 'idle' | 'submitting' | 'recovering' | 'accepted' | 'rejected' | 'conflict' | 'unknown' | 'disposed';
    readonly attempt: number;
    readonly receipt?: CommandReceipt<Changes, Revision, Conflict>;
    /** Local application/refetch errors never change a definitive server receipt. */
    readonly error?: unknown;
}
/** Write policy and domain hooks.
 * @see https://pro.rv-grid.com/guides/server-data-commands/#configuration-types
 */
export interface CommandOptions<Command, Changes, Revision = string, Conflict = Changes> {
    /** Restore a previously submitted envelope as unknown; execute() must not resubmit it. */
    readonly resume?: boolean;
    readonly submit: CommandProvider<Command, Changes, Revision, Conflict>;
    /** Read a durable receipt by operation ID. Never resubmit from this callback. */
    readonly recover?: CommandProvider<Command, Changes, Revision, Conflict>;
    /** Explicit backend guarantee: identical operation IDs/payloads cannot execute twice. */
    readonly idempotent?: boolean;
    /** Validate product-specific revision, completeness and canonical-change semantics. */
    readonly validateReceipt?: (receipt: CommandReceipt<Changes, Revision, Conflict>) => boolean;
    /** Apply canonical changes atomically; domain pending/history state remains product-owned. */
    readonly applyAccepted?: (changes: Changes, receipt: CommandReceipt<Changes, Revision, Conflict>) => void | Promise<void>;
    readonly source?: {
        accepted(): Promise<void>;
    };
    readonly onStatus?: (state: CommandState<Changes, Revision, Conflict>) => void;
}
export interface CommandExecution<Command, Changes, Revision = string, Conflict = Changes> {
    /** A detached snapshot. Mutating it cannot change a submitted command. */
    readonly envelope: CommandEnvelope<Command, Revision>;
    getState(): CommandState<Changes, Revision, Conflict>;
    execute(): Promise<CommandReceipt<Changes, Revision, Conflict>>;
    recover(): Promise<CommandReceipt<Changes, Revision, Conflict>>;
    retry(): Promise<CommandReceipt<Changes, Revision, Conflict>>;
    /** Retry local canonical application/refetch after acceptance, without another write. */
    reconcile(): Promise<void>;
    cancel(): void;
    dispose(): void;
}
/** One logical write. Keep this handle for recovery/retry; backend receipts provide durability.
 * @see https://pro.rv-grid.com/guides/server-data-commands/
 */
export declare function createCommandExecution<Command, Changes, Revision = string, Conflict = Changes>(envelope: CommandEnvelope<Command, Revision>, options: CommandOptions<Command, Changes, Revision, Conflict>): CommandExecution<Command, Changes, Revision, Conflict>;
