/** Library-independent contracts. Product packages need not depend on this package. */
export interface SourceIdentity {
    readonly sourceId: string;
    readonly schemaId: string;
    readonly tenantId: string;
    /** Non-secret principal/permission identity. Never put credentials here. */
    readonly authorizationScope: string;
}
export type ReadProvider<Request, Result> = (request: Request, context: {
    readonly signal: AbortSignal;
}) => Promise<Result> | Result;
export interface ReadStatus {
    readonly status: 'pending' | 'success' | 'error';
    readonly fetching: boolean;
    readonly paused: boolean;
    readonly error: unknown;
    /** Infinite bindings expose Query's pagination state without a second page ledger. */
    readonly hasNextPage?: boolean;
    readonly hasPreviousPage?: boolean;
    readonly fetchingNextPage?: boolean;
    readonly fetchingPreviousPage?: boolean;
}
/** Synchronous domain-aware application; preserve pending changes/history here. */
export interface ReadPort<Result> {
    /** Used to reject a second remote controller for the same mounted view. */
    readonly owner: object;
    /** Release old projection/row references on scope/request change and disposal. */
    clear(): void;
    hydrate(result: Result, context: {
        readonly origin: 'remote';
    }): void;
    status(status: ReadStatus): void;
}
/** Subscription seam a product can implement without importing Query. */
export interface ReadIntent<Request> {
    current(): Request;
    subscribe(listener: (request: Request) => void): () => void;
}
export interface ReadBinding<Request> {
    setRequest(request: Request): void;
    refresh(): Promise<void>;
    dispose(): void;
}
export type ReadConsistency<Revision> = {
    readonly mode: 'snapshot';
    readonly revision: Revision;
} | {
    readonly mode: 'eventual';
    readonly reload: 'sequence' | 'route';
};
export interface CommandEnvelope<Command, Revision = string> {
    readonly operationId: string;
    readonly resourceId: string;
    readonly expectedRevision?: Revision;
    readonly command: Command;
}
/** Payloads/revisions remain product-specific; transport failures are not rejections. */
export type CommandReceipt<Changes, Revision = string, Conflict = Changes> = {
    readonly operationId: string;
    readonly status: 'accepted';
    readonly changes: Changes;
    readonly revision: Revision;
} | {
    readonly operationId: string;
    readonly status: 'rejected';
    readonly message: string;
} | {
    readonly operationId: string;
    readonly status: 'conflict';
    readonly message: string;
    readonly authoritative: Conflict;
    readonly revision: Revision;
} | {
    readonly operationId: string;
    readonly status: 'unknown';
    readonly message?: string;
};
/** Compatibility only: cannot cancel a transport that ignores signals. */
export declare function fromLegacyRead<Request, Result>(read: (request: Request) => Promise<Result> | Result): ReadProvider<Request, Result>;
export interface RemoteBlockStatus {
    readonly status: 'pending' | 'success' | 'error';
    readonly fetching: boolean;
    readonly paused: boolean;
    readonly error: unknown;
}
export interface RemoteBlockPort<Request, Result> {
    readonly owner: object;
    hydrate(request: Request, result: Result, context: {
        readonly origin: 'remote';
    }): void;
    status(request: Request, state: RemoteBlockStatus): void;
    /** Release editable row references while preserving logical slot/route identity. */
    evict(request: Request): void;
}
export interface RemoteBlockController<Request> {
    observe(request: Request, force?: boolean): Promise<boolean>;
    retain(keep: (request: Request) => boolean): void;
    reset(): void;
    /** Optional aggregate physical-attempt diagnostics for the shared source. */
    getRequestState?(): {
        activeRequests: number;
        queuedRequests: number;
    };
    refresh(): Promise<void>;
    dispose(): void;
}
