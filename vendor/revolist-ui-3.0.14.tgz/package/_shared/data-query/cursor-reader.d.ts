import type { LoadQueryOptions } from './load-options.js';
import type { ReadStatus } from './contracts.js';
export interface CursorData<Page, Param> {
    pages: Page[];
    pageParams: Param[];
}
export interface CursorSubscription<Page, Param> {
    readonly ready: Promise<CursorData<Page, Param>>;
    fetchNextPage(): Promise<void>;
    refresh(): Promise<void>;
    dispose(): void;
}
/** Cursor sequences use Query's page ownership; no product transport/page cache is required. */
export declare function createCursorReader<Request, Page, Param>(operation: string, read: (request: Request, pageParam: Param, signal: AbortSignal) => Promise<Page> | Page, keyRequest: (request: Request) => unknown, initialPageParam: Param, getNextPageParam: (last: Page, pages: Page[], lastParam: Param) => Param | undefined, options?: Omit<LoadQueryOptions<never>, 'consistency' | 'reconcile'> | false): {
    observe(request: Request, settings?: {
        signal?: AbortSignal;
        force?: boolean;
        onData?: (data: CursorData<Page, Param>) => void;
        onStatus?: (status: ReadStatus) => void;
    }): CursorSubscription<Page, Param>;
    /** Explicit product refresh starts a new sequence; mounted peers follow the reset. */
    reset(request: Request): void;
    invalidate(): void;
    dispose(): void;
};
