import type { ReadBinding, ReadPort } from './contracts.js';
/** One uncached subscription. Product block ownership guards delivery after reset. */
export declare function bindDirectRead<Result>(read: (signal: AbortSignal) => Promise<Result>, port: ReadPort<Result>, materialize?: (data: Result) => Result): Pick<ReadBinding<unknown>, 'refresh' | 'dispose'>;
