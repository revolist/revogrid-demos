import type { InfiniteData } from '@tanstack/query-core';
import type { ReadBinding, ReadProvider } from './contracts.js';
import { type BindingOptions, type QueryRead } from './binding.js';
export interface InfiniteRead<Request, Page, PageParam> extends Omit<QueryRead<Request, Page>, 'read' | 'materialize'> {
    readonly read: ReadProvider<{
        readonly request: Request;
        readonly pageParam: PageParam;
    }, Page>;
    readonly initialPageParam: PageParam;
    readonly getNextPageParam: (lastPage: Page, pages: Page[], lastParam: PageParam) => PageParam | null | undefined;
    readonly maxPages?: number;
    readonly getPreviousPageParam?: (firstPage: Page, pages: Page[], firstParam: PageParam) => PageParam | null | undefined;
}
export interface InfiniteBinding<Request, Page, PageParam> extends ReadBinding<InfiniteRead<Request, Page, PageParam>> {
    fetchNextPage(): Promise<void>;
    fetchPreviousPage(): Promise<void>;
}
export declare function bindInfiniteQuery<Request, Page, PageParam>(initial: InfiniteRead<Request, Page, PageParam>, options: BindingOptions<InfiniteData<Page, PageParam>>): InfiniteBinding<Request, Page, PageParam>;
