import type { SourceIdentity } from './contracts.js';
/** Tagged encoding avoids collisions between undefined/null, strings/numbers and -0. */
export type KeyValue = string | number | boolean | null | readonly KeyValue[];
export declare function encodeRequest(value: unknown, ancestors?: Set<object>): KeyValue;
export declare function sourceKey(scope: SourceIdentity): readonly ["revo", 1, string[]];
export declare function resultKey(scope: SourceIdentity, resource: string, operation: string, request: unknown): readonly ["revo", 1, string[], string, string, "result", KeyValue];
export declare function infiniteResultKey(scope: SourceIdentity, resource: string, operation: string, request: unknown): readonly ["revo", 1, string[], string, string, "infinite", KeyValue];
/** Record insertion order expresses current grid multi-sort precedence. */
export declare function orderedSort(sort: Readonly<Record<string, 'asc' | 'desc' | undefined>> | undefined): [string, "asc" | "desc"][];
