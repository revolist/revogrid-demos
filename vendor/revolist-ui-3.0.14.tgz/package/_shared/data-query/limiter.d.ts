/** One physical-attempt budget per source runtime, not a request/result cache. */
export declare class SourceLimiter {
    readonly concurrency: number;
    private active;
    private readonly queue;
    constructor(concurrency: number);
    getRequestState(): {
        activeRequests: number;
        queuedRequests: number;
    };
    run<T>(signal: AbortSignal, read: () => Promise<T> | T): Promise<T>;
}
