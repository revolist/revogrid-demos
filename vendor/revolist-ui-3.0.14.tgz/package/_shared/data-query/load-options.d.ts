import type { DataQueryScope } from './source.js';
import type { ReadStatus } from './contracts.js';
import type { BlockConsistency } from './blocks.js';
import type { QueryObserverOptions } from '@tanstack/query-core';
/** Read policy only: identity, transport, acceptance framing and projection stay engine-owned. */
export declare const nativeReadOptionKeys: readonly ["enabled", "staleTime", "gcTime", "refetchInterval", "refetchIntervalInBackground", "refetchOnMount", "refetchOnWindowFocus", "refetchOnReconnect", "retry", "retryDelay", "retryOnMount", "networkMode", "meta"];
/** Native callbacks receive the native Query; its cached data is engine-owned/opaque. */
export type NativeReadOptions = Pick<QueryObserverOptions<unknown, unknown>, typeof nativeReadOptionKeys[number]>;
/** Also protects JavaScript callers from overriding keys, queryFn or acceptance framing. */
export declare function nativeReadOptions<FnData, Data = FnData>(options?: NativeReadOptions): Pick<QueryObserverOptions<FnData, unknown, Data, Data>, typeof nativeReadOptionKeys[number]>;
/**
 * Optional native read policies plus shared scope, consistency and product reconciliation.
 * Native options: enabled, staleTime, gcTime, refetchInterval, refetchIntervalInBackground,
 * refetchOnMount, refetchOnWindowFocus, refetchOnReconnect, retry, retryDelay,
 * retryOnMount, networkMode and meta. All existing loader callbacks stay unchanged.
 * @see [Usage, configuration types and defaults](https://pro.rv-grid.com/guides/server-data-queries/#configuration-types)
 */
export interface LoadQueryOptions<Result> extends NativeReadOptions {
    readonly source?: DataQueryScope;
    readonly resource?: string;
    readonly consistency?: BlockConsistency<Result>;
    /** Application-owned pending proposals. The input is detached from the cache. */
    readonly reconcile?: (result: Result) => Result;
    readonly onStatus?: (status: ReadStatus) => void;
}
