/** Own structured-cloneable transport data without sharing writable memory. */
export declare function materializeData<T>(data: T): T;
