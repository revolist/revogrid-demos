export interface ReadPolicy {
    readonly staleTime: number;
    readonly gcTime: number;
    readonly refetchOnMount: boolean;
    readonly refetchOnWindowFocus: boolean;
    readonly refetchOnReconnect: boolean;
    readonly retry: number;
    readonly retryDelay: number;
}
/** Explicit pilot defaults. Bindings override host defaults locally, never globally. */
export declare const defaultReadPolicy: Readonly<ReadPolicy>;
/** HTTP providers may expose a status; validation/auth failures are not transient. */
export declare function isRetryableRead(error: unknown): boolean;
export declare function resolveReadPolicy(policy?: Partial<ReadPolicy>): ReadPolicy;
