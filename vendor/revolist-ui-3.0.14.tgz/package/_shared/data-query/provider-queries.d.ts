import type { NativeReadOptions } from './load-options.js';
import type { DataQueryScope } from './source.js';
import type { ReadStatus } from './contracts.js';
/** Policy for one-shot provider calls. Polling/enabled require a mounted product observer.
 * @see https://pro.rv-grid.com/guides/server-data-queries/#ancillary-providers
 */
export interface ProviderQueryOptions extends Pick<NativeReadOptions, 'staleTime' | 'gcTime' | 'retry' | 'retryDelay' | 'networkMode' | 'meta'> {
    readonly source?: DataQueryScope;
    /** Include endpoint/project identity when it is hidden inside a callback. */
    readonly resource?: string;
    readonly onStatus?: (status: ReadStatus) => void;
}
/** Keeps live callback context out of keys; Query owns every physical attempt and cached result. */
export declare function createProviderQueries(options?: ProviderQueryOptions | false): {
    read<T>(operation: string, key: unknown, execute: (signal: AbortSignal) => T | PromiseLike<T>, signal?: AbortSignal, settings?: {
        fresh?: boolean;
    }): Promise<T>;
    accepted(): Promise<void>;
    /** A cache failure must never turn an already accepted write into a retryable write failure. */
    afterWrite(): Promise<void>;
    dispose(): void;
};
