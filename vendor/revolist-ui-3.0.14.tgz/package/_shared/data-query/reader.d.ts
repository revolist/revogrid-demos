import type { LoadQueryOptions } from './load-options.js';
import type { ReadStatus } from './contracts.js';
export interface QueryReadSubscription<Result> {
    readonly ready: Promise<Result>;
    refresh(): Promise<void>;
    dispose(): void;
}
export interface QueryReader<Request, Result> {
    read(request: Request, signal?: AbortSignal, options?: {
        fresh?: boolean;
    }): Promise<Result>;
    observe(request: Request, options?: {
        signal?: AbortSignal;
        force?: boolean;
        onData?: (result: Result) => void;
        onStatus?: (status: ReadStatus) => void;
    }): QueryReadSubscription<Result>;
    invalidate(): void;
    accepted(): Promise<void>;
    dispose(): void;
}
/** Promise providers and mounted consumers share the same validated read/cache lifecycle. */
export declare function createQueryReader<Request, Result>(operation: string, read: (request: Request, signal: AbortSignal) => Promise<Result> | Result, keyRequest: (request: Request) => unknown, options?: LoadQueryOptions<Result> | false, materialize?: (result: Result, request: Request) => Result): QueryReader<Request, Result>;
