import type { LoadQueryOptions } from './load-options.js';
import type { RemoteBlockController, RemoteBlockPort } from './contracts.js';
export type RemoteLoadController<Request> = RemoteBlockController<Request> & {
    invalidate(): void;
};
/** Own a private context by default; supplied scopes remain owned by the caller. */
export declare function createRemoteLoad<Request, Result>(operation: string, port: RemoteBlockPort<Request, Result>, read: (request: Request, signal: AbortSignal) => Promise<Result> | Result, keyRequest: (request: Request) => unknown, options?: LoadQueryOptions<Result> | false, concurrency?: number, debounceMs?: number): RemoteLoadController<Request>;
