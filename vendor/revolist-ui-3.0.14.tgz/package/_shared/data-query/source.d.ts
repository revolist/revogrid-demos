import { QueryClient } from '@tanstack/query-core';
import type { SourceIdentity } from './contracts.js';
import { SourceLimiter } from './limiter.js';
import { type ReadPolicy } from './policy.js';
/** Internal cache framing; products receive only detached value projections. */
export interface ReadValue<T> {
    readonly acceptanceVersion: number;
    readonly value: T;
}
export interface SourceOptions {
    readonly concurrency?: number;
    readonly policy?: Partial<ReadPolicy>;
}
export declare class DataQuerySource {
    readonly client: QueryClient;
    readonly identity: SourceIdentity;
    readonly policy: ReadPolicy;
    readonly limiter: SourceLimiter;
    private version;
    /** Use getDataQuerySource so equal scopes share the limiter and acceptance fence. */
    constructor(client: QueryClient, identity: SourceIdentity, options: SourceOptions);
    isCurrent(value: ReadValue<unknown>): boolean;
    read<T>(signal: AbortSignal, provider: () => Promise<T> | T, materialize?: (value: T) => T): Promise<ReadValue<T>>;
    /** Domain code applies canonical changes before calling this after acceptance. */
    accepted(): Promise<void>;
    /** Coarse, safe source-wide invalidation; product mappings can narrow it later. */
    invalidate(): Promise<void>;
}
/** Structural public scope survives declaration bundling in consuming products. */
export type DataQueryScope = Omit<DataQuerySource, 'limiter'> & {
    readonly limiter: Pick<SourceLimiter, keyof SourceLimiter>;
};
export declare function getDataQuerySource(client: QueryClient, identity: SourceIdentity, options?: SourceOptions): DataQuerySource;
/** Create once per application/session, or once per SSR request; never a global SSR client. */
export declare function createDataQueryContext(client?: QueryClient): {
    client: QueryClient;
    source(identity: SourceIdentity, options?: SourceOptions): DataQuerySource;
    /** Dispose this context's bindings first. Injected caches are never cleared. */
    dispose(): void;
};
