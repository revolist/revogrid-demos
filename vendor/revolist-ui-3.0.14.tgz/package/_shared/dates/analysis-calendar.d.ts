export type AnalysisCalendarUnit = 'day' | 'week' | 'month' | 'quarter' | 'year';
/** UTC calendar shifts preserve the time of day and clamp month-end dates. */
export declare function shiftAnalysisCalendarInstant(epoch: number, unit: AnalysisCalendarUnit, amount: number): number;
/** ISO weeks start on Monday; boundaries are UTC instants and end is exclusive. */
export declare function analysisCalendarPeriod(epoch: number, unit: AnalysisCalendarUnit): {
    start: number;
    end: number;
};
