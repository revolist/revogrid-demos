export declare const UTC_CALENDAR_PRESETS: readonly ["1M", "3M", "YTD", "1Y", "all"];
export type UtcCalendarPreset = (typeof UTC_CALENDAR_PRESETS)[number];
export interface UtcCalendarRange {
    min: number;
    max: number;
}
/** UTC calendar arithmetic preserves time-of-day and clamps month-end, including years below 100. */
export declare function shiftUtcCalendarMonths(instant: number, months: number): number | undefined;
export type UtcCalendarWindowUnit = 'day' | 'week' | 'month' | 'year';
/** Exact trailing UTC windows preserve the anchor instant and clamp calendar month ends. */
export declare function resolveUtcCalendarWindow(window: {
    unit: UtcCalendarWindowUnit;
    count: number;
}, domain: UtcCalendarRange): UtcCalendarRange | undefined;
/** Presets anchor to the latest available instant, never wall-clock time or loaded page size. */
export declare function resolveUtcCalendarPreset(preset: UtcCalendarPreset, domain: UtcCalendarRange): UtcCalendarRange | undefined;
/** Inclusive UTC date inputs become inclusive millisecond viewport bounds. */
export declare function resolveUtcCustomCalendarRange(from: string, to: string, domain: UtcCalendarRange): UtcCalendarRange | undefined;
