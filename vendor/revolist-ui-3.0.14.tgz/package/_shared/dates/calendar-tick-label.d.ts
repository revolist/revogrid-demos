import type { UtcCalendarTickUnit } from './calendar-ticks';
/** UTC fallback text and precision for a calendar tick, before consumer localization. */
export declare function formatUtcCalendarTickLabel(value: number, unit: UtcCalendarTickUnit): {
    text: string;
    dateOnly: boolean;
} | undefined;
