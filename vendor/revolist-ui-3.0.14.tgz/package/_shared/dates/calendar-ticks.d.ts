export type UtcCalendarTickUnit = 'second' | 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';
/** UTC period increment, preserving calendar boundaries instead of assuming month lengths. */
export declare function incrementUtcCalendar(value: number, unit: UtcCalendarTickUnit, step?: number): number;
/** Calendar boundaries within the observed domain; never adds observations or fills missing values. */
export declare function utcCalendarTicks(min: number, max: number, target?: number, minimumUnit?: UtcCalendarTickUnit): {
    unit: UtcCalendarTickUnit;
    values: number[];
};
/** Missing means an absent calendar bucket, never a time-of-day change within adjacent buckets. */
export declare function hasMissingUtcCalendarPeriod(previous: number, next: number, unit: 'day' | 'week' | 'month' | 'quarter' | 'year'): boolean;
