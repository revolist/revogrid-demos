import type { ISODateString } from './iso';
/** Unique identifier for a working calendar. */
export type CalendarId = string | number;
/** Time-of-day working window for calendar-aware schedulers. */
export interface CalendarWorkingTimeRange {
    /** Start time in `HH:mm` or AM/PM format. */
    readonly start: string;
    /** End time in `HH:mm` or AM/PM format. */
    readonly end: string;
}
/** Parsed working time window expressed as minutes from midnight. */
export interface CalendarResolvedWorkingTimeRange {
    readonly startMinutes: number;
    readonly endMinutes: number;
}
/** Shared bound for working-date traversal. */
export declare const CALENDAR_WORKING_DATE_SEARCH_LIMIT = 3660;
export type CalendarWeekday = 1 | 2 | 3 | 4 | 5 | 6 | 7;
/** Overrides one ISO weekday. An explicit empty range list closes that weekday. */
export type CalendarWeekdayWorkingHours = Partial<Readonly<Record<CalendarWeekday, readonly CalendarWorkingTimeRange[]>>>;
/** Civil-date recurrence anchored to the exception's original start and end dates. */
export interface CalendarExceptionRecurrence {
    readonly frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    /** Positive integral period count; defaults to one. */
    readonly interval?: number;
    /** Inclusive final matching date; omission repeats indefinitely. */
    readonly until?: ISODateString;
}
/** Replaces the entire working schedule on matching dates; [] makes them nonworking. */
export interface CalendarException {
    readonly id: string;
    readonly name?: string;
    readonly startDate: ISODateString;
    readonly endDate?: ISODateString;
    readonly workingHours: readonly CalendarWorkingTimeRange[];
    readonly recurrence?: CalendarExceptionRecurrence;
}
/**
 * Defines the working schedule for tasks, events, and resources.
 * Working days use ISO weekday numbers: 1 = Monday ... 7 = Sunday.
 */
export interface CalendarEntity {
    /** Unique calendar identifier. */
    readonly id: CalendarId;
    /** Display name, for example `"Standard"` or `"Night Shift"`. */
    readonly name: string;
    /** IANA time zone, for example `"America/New_York"`. */
    readonly timeZone: string;
    /** ISO weekday numbers that are working days. */
    readonly workingDays: readonly number[];
    /** Specific dates that are non-working regardless of weekday. */
    readonly holidays: readonly ISODateString[];
    /** Optional working time windows inside a working day. */
    readonly workingHours?: CalendarWorkingTimeRange | readonly CalendarWorkingTimeRange[];
    /** Base calendar. A derived calendar inherits its working week unless explicitly disabled. */
    readonly baseCalendarId?: CalendarId;
    /** Defaults to true with a base; false uses the local legacy week and local weekday overrides. */
    readonly inheritWorkingWeek?: boolean;
    readonly weekdayWorkingHours?: CalendarWeekdayWorkingHours;
    /** Base rules apply before child rules; the last matching exception wins. */
    readonly exceptions?: readonly CalendarException[];
    /** Number of working hours per day, used for effort/capacity calculations. */
    readonly hoursPerDay: number;
}
/** Default Monday-Friday calendar shared by Gantt and Event Scheduler. */
export declare const DEFAULT_CALENDAR: CalendarEntity;
/** Calendar with derived lookup-friendly fields used by schedulers. */
export interface ResolvedCalendarEntity {
    readonly calendar: CalendarEntity;
    readonly workingDays: readonly number[];
    readonly workingHours: readonly CalendarResolvedWorkingTimeRange[];
    readonly holidays: ReadonlySet<string>;
}
export interface CalendarListLookupContext {
    readonly calendars: readonly CalendarEntity[];
    readonly primaryCalendarId?: CalendarId;
}
export type CalendarLookupTarget = CalendarId | {
    readonly calendarId?: CalendarId;
} | undefined;
export declare function calendarKey(calendarId: CalendarId): string;
export declare function normalizeIsoWorkingDays(days: readonly number[] | undefined, fallback?: readonly number[]): readonly number[];
export declare function jsWeekdayFromIsoWeekday(day: number): number;
export declare function jsWeekdaysFromIsoWeekdays(days: readonly number[]): readonly number[];
export declare function normalizeCalendarHolidaySet(holidays: readonly ISODateString[] | undefined): ReadonlySet<string>;
export declare function normalizeCalendarWorkingHours(workingHours: CalendarWorkingTimeRange | readonly CalendarWorkingTimeRange[] | undefined, options?: {
    readonly errorPrefix?: string;
}): readonly CalendarResolvedWorkingTimeRange[];
export declare function normalizeCalendar(calendar: CalendarEntity, options?: {
    readonly workingHoursErrorPrefix?: string;
}): ResolvedCalendarEntity;
export declare function createResolvedCalendarMap(calendars: readonly CalendarEntity[] | undefined, options?: {
    readonly workingHoursErrorPrefix?: string;
}): Map<string, ResolvedCalendarEntity>;
export declare function createCalendarMap(calendars: readonly CalendarEntity[] | undefined): Map<CalendarId, CalendarEntity>;
export declare function resolveCalendarFromMap(target: CalendarLookupTarget, calendarsById: ReadonlyMap<CalendarId, CalendarEntity>, primaryCalendar: CalendarEntity | null): CalendarEntity | null;
export declare function resolveCalendarFromList(context: CalendarListLookupContext, target?: CalendarLookupTarget): CalendarEntity | null;
export declare function resolveCalendarItemFromMap<T>(target: CalendarLookupTarget, items: ReadonlyMap<string, T>): T | null;
export declare function isCalendarHoliday(date: ISODateString | string, calendar: {
    readonly holidays: readonly string[] | ReadonlySet<string>;
} | null | undefined): boolean;
export declare function isCalendarWorkingWeekday(weekday: number, calendar: Pick<CalendarEntity, 'workingDays'> | Pick<ResolvedCalendarEntity, 'workingDays'> | null | undefined): boolean;
export type CalendarScheduleSource = Pick<CalendarEntity, 'workingDays'> & {
    readonly holidays: readonly string[] | ReadonlySet<string>;
    readonly workingHours?: CalendarEntity['workingHours'];
    readonly weekdayWorkingHours?: CalendarWeekdayWorkingHours;
    readonly exceptions?: readonly CalendarException[];
    readonly id?: CalendarId;
};
export interface CalendarDateSchedule {
    readonly isWorking: boolean;
    readonly workingHours: readonly CalendarResolvedWorkingTimeRange[];
    readonly exception?: CalendarException;
    readonly exceptionCalendarId?: CalendarId;
}
/** Evaluates civil UTC dates; timeZone metadata does not reinterpret existing scheduler timestamps. */
export declare function getCalendarDateSchedule(date: ISODateString | string, calendar: CalendarScheduleSource | ResolvedCalendarEntity | null | undefined): CalendarDateSchedule;
export declare function isWorkingCalendarDate(date: ISODateString | string, _weekday: number, calendar: CalendarScheduleSource | ResolvedCalendarEntity | null | undefined): boolean;
export declare function isCalendarWorkingHour(date: ISODateString | string, calendar: CalendarEntity | ResolvedCalendarEntity | null | undefined): boolean;
export declare function isCalendarWorkingMinute(date: ISODateString | string, calendar: CalendarEntity | ResolvedCalendarEntity | null | undefined): boolean;
export declare function isCalendarWorkingMinuteEnd(date: ISODateString | string, calendar: CalendarEntity | ResolvedCalendarEntity | null | undefined): boolean;
/** Matches recurrence by civil calendar fields without scanning every date or altering time zones. */
export declare function matchesCalendarException(date: string, exception: CalendarException): boolean;
export interface CalendarValidationIssue {
    readonly calendarId: CalendarId;
    readonly code: string;
    readonly message: string;
    readonly exceptionId?: string;
}
/** Validates editor/import input without mutating it; legacy lookup remains tolerant of weekday normalization. */
export declare function validateCalendars(calendars: readonly CalendarEntity[]): readonly CalendarValidationIssue[];
/** Deeply clones calendar source data for transactional editors, snapshots and history. */
export declare function cloneCalendars(calendars: readonly CalendarEntity[]): CalendarEntity[];
