/** Calendar and clock fields interpreted in a specific IANA timezone. */
export interface CivilDateTime {
    readonly year: number;
    readonly month: number;
    readonly day: number;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
}
export type CivilDate = Pick<CivilDateTime, 'year' | 'month' | 'day'>;
export declare function getBrowserTimeZone(): string;
/** Projects an instant into Gregorian civil fields in an IANA timezone. */
export declare function getCivilParts(instant: Date, timeZone: string): CivilDateTime;
/** Parses a valid ISO date-only string into timezone-independent civil fields. */
export declare function parseIsoCivilDate(value: string): CivilDate | undefined;
/** Parses a `datetime-local` value into civil fields without applying a timezone. */
export declare function parseIsoLocalCivilDateTime(value: string): CivilDateTime | undefined;
/** Returns every instant represented by a civil second in an IANA timezone. */
export declare function getPossibleInstants(value: CivilDateTime, timeZone: string): Date[];
export declare function resolveExactCivilInstant(value: CivilDateTime, timeZone: string): Date | undefined;
/** Period boundaries advance through a timezone gap to its first valid civil instant. */
export declare function resolveCivilBoundary(value: CivilDateTime, timeZone: string): Date;
/** Adds civil days independently of the machine timezone and DST. */
export declare function addCivilDays(value: CivilDate, days: number): CivilDate;
/** Adds civil months, clamping the authored day to the target month's last day. */
export declare function addCivilMonths(value: CivilDate, months: number): CivilDate;
/** Signed civil-day distance in milliseconds, without timezone offsets. */
export declare function compareCivilDates(left: CivilDate, right: CivilDate): number;
/** JavaScript weekday index of a civil date: Sunday is zero. */
export declare function getCivilWeekday(value: CivilDate): number;
/** Parses a native datetime-local value in a schedule timezone. Gaps are invalid;
 * new repeated times use the earlier instant. An unchanged original keeps its fold and precision. */
export declare function parseZonedDateTimeControlValue(value: string, timeZone?: string, original?: Date): Date | undefined;
export interface TimeZoneOffsetRange {
    readonly startMs: number;
    readonly endMs: number;
    readonly offsetMs: number;
}
/** Splits an instant range at offset transitions, including repeated and skipped hours. */
export declare function splitTimeZoneOffsetRanges(startMs: number, endMs: number, timeZone?: string): TimeZoneOffsetRange[];
/** Projects an instant interval onto one civil day's clock, retaining DST splits. */
export declare function projectCivilDayRange(date: string, startMs: number, endMs: number, timeZone?: string, rangeStart?: number, rangeEnd?: number): (TimeZoneOffsetRange & {
    readonly startMinutes: number;
    readonly endMinutes: number;
})[];
