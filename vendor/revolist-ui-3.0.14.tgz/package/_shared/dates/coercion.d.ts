/** Converts supported scalars to a valid Date; cloning can be disabled for read-only hot paths. */
export declare function coerceValidDate(value: unknown, cloneDate?: boolean): Date | undefined;
