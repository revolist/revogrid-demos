import { type TimelineUnit, type TimelineWeekStartsOn } from './timeline';
export type DateBucketInput = {
    kind: 'civil-date';
} | {
    kind: 'instant';
    timeZone: string;
};
type DateBucketBase = {
    version: 1;
    input: DateBucketInput;
    calendar: 'gregory';
    invalid?: 'error' | 'blank';
};
/** Portable Gregorian wall-clock semantics. No implicit process timezone. */
export type DateBucketOperation = DateBucketBase & ({
    type: 'truncate';
    grain: Exclude<TimelineUnit, 'week'>;
    weekStartsOn?: never;
} | {
    type: 'truncate';
    grain: 'week';
    weekStartsOn: TimelineWeekStartsOn;
} | {
    type: 'weekday';
    grain?: never;
    weekStartsOn?: never;
});
export type DateBucketResult = {
    kind: 'value';
    value: string | number;
} | {
    kind: 'missing';
} | {
    kind: 'invalid';
    reason: string;
};
export type DateBucketClassifier = (value: unknown) => DateBucketResult;
/** Compiles a reusable classifier without reading facts or changing existing date helper semantics. */
export declare function compileDateBucketClassifier(inputPolicy: DateBucketOperation): DateBucketClassifier;
export {};
