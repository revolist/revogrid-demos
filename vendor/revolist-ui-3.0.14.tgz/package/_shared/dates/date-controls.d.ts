export { coerceValidDate } from './coercion';
export type LocalDateControlKind = 'date' | 'datetime' | 'time';
/** Formats local `Date` fields for native date, datetime-local, and time controls. */
export declare function formatLocalDateControlValue(kind: LocalDateControlKind, date: Date, precision?: 'minute' | 'second'): string;
/**
 * Parses native date, datetime-local, and time control values as local time.
 * Returns `undefined` when the syntax or calendar value is invalid.
 */
export declare function parseLocalDateControlValue(kind: LocalDateControlKind, value: string, baseDate?: Date): Date | undefined;
/** Legacy temporal filter coercion accepts only offset-qualified datetime strings. */
export declare function parseOffsetDateTimeValue(value: unknown): Date | undefined;
