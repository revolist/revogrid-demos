import { type ISODateString } from './iso';
export interface DateEntryOptions {
    /** Numeric Gregorian input; ISO is accepted in every mode. */
    format?: 'iso' | 'eu' | 'us' | 'locale';
    locale?: string;
    parse?: (text: string) => string | undefined;
    formatValue?: (date: ISODateString) => string;
}
export declare function dateEntryPlaceholder(options?: DateEntryOptions): string;
export declare function formatDateEntry(date: string, options?: DateEntryOptions): string;
/** Strict civil parsing; never rely on Date's rollover or ambiguous string parser. */
export declare function parseDateEntry(text: string, options?: DateEntryOptions): ISODateString | undefined;
