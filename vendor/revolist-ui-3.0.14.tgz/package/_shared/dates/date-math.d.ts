import { type ISODateString, type ISODateTimeString } from './iso';
export declare const MINUTE_IN_MS: number;
export declare const HOUR_IN_MS: number;
export declare const DAY_IN_MS: number;
export declare const WEEK_IN_MS: number;
export declare const MINUTE_IN_DAYS: number;
/**
 * Adds calendar days using UTC math.
 * Datetime inputs preserve datetime output; date-only inputs return date-only output.
 */
export declare function addDays(date: string, days: number): ISODateString;
export declare function subtractDays(date: string, days: number): ISODateString;
export declare function addHours(date: string, hours: number): ISODateTimeString;
export declare function addMinutes(date: string, minutes: number): ISODateTimeString;
export declare function addMonths(date: string, months: number): ISODateString;
/** Adds calendar months while preserving the day-of-month, clamped to the target month. */
export declare function addCalendarMonths(date: string, months: number): ISODateString;
export declare function diffInDays(startDate: string, endDate: string): number;
export declare function diffInCalendarDays(startDate: string, endDate: string): number;
/**
 * Returns the Gantt duration between two task dates.
 * Date-only ranges are inclusive; datetime ranges use elapsed days and keep a
 * non-zero positive duration at one minute minimum.
 */
export declare function diffInTaskDuration(startDate: string, endDate: string): number;
export declare function diffInHours(startDate: string, endDate: string): number;
export declare function diffInMinutes(startDate: string, endDate: string): number;
export declare function compareIsoDates(left: string, right: string): number;
export declare function isBefore(left: string, right: string): boolean;
export declare function isAfter(left: string, right: string): boolean;
export declare function minDate(left: string, right: string): ISODateString;
export declare function maxDate(left: string, right: string): ISODateString;
export interface ISODateRange {
    readonly startDate: ISODateString;
    readonly endDate: ISODateString;
}
/**
 * Resolves the calendar dates occupied by a half-open datetime range
 * `[startDateTime, endDateTime)`. A zero or inverted range remains on the
 * start date so callers can handle invalid duration separately.
 */
export declare function getOccupiedDateRange(startDateTime: string, endDateTime: string, timeZone?: string): ISODateRange;
export declare function shiftDate(date: string, deltaDays: number): ISODateString;
export declare function shiftDateRange<T extends ISODateRange>(range: T, deltaDays: number): T;
export declare function shiftDateRanges<T extends ISODateRange>(ranges: readonly T[] | undefined, deltaDays: number): readonly T[] | undefined;
export declare function startOfWeek(date: string): ISODateString;
export declare function startOfMonth(date: string): ISODateString;
/** Returns the final UTC calendar date in the month containing `date`. */
export declare function endOfMonth(date: string): ISODateString;
/**
 * Returns every date needed to render a natural four-to-six-week month grid,
 * including the leading and trailing dates from adjacent months.
 */
export declare function createCompletedMonthDateList(date: string, weekStartsOn: number): readonly ISODateString[];
export declare function startOfQuarter(date: string): ISODateString;
export declare function startOfYear(date: string): ISODateString;
export declare function endOfYear(date: string): ISODateString;
/** Returns the UTC Monday for the week containing `date`. */
export declare function getWeekStartIsoDate(date: Date): ISODateString;
export declare function getMonthStartIsoDate(date: Date): ISODateString;
export declare function getIsoWeekNumber(date: Date): number;
export declare function todayIsoDate(): ISODateString;
/** Returns an inclusive date list and throws when the range is invalid. */
export declare function createDateList(startDate: string, endDate: string, options?: {
    readonly maxDays?: number;
    readonly rangeLabel?: string;
}): readonly ISODateString[];
/**
 * Returns an inclusive date list or `[]` for invalid input.
 * Use this when remote/user data should not throw during projection.
 */
export declare function createSafeDateList(startDate: string, endDate: string): readonly ISODateString[];
/** Tests overlap for half-open numeric ranges: `[start, end)` and `[rangeStart, rangeEnd)`. */
export declare function rangesOverlap(start: number, end: number, rangeStart: number, rangeEnd: number): boolean;
export interface ISODateBoundsRange {
    readonly start: string;
    readonly end: string;
}
/** Returns the UTC midnight timestamp for the date containing `value`. */
export declare function startOfUtcDayMs(value: string | number | Date): number;
/** Returns half-open instant bounds for a civil date (UTC by default). */
export declare function getDateDayBounds(date: string, timeZone?: string): {
    readonly startMs: number;
    readonly endMs: number;
};
/** Returns half-open instant bounds for an inclusive civil date range (UTC by default). */
export declare function getDateRangeBounds(range: ISODateBoundsRange, timeZone?: string): {
    readonly startMs: number;
    readonly endMs: number;
};
