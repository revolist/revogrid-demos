import { type ISODateString } from './iso';
/** Display systems with twelve months. Values always remain Gregorian ISO civil dates. */
export type DisplayCalendarSystem = 'gregory' | 'persian' | 'islamic-umalqura';
export declare function formatDisplayCalendarDate(date: ISODateString, locale: string, options: Intl.DateTimeFormatOptions, system?: DisplayCalendarSystem): string;
export declare function getDisplayCalendarParts(date: ISODateString, system?: DisplayCalendarSystem): {
    year: number;
    month: number;
    day: number;
};
export declare function startOfDisplayMonth(date: ISODateString, system?: DisplayCalendarSystem): ISODateString;
export declare function addDisplayMonths(date: ISODateString, count: number, system?: DisplayCalendarSystem, preserveDay?: boolean): ISODateString;
export declare function endOfDisplayMonth(date: ISODateString, system?: DisplayCalendarSystem): ISODateString;
export declare function displayYearMonths(date: ISODateString, system?: DisplayCalendarSystem): readonly ISODateString[];
/** Week numbers can follow ISO rules or a locale's configured first week. */
export declare function displayWeekNumber(date: ISODateString, weekStartsOn?: number, firstWeekContainsDate?: number, system?: DisplayCalendarSystem): number;
