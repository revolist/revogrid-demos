export type DateDisplayFormat = 'locale' | 'eu' | 'us' | 'iso' | 'long';
export type TimeDisplayFormat = 'locale' | '12h' | '24h';
export type DateTimeDisplayOptions = {
    locale?: string | string[];
    dateFormat?: DateDisplayFormat;
    timeFormat?: TimeDisplayFormat;
    timeZone?: string;
};
/** Formats an instant for UI display without changing its stored representation. */
export declare function formatDateTimeDisplay(value: unknown, options: DateTimeDisplayOptions & {
    mode: 'date' | 'time' | 'dateTime';
}): string | undefined;
/** Formats a civil date without applying a timezone; instant values use the requested zone. */
export declare function formatCalendarDateDisplay(value: unknown, locale?: string, timeZone?: string): string | undefined;
/** Compact civil/instant range caption for constrained controls; retains years across years. */
export declare function formatCompactDateRangeDisplay(from: Date, to: Date, locale?: string | string[], timeZone?: string): string;
