import { type DurationUnit, type ParsedDuration } from './duration';
export interface DurationControlOptions {
    defaultUnit: DurationUnit;
    allowedUnits?: readonly DurationUnit[];
    allowElapsed?: boolean;
    required?: boolean;
    /** Numeric bounds apply to the authored value, without implicit calendar conversions. */
    min?: number;
    max?: number;
    maximumFractionDigits?: number;
}
export declare function parseDurationControl(value: unknown, options: DurationControlOptions): {
    valid: boolean;
    value: ParsedDuration | null;
};
