/**
 * Shared duration parsing, canonical-hour conversion, and display formatting.
 * Gantt, scheduler, and import/export adapters consume this dates-layer module.
 */
import type { CalendarEntity } from './calendars';
/** Unit retained with an authored task duration. */
export type DurationUnit = 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';
/** Project-level duration display and working-time conversion settings. */
export interface DurationSettings {
    /** Unit used for bare input and display. `auto` chooses minutes, hours, or days by magnitude. */
    readonly defaultUnit?: DurationUnit | 'auto';
    /** Unit used for bare Work input and display. Defaults to `auto`, independently from task Duration. */
    readonly defaultWorkUnit?: DurationUnit | 'auto';
    /** Working hours represented by one duration day. Defaults to the effective calendar, then 8. */
    readonly hoursPerDay?: number;
    /** Working hours represented by one duration week. Defaults to the effective workweek, then 40. */
    readonly hoursPerWeek?: number;
    /** Working days represented by one duration month. Defaults to 20. */
    readonly daysPerMonth?: number;
    /** Maximum digits shown after the decimal separator. Defaults to 1. */
    readonly maximumFractionDigits?: number;
}
export interface ResolvedDurationSettings {
    readonly defaultUnit: DurationUnit | 'auto';
    readonly defaultWorkUnit: DurationUnit | 'auto';
    readonly hoursPerDay: number;
    readonly hoursPerWeek: number;
    readonly daysPerMonth: number;
    readonly maximumFractionDigits: number;
}
export interface ParsedDuration {
    readonly value: number;
    readonly unit: DurationUnit;
    readonly elapsed: boolean;
}
export interface ParseDurationOptions {
    readonly defaultUnit?: DurationUnit;
    readonly allowElapsed?: boolean;
}
export interface FormatDurationValueOptions {
    readonly elapsed?: boolean;
    /** Maximum digits shown after the decimal separator. Defaults to 1. */
    readonly maximumFractionDigits?: number;
}
export interface FormatWorkingDurationOptions extends FormatDurationValueOptions {
    readonly unit?: DurationUnit;
}
export declare function resolveDurationSettings(settings: DurationSettings | undefined, calendar?: Pick<CalendarEntity, 'hoursPerDay' | 'workingDays'> | null): ResolvedDurationSettings;
export declare function parseDuration(input: unknown, options?: ParseDurationOptions): ParsedDuration | null;
/** Returns true when text explicitly contains a unit rather than a bare number. */
export declare function hasDurationUnitToken(input: unknown): boolean;
export declare function durationToWorkingDays(value: number, unit: DurationUnit, settings: ResolvedDurationSettings): number;
/** Converts a displayed duration magnitude into canonical stored working hours. */
export declare function durationToHours(value: number, unit: DurationUnit, settings: ResolvedDurationSettings): number;
export declare function workingDaysToDuration(workingDays: number, unit: DurationUnit, settings: ResolvedDurationSettings): number;
/** Converts canonical stored working hours into a display magnitude. */
export declare function hoursToDuration(hours: number, unit: DurationUnit, settings: ResolvedDurationSettings): number;
/** Converts an elapsed duration to continuous 24-hour calendar days. */
export declare function durationToElapsedDays(value: number, unit: DurationUnit): number;
/** Converts an elapsed display magnitude into canonical stored continuous hours. */
export declare function durationToElapsedHours(value: number, unit: DurationUnit): number;
export declare function elapsedDaysToDuration(elapsedDays: number, unit: DurationUnit): number;
/** Converts canonical stored continuous hours into an elapsed display magnitude. */
export declare function elapsedHoursToDuration(elapsedHours: number, unit: DurationUnit): number;
export declare function resolveAutomaticDurationUnit(workingDays: number, settings: ResolvedDurationSettings): DurationUnit;
/** Selects the automatic display unit for a canonical working-hour value. */
export declare function resolveAutomaticDurationUnitFromHours(hours: number, settings: ResolvedDurationSettings): DurationUnit;
export declare function formatDurationValue(value: number, unit: DurationUnit, options?: FormatDurationValueOptions): string;
export declare function formatWorkingDuration(workingDays: number, settings: ResolvedDurationSettings, options?: FormatWorkingDurationOptions): string;
