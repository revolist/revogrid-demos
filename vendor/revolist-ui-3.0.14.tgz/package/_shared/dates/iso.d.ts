export type ISODateString = `${number}-${number}-${number}` | `${number}-${number}-${number}T${string}`;
export type ISODateTimeString = `${number}-${number}-${number}T${string}`;
export declare const ISO_DATE_ONLY_PATTERN: RegExp;
export declare const ISO_DATE_PATTERN: RegExp;
export declare const ISO_DATE_PREFIX_PATTERN: RegExp;
export declare const ISO_DATETIME_PATTERN: RegExp;
export declare const ISO_DATETIME_INPUT_PATTERN: RegExp;
export declare const ISO_LOCAL_DATETIME_INPUT_PATTERN: RegExp;
export declare const ISO_UTC_DATETIME_WITHOUT_ZONE_PATTERN: RegExp;
/**
 * Parses date-only strings at UTC midnight instead of local midnight.
 * Datetime strings are delegated to the JavaScript `Date` parser.
 */
export declare function parseIsoDate(date: string): Date;
/**
 * Parses grid-facing date values while preserving local calendar semantics for
 * date-only strings. JSON-quoted strings cover normalized selection keys for
 * Date-valued cells.
 */
export declare function parseLocalDateValue(value: unknown): Date | undefined;
/** Parses the `YYYY-MM-DD` prefix of a date or datetime at UTC midnight. */
export declare function parseIsoDateOnly(value: string): Date;
export declare function isIsoDateTimeInput(value: string): boolean;
export declare function getIsoWeekdayUtc(date: Date): number;
export declare function getUtcWeekday(value: string | Date): number;
export declare function getIsoWeekday(value: string | Date): number;
export declare function isValidIsoWeekday(value: number): boolean;
export declare function formatIsoDate(date: Date): ISODateString;
/** Serializes the calendar date containing an instant in the requested IANA timezone. */
export declare function formatIsoDateInTimeZone(date: Date, timeZone: string): ISODateString;
/** Serializes an instant as a timezone-local value accepted by `datetime-local` controls. */
export declare function formatLocalIsoDateTimeInTimeZone(date: Date, timeZone: string): string;
/** Serializes the local calendar fields of a valid `Date` as `YYYY-MM-DD`. */
export declare function formatLocalIsoDate(value: Date): ISODateString;
/** Returns local calendar fields as `YYYY-MM-DD`, or `null` for a missing/invalid date. */
export declare function toLocalIsoDate(value: Date | undefined): ISODateString | null;
export declare function formatIsoDateTime(date: Date): ISODateTimeString;
export declare function isValidIsoDate(value: string | undefined): value is ISODateString;
export declare function isValidIsoDateTime(value: string | undefined): value is ISODateTimeString;
/**
 * Validates either a date-only ISO value or a UTC datetime value.
 * Date-only values must round-trip as `YYYY-MM-DD`; datetimes must round-trip
 * exactly through `toISOString()`.
 */
export declare function isValidIsoDateValue(value: string | undefined): value is ISODateString;
/** Returns a valid `YYYY-MM-DD` value or throws with a user-facing message. */
export declare function normalizeIsoDate(value: string): ISODateString;
/**
 * Parses scheduler datetime input as UTC.
 * Values without a trailing `Z` are treated as UTC, not local time.
 */
export declare function parseDateTime(value: string): Date;
export declare function toISODate(date: Date, timeZone?: string): ISODateString;
export declare function toIsoDate(date: Date): ISODateString;
/** Syntax and native-parser acceptance for legacy ISO date-only sequences; allows day overflow. */
export declare function isParseableIsoDateOnly(value: unknown): value is string;
/** Recognizes parseable ISO-looking chart/category values; preserves native day overflow. */
export declare function isParseableIsoDateValue(value: string): boolean;
/** Legacy UTC operand syntax requires seconds, with optional fractional precision. */
export declare function isParseableUtcDateTime(value: string): boolean;
