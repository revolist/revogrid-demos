/** Returns a new local calendar boundary, preserving local DST rules. */
export declare function startOfLocalCalendarUnit(value: Date, unit: 'day' | 'month' | 'quarter' | 'year'): Date;
/** Local calendar-day arithmetic, preserving wall-clock time across DST. */
export declare function addLocalCalendarDays(value: Date, days: number): Date;
/** Local calendar-month arithmetic with native Date overflow semantics. */
export declare function addLocalCalendarMonths(value: Date, months: number): Date;
