import { type ISODateString } from './iso';
export type RelativeDateWindowPreset = 'last7Days' | 'today' | 'thisMonth' | 'thisQuarter' | 'yearToDate' | 'overdue';
export type RelativeDateWindowDirection = 'last' | 'next';
export type RelativeDateWindowUnit = 'day' | 'week' | 'month' | 'quarter' | 'year';
export type RelativeDateWindowExpression = Readonly<{
    version: 1;
    mode: 'preset';
    preset: RelativeDateWindowPreset;
} | {
    version: 1;
    mode: 'custom';
    direction: RelativeDateWindowDirection;
    amount: number;
    unit: RelativeDateWindowUnit;
    rolling: boolean;
}>;
export interface RelativeDateWindowSettings {
    /** Sunday is 0 and Saturday is 6. */
    readonly weekStartsOn: 0 | 1 | 2 | 3 | 4 | 5 | 6;
    readonly fiscalYearStart: {
        readonly month: number;
        readonly day: number;
    };
}
export interface RelativeDateWindowRange {
    /** Inclusive lower calendar date. */
    readonly from?: ISODateString;
    /** Inclusive upper calendar date. */
    readonly to?: ISODateString;
}
export declare function isRelativeDateWindowExpression(value: unknown): value is RelativeDateWindowExpression;
/** Returns the start of the fiscal year containing a civil date. */
export declare function startOfFiscalYear(date: ISODateString, settings: Pick<RelativeDateWindowSettings, 'fiscalYearStart'>): ISODateString;
/** Resolves a relative expression to inclusive civil-date boundaries. */
export declare function resolveRelativeDateWindow(today: string, expression: RelativeDateWindowExpression, settings: RelativeDateWindowSettings): RelativeDateWindowRange | undefined;
