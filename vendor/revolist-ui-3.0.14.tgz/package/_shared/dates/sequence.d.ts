/**
 * Parsed date value with the visible input format needed for output.
 */
export type ParsedDateValue = {
    /** Parsed date normalized to a Date object. */
    date: Date;
    /** Original visible input format. */
    format: 'date-object' | 'yyyy-mm-dd' | 'yyyy/mm/dd' | 'mm/dd/yyyy';
};
/**
 * Parses a Date object or supported date string.
 *
 * @param value Value to parse.
 * @returns Parsed date and original format, or `null` for unsupported values.
 */
export declare function parseDateValue(value: unknown): ParsedDateValue | null;
/**
 * Formats a date using the preserved input format.
 *
 * @param date Date to format.
 * @param format Output format captured from the selected source value.
 * @returns Date object copy or formatted date string.
 */
export declare function formatDateValue(date: Date, format: ParsedDateValue['format']): string | Date;
/**
 * Adds a number of days using UTC date math.
 *
 * @param date Source date.
 * @param days Number of days to add.
 * @returns New Date instance.
 */
export declare function addUtcDays(date: Date, days: number): Date;
/**
 * Adds a number of months using UTC date math.
 *
 * @param date Source date.
 * @param months Number of months to add.
 * @returns New Date instance.
 */
export declare function addUtcMonths(date: Date, months: number): Date;
/**
 * Calculates whole-month distance between two UTC dates.
 *
 * @param a Start date.
 * @param b End date.
 * @returns Number of calendar months from `a` to `b`.
 */
export declare function monthDiff(a: Date, b: Date): number;
/**
 * Parsed clock-time value with the visible input format needed for output.
 */
export type ParsedTimeValue = {
    /** Seconds elapsed since midnight. */
    seconds: number;
    /** Original visible input format. */
    format: 'hh:mm' | 'hh:mm:ss';
};
/**
 * Parses a supported clock-time string.
 *
 * @param value Value to parse.
 * @returns Parsed seconds and original format, or `null` for unsupported values.
 */
export declare function parseTimeValue(value: unknown): ParsedTimeValue | null;
/**
 * Formats seconds since midnight as a clock-time string.
 *
 * @param totalSeconds Seconds since midnight. Values wrap around 24 hours.
 * @param format Output format captured from the selected source value.
 * @returns Formatted clock-time string.
 */
export declare function formatTimeValue(totalSeconds: number, format: ParsedTimeValue['format']): string;
