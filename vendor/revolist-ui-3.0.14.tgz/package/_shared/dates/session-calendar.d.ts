export interface CivilSessionCalendarInput {
    timeZone: string;
    disambiguation?: 'reject' | 'earlier' | 'later';
    sessions: readonly {
        date: string;
        open: string;
        close: string;
        endDate?: string;
    }[];
}
export interface InstantSessionCalendar {
    timeZone: string;
    sessions: {
        open: number;
        close: number;
    }[];
}
/** Explicit civil sessions only. Missing/ambiguous times never acquire an implicit offset. */
export declare function createSessionCalendar(input: CivilSessionCalendarInput): InstantSessionCalendar;
