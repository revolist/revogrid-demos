export type SpreadsheetDateOrder = 'mdy' | 'dmy' | 'ymd';
/** Resolve the conventional spreadsheet date order for a BCP 47 locale. */
export declare function resolveSpreadsheetDateOrder(locale: string): SpreadsheetDateOrder;
/** Resolve whether a locale conventionally displays spreadsheet times in 12-hour form. */
export declare function usesSpreadsheetTwelveHourClock(locale: string): boolean;
export interface SpreadsheetDateParts {
    readonly year: number;
    /** One-based calendar month. */
    readonly month: number;
    readonly day: number;
    /** Sunday is zero, matching `Date#getDay`. */
    readonly weekday: number;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
    readonly millisecond: number;
    readonly elapsedHours: number;
    readonly elapsedMinutes: number;
    readonly elapsedSeconds: number;
    /** Excel's intentionally fictional 1900-02-29. */
    readonly fictionalLeapDay: boolean;
}
export interface SpreadsheetDisplayDateTimeOptions {
    readonly dateOrder?: SpreadsheetDateOrder;
    readonly locale?: string;
    readonly hasDate?: boolean;
    readonly hasTime?: boolean;
    /** Leading elapsed unit for formats such as `[h]:mm:ss`. */
    readonly elapsedUnit?: 'h' | 'm' | 's';
}
/**
 * Coerces spreadsheet date values into local calendar fields.
 * Numeric values use Excel's 1900 date system, including its skipped serial 60.
 */
export declare function coerceSpreadsheetDate(value: unknown): Date | undefined;
/** Converts an Excel 1900-system serial into a local spreadsheet date. */
export declare function excelSerialToSpreadsheetDate(serial: number): Date | undefined;
/**
 * Resolves Excel 1900-system serial fields without losing serial 60. This is
 * intended for spreadsheet number-format evaluation where 1900-02-29 must be
 * displayed exactly even though JavaScript `Date` cannot represent it.
 */
export declare function excelSerialToSpreadsheetDateParts(serial: number): SpreadsheetDateParts | undefined;
/** Converts local spreadsheet calendar fields into an Excel 1900-system serial. */
export declare function spreadsheetDateToExcelSerial(value: Date): number | undefined;
/** Converts the calendar fields displayed in a timezone into an Excel serial. */
export declare function spreadsheetDateToExcelSerialInTimeZone(value: Date, timeZone: string): number | undefined;
/**
 * Parses a locale-displayed spreadsheet date without relying on JavaScript's
 * implementation-defined non-ISO string parser.
 */
export declare function parseSpreadsheetDateDisplay(value: string, order: SpreadsheetDateOrder, locale?: string): Date | undefined;
/** Parse browser-visible spreadsheet date/time text into an Excel day serial. */
export declare function parseSpreadsheetDateTimeDisplay(value: string, options: SpreadsheetDisplayDateTimeOptions): number | undefined;
