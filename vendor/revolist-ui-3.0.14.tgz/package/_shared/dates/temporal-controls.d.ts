import { type LocalDateControlKind } from './date-controls';
export type TemporalControlValue = string | string[] | {
    from: string;
    to?: string;
} | null;
export declare function temporalDatePart(value: string): string;
export declare function temporalTimePart(value: string): string;
export declare function withTemporalDate(date: string, previous: string, kind: LocalDateControlKind): string;
export declare function withTemporalTime(value: string, time: string, kind: LocalDateControlKind): string;
export declare function isValidTemporalControl(kind: LocalDateControlKind, value: string): boolean;
/** Date-only values never shift zones. Other stored representations are projected for editing. */
export declare function temporalToControl(kind: LocalDateControlKind, value: unknown, timeZone?: string): string;
/** Shared representation-preserving commit boundary. Undefined means invalid; null means cleared. */
export declare function temporalFromControl(kind: LocalDateControlKind, draft: string, original?: unknown, timeZone?: string): unknown;
export declare function timeControlSeconds(value: string): number | undefined;
export declare function isTimeControlAllowed(value: string, options: {
    min?: string;
    max?: string;
    step?: number;
}): boolean;
/** Explicit clock presentation without relying on the browser/OS native time-input locale. */
export declare function formatClockControl(value: string, format: '12h' | '24h', precision?: 'minute' | 'second', locale?: string): string;
export declare function parseClockControl(value: string, precision?: 'minute' | 'second', locale?: string): string | undefined;
