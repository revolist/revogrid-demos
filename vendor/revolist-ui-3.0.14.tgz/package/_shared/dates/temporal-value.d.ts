import { type DisplayCalendarSystem } from './display-calendar';
import { type DateEntryOptions } from './date-entry';
import { type LocalDateControlKind } from './date-controls';
export interface TemporalValueFormatOptions {
    kind?: LocalDateControlKind;
    locale?: string;
    calendarSystem?: DisplayCalendarSystem;
    dateInput?: DateEntryOptions;
    timeFormat?: 'locale' | '12h' | '24h';
    precision?: 'minute' | 'second';
    formatValue?: (value: string) => string;
}
/** Input is already projected into the user's civil date/time by the owning adapter. */
export declare function formatTemporalValue(value: string, options?: TemporalValueFormatOptions, full?: boolean): string;
export declare function formatTemporalRange(from: string, to: string, options?: TemporalValueFormatOptions): string;
/** Preserve invalid stored text instead of guessing dates from partial numeric strings. */
export declare function temporalDisplayControl(value: unknown, kind: LocalDateControlKind, timeZone?: string): string;
