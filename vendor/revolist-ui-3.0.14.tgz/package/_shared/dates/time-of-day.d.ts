import { type ISODateTimeString } from './iso';
/**
 * Parses `HH:mm` or `h:mm AM/PM` into minutes from midnight.
 * `24:00` is accepted only when `allowEndOfDay` is enabled.
 */
export declare function parseTimeOfDay(value: string, options?: {
    allowEndOfDay?: boolean;
}): number;
export declare function formatTimeOfDay(totalMinutes: number): string;
export declare function formatCompactTimeOfDay(totalMinutes: number): string;
export declare function formatAmPmTimeOfDay(totalMinutes: number): string;
export declare function formatDisplayTimeOfDay(totalMinutes: number, options?: {
    readonly timeLabelFormatter?: (minutes: number, slotIndex: number) => string;
    readonly slotIndex?: number;
    readonly useAmPm?: boolean;
}): string;
export declare function formatDurationMinutes(totalMinutes: number): string;
export declare function formatDuration(duration: number | undefined | null, options?: {
    readonly hoursPerDay?: number;
}): string;
export declare function hasAmPmMarker(value: string): boolean;
export declare function getDateMinutes(date: Date, timeZone?: string): number;
/** Clock minutes including seconds and milliseconds, independent of the machine timezone. */
export declare function getPreciseDateMinutes(date: Date, timeZone?: string): number;
export interface TimeZoneWeekdayHour {
    /** Sunday is 0 and Saturday is 6, matching `Date#getUTCDay`. */
    readonly weekday: number;
    readonly hour: number;
}
export type TimeZoneWeekdayHourReader = (instant: Date) => TimeZoneWeekdayHour | undefined;
/** Compiles timezone projection once and keeps a bounded minute-level result cache. */
export declare function createTimeZoneWeekdayHourReader(timeZone: string): TimeZoneWeekdayHourReader;
/** Returns whether a string names an Intl-supported IANA timezone. */
export declare function isIanaTimeZone(timeZone: string): boolean;
/** Validates an IANA timezone at the shared date boundary. */
export declare function assertIanaTimeZone(timeZone: string, label?: string): void;
/** Extracts the civil weekday/hour containing an instant in an IANA timezone. */
export declare function getTimeZoneWeekdayHour(instant: Date, timeZone: string): TimeZoneWeekdayHour | undefined;
/** Creates an instant from a civil date and clock minutes (UTC by default).
 * Gaps advance to the first valid minute; repeated times use the earlier instant. */
export declare function createDateTime(date: string, minutes: number, timeZone?: string): ISODateTimeString;
export declare function createDateTimeFromTimeOfDay(date: string, time: string, dayOffset?: number): ISODateTimeString;
/**
 * Serializes a local `Date` clock value as a UTC ISO datetime.
 * This preserves the user's local wall-clock fields for scheduler form inputs.
 */
export declare function getLocalDateTimeAsUtcIsoDateTime(date: Date): ISODateTimeString;
/** Shifts an absolute instant by elapsed minutes without truncating fractions. */
export declare function addElapsedMinutes(value: string, minutes: number): ISODateTimeString;
/** Exact elapsed duration, including seconds and milliseconds. Legacy rounded helpers are unchanged. */
export declare function getElapsedDurationMinutes(event: {
    readonly startDateTime: string;
    readonly endDateTime: string;
}): number;
export declare function shiftDateTime(value: string, deltaMinutes: number): ISODateTimeString;
/** Replaces the calendar date, preserving clock fields in the requested timezone (UTC by default). */
export declare function replaceDateTimeDate(value: string, date: string, timeZone?: string): ISODateTimeString;
/** Advances whole schedule-local days. Fractional offsets retain legacy elapsed-day behavior. */
export declare function shiftDateTimeByCalendarDays(value: string, days: number, timeZone?: string): ISODateTimeString;
export type DateTimeDurationMode = 'elapsed' | 'calendarDays';
export interface MoveDateTimeRangeOptions {
    /** Defaults to exact elapsed duration; calendarDays preserves civil date/clock duration. */
    readonly durationMode?: DateTimeDurationMode;
    /** Timezone for calendarDays arithmetic. Defaults to UTC. */
    readonly timeZone?: string;
}
/** Moves a range preserving elapsed duration by default, or schedule-local civil duration. */
export declare function moveDateTimeRange(start: string, end: string, nextStart: string, options?: MoveDateTimeRangeOptions): {
    readonly startDateTime: ISODateTimeString;
    readonly endDateTime: ISODateTimeString;
};
export declare function isMidnightDateTime(value: string, timeZone?: string): boolean;
export declare function getDateTimeDurationMinutes(startDateTime: string, endDateTime: string): number;
export declare function getDurationMinutes(event: {
    readonly startDateTime: ISODateTimeString | string;
    readonly endDateTime: ISODateTimeString | string;
}): number;
/** Returns an event duration in minutes, clamped to zero for inverted ranges. */
export declare function getClampedDateTimeDurationMinutes(startDateTime: string, endDateTime: string): number;
export declare function snapMinutes(minutes: number, snap: number): number;
/** Snaps clock minutes in the requested timezone; repeated times retain the nearest original fold. */
export declare function snapDateTime(value: string, snap: number, timeZone?: string): ISODateTimeString;
