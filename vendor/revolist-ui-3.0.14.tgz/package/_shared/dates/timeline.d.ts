import { type ISODateString, type ISODateTimeString } from './iso';
export type TimelineUnit = 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';
export type TimelineWeekStartsOn = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export declare function normalizeTimelineWeekStartsOn(value: unknown): TimelineWeekStartsOn;
/** Parses a timeline row value only when it identifies one unambiguous instant. */
export declare function parseTimelineInstantValue(value: unknown): Date | undefined;
export declare function startOfTimelineWeek(date: string, weekStartsOn: TimelineWeekStartsOn): ISODateString;
/** Parses a timeline boundary as UTC for deterministic scale math. */
export declare function parseTimelineDateValue(date: string): Date;
/**
 * Returns the UTC-aligned start for a timeline unit.
 * Intraday units preserve datetime precision; day and larger units return date-only values.
 */
export declare function startOfTimelineUnit(unit: TimelineUnit, date: string, weekStartsOn?: TimelineWeekStartsOn): ISODateString | ISODateTimeString;
/** Adds a timeline unit while preserving the timeline's UTC normalization rules. */
export declare function addTimelineUnit(unit: TimelineUnit, date: string, amount: number): ISODateString | ISODateTimeString;
/**
 * Converts an inclusive Gantt date boundary to an exclusive timeline boundary.
 * Datetime values already represent instants and are returned unchanged.
 */
export declare function getTimelineEndExclusiveDate(date: string): ISODateString | ISODateTimeString;
export declare function getTimelineQuarter(date: string): number;
/** Formats timeline labels with a cached formatter; UTC remains the default timezone. */
export declare function formatTimelineDateLabel(date: string | Date, locale: string, options: Intl.DateTimeFormatOptions, timeZone?: string): string;
/** Formats the compact weekday/day tier used below an enclosing month label. */
export declare function formatTimelineCompactWeekdayDayLabel(date: string | Date, locale: string, timeZone?: string): string;
export declare function startOfHour(date: string): ISODateTimeString;
export declare function startOfMinute(date: string): ISODateTimeString;
