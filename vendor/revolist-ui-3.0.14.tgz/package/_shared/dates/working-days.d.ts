import { type ISODateString } from './iso';
import { type CalendarScheduleSource, type CalendarWorkingTimeRange } from './calendars';
export type WorkingTimeRange = CalendarWorkingTimeRange;
export interface WorkingCalendar extends CalendarScheduleSource {
    readonly holidays: readonly string[];
    readonly hoursPerDay?: number;
}
export interface WorkingDayOptions {
    readonly excludeHolidaysFromDuration: boolean;
}
export interface LagCalendarOptions {
    readonly lagCalendar: 'calendar-days' | 'working-days';
}
/** Checks a date against calendar working weekdays and holiday exclusions. */
export declare function isWorkingDate(date: ISODateString, calendar: WorkingCalendar | null | undefined): boolean;
/**
 * Moves forward until a working date is found.
 * Returns the original date when no working date is found before `iterationLimit`.
 */
export declare function moveToNextWorkingDate(date: ISODateString, calendar: WorkingCalendar | null | undefined, iterationLimit?: number): ISODateString;
export declare function moveToNextWorkingDateTime(date: ISODateString, calendar: WorkingCalendar | null | undefined, iterationLimit?: number): ISODateString;
/**
 * Moves backward until a working date is found.
 * Returns the original date when no working date is found before `iterationLimit`.
 */
export declare function moveToPreviousWorkingDate(date: ISODateString, calendar: WorkingCalendar | null | undefined, iterationLimit?: number): ISODateString;
/** Adds working days, excluding the start date from the counted offset. */
export declare function addWorkingDays(startDate: ISODateString, days: number, calendar: WorkingCalendar | null | undefined): ISODateString;
/** Subtracts working days, excluding the start date from the counted offset. */
export declare function subtractWorkingDays(startDate: ISODateString, days: number, calendar: WorkingCalendar | null | undefined): ISODateString;
/** Applies dependency lag using either calendar days or working days. */
export declare function offsetByLagCalendar(date: ISODateString, days: number, calendar: WorkingCalendar | null | undefined, options: LagCalendarOptions): ISODateString;
/**
 * Resolves a task end date from start and duration.
 * Date-only durations are inclusive; datetime durations support fractional days.
 */
export declare function resolveTaskEndDate(startDate: ISODateString, duration: number, calendar: WorkingCalendar | null | undefined, options: WorkingDayOptions): ISODateString;
/**
 * Resolves a task start date from end and duration.
 * Date-only durations are inclusive; datetime durations support fractional days.
 */
export declare function resolveTaskStartDateFromEnd(endDate: ISODateString, duration: number, calendar: WorkingCalendar | null | undefined, options: WorkingDayOptions): ISODateString;
/** Counts working dates inclusively between start and end. */
export declare function countWorkingDaysInclusive(startDate: ISODateString, endDate: ISODateString, calendar: WorkingCalendar | null | undefined): number;
export declare function countWorkingDuration(startDate: ISODateString, endDate: ISODateString, calendar: WorkingCalendar | null | undefined): number;
/**
 * Snaps a date to the nearest working date in the requested direction.
 * Returns the original date when no working date is found before `iterationLimit`.
 */
export declare function snapToWorkingDate(date: ISODateString, calendar: WorkingCalendar | null | undefined, direction?: 'forward' | 'back', iterationLimit?: number): ISODateString;
/** Counts ISO weekdays inclusively with no holidays, without iterating over the full range. */
export declare function countWeekdaysInclusive(startDate: string, endDate: string): number;
/** Advances by a finite count of UTC Monday-Friday dates, excluding the start date; no holiday exclusions. */
export declare function addUtcWeekdays(value: Date, days: number): Date;
