import { type UtcCalendarPreset, type UtcCalendarRange, type UtcCalendarWindowUnit } from './calendar-range';
/** Civil trailing windows; folds use the earlier instant, gaps advance to the first valid minute. */
export declare function resolveCalendarWindow(window: {
    unit: UtcCalendarWindowUnit;
    count: number;
}, domain: UtcCalendarRange, timeZone?: string): UtcCalendarRange | undefined;
/** Full-domain anchoring and millisecond storage are independent of the display zone. */
export declare function resolveCalendarPreset(preset: UtcCalendarPreset, domain: UtcCalendarRange, timeZone?: string): UtcCalendarRange | undefined;
/** Inclusive civil dates; skipped authored dates are rejected, never silently relabelled. */
export declare function resolveCustomCalendarRange(from: string, to: string, domain: UtcCalendarRange, timeZone?: string): UtcCalendarRange | undefined;
/** Calendar inputs accept positive four-digit civil years; other domains keep presets available. */
export declare function formatCalendarInputDate(instant: number, timeZone?: string): string;
