import { h, ComponentChildren } from 'preact';
export interface ActivityMessageProps {
    className?: string;
    avatar: ComponentChildren;
    timestamp: ComponentChildren;
    header?: ComponentChildren;
    children: ComponentChildren;
    actions?: ComponentChildren;
    details?: ComponentChildren;
}
/** A compact, composable message with an avatar, timestamp and optional actions. */
export declare function ActivityMessage({ className, avatar, timestamp, header, children, actions, details }: ActivityMessageProps): h.JSX.Element;
