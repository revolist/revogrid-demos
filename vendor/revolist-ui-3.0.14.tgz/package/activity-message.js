import { jsx as e, jsxs as t } from "preact/jsx-runtime";
//#region src/activity-message.tsx
function n({ className: n = "", avatar: r, timestamp: i, header: a, children: o, actions: s, details: c }) {
	return /* @__PURE__ */ t("article", {
		class: `rv-activity-message ${n}`,
		children: [
			/* @__PURE__ */ e("div", {
				class: "rv-activity-message-avatar",
				children: r
			}),
			/* @__PURE__ */ t("div", {
				class: "rv-activity-message-card",
				children: [
					a && /* @__PURE__ */ e("div", {
						class: "rv-activity-message-header",
						children: a
					}),
					/* @__PURE__ */ e("div", {
						class: `rv-activity-message-content${a ? " rv-activity-message-content--full" : ""}`,
						children: o
					}),
					/* @__PURE__ */ e("div", {
						class: "rv-activity-message-time",
						children: i
					}),
					s && /* @__PURE__ */ e("div", {
						class: "rv-activity-message-actions",
						children: s
					})
				]
			}),
			c && /* @__PURE__ */ e("div", {
				class: "rv-activity-message-details",
				children: c
			})
		]
	});
}
//#endregion
export { n as ActivityMessage };
