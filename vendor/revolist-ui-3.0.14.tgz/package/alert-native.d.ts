import { AlertProps } from './alert';
export type NativeAlertProps = AlertProps & {
    content?: string | Node;
};
/** Stateful native mount boundary. Preact owns the shared alert and its updates. */
export declare function renderAlertInto(host: HTMLElement, { content, ...props }: NativeAlertProps): void;
export declare function createAlertElement(document: Document, props: NativeAlertProps): HTMLElement;
export declare function releaseAlertElement(host: HTMLElement): void;
