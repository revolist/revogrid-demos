import { ComponentChildren, JSX } from 'preact';
export type AlertProps = Omit<JSX.IntrinsicElements['div'], 'title'> & {
    tone?: 'neutral' | 'warning' | 'danger' | 'success';
    label?: string;
    icon?: ComponentChildren;
    title?: ComponentChildren;
    description?: ComponentChildren;
    actions?: ComponentChildren;
};
/** The same alert markup for Preact and renderer-neutral grid templates. */
export declare function renderAlert<T>(renderer: (tag: string, attributes: any, children?: any) => T, { children, tone, label, icon, title, description, actions, className, class: htmlClass, ...attributes }: AlertProps): T;
export declare function Alert(props: AlertProps): import('preact').VNode<import('preact').Attributes>;
