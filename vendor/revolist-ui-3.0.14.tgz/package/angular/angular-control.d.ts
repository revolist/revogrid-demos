import { type DoCheck } from '@angular/core';
import * as i0 from "@angular/core";
/** Decorates Angular's native controls without replacing form bindings or DOM events. */
export declare class UiControlDirective implements DoCheck {
    private readonly element;
    private classes;
    ngDoCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiControlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UiControlDirective, "button[rvControl],input[rvControl],select[rvControl],textarea[rvControl],summary[rvControl]", never, {}, {}, never, never, true, never>;
}
