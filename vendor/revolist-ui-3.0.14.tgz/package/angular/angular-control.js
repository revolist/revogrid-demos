import { Directive, ElementRef, inject } from '@angular/core';
import { controlAttributes } from '../control-presentation.js';
import * as i0 from "@angular/core";
/** Decorates Angular's native controls without replacing form bindings or DOM events. */
export class UiControlDirective {
    element = inject(ElementRef).nativeElement;
    classes = [];
    ngDoCheck() {
        const element = this.element;
        const tag = element.localName;
        const type = element.getAttribute('type');
        const presentation = controlAttributes(tag, type === null ? {} : { type });
        const classes = presentation.class.split(/\s+/).filter(Boolean);
        for (const name of this.classes)
            if (!classes.includes(name))
                element.classList.remove(name);
        element.classList.add(...classes);
        this.classes = classes;
        if (tag === 'button' && !element.hasAttribute('type'))
            element.setAttribute('type', presentation.type);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.0", ngImport: i0, type: UiControlDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.0", type: UiControlDirective, isStandalone: true, selector: "button[rvControl],input[rvControl],select[rvControl],textarea[rvControl],summary[rvControl]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.0", ngImport: i0, type: UiControlDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[rvControl],input[rvControl],select[rvControl],textarea[rvControl],summary[rvControl]',
                    standalone: true,
                }]
        }] });
