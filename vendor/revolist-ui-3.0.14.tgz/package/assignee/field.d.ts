import { ComponentChildren } from 'preact';
import { DropdownProps } from '../dropdown/dropdown.types';
import { AssigneeAssignment, AssigneeId } from './model';
import { AssigneeFieldOptions, AssigneePickerProps, AssigneeOption } from './types';
export declare function AssigneeField({ value, options, theme, renderPicker, renderValue, save, cancel, }: {
    value: unknown;
    options: AssigneeFieldOptions;
    theme?: string;
    renderPicker?: (props: AssigneePickerProps) => ComponentChildren;
    renderValue?: (h: Parameters<NonNullable<DropdownProps<AssigneeId>['renderValue']>>[0], option: AssigneeOption, units: number) => any;
    save: (value: AssigneeAssignment[]) => void;
    cancel: () => void;
}): import("preact").JSX.Element;
