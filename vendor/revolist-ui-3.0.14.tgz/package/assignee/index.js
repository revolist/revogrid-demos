import { Input as e } from "../native-control.js";
import { t } from "../_chunks/alert-BjgGD4ar.js";
import { SearchInput as n } from "../search-input/index.js";
import { SharedResourcePicker as r } from "../resource-picker/resource-picker.js";
import { t as i } from "../_chunks/dropdown-B1_emHGN.js";
import { EditorActions as a } from "../editor-actions.js";
import { jsx as o, jsxs as s } from "preact/jsx-runtime";
import { useRef as c, useState as l } from "preact/hooks";
//#region src/assignee/model.ts
function u(e) {
	let t = /* @__PURE__ */ new Map();
	if (Array.isArray(e)) for (let n of e) n && (typeof n.value == "string" || typeof n.value == "number") && t.set(n.value, {
		value: n.value,
		units: n.units
	});
	return [...t.values()];
}
function d(e) {
	return Number.isFinite(e) && e >= 0;
}
function f(e, t, n, r) {
	let i = new Map(t.map((e) => [e.value, e])), a = new Set(e.map((e) => e.value)), o = e.filter((e) => !i.has(e.value) || i.get(e.value)?.disabled || n.has(e.value));
	for (let e of t) n.has(e.value) && !a.has(e.value) && !e.disabled && o.push({
		value: e.value,
		units: r
	});
	return o;
}
function p(e, t) {
	return t === 0 ? String(e) : `${e} ${t}%`;
}
//#endregion
//#region src/assignee/picker.tsx
function m(t) {
	let n = t.text, i = t.value.every((e) => d(e.units));
	return /* @__PURE__ */ s("div", {
		id: t.id,
		class: "rv-assignee-picker",
		role: "dialog",
		"aria-label": n?.dialogLabel ?? "Assign people",
		onKeyDown: (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "Enter" && (e.preventDefault(), e.stopPropagation(), t.value.every((e) => d(e.units)) && t.apply()), e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), t.cancel());
		},
		children: [
			/* @__PURE__ */ o(r, {
				resources: t.options.map((e) => ({
					...e,
					id: e.value,
					name: e.name ?? e.label
				})),
				selectedResourceIds: t.value.map((e) => e.value),
				classNames: { avatar: t.showAvatars === !1 ? "rv-assignee-avatar--hidden" : void 0 },
				preserveOrder: !0,
				isResourceDisabled: (e) => !!e.disabled,
				text: {
					groupAriaLabel: n?.label ?? "Assignees",
					searchAriaLabel: n?.searchLabel ?? "Search assignees",
					searchPlaceholder: n?.searchPlaceholder ?? "Search name or role…",
					emptySearch: n?.empty ?? "No assignees found",
					emptyResources: n?.empty ?? "No assignees found"
				},
				onChange: (e) => t.change(f(t.value, t.options, new Set(e), t.defaultUnits))
			}),
			/* @__PURE__ */ o("div", {
				class: "rv-assignee-picker__allocations",
				children: t.value.map((r) => {
					let i = t.options.find((e) => e.value === r.value), a = i?.name ?? i?.label ?? String(r.value);
					return /* @__PURE__ */ s("label", { children: [/* @__PURE__ */ o("span", { children: a }), /* @__PURE__ */ o(e, {
						type: "number",
						min: 0,
						step: "any",
						disabled: i?.disabled,
						"aria-label": n?.unitsLabel?.(a) ?? `Units for ${a}`,
						value: Number.isFinite(r.units) ? String(r.units) : "",
						onInput: (e) => t.change(t.value.map((t) => t.value === r.value ? {
							...t,
							units: e.currentTarget.valueAsNumber
						} : t))
					})] }, `${typeof r.value}:${r.value}`);
				})
			}),
			/* @__PURE__ */ s("div", {
				class: "rv-assignee-picker__footer",
				children: [/* @__PURE__ */ o("span", {
					"aria-live": "polite",
					children: n?.selected?.(t.value.length) ?? `${t.value.length} selected`
				}), /* @__PURE__ */ o(a, {
					showConfirm: t.showActions ?? t.autoApply === !1,
					apply: t.apply,
					cancel: t.cancel,
					disabled: !i,
					text: {
						apply: n?.apply ?? "Save",
						cancel: n?.cancel ?? "Cancel"
					}
				})]
			}),
			!i && /* @__PURE__ */ o("p", {
				role: "alert",
				children: n?.invalidUnits ?? "Units must be a non-negative number."
			})
		]
	});
}
//#endregion
//#region src/assignee/field.tsx
function h({ value: e, options: t, theme: n, renderPicker: r, renderValue: a, save: s, cancel: f }) {
	let [h, g] = l(() => u(e)), _ = c(h), v = c(!1), y = (e) => {
		_.current = e, g(e);
	}, b = () => _.current.every((e) => d(e.units)) ? (v.current = !0, s(_.current), !0) : !1, x = t.autoApply !== !1, S = new Map(t.source.map((e) => [e.value, e])), C = [...t.source, ...h.filter((e) => !S.has(e.value)).map((e) => ({
		value: e.value,
		label: String(e.value)
	}))], w = d(t.defaultUnits ?? 100) ? t.defaultUnits ?? 100 : 100;
	return /* @__PURE__ */ o(i, {
		source: C,
		value: h.map((e) => e.value),
		className: "rv-assignee-editor",
		placeholder: t.text?.placeholder ?? "Assign people…",
		config: {
			multiSelect: !0,
			autoOpen: !0,
			autoFocus: !0,
			topLayer: !0,
			ariaLabel: t.text?.label ?? "Assignees",
			removeLabel: t.text?.removeLabel,
			popupClassName: "rv-assignee-picker-menu edit-input-wrapper",
			theme: n
		},
		renderValue: (e, t) => {
			let n = h.find((e) => e.value === t.value)?.units ?? 0;
			return a ? a(e, t, n) : p(t.name ?? t.label, n);
		},
		onChange: (e) => {
			let t = new Set(Array.isArray(e) ? e : [e]);
			y(_.current.filter((e) => t.has(e.value)));
		},
		beforeOutsideClose: x ? () => _.current.every((e) => d(e.units)) ? JSON.stringify(_.current) === JSON.stringify(u(e)) || b() : !1 : void 0,
		onClose: () => {
			v.current || f();
		},
		renderContent: ({ id: e, close: i }) => {
			let a = {
				id: e,
				options: t.source,
				value: h,
				change: y,
				autoApply: x,
				showActions: t.showActions,
				theme: n,
				defaultUnits: w,
				showAvatars: t.showAvatars,
				text: t.text,
				apply: b,
				cancel: () => i(!1)
			};
			return r ? r(a) : /* @__PURE__ */ o(m, { ...a });
		}
	});
}
//#endregion
//#region src/assignee/layout.tsx
function g({ query: e, onQueryChange: r, searchRef: i, children: c, ...l }) {
	return /* @__PURE__ */ s("div", {
		id: l.id,
		class: "rv-assignee-picker",
		role: "dialog",
		"aria-label": l.text?.dialogLabel ?? "Assign people",
		onKeyDown: (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "Enter" && (e.preventDefault(), e.stopPropagation(), l.value.every((e) => d(e.units)) && l.apply()), e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), l.cancel());
		},
		children: [
			/* @__PURE__ */ o("div", {
				class: "rv-assignee-picker__search",
				children: /* @__PURE__ */ o(n, {
					inputRef: i,
					autoFocus: !0,
					"aria-label": l.text?.searchLabel ?? "Search assignees",
					placeholder: l.text?.searchPlaceholder ?? "Search name or role…",
					value: e,
					onValueChange: r
				})
			}),
			c,
			!l.options.some((t) => `${t.name ?? ""} ${t.label} ${t.role ?? ""}`.toLocaleLowerCase().includes(e.trim().toLocaleLowerCase())) && /* @__PURE__ */ o("p", {
				role: "status",
				children: l.text?.empty ?? "No assignees found"
			}),
			/* @__PURE__ */ s("div", {
				class: "rv-assignee-picker__footer",
				children: [/* @__PURE__ */ o("span", {
					"aria-live": "polite",
					children: l.text?.selected?.(l.value.length) ?? `${l.value.length} selected`
				}), /* @__PURE__ */ o(a, {
					showConfirm: l.showActions ?? l.autoApply === !1,
					apply: l.apply,
					cancel: l.cancel,
					disabled: l.value.some((e) => !d(e.units)),
					text: {
						apply: l.text?.apply ?? "Save",
						cancel: l.text?.cancel ?? "Cancel"
					}
				})]
			}),
			l.value.some((e) => !d(e.units)) && /* @__PURE__ */ o(t, {
				tone: "danger",
				children: l.text?.invalidUnits ?? "Units must be a non-negative number."
			})
		]
	});
}
//#endregion
export { h as AssigneeField, m as AssigneePicker, g as AssigneePickerLayout, u as copyAssigneeAssignments, p as formatAssigneeLabel, f as reconcileAssigneeSelection, d as validAssigneeUnits };
