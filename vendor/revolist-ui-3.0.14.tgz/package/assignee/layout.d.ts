import { ComponentChildren, RefObject } from 'preact';
import { AssigneePickerProps } from './types';
/** Renderer-neutral search, validation and actions around a specialized resource list. */
export declare function AssigneePickerLayout({ query, onQueryChange, searchRef, children, ...props }: AssigneePickerProps & {
    query: string;
    onQueryChange: (value: string) => void;
    searchRef?: RefObject<HTMLInputElement>;
    children: ComponentChildren;
}): import("preact").JSX.Element;
