/** Stable resource identifier. Numeric and string IDs remain distinct. */
export type AssigneeId = string | number;
/** Allocation in percent; values above 100 represent over-allocation. */
export interface AssigneeAssignment {
    value: AssigneeId;
    units: number;
}
/** Copy and deduplicate stored assignments without modifying the source row. */
export declare function copyAssigneeAssignments(value: unknown): AssigneeAssignment[];
export declare function validAssigneeUnits(units: number): boolean;
/** Reconcile checkbox state while retaining unknown IDs and locked assignments. */
export declare function reconcileAssigneeSelection(previous: AssigneeAssignment[], options: readonly {
    value: AssigneeId;
    disabled?: boolean;
}[], selected: ReadonlySet<AssigneeId>, defaultUnits: number): AssigneeAssignment[];
/** Zero allocations keep the assignee name without a percentage suffix. */
export declare function formatAssigneeLabel(name: string | number, units: number): string;
