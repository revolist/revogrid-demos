import { AssigneePickerProps } from './types';
/** Standalone allocation picker; grid consumers may supply a virtualized body. */
export declare function AssigneePicker(props: AssigneePickerProps): import("preact").JSX.Element;
