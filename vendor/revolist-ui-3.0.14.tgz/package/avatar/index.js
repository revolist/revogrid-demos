import { createPreactElement as e } from "../preact-mount.js";
import { AVATAR_CELL_BACKGROUNDS as t } from "../color-palette/common-palettes.js";
import { jsx as n } from "preact/jsx-runtime";
import { useState as r } from "preact/hooks";
//#region src/avatar/index.view.tsx
function i({ options: e = {} }) {
	let [i, a] = r(!1), { index: o = 0, initials: l, rectangular: d = !1, size: f, value: p } = e, m = [
		"avatar-cell",
		`avatar-cell--${Math.max(o, 0) % t.length}`,
		d ? "avatar-cell--rectangular rectangular" : "",
		u(f),
		e.className
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ n("span", {
		class: m,
		title: e.label || String(p ?? ""),
		role: "img",
		"aria-label": e.ariaLabel || e.label || void 0,
		style: e.style,
		children: c(p) && !i ? /* @__PURE__ */ n("img", {
			class: "avatar-cell__image",
			src: String(p),
			alt: e.label || "",
			onError: () => a(!0)
		}) : l ?? s(p)
	});
}
function a(t, r = {}) {
	return e(t, /* @__PURE__ */ n(i, { options: r }));
}
function o(e = 0) {
	return t[Math.max(e, 0) % t.length];
}
function s(e) {
	return String(e ?? "").split(/\s+/).filter(Boolean).slice(0, 2).map((e) => e[0]?.toUpperCase() ?? "").join("");
}
function c(e) {
	return typeof e == "string" && /^(https?:|data:image\/|blob:|\/|\.\.?\/)/.test(e);
}
function l(e) {
	let t = Number(e);
	return Number.isFinite(t) ? Math.max(t - 1, 0) : 0;
}
function u(e) {
	if (e) return e <= 16 ? "avatar-cell--size-16" : e <= 20 ? "avatar-cell--size-20" : e <= 32 ? "avatar-cell--size-32" : e <= 40 ? "avatar-cell--size-40" : "avatar-cell--size-48";
}
function d(e, n = {}) {
	let { index: r = 0, initials: i, rectangular: a = !1, size: o, value: l } = n, d = c(l), f = u(o), p = {
		class: [
			"avatar-cell",
			`avatar-cell--${Math.max(r, 0) % t.length}`,
			a ? "avatar-cell--rectangular rectangular" : "",
			f,
			n.className
		].filter(Boolean).join(" "),
		title: n.label || String(l ?? "")
	};
	return n.key !== void 0 && (p.key = n.key), n.style !== void 0 && (p.style = n.style), n.ariaLabel !== void 0 && (p["aria-label"] = n.ariaLabel), d ? e("span", p, [e("img", {
		class: "avatar-cell__image",
		src: String(l),
		alt: n.label || ""
	})]) : e("span", p, i ?? s(l));
}
function f(e, t = {}) {
	return e("span", { class: "avatar-cell-with-text" }, [d(e, t), e("span", { class: "avatar-cell-with-text__label" }, String(t.label ?? t.value ?? ""))]);
}
//#endregion
export { t as AVATAR_CELL_BACKGROUNDS, i as AvatarElement, d as avatarTemplate, f as avatarWithTextTemplate, a as createAvatarElement, o as getAvatarCellBackground, l as getAvatarIndex, s as getAvatarInitials };
