import { h } from 'preact';
export { AVATAR_CELL_BACKGROUNDS } from '../color-palette/common-palettes';
export type AvatarTemplateOptions = {
    ariaLabel?: string;
    className?: string;
    index?: number;
    initials?: string;
    key?: string | number;
    label?: string;
    rectangular?: boolean;
    size?: number;
    style?: Record<string, string | number | null | undefined>;
    value?: unknown;
};
/** Shared Preact avatar, including image-error fallback. */
export declare function AvatarElement({ options }: {
    options?: AvatarTemplateOptions;
}): h.JSX.Element;
export declare function createAvatarElement(document: Document, options?: AvatarTemplateOptions): HTMLSpanElement;
export declare function getAvatarCellBackground(index?: number): "linear-gradient(135deg, #7dd3fc, #2563eb)" | "linear-gradient(135deg, #facc15, #b45309)" | "linear-gradient(135deg, #f9a8d4, #be185d)" | "linear-gradient(135deg, #a5b4fc, #4f46e5)" | "linear-gradient(135deg, #86efac, #15803d)" | "linear-gradient(135deg, #fda4af, #be123c)" | "linear-gradient(135deg, #c4b5fd, #7c3aed)" | "linear-gradient(135deg, #fdba74, #c2410c)";
export declare function getAvatarInitials(value: unknown): string;
export declare function getAvatarIndex(value: unknown): number;
export declare function avatarTemplate(h: any, options?: AvatarTemplateOptions): any;
/** Shared avatar-and-label presentation; resource/row lookup stays with consumers. */
export declare function avatarWithTextTemplate(h: any, options?: AvatarTemplateOptions): any;
