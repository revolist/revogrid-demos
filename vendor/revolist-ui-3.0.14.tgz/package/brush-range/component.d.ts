import { h, ComponentChildren } from 'preact';
import { RangeSliderProps } from '../filter/filters/slider/types';
import { DistributionChartProps } from '../distribution-chart';
export interface BrushRangeProps {
    readonly chart?: DistributionChartProps | null;
    readonly slider: RangeSliderProps;
    readonly startLabel: ComponentChildren;
    readonly selectionLabel: ComponentChildren;
    readonly endLabel: ComponentChildren;
    /** Retains the established filter-specific selectors while sharing the markup owner. */
    readonly legacyClassPrefix?: string;
}
/**
 * Shared presentation for distribution-backed brush filters. Domain editors own
 * the chart data and translate slider positions to their filter conditions.
 */
export declare function BrushRange({ chart, slider, startLabel, selectionLabel, endLabel, legacyClassPrefix, }: BrushRangeProps): h.JSX.Element;
