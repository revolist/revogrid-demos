import { PreactRangeSlider as e } from "../filter/filters/slider/preact.js";
import { DistributionChart as t } from "../distribution-chart/index.js";
import { jsx as n, jsxs as r } from "preact/jsx-runtime";
//#region src/brush-range/component.tsx
function i(...e) {
	return e.filter(Boolean).join(" ");
}
function a(e) {
	return typeof e == "string" || typeof e == "number" ? String(e) : void 0;
}
function o({ chart: o, slider: s, startLabel: c, selectionLabel: l, endLabel: u, legacyClassPrefix: d }) {
	let f = (e) => d ? `${d}__${e}` : void 0;
	return /* @__PURE__ */ r("div", {
		class: "brush-range",
		children: [
			o ? /* @__PURE__ */ n(t, {
				...o,
				className: i("brush-range__chart", f("chart"), o.className)
			}) : null,
			/* @__PURE__ */ n(e, {
				...s,
				className: i("brush-range__range", f("range"), s.className),
				controlClassName: i("brush-range__controls", f("controls"), s.controlClassName),
				fromClassName: i(f("lower"), s.fromClassName),
				toClassName: i(f("upper"), s.toClassName)
			}),
			/* @__PURE__ */ r("div", {
				class: i("brush-range__labels", f("labels")),
				children: [
					/* @__PURE__ */ n("span", {
						class: "brush-range__label brush-range__label--start",
						title: a(c),
						children: c
					}),
					/* @__PURE__ */ n("span", {
						class: i("brush-range__label", "brush-range__selection", f("selection")),
						role: "status",
						title: a(l),
						children: l
					}),
					/* @__PURE__ */ n("span", {
						class: "brush-range__label brush-range__label--end",
						title: a(u),
						children: u
					})
				]
			})
		]
	});
}
//#endregion
export { o as BrushRange };
