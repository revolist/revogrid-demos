export declare const DeleteButton: ({ onClick, disabled, className, onMouseDown, onDblClick, locale, }: {
    onClick: (e: MouseEvent) => void;
    disabled?: boolean;
    onMouseDown?: (event: MouseEvent) => void;
    onDblClick?: (event: MouseEvent) => void;
    className?: string;
    locale?: {
        title?: string;
        ariaLabel?: string;
    };
}) => any;
