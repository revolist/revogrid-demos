export { t as DeleteButton } from "../_chunks/delete-button-DnpmDNEJ.js";
