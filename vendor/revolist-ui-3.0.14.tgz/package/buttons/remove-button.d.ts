import { h } from 'preact';
import { DeleteButton } from './delete-button';
export type RemoveButtonProps = Parameters<typeof DeleteButton>[0] & {
    /** Compact hit area for an action embedded inside a selected-value chip. */
    compact?: boolean;
};
/** Neutral close/remove action; DeleteButton keeps its legacy danger variant. */
export declare function RemoveButton({ compact, className, ...props }: RemoveButtonProps): h.JSX.Element;
