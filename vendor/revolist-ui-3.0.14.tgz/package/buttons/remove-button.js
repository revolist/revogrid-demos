import { t as e } from "../_chunks/delete-button-DnpmDNEJ.js";
import { jsx as t } from "preact/jsx-runtime";
//#region src/buttons/remove-button.tsx
function n({ compact: n = !1, className: r = "", ...i }) {
	return /* @__PURE__ */ t(e, {
		...i,
		className: `rv-remove-button${n ? " rv-remove-button--compact" : ""} ${r}`
	});
}
//#endregion
export { n as RemoveButton };
