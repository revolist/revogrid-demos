import { h, ComponentChildren, JSX } from 'preact';
export interface SvgButtonProps extends Omit<JSX.IntrinsicElements['button'], 'className' | 'children'> {
    readonly label: string;
    readonly busy?: boolean;
    /** Explicit variants retain shared appearance when consumer classes are supplied. */
    readonly variant?: 'link' | 'ghost' | 'solid';
    readonly badge?: string | number;
    readonly badgeClassName?: string;
    readonly icon?: string;
    readonly iconContent?: ComponentChildren;
    readonly visibleLabel?: string;
    readonly className?: string;
    readonly iconClassName?: string;
    readonly labelClassName?: string;
    readonly children?: ComponentChildren;
}
/** Shared native button presentation for trusted bundled SVG controls. */
export declare function SvgButton({ label, variant, icon, visibleLabel, className, iconClassName, labelClassName, children, iconContent, badge, badgeClassName, class: nativeClass, disabled, ...attributes }: SvgButtonProps): h.JSX.Element;
