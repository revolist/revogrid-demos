import { controlClassName as e } from "../control-presentation.js";
import { ButtonControl as t } from "../native-control.js";
import { n } from "../_chunks/control-tooltip-DYksNy2m.js";
import { SvgIcon as r } from "../icons/icon.js";
import { jsx as i, jsxs as a } from "preact/jsx-runtime";
//#region src/buttons/svg-button.tsx
function o({ label: o, variant: s, icon: c, visibleLabel: l, className: u, iconClassName: d, labelClassName: f, children: p, iconContent: m, badge: h, badgeClassName: g = "", class: _, disabled: v, ...y }) {
	let b = n(o, !0, {
		className: "rv-control-tooltip",
		placement: "above"
	});
	return /* @__PURE__ */ a(t, {
		type: "button",
		title: v ? void 0 : o,
		"aria-label": h === void 0 ? o : `${o} ${h}`,
		...y,
		disabled: v,
		...v ? b.triggerProps : {},
		class: e(u ?? (s ? "" : "rv-btn-ghost"), s && `rv-btn-${s}`, _, "rv-icon-action", !l && "rv-btn-icon"),
		children: [
			c ? /* @__PURE__ */ i(r, {
				svg: c,
				className: d
			}) : m,
			l ? /* @__PURE__ */ i("span", {
				class: f,
				children: l
			}) : null,
			h !== void 0 && /* @__PURE__ */ i("span", {
				class: `rv-badge ${g}`,
				"aria-hidden": "true",
				children: h
			}),
			p,
			v ? b.tooltip : /* @__PURE__ */ i("span", {
				class: "rv-control-tooltip",
				"aria-hidden": "true",
				children: o
			})
		]
	});
}
//#endregion
export { o as SvgButton };
