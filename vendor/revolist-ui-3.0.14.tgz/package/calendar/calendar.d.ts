import { h } from 'preact';
import { CalendarProps } from './types';
export declare function Calendar({ locale, weekStartsOn, showOutsideDays, allowOutsideMonthSelection, fixedWeeks, showTodayButton, showHeader, showNavigation, showPreviousButton, showNextButton, showMonthLabel, showWeekdays, enableYearView, translations, ...props }: CalendarProps): h.JSX.Element;
