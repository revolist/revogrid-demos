import { h } from 'preact';
import { ISODateString, DisplayCalendarSystem } from '../_shared/dates/index';
import { CalendarProps, CalendarTranslations } from './types';
export declare function CalendarCaption({ month, system, locale, layout, start, end, disabled, labels, onChange, }: {
    month: ISODateString;
    system: DisplayCalendarSystem;
    locale: string;
    layout: CalendarProps['captionLayout'];
    start?: ISODateString;
    end?: ISODateString;
    disabled?: boolean;
    labels: CalendarTranslations;
    onChange: (month: ISODateString) => void;
}): h.JSX.Element;
