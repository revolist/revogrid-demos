import { h, ComponentChildren } from 'preact';
import { ISODateString } from '../_shared/dates/index';
export interface CalendarDayProps {
    readonly date: ISODateString;
    readonly label: string;
    readonly className?: string;
    readonly outside: boolean;
    readonly hidden: boolean;
    readonly disabled: boolean;
    readonly focused: boolean;
    readonly selected: boolean;
    readonly previewed: boolean;
    readonly previewInvalid?: boolean;
    readonly previewDescriptionId?: string;
    readonly rangeStart: boolean;
    readonly rangeEnd: boolean;
    readonly previewStart: boolean;
    readonly previewEnd: boolean;
    readonly today: boolean;
    readonly content?: ComponentChildren;
    readonly setRef: (date: ISODateString, element: HTMLButtonElement | null) => void;
    readonly onFocus: (date: ISODateString) => void;
    readonly onPreview: (date?: ISODateString) => void;
    readonly onKeyDown: (event: h.JSX.TargetedKeyboardEvent<HTMLButtonElement>, date: ISODateString) => void;
    readonly onSelect: (date: ISODateString) => void;
}
export declare function CalendarDay(props: CalendarDayProps): h.JSX.Element;
