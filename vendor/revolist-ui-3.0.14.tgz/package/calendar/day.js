import { c as e } from "../_chunks/iso-B0YHBK7m.js";
import { jsx as t } from "preact/jsx-runtime";
//#region src/calendar/day.tsx
function n(n) {
	let r = [
		"revo-calendar__day",
		n.className,
		n.outside && "outside",
		n.disabled && "disabled",
		n.selected && "in-range",
		n.previewed && "in-preview",
		n.previewInvalid && "in-invalid-preview",
		n.rangeStart && "range-start",
		n.rangeEnd && "range-end",
		n.previewStart && "preview-start",
		n.previewEnd && "preview-end"
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ t("button", {
		ref: (e) => n.setRef(n.date, e),
		type: "button",
		role: "gridcell",
		"data-calendar-date": n.date,
		class: r,
		disabled: n.disabled || n.hidden,
		tabIndex: !n.hidden && n.focused ? 0 : -1,
		"aria-hidden": n.hidden || void 0,
		"aria-selected": n.selected || void 0,
		"aria-invalid": n.previewInvalid || void 0,
		"aria-describedby": n.previewInvalid ? n.previewDescriptionId : void 0,
		"aria-current": n.today ? "date" : void 0,
		"aria-label": n.label,
		onFocus: () => {
			n.onFocus(n.date), n.onPreview(n.date);
		},
		onMouseEnter: () => n.onPreview(n.date),
		onMouseLeave: () => n.onPreview(),
		onKeyDown: (e) => n.onKeyDown(e, n.date),
		onClick: () => n.onSelect(n.date),
		children: n.content ?? e(n.date).getUTCDate()
	});
}
//#endregion
export { n as CalendarDay };
