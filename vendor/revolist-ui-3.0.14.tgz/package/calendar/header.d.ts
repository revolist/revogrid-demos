import { h, ComponentChildren } from 'preact';
import { ISODateString } from '../_shared/dates/index';
export declare function CalendarHeader({ label, previousLabel, nextLabel, labelAction, caption, showLabel, showPrevious, showNext, previousDisabled, nextDisabled, onPrevious, onNext, }: {
    label: string;
    previousLabel: string;
    nextLabel: string;
    caption?: ComponentChildren;
    labelAction?: {
        ariaLabel: string;
        onClick: () => void;
    };
    showLabel?: boolean;
    showPrevious?: boolean;
    showNext?: boolean;
    previousDisabled?: boolean;
    nextDisabled?: boolean;
    onPrevious: () => void;
    onNext: () => void;
}): h.JSX.Element;
export declare function CalendarWeekdays({ dates, locale, format, weekNumberLabel, }: {
    dates: readonly ISODateString[];
    weekNumberLabel?: string;
    locale: string;
    format: (date: ISODateString, locale: string) => string;
}): h.JSX.Element;
