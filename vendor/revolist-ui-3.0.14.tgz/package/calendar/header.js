export { t as CalendarHeader, n as CalendarWeekdays } from "../_chunks/header-ChgiwXiD.js";
