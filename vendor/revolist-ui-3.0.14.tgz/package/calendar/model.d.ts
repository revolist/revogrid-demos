import { DisplayCalendarSystem, ISODateString } from '../_shared/dates/index';
import { CalendarDateRange, CalendarWeekStart, MoveCalendarFocusOptions } from './types';
export declare function createCalendarMonth(month: ISODateString, weekStartsOn: CalendarWeekStart, fixedWeeks?: boolean, system?: DisplayCalendarSystem): readonly ISODateString[];
export declare function orderCalendarRange(from: ISODateString, to: ISODateString): CalendarDateRange;
export declare function isDateInCalendarRange(date: ISODateString, range?: CalendarDateRange): boolean;
export declare function isCalendarDateDisabled(date: ISODateString, options: Pick<MoveCalendarFocusOptions, 'minDate' | 'maxDate' | 'isDisabled'>): boolean;
export declare function isCalendarMonthDisabled(month: ISODateString, options: Pick<MoveCalendarFocusOptions, 'minDate' | 'maxDate'> & {
    readonly isMonthDisabled?: (month: ISODateString) => boolean;
    readonly calendarSystem?: DisplayCalendarSystem;
}): boolean;
export declare function moveCalendarFocus(options: MoveCalendarFocusOptions): ISODateString | undefined;
