import { f as e, i as t } from "../_chunks/model-mPO2tG2f.js";
import { CalendarDay as n } from "./day.js";
import { jsx as r, jsxs as i } from "preact/jsx-runtime";
//#region src/calendar/month-grid.tsx
function a({ dates: a, system: o = "gregory", selectedDates: s, visibleMonths: c, weekNumber: l, weekNumberLabel: u = "Week number", month: d, focusedDate: f, referenceDate: p, selection: m, preview: h, previewInvalid: g, previewDescriptionId: _, showOutsideDays: v, allowOutsideMonthSelection: y, dayClassName: b, renderDay: x, isDisabled: S, formatDayLabel: C, setDayRef: w, onFocus: T, onPreview: E, onKeyDown: D, onSelect: O }) {
	return /* @__PURE__ */ r("div", {
		class: "revo-calendar__month-grid",
		children: Array.from({ length: a.length / 7 }, (k, A) => /* @__PURE__ */ i("div", {
			class: "revo-calendar__week",
			role: "row",
			"aria-hidden": !l && a.slice(A * 7, A * 7 + 7).every((t) => e(t, o) !== d && (!v || c?.includes(e(t, o)))) || void 0,
			children: [l && /* @__PURE__ */ r("span", {
				class: "revo-calendar__week-number",
				role: "rowheader",
				"aria-label": `${u} ${l(a[A * 7])}`,
				children: l(a[A * 7])
			}), a.slice(A * 7, A * 7 + 7).map((i) => {
				let a = e(i, o) !== d, l = a && (!v || !!c?.includes(e(i, o))), u = S(i) || a && !y, k = {
					outside: a,
					disabled: u,
					selected: !!s?.includes(i) || t(i, m),
					previewed: t(i, h),
					today: i === p
				};
				return /* @__PURE__ */ r(n, {
					date: i,
					label: C(i),
					className: typeof b == "function" ? b(i, k) : b,
					outside: a,
					hidden: l,
					disabled: u,
					focused: i === f,
					selected: k.selected,
					previewed: k.previewed,
					previewInvalid: k.previewed && g,
					previewDescriptionId: _,
					rangeStart: s?.includes(i) || m?.from === i,
					rangeEnd: s?.includes(i) || m?.to === i,
					previewStart: h?.from === i,
					previewEnd: h?.to === i,
					today: k.today,
					content: x?.(i, k),
					setRef: (e, t) => {
						a || w(e, t);
					},
					onFocus: T,
					onPreview: E,
					onKeyDown: D,
					onSelect: O
				}, i);
			})]
		}, A))
	});
}
//#endregion
export { a as CalendarMonthGrid };
