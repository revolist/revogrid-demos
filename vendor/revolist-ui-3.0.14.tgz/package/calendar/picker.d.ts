import { h } from 'preact';
import { ISODateString } from '../_shared/dates/index';
import { CalendarProps } from './types';
export interface CalendarRangeSelection {
    readonly from: ISODateString;
    readonly to?: ISODateString;
}
type Base = Omit<CalendarProps, 'month' | 'focusedDate' | 'selection' | 'preview' | 'previewInvalid' | 'previewDescription' | 'selectedDates' | 'onSelect' | 'onMonthChange' | 'onFocusedDateChange' | 'onPreviewDateChange' | 'presets' | 'onPresetSelect'> & {
    readonly month?: ISODateString;
    readonly defaultMonth?: ISODateString;
    readonly onMonthChange?: (month: ISODateString) => void;
    readonly required?: boolean;
    /** Multiple: selected dates. Range: nights. */
    readonly min?: number;
    readonly max?: number;
    readonly excludeDisabled?: boolean;
};
type Preset<T> = {
    readonly label: string;
    readonly selection: T;
};
export type CalendarPickerProps = Base & ({
    readonly mode?: 'single';
    readonly selected?: ISODateString;
    readonly onSelectionChange: (value: ISODateString | undefined) => void;
    readonly presets?: readonly Preset<ISODateString>[];
} | {
    readonly mode: 'multiple';
    readonly selected?: readonly ISODateString[];
    readonly onSelectionChange: (value: readonly ISODateString[]) => void;
    readonly presets?: readonly Preset<readonly ISODateString[]>[];
} | {
    readonly mode: 'range';
    readonly selected?: CalendarRangeSelection;
    readonly onSelectionChange: (value: CalendarRangeSelection | undefined) => void;
    readonly presets?: readonly Preset<CalendarRangeSelection>[];
});
/** Controlled selection composition over the compatible low-level Calendar. */
export declare function CalendarPicker(props: CalendarPickerProps): h.JSX.Element;
export {};
