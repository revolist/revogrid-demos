import { CalendarTranslations } from './types';
/** Complete English fallback used when a consumer does not override independent calendar text. */
export declare const DEFAULT_CALENDAR_TRANSLATIONS: Readonly<Required<CalendarTranslations>>;
