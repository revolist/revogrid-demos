//#region src/calendar/translations.ts
var e = Object.freeze({
	previousMonth: "Previous month",
	nextMonth: "Next month",
	previousYear: "Previous year",
	nextYear: "Next year",
	chooseMonth: "Choose month",
	chooseYear: "Choose year",
	weekNumber: "Week number",
	calendar: "Calendar",
	today: "Today",
	invalidSelection: "This date cannot be selected."
});
//#endregion
export { e as DEFAULT_CALENDAR_TRANSLATIONS };
