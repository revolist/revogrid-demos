import { h } from 'preact';
import { DisplayCalendarSystem, ISODateString } from '../_shared/dates/index';
export declare function CalendarYearGrid({ month, system, referenceDate, minDate, maxDate, isMonthDisabled, locale, ariaLabel, onSelect, onEscape, }: {
    month: ISODateString;
    system?: DisplayCalendarSystem;
    referenceDate?: ISODateString;
    minDate?: ISODateString;
    maxDate?: ISODateString;
    isMonthDisabled?: (month: ISODateString) => boolean;
    locale: string;
    ariaLabel: string;
    onSelect: (month: ISODateString) => void;
    onEscape: () => void;
}): h.JSX.Element;
