import { f as e, l as t, r as n, u as r } from "../_chunks/model-mPO2tG2f.js";
import { jsx as i } from "preact/jsx-runtime";
//#region src/calendar/year-grid.tsx
function a({ month: a, system: o = "gregory", referenceDate: s, minDate: c, maxDate: l, isMonthDisabled: u, locale: d, ariaLabel: f, onSelect: p, onEscape: m }) {
	let h = t(a, o);
	return /* @__PURE__ */ i("div", {
		class: "revo-calendar__year-grid",
		role: "group",
		"aria-label": f,
		onKeyDown: (e) => {
			e.key === "Escape" && (e.preventDefault(), m());
		},
		children: h.map((t) => {
			let f = n(t, {
				minDate: c,
				maxDate: l,
				isMonthDisabled: u,
				calendarSystem: o
			}), m = t === a, h = s ? e(s, o) === t : !1;
			return /* @__PURE__ */ i("button", {
				type: "button",
				class: `revo-calendar__month${m ? " active" : ""}${h ? " current" : ""}`,
				"data-calendar-month": t,
				"aria-pressed": m ? "true" : "false",
				disabled: f,
				onClick: () => p(t),
				children: r(t, d, { month: "long" }, o)
			}, t);
		})
	});
}
//#endregion
export { a as CalendarYearGrid };
