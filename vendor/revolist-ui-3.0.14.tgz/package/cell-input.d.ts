/** Compact native input presentation for grid-hosted editors. */
export declare function cellInputProps<T extends Record<string, unknown>>(attributes: T): {
    type: string;
    enterKeyHint: string;
} & T & {
    class: string;
};
