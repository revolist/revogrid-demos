//#region src/cell-input.ts
function e(e) {
	return {
		type: "text",
		enterKeyHint: "enter",
		...e,
		class: "rv-cell-input"
	};
}
//#endregion
export { e as cellInputProps };
