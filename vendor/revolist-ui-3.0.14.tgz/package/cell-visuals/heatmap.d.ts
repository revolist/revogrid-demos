import { ElementFactory } from './types';
export declare function renderHeatmap(h: ElementFactory, options: {
    value: unknown;
    minValue?: number;
    maxValue?: number;
    midValue?: number;
    colorMap?: 'heatmap' | 'coldmap';
    lowColor?: string;
    midColor?: string;
    highColor?: string;
}): any;
