import { ElementFactory, ValueClasses } from './types';
export declare function renderMiniBarChart(h: ElementFactory, options: {
    value: unknown;
    minValue?: number;
    maxValue?: number;
    barPosition?: 'top' | 'bottom';
    classesForValue?: ValueClasses;
}): any;
