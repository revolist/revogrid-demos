import { ElementFactory } from './types';
export interface PieData {
    value: number;
    color?: string;
    name?: string;
}
export declare function renderPie(h: ElementFactory, value?: readonly PieData[] | readonly number[], options?: {
    size?: number;
    labelFont?: string;
    ariaLabel?: string;
}): any;
