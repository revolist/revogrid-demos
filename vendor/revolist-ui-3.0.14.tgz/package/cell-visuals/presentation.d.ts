import { ElementFactory } from './types';
export declare function renderProgressLine(h: ElementFactory, options: {
    percent: number;
    label: string;
    classes?: Record<string, boolean>;
}): any;
export declare function renderProgressLineValue(h: ElementFactory, options: {
    percent: number;
    label: string;
    classes?: Record<string, boolean>;
}): any;
export declare function renderBadgeValue(h: ElementFactory, options: {
    value: unknown;
    backgroundColor?: string;
    color?: string;
    isDefault?: boolean;
    rectangular?: boolean;
    classes?: Record<string, boolean>;
}): any;
export declare function renderChange(h: ElementFactory, options: {
    value: number;
    label: unknown;
    classes?: Record<string, boolean>;
}): any;
export declare function renderThumbs(h: ElementFactory, value: boolean, labels?: {
    true: string;
    false: string;
}): any;
export declare function renderTypeIcon(h: ElementFactory, options: {
    icon: string;
    className: string;
    title: string;
}): any;
export declare function renderLabelledIcon(h: ElementFactory, options: {
    icon: unknown;
    label: string;
}): any;
export declare function renderPercentageSummary(h: ElementFactory, items: readonly {
    label: string;
    count: number;
    percentage: number;
    other?: boolean;
}[]): any;
export declare function renderAggregateSummary(h: ElementFactory, items: readonly string[]): any;
