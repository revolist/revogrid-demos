import { ElementFactory, ValueClasses } from './types';
export declare function renderSparkline(h: ElementFactory, options: {
    value: unknown;
    minValue?: number;
    maxValue?: number;
    ariaLabel?: string | ((values: readonly number[]) => string);
    classesForValue?: ValueClasses;
}): any;
