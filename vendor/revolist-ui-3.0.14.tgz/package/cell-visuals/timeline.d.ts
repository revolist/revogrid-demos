import { ElementFactory } from './types';
export interface TimelineEvent {
    readonly start: number;
    readonly end: number;
    readonly label?: string;
}
/**
 * Converts valid Timeline events to the same readable text used by tooltips
 * and accessibility labels.
 *
 * @param value Timeline event array; invalid entries are ignored.
 * @param separator Text inserted between valid event descriptions.
 * @returns A human-readable schedule, or an empty string when no event is valid.
 *
 * @example
 * formatTimelineEvents([
 *   { start: 8, end: 12, label: 'Build' },
 *   { start: 14, end: 18, label: 'Review' },
 * ], '; ');
 * // "Build: 8–12; Review: 14–18"
 */
export declare function formatTimelineEvents(value: unknown, separator?: string): string;
export declare function renderTimeline(h: ElementFactory, options: {
    value: unknown;
    range?: {
        start: number;
        end: number;
    };
    ariaLabel?: string | ((events: readonly TimelineEvent[]) => string);
}): any;
