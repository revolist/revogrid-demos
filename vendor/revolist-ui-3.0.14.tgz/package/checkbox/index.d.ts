export declare const SHARED_CHECKBOX_CLASS = "rv-checkbox";
export type SharedCheckboxAttributes = Record<string, unknown> & {
    class?: string;
    className?: string;
};
type PreactH = typeof import('preact').h;
type PreactVNode = import('preact').VNode;
export type CheckboxProps = Omit<SharedCheckboxAttributes, 'onChange'> & {
    checked?: boolean;
    indeterminate?: boolean;
    label?: any;
    description?: any;
    ariaLabel?: string;
    controlClassName?: string;
    inputRef?: (input: HTMLInputElement | null) => void;
    onChange?: (checked: boolean, event: Event & {
        currentTarget: HTMLInputElement;
    }) => void;
};
/**
 * Render the shared native checkbox while keeping the caller's renderer and
 * event semantics. This works with both RevoGrid/Stencil templates and Preact.
 */
export declare function renderCheckbox(h: PreactH, attributes?: SharedCheckboxAttributes): PreactVNode;
export declare function renderCheckbox<T>(h: (nodeName: any, attributes: any) => T, attributes?: SharedCheckboxAttributes): T;
/**
 * Preact adapter for the shared checkbox presentation. The native input stays
 * the interaction owner; the adapter only normalizes indeterminate state and
 * optional label/description composition.
 */
export declare function Checkbox({ checked, indeterminate, label, description, ariaLabel, controlClassName, inputRef, onChange, ...attributes }: CheckboxProps): any;
export {};
