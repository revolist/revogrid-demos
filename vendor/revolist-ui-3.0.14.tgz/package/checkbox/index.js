import { renderControl as e } from "../control-presentation.js";
import { h as t } from "preact";
//#region src/checkbox/index.ts
var n = "rv-checkbox";
function r(t, r = {}) {
	let { class: i, className: a, ...o } = r, s = [
		n,
		i,
		a
	].filter(Boolean).join(" ");
	return e(t, "input", {
		...o,
		class: s,
		type: "checkbox"
	});
}
function i({ checked: e, indeterminate: n = !1, label: i, description: a, ariaLabel: o, controlClassName: s = "", inputRef: c, onChange: l, ...u }) {
	let d = r(t, {
		...u,
		checked: e,
		"aria-label": o,
		"aria-checked": n ? "mixed" : !!e,
		ref: (e) => {
			e && (e.indeterminate = n), c?.(e);
		},
		onChange: (e) => {
			l?.(e.currentTarget.checked, e);
		}
	});
	return i === void 0 && a === void 0 ? d : t("label", { class: `rv-checkbox-control ${s}`.trim() }, [d, t("span", { class: "rv-checkbox-control__copy" }, [i === void 0 ? null : t("span", { class: "rv-checkbox-control__label" }, i), a === void 0 ? null : t("span", { class: "rv-checkbox-control__description" }, a)])]);
}
//#endregion
export { i as Checkbox, n as SHARED_CHECKBOX_CLASS, r as renderCheckbox };
