import { h, ComponentChildren, JSX } from 'preact';
export type ChoiceChipValue = string | number;
export type ChoiceChipOption<T extends ChoiceChipValue = ChoiceChipValue> = {
    value: T;
    label: any;
    color?: string;
    ariaLabel?: string;
    title?: string;
    disabled?: boolean;
    className?: string;
    style?: any;
    testId?: string;
    info?: ComponentChildren;
    onRemove?: () => void;
    removeLabel?: string;
};
export type ChoiceChipsProps<T extends ChoiceChipValue = ChoiceChipValue> = {
    value?: T | readonly T[];
    options: readonly ChoiceChipOption<T>[];
    onChange: (value: T, option: ChoiceChipOption<T>) => void;
    ariaLabel: string;
    appearance?: 'soft' | 'outlined';
    size?: 'small' | 'medium';
    className?: string;
    itemClassName?: string;
    disabled?: boolean;
    testId?: string;
};
/** Shared wrapping choice control for compact presets and granularities. */
export declare function ChoiceChips<T extends ChoiceChipValue = ChoiceChipValue>({ value, options, onChange, ariaLabel, appearance, size, className, itemClassName, disabled, testId, }: ChoiceChipsProps<T>): any;
export declare function ChoiceChipInfoButton({ 'data-tooltip': details, title, ref: forwardedRef, ...props }: JSX.IntrinsicElements['button'] & {
    'data-tooltip'?: string;
}): h.JSX.Element;
/** Optional actions are siblings of the selection button, never nested buttons. */
export declare function ChoiceChip({ children, color, selected, onSelect, info, onRemove, removeLabel, removeClassName, className, disabled, ...props }: Omit<JSX.IntrinsicElements['button'], 'onSelect' | 'children'> & {
    children: ComponentChildren;
    color?: string;
    selected?: boolean;
    onSelect?: JSX.MouseEventHandler<HTMLButtonElement>;
    info?: ComponentChildren;
    onRemove?: () => void;
    removeLabel?: string;
    removeClassName?: string;
}): h.JSX.Element;
