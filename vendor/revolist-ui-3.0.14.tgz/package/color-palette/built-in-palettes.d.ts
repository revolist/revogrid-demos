export interface BuiltInColorPalette {
    readonly id: string;
    readonly title: string;
    readonly usage: string;
    readonly colors: Readonly<Record<string, string>>;
    readonly consumers: readonly string[];
}
/** One catalog for Sass generation, auditing, and the Colors reference page. */
export declare const builtInColorPalettes: readonly BuiltInColorPalette[];
