import { commonPalettes as e } from "./common-palettes.js";
import { platformPalettes as t } from "./platform-palettes.js";
import { proPalettes as n } from "./pro-palettes.js";
import { chartPalettes as r } from "./chart-palettes.js";
import { pivotPalettes as i } from "./pivot-palettes.js";
import { ganttPalettes as a } from "./gantt-palettes.js";
import { schedulerPalettes as o } from "./scheduler-palettes.js";
//#region src/color-palette/built-in-palettes.ts
var s = [
	...e,
	...t,
	...n,
	...r,
	...i,
	...a,
	...o
];
//#endregion
export { s as builtInColorPalettes };
