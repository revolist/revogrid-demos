/** Built-in colors; preserve concrete values for portable drawings and persisted defaults. */
export declare const CHART_SERIES_COLORS: {
    readonly violet: "#6647f0";
    readonly orange: "#fc6d2d";
    readonly blue: "#0091ff";
    readonly magenta: "#ff02f0";
    readonly teal: "#00b8a6";
    readonly yellow: "#f5b700";
    readonly pink: "#e14b8d";
    readonly indigo: "#6c78f4";
};
export declare const CHART_THEME_LIGHT: {
    readonly background: "#ffffff";
    readonly foreground: "#171717";
    readonly muted: "#666666";
    readonly grid: "#e0e0e0";
};
export declare const CHART_THEME_DARK: {
    readonly background: "#1b1b1f";
    readonly foreground: "#f5f5f5";
    readonly muted: "#a3a3a3";
    readonly grid: "#404040";
};
export declare const CHART_GEOGRAPHIC_COLORS: {
    readonly markLight: "#4285d4";
    readonly markDark: "#60a5fa";
    readonly heatLight: "#e8590c";
    readonly heatDark: "#fb923c";
};
export declare const CHART_DRAWING_COLORS: {
    readonly black: "#000000";
    readonly white: "#ffffff";
    readonly annotation: "white";
    readonly textFallback: "#171717";
};
export declare const chartPalettes: readonly [{
    readonly id: "chart-series";
    readonly title: "Chart series";
    readonly usage: "Ordered categorical series defaults; public DEFAULT_PALETTE retains its original order.";
    readonly colors: {
        readonly violet: "#6647f0";
        readonly orange: "#fc6d2d";
        readonly blue: "#0091ff";
        readonly magenta: "#ff02f0";
        readonly teal: "#00b8a6";
        readonly yellow: "#f5b700";
        readonly pink: "#e14b8d";
        readonly indigo: "#6c78f4";
    };
    readonly consumers: readonly ["Charts renderer DEFAULT_PALETTE", "Charts WebGL focus"];
}, {
    readonly id: "chart-theme-light";
    readonly title: "Chart drawing · light";
    readonly usage: "Portable drawing surfaces, text, muted labels and grid lines.";
    readonly colors: {
        readonly background: "#ffffff";
        readonly foreground: "#171717";
        readonly muted: "#666666";
        readonly grid: "#e0e0e0";
    };
    readonly consumers: readonly ["Charts renderer theme", "Pivot chart theme"];
}, {
    readonly id: "chart-theme-dark";
    readonly title: "Chart drawing · dark";
    readonly usage: "Portable dark drawing surfaces, text, muted labels and grid lines.";
    readonly colors: {
        readonly background: "#1b1b1f";
        readonly foreground: "#f5f5f5";
        readonly muted: "#a3a3a3";
        readonly grid: "#404040";
    };
    readonly consumers: readonly ["Charts renderer theme", "Pivot chart theme"];
}, {
    readonly id: "chart-geographic";
    readonly title: "Geographic layers";
    readonly usage: "Default map markers and heat colors for light and dark charts.";
    readonly colors: {
        readonly markLight: "#4285d4";
        readonly markDark: "#60a5fa";
        readonly heatLight: "#e8590c";
        readonly heatDark: "#fb923c";
    };
    readonly consumers: readonly ["Charts geographic renderer"];
}, {
    readonly id: "chart-drawing";
    readonly title: "Chart drawing primitives";
    readonly usage: "Contrast text, SVG annotations, organization shadows.";
    readonly colors: {
        readonly black: "#000000";
        readonly white: "#ffffff";
        readonly annotation: "white";
        readonly textFallback: "#171717";
    };
    readonly consumers: readonly ["Charts annotations and analysis", "Charts treemap labels", "Charts organization shadows"];
}];
