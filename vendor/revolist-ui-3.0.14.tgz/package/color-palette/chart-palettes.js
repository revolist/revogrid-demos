import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/chart-palettes.ts
var t = {
	violet: e.hex6647f0,
	orange: e.hexfc6d2d,
	blue: e.hex0091ff,
	magenta: e.hexff02f0,
	teal: e.hex00b8a6,
	yellow: e.hexf5b700,
	pink: e.hexe14b8d,
	indigo: e.hex6c78f4
}, n = {
	background: e.white,
	foreground: e.hex171717,
	muted: e.hex666666,
	grid: e.hexe0e0e0
}, r = {
	background: e.hex1b1b1f,
	foreground: e.hexf5f5f5,
	muted: e.hexa3a3a3,
	grid: e.hex404040
}, i = {
	markLight: e.hex4285d4,
	markDark: e.hex60a5fa,
	heatLight: e.hexe8590c,
	heatDark: e.hexfb923c
}, a = {
	black: e.black,
	white: e.white,
	annotation: e.watermarkForeground,
	textFallback: e.hex171717
}, o = [
	{
		id: "chart-series",
		title: "Chart series",
		usage: "Ordered categorical series defaults; public DEFAULT_PALETTE retains its original order.",
		colors: t,
		consumers: ["Charts renderer DEFAULT_PALETTE", "Charts WebGL focus"]
	},
	{
		id: "chart-theme-light",
		title: "Chart drawing · light",
		usage: "Portable drawing surfaces, text, muted labels and grid lines.",
		colors: n,
		consumers: ["Charts renderer theme", "Pivot chart theme"]
	},
	{
		id: "chart-theme-dark",
		title: "Chart drawing · dark",
		usage: "Portable dark drawing surfaces, text, muted labels and grid lines.",
		colors: r,
		consumers: ["Charts renderer theme", "Pivot chart theme"]
	},
	{
		id: "chart-geographic",
		title: "Geographic layers",
		usage: "Default map markers and heat colors for light and dark charts.",
		colors: i,
		consumers: ["Charts geographic renderer"]
	},
	{
		id: "chart-drawing",
		title: "Chart drawing primitives",
		usage: "Contrast text, SVG annotations, organization shadows.",
		colors: a,
		consumers: [
			"Charts annotations and analysis",
			"Charts treemap labels",
			"Charts organization shadows"
		]
	}
];
//#endregion
export { a as CHART_DRAWING_COLORS, i as CHART_GEOGRAPHIC_COLORS, t as CHART_SERIES_COLORS, r as CHART_THEME_DARK, n as CHART_THEME_LIGHT, o as chartPalettes };
