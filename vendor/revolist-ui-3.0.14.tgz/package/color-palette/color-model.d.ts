export declare function normalizeHexColor(value: string | undefined): string | undefined;
/** Same keyboard order for native and Preact palette adapters. */
export declare function handleColorPaletteKeyDown(event: KeyboardEvent): void;
