import { h } from 'preact';
import { ColorPaletteOption, ColorPaletteValue } from './palette';
export * from './palette';
export interface ColorPaletteProps {
    readonly value: ColorPaletteValue;
    readonly options?: readonly ColorPaletteOption[];
    readonly ariaLabel: string;
    readonly defaultLabel: string;
    readonly colorAriaLabel: (option: ColorPaletteOption) => string;
    readonly disabled?: boolean;
    readonly includeDefault?: boolean;
    readonly defaultDisabled?: boolean;
    readonly onChange: (value: ColorPaletteValue) => void;
}
export declare function ColorPalette({ value, options, ariaLabel, defaultLabel, colorAriaLabel, disabled, includeDefault, defaultDisabled, onChange, }: ColorPaletteProps): h.JSX.Element;
