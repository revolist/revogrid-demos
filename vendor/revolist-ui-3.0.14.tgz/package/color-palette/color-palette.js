import { t as e } from "../_chunks/color-palette-B2-d_Iss.js";
import { DEFAULT_COLOR_PALETTE_OPTIONS as t } from "./palette.js";
export { e as ColorPalette, t as DEFAULT_COLOR_PALETTE_OPTIONS };
