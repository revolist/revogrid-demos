export declare const COLOR_PICKER_DEFAULT_COLOR: "#2563eb";
export declare const COLOR_PICKER_HEX_LENGTH = 7;
