import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/color-picker.constants.ts
var t = e.blue600, n = 7;
//#endregion
export { t as COLOR_PICKER_DEFAULT_COLOR, n as COLOR_PICKER_HEX_LENGTH };
