import { h } from 'preact';
export declare function ColorPicker({ label, value, defaultLabel, customLabel, customHexLabel, invalidColor, colorLabels, optional, allowHexInput, disabled, onChange, }: {
    readonly label: string;
    readonly value?: string;
    readonly defaultLabel: string;
    readonly customLabel: string;
    readonly customHexLabel?: string;
    readonly invalidColor?: string;
    readonly colorLabels: Readonly<Record<string, string>>;
    readonly optional?: boolean;
    /** Set false for a selection-only palette and native color chooser. */
    readonly allowHexInput?: boolean;
    readonly disabled?: boolean;
    readonly onChange: (value: string | undefined) => void;
}): h.JSX.Element;
export { normalizeHexColor } from './color-model';
