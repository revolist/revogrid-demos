export { createControlId as createColorPickerId } from "../core/control-id.js";
