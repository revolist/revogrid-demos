import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/gantt-palettes.ts
var t = { "rv-panel-accent": e.hex3f8f7d }, n = {
	"neutral-text": e.hex475569,
	"complete-text": e.hex047857,
	"late-text": e.hexb91c1c,
	"neutral-bg": e.hexf8fafc,
	"neutral-border": e.hexcbd5e1,
	"in-progress-bg": e.hexeff6ff,
	"in-progress-border": e.hexbfdbfe,
	"in-progress-text": e.blue600,
	"complete-bg": e.hexecfdf5,
	"complete-border": e.hexa7f3d0,
	"blocked-bg": e.hexfef2f2,
	"blocked-border": e.hexfecaca,
	"neutral-dark-bg": e.rgba_148_163_184_0_14,
	"neutral-dark-border": e.rgba_148_163_184_0_36,
	"neutral-dark-text": e.hexcbd5e1,
	"in-progress-dark-bg": e.rgba_37_99_235_0_18,
	"in-progress-dark-border": e.rgba_96_165_250_0_42,
	"in-progress-dark-text": e.hex93c5fd,
	"complete-dark-bg": e.rgba_4_120_87_0_2,
	"complete-dark-border": e.rgba_52_211_153_0_44,
	"complete-dark-text": e.hex6ee7b7,
	"blocked-dark-bg": e.rgba_185_28_28_0_2,
	"blocked-dark-border": e.rgba_248_113_113_0_44,
	"blocked-dark-text": e.hexfca5a5
}, r = {
	selection: e.hex3b82f6,
	"split-border-start": e.rgba_255_255_255_0_75,
	"split-border-end": e.rgba_255_255_255_0_75,
	"split-stripe-light": e.rgba_255_255_255_0_88,
	"split-stripe-dark": e.rgba_15_23_42_0_16,
	"split-handle": e.rgba_15_23_42_0_42,
	"assignee-badge-border": e.rgba_15_23_42_0_72,
	"assignee-badge-bg": e.hexfacc15,
	"assignee-badge-text": e.hex0f172a,
	"progress-handle": e.rgb_255_255_255,
	"progress-handle-shadow": e.blackKeyword,
	"resize-handle": e.rgba_255_255_255_0_45,
	"dependency-handle-border": e.rgba_42_95_134_0_92,
	"dependency-handle-bg": e.rgba_255_255_255_0_98,
	"progress-preview": e.rgba_132_204_22_0_42,
	"range-selection": e.hex3b82f6,
	"milestone-highlight": e.rgba_255_255_255_0_6
}, i = {
	"interaction-highlight": e.hexfff,
	"annotation-text": e.hex17120a
}, a = { "marker-text": e.hexfff }, o = {
	"task-bg": e.hex5be16b,
	"task-border": e.rgba_0_0_0_0_1,
	"task-progress-bg": e.hex329e16,
	"task-text": e.hex1f2d05,
	"critical-bg": e.hexff77d2,
	"critical-border": e.hexdb3fa9,
	"critical-progress-bg": e.hexf43f9e,
	"summary-bg": e.hex3b82f6,
	"summary-critical-bg": e.hexff77d2,
	"milestone-bg": e.hexfacc15,
	"milestone-border": e.hexa87800,
	"bar-mix-bg": e.white,
	"bar-progress-mix": e.white,
	"shadow-strong": e.rgba_250_204_21_0_18,
	"dependency-stroke": e.hex525866,
	"dependency-stroke-hover": e.hex329e16,
	"dependency-stroke-selected": e.hexff77d2,
	"dependency-stroke-critical": e.hexf43f9e,
	"baseline-bg": e.rgba_167_179_196_0_72,
	"indicator-deadline": e.hexff4d4f,
	"indicator-constraint": e.hex60a5fa,
	"indicator-custom": e.hexa78bfa,
	"indicator-warning": e.hexf59e0b,
	"range-bg": e.rgba_190_242_100_0_14,
	"non-working-bg": e.rgba_17_24_39_0_032,
	"project-line": e.hexff77d2,
	"today-line": e.hexf5a623,
	"milestone-line": e.hexfacc15,
	"resource-load-bg": e.rgba_22_204_22_0_90,
	"resource-load-over-bg": e.rgba_212_36_36_0_90,
	"resource-capacity-line": e.rgba_15_23_42_0_42,
	"tooltip-dependency-block": e.hexb9dcfb,
	"tooltip-dependency-dot": e.hex2b91df,
	"revo-grid-cell-disabled-bg": e.rgba_0_0_0_0_02
}, s = {
	"task-bg": e.hexbef264,
	"task-border": e.rgba_0_0_0_0_1,
	"task-progress-bg": e.hex329e16,
	"task-text": e.hex1f2d05,
	"critical-bg": e.hexff77d2,
	"critical-border": e.hexd83aa5,
	"critical-progress-bg": e.hexf43f9e,
	"summary-bg": e.hex60a5fa,
	"summary-critical-bg": e.hexff77d2,
	"milestone-bg": e.hexfacc15,
	"milestone-border": e.hex9a7200,
	"bar-mix-bg": e.hex74ff17,
	"bar-progress-mix": e.white,
	"shadow-strong": e.rgba_250_204_21_0_18,
	"baseline-bg": e.rgba_109_114_125_0_78,
	"non-working-bg": e.rgba_255_255_255_0_035,
	"resource-load-bg": e.rgba_190_242_100_0_9,
	"resource-load-over-bg": e.rgba_251_113_133_0_78,
	"resource-capacity-line": e.rgba_248_250_252_0_42,
	"tooltip-dependency-block": e.rgba_96_165_250_0_32,
	"tooltip-dependency-dot": e.hex93c5fd
}, c = {
	"avatar-fallback": e.hex94a3b8,
	cyan: e.hex22d3ee,
	emerald: e.hex34d399,
	yellow: e.hexfacc15,
	rose: e.hexfb7185,
	violet: e.hexa78bfa,
	blue: e.hex60a5fa,
	orange: e.hexf97316,
	teal: e.hex2dd4bf
}, l = {
	"gantt-layout": t,
	"gantt-status-badges": n,
	"gantt-task-bars": r,
	"gantt-timeline-header": i,
	"gantt-timeline": a,
	"gantt-theme-light": o,
	"gantt-theme-dark": s,
	"gantt-assignees": c
}, u = [
	{
		id: "gantt-layout",
		title: "Gantt layout",
		usage: "Built-in layout colors; product CSS overrides remain supported.",
		colors: t,
		consumers: ["packages/gantt/src/gantt/assets/styles/_layout.scss"]
	},
	{
		id: "gantt-status-badges",
		title: "Gantt status badges",
		usage: "Built-in status badges colors; product CSS overrides remain supported.",
		colors: n,
		consumers: ["packages/gantt/src/gantt/assets/styles/_status-badges.scss"]
	},
	{
		id: "gantt-task-bars",
		title: "Gantt task bars",
		usage: "Built-in task bars colors; product CSS overrides remain supported.",
		colors: r,
		consumers: ["packages/gantt/src/gantt/assets/styles/_task-bars.scss"]
	},
	{
		id: "gantt-timeline-header",
		title: "Gantt timeline header",
		usage: "Built-in timeline header colors; product CSS overrides remain supported.",
		colors: i,
		consumers: ["packages/gantt/src/gantt/assets/styles/_timeline-header.scss"]
	},
	{
		id: "gantt-timeline",
		title: "Gantt timeline",
		usage: "Built-in timeline colors; product CSS overrides remain supported.",
		colors: a,
		consumers: ["packages/gantt/src/gantt/assets/styles/_timeline.scss"]
	},
	{
		id: "gantt-theme-light",
		title: "Gantt theme light",
		usage: "Built-in theme light colors; product CSS overrides remain supported.",
		colors: o,
		consumers: ["packages/gantt/src/gantt/assets/styles/_tokens.scss"]
	},
	{
		id: "gantt-theme-dark",
		title: "Gantt theme dark",
		usage: "Built-in theme dark colors; product CSS overrides remain supported.",
		colors: s,
		consumers: ["packages/gantt/src/gantt/assets/styles/_tokens.scss"]
	},
	{
		id: "gantt-assignees",
		title: "Gantt assignees",
		usage: "Default assignees colors, preserving configured user colors and theme overrides.",
		colors: c,
		consumers: ["packages/gantt/src/gantt/grid/gantt-grid-sync.ts", "packages/gantt/src/gantt/projection/assignment-display.ts"]
	}
];
//#endregion
export { c as ganttAssigneesColors, l as ganttColors, t as ganttLayoutColors, u as ganttPalettes, n as ganttStatusBadgesColors, r as ganttTaskBarsColors, s as ganttThemeDarkColors, o as ganttThemeLightColors, a as ganttTimelineColors, i as ganttTimelineHeaderColors };
