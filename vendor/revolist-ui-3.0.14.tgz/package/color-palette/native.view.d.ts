export interface NativeColorPickerProps {
    label: string;
    value?: string;
    disabled?: boolean;
    optional?: boolean;
    defaultLabel: string;
    customLabel: string;
    invalidColor?: string;
    colorLabels: Readonly<Record<string, string>>;
    onChange(value: string | undefined): void;
}
/** Compatibility mount API; palette markup and interaction belong to ColorPicker. */
export declare function mountColorPicker(host: HTMLElement, props: NativeColorPickerProps): {
    destroy(): void;
};
