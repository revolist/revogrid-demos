export interface ColorPaletteOption {
    readonly value: string;
    readonly label: string;
    readonly disabled?: boolean;
}
export type ColorPaletteValue = string | null;
export declare const DEFAULT_COLOR_PALETTE_OPTIONS: readonly ColorPaletteOption[];
