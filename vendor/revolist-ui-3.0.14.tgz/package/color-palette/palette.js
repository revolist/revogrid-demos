import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/palette.ts
var t = [
	{
		value: e.hexe53935,
		label: "Red"
	},
	{
		value: e.hexd81b60,
		label: "Pink"
	},
	{
		value: e.hexc000c0,
		label: "Magenta"
	},
	{
		value: e.hex8e24aa,
		label: "Purple"
	},
	{
		value: e.hex5e35b1,
		label: "Deep purple"
	},
	{
		value: e.hex4527a0,
		label: "Violet"
	},
	{
		value: e.hex3949ab,
		label: "Indigo"
	},
	{
		value: e.blue600,
		label: "Blue"
	},
	{
		value: e.hex03a9f4,
		label: "Light blue"
	},
	{
		value: e.hex26c6da,
		label: "Cyan"
	},
	{
		value: e.hex00897b,
		label: "Teal"
	},
	{
		value: e.hex43a047,
		label: "Green"
	},
	{
		value: e.hex8bc34a,
		label: "Light green"
	},
	{
		value: e.hexc0ca33,
		label: "Lime"
	},
	{
		value: e.hexfdd835,
		label: "Yellow"
	},
	{
		value: e.hexffb300,
		label: "Amber"
	},
	{
		value: e.hexfb8c00,
		label: "Orange"
	},
	{
		value: e.hexf4511e,
		label: "Vermilion"
	},
	{
		value: e.hex6d4c41,
		label: "Brown"
	},
	{
		value: e.hexe0e0e0,
		label: "Light gray"
	},
	{
		value: e.hexbdbdbd,
		label: "Silver"
	},
	{
		value: e.hex757575,
		label: "Gray"
	},
	{
		value: e.black,
		label: "Black"
	}
];
//#endregion
export { t as DEFAULT_COLOR_PALETTE_OPTIONS };
