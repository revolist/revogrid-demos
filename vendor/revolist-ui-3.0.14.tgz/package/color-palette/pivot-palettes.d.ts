/** Built-in colors; preserve concrete values for portable drawings and persisted defaults. */
export declare const PIVOT_CONDITIONAL_COLORS: {
    readonly background: "#fff3a3";
    readonly foreground: "#111111";
};
export declare const PIVOT_COLOR_EDITOR_COLORS: {
    readonly primary: "#2563eb";
    readonly negative: "#dc2626";
    readonly neutral: "#ffffff";
};
export declare const PIVOT_INTERFACE_MIX_COLORS: {
    readonly shade: "black";
    readonly tint: "white";
};
export declare const pivotPalettes: readonly [{
    readonly id: "pivot-interface-mix";
    readonly title: "Pivot interface accent mixing";
    readonly usage: "Fixed shade and tint operands for theme-aware accent text; accent overrides and mixing percentages are preserved.";
    readonly colors: {
        readonly shade: "black";
        readonly tint: "white";
    };
    readonly consumers: readonly ["Pivot configurators", "Pivot field actions", "Pivot chart controls"];
}, {
    readonly id: "pivot-conditional";
    readonly title: "Pivot conditional formatting";
    readonly usage: "Initial background and foreground for conditional-format rules.";
    readonly colors: {
        readonly background: "#fff3a3";
        readonly foreground: "#111111";
    };
    readonly consumers: readonly ["Pivot conditional-format draft"];
}, {
    readonly id: "pivot-color-editor";
    readonly title: "Pivot chart color editor";
    readonly usage: "Initial positive, negative and neutral colors for color mappings.";
    readonly colors: {
        readonly primary: "#2563eb";
        readonly negative: "#dc2626";
        readonly neutral: "#ffffff";
    };
    readonly consumers: readonly ["Pivot chart color editor"];
}];
