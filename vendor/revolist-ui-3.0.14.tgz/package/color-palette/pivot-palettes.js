import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/pivot-palettes.ts
var t = {
	background: e.hexfff3a3,
	foreground: e.hex111111
}, n = {
	primary: e.blue600,
	negative: e.red600,
	neutral: e.white
}, r = {
	shade: e.blackKeyword,
	tint: e.watermarkForeground
}, i = [
	{
		id: "pivot-interface-mix",
		title: "Pivot interface accent mixing",
		usage: "Fixed shade and tint operands for theme-aware accent text; accent overrides and mixing percentages are preserved.",
		colors: r,
		consumers: [
			"Pivot configurators",
			"Pivot field actions",
			"Pivot chart controls"
		]
	},
	{
		id: "pivot-conditional",
		title: "Pivot conditional formatting",
		usage: "Initial background and foreground for conditional-format rules.",
		colors: t,
		consumers: ["Pivot conditional-format draft"]
	},
	{
		id: "pivot-color-editor",
		title: "Pivot chart color editor",
		usage: "Initial positive, negative and neutral colors for color mappings.",
		colors: n,
		consumers: ["Pivot chart color editor"]
	}
];
//#endregion
export { n as PIVOT_COLOR_EDITOR_COLORS, t as PIVOT_CONDITIONAL_COLORS, r as PIVOT_INTERFACE_MIX_COLORS, i as pivotPalettes };
