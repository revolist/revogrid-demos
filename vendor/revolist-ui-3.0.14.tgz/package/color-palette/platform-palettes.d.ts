/** Stable identity colors; order participates in the user-ID hash assignment. */
export declare const COLLABORATIVE_IDENTITY_COLORS: {
    readonly blue: "#2563eb";
    readonly green: "#16a34a";
    readonly red: "#dc2626";
    readonly purple: "#9333ea";
    readonly orange: "#ea580c";
    readonly cyan: "#0891b2";
    readonly rose: "#be123c";
    readonly indigo: "#4f46e5";
};
export declare const TRIAL_WATERMARK_COLORS: {
    readonly foreground: "white";
    readonly background: "rgba(166, 0, 0, 0.9)";
};
export declare const platformPalettes: readonly [{
    readonly id: "collaborative-identity";
    readonly title: "Collaborative editing identities";
    readonly usage: "Deterministic fallback colors for collaborator IDs; explicit user colors take precedence.";
    readonly colors: {
        readonly blue: "#2563eb";
        readonly green: "#16a34a";
        readonly red: "#dc2626";
        readonly purple: "#9333ea";
        readonly orange: "#ea580c";
        readonly cyan: "#0891b2";
        readonly rose: "#be123c";
        readonly indigo: "#4f46e5";
    };
    readonly consumers: readonly ["packages/collaborative-editing/plugins/collaborative-editing/collaborative-editing.utils.ts"];
}, {
    readonly id: "trial-watermark";
    readonly title: "Trial watermark";
    readonly usage: "Foreground and translucent background of delayed trial notices in grids and charts.";
    readonly colors: {
        readonly foreground: "white";
        readonly background: "rgba(166, 0, 0, 0.9)";
    };
    readonly consumers: readonly ["packages/trial-control/src/watermark.ts"];
}];
