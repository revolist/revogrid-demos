import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/platform-palettes.ts
var t = {
	blue: e.blue600,
	green: e.green600,
	red: e.red600,
	purple: e.purple600,
	orange: e.orange600,
	cyan: e.cyan600,
	rose: e.rose700,
	indigo: e.indigo600
}, n = {
	foreground: e.watermarkForeground,
	background: e.watermarkBackground
}, r = [{
	id: "collaborative-identity",
	title: "Collaborative editing identities",
	usage: "Deterministic fallback colors for collaborator IDs; explicit user colors take precedence.",
	colors: t,
	consumers: ["packages/collaborative-editing/plugins/collaborative-editing/collaborative-editing.utils.ts"]
}, {
	id: "trial-watermark",
	title: "Trial watermark",
	usage: "Foreground and translucent background of delayed trial notices in grids and charts.",
	colors: n,
	consumers: ["packages/trial-control/src/watermark.ts"]
}];
//#endregion
export { t as COLLABORATIVE_IDENTITY_COLORS, n as TRIAL_WATERMARK_COLORS, r as platformPalettes };
