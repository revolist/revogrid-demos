/** Built-in Pro product colors. Values preserve existing product appearance. */
export declare const proBaseColors: {
    readonly white: "white";
    readonly black: "black";
};
export declare const proFormattingColors: {
    readonly border: "#64748b";
    readonly borderLabel: "#64748B";
    readonly accent: "#2563eb";
    readonly negative: "#dc2626";
    readonly scaleMid: "#facc15";
    readonly scaleHigh: "#16a34a";
    readonly black: "#000000";
    readonly conditionalFill: "#fff3a3";
    readonly conditionalText: "#111111";
};
export declare const proExportColors: {
    readonly headerFill: "#F3F4F6";
    readonly headerBorder: "#D1D5DB";
};
export declare const proNotesColors: {
    readonly none: "#9ca3af";
    readonly info: "#2563eb";
    readonly warning: "#d97706";
    readonly blocker: "#dc2626";
    readonly resolved: "#16a34a";
};
export declare const proPresenceColors: {
    readonly default: "#2563eb";
    readonly outlineLight: "rgba(255, 255, 255, 0.88)";
    readonly white: "#fff";
    readonly surface: "rgba(255, 255, 255, 0.18)";
    readonly surfaceStrong: "rgba(255, 255, 255, 0.72)";
    readonly outlineDark: "rgba(22, 22, 26, 0.9)";
};
export declare const proCellFlashColors: {
    readonly lightHighlight: "rgba(255, 238, 0, 0.58)";
    readonly lightRowHighlight: "rgba(255, 238, 0, 0.20)";
    readonly lightUp: "#15803d";
    readonly lightDown: "#dc2626";
    readonly darkHighlight: "rgba(250, 204, 21, 0.34)";
    readonly darkRowHighlight: "rgba(250, 204, 21, 0.16)";
    readonly darkUp: "#4ade80";
    readonly darkDown: "#f87171";
};
export declare const proColumnTypesColors: {
    readonly foreground: "#fff";
    readonly green: "#00ca72";
    readonly blue: "#0b63f6";
    readonly cyan: "#24b7f3";
    readonly red: "#f43f5e";
    readonly orange: "#fdab3d";
    readonly yellow: "#ffcb00";
    readonly yellowForeground: "#3b3f4a";
    readonly violet: "#784bd1";
    readonly pink: "#ff158a";
    readonly gray: "#676879";
};
export declare const proFilterSyntaxColors: {
    readonly keyword: "#315fdc";
    readonly value: "#0f766e";
    readonly number: "#a14b08";
    readonly boolean: "#7c3aed";
    readonly field: "#64748b";
    readonly property: "#9f1239";
    readonly darkKeyword: "#8fb0ff";
    readonly darkValue: "#6ee7b7";
    readonly darkNumber: "#fdba74";
    readonly darkBoolean: "#c4b5fd";
    readonly darkField: "rgba(255, 255, 255, 0.68)";
    readonly darkProperty: "#fda4af";
};
export declare const proFormulaSyntaxColors: {
    readonly function: "#7c3aed";
    readonly reference: "#2563eb";
    readonly number: "#059669";
    readonly punctuation: "#667085";
    readonly string: "#c2410c";
    readonly name: "#be123c";
    readonly enterHintLight: "#666";
    readonly enterHintDark: "#97a6ba";
};
export declare const proFormulaDependenciesColors: {
    readonly blue: "#2563eb";
    readonly red: "#dc2626";
    readonly green: "#16a34a";
    readonly purple: "#9333ea";
    readonly orange: "#ea580c";
    readonly cyan: "#0891b2";
};
export declare const proCellChartsColors: {
    readonly rangePickerShadow: "#0003";
    readonly bar: "#3f3f46";
    readonly event: "#22c55e";
    readonly eventEnd: "#16a34a";
    readonly eventHoverEnd: "#15803d";
    readonly progress: "rgb(14, 79, 229)";
    readonly progressTrack: "lightgray";
    readonly threshold: "#3b82f6";
    readonly progressText: "#ffffff";
};
export declare const proExcelNamedColors: {
    readonly black: "#000000";
    readonly blue: "#0000ff";
    readonly cyan: "#00ffff";
    readonly green: "#008000";
    readonly magenta: "#ff00ff";
    readonly red: "#ff0000";
    readonly white: "#ffffff";
    readonly yellow: "#ffff00";
};
export declare const proExcelIndexedColors: {
    readonly color1: "#000000";
    readonly color2: "#ffffff";
    readonly color3: "#ff0000";
    readonly color4: "#00ff00";
    readonly color5: "#0000ff";
    readonly color6: "#ffff00";
    readonly color7: "#ff00ff";
    readonly color8: "#00ffff";
    readonly color9: "#800000";
    readonly color10: "#008000";
    readonly color11: "#000080";
    readonly color12: "#808000";
    readonly color13: "#800080";
    readonly color14: "#008080";
    readonly color15: "#c0c0c0";
    readonly color16: "#808080";
    readonly color17: "#9999ff";
    readonly color18: "#993366";
    readonly color19: "#ffffcc";
    readonly color20: "#ccffff";
    readonly color21: "#660066";
    readonly color22: "#ff8080";
    readonly color23: "#0066cc";
    readonly color24: "#ccccff";
    readonly color25: "#000080";
    readonly color26: "#ff00ff";
    readonly color27: "#ffff00";
    readonly color28: "#00ffff";
    readonly color29: "#800080";
    readonly color30: "#800000";
    readonly color31: "#008080";
    readonly color32: "#0000ff";
    readonly color33: "#00ccff";
    readonly color34: "#ccffff";
    readonly color35: "#ccffcc";
    readonly color36: "#ffff99";
    readonly color37: "#99ccff";
    readonly color38: "#ff99cc";
    readonly color39: "#cc99ff";
    readonly color40: "#ffcc99";
    readonly color41: "#3366ff";
    readonly color42: "#33cccc";
    readonly color43: "#99cc00";
    readonly color44: "#ffcc00";
    readonly color45: "#ff9900";
    readonly color46: "#ff6600";
    readonly color47: "#666699";
    readonly color48: "#969696";
    readonly color49: "#003366";
    readonly color50: "#339966";
    readonly color51: "#003300";
    readonly color52: "#333300";
    readonly color53: "#993300";
    readonly color54: "#993366";
    readonly color55: "#333399";
    readonly color56: "#333333";
};
export declare const proPalettes: readonly [{
    readonly id: "pro-base";
    readonly title: "Pro utility colors";
    readonly usage: "Icon mask contrast and legacy fallback surfaces.";
    readonly colors: {
        readonly white: "white";
        readonly black: "black";
    };
    readonly consumers: readonly ["packages/pro/plugins/audit-history-panel/_audit-history-panel.scss", "packages/pro/plugins/column-group-panel/delete.icon.ts", "packages/pro/plugins/loader/loader.style.scss"];
}, {
    readonly id: "pro-formatting";
    readonly title: "Pro data formatting";
    readonly usage: "Formatting editor defaults, conditional scales, negative values, and Excel border fallback.";
    readonly colors: {
        readonly border: "#64748b";
        readonly borderLabel: "#64748B";
        readonly accent: "#2563eb";
        readonly negative: "#dc2626";
        readonly scaleMid: "#facc15";
        readonly scaleHigh: "#16a34a";
        readonly black: "#000000";
        readonly conditionalFill: "#fff3a3";
        readonly conditionalText: "#111111";
    };
    readonly consumers: readonly ["packages/pro/plugins/conditional-formatting/conditional-formatting.editor.ts", "packages/pro/plugins/data-grid-formatting/editor/advanced-format-panel.tsx", "packages/pro/plugins/data-grid-formatting/editor/borders-section.tsx", "packages/pro/plugins/data-grid-formatting/editor/format-preview.tsx", "packages/pro/plugins/data-grid-formatting/editor/index.tsx", "packages/pro/plugins/data-grid-formatting/format/advanced.ts", "packages/pro/plugins/data-grid-formatting/format/excel.ts", "packages/pro/plugins/data-grid-formatting/rendering/index.ts"];
}, {
    readonly id: "pro-export";
    readonly title: "Pro spreadsheet export";
    readonly usage: "Portable spreadsheet header fill and border values.";
    readonly colors: {
        readonly headerFill: "#F3F4F6";
        readonly headerBorder: "#D1D5DB";
    };
    readonly consumers: readonly ["packages/pro/plugins/export-excel/internal/export-transforms.ts"];
}, {
    readonly id: "pro-notes";
    readonly title: "Pro note severity";
    readonly usage: "None, information, warning, blocker, and resolved note indicators.";
    readonly colors: {
        readonly none: "#9ca3af";
        readonly info: "#2563eb";
        readonly warning: "#d97706";
        readonly blocker: "#dc2626";
        readonly resolved: "#16a34a";
    };
    readonly consumers: readonly ["packages/pro/plugins/grid-notes/grid-notes.plugin.ts", "packages/pro/plugins/grid-notes/grid-notes.style.scss"];
}, {
    readonly id: "pro-presence";
    readonly title: "Pro collaborative presence";
    readonly usage: "Collaborator fallback, marker outlines, and translucent marker surfaces.";
    readonly colors: {
        readonly default: "#2563eb";
        readonly outlineLight: "rgba(255, 255, 255, 0.88)";
        readonly white: "#fff";
        readonly surface: "rgba(255, 255, 255, 0.18)";
        readonly surfaceStrong: "rgba(255, 255, 255, 0.72)";
        readonly outlineDark: "rgba(22, 22, 26, 0.9)";
    };
    readonly consumers: readonly ["packages/pro/plugins/collaborative-presence/collaborative-presence.layer.ts", "packages/pro/plugins/collaborative-presence/collaborative-presence.style.scss"];
}, {
    readonly id: "pro-cell-flash";
    readonly title: "Pro cell feedback";
    readonly usage: "Unchanged light/dark flash highlight and positive/negative movement colors.";
    readonly colors: {
        readonly lightHighlight: "rgba(255, 238, 0, 0.58)";
        readonly lightRowHighlight: "rgba(255, 238, 0, 0.20)";
        readonly lightUp: "#15803d";
        readonly lightDown: "#dc2626";
        readonly darkHighlight: "rgba(250, 204, 21, 0.34)";
        readonly darkRowHighlight: "rgba(250, 204, 21, 0.16)";
        readonly darkUp: "#4ade80";
        readonly darkDown: "#f87171";
    };
    readonly consumers: readonly ["packages/pro/plugins/cell-flash/cell-flash.style.scss"];
}, {
    readonly id: "pro-column-types";
    readonly title: "Pro column type icons";
    readonly usage: "Colored badges identifying built-in column types.";
    readonly colors: {
        readonly foreground: "#fff";
        readonly green: "#00ca72";
        readonly blue: "#0b63f6";
        readonly cyan: "#24b7f3";
        readonly red: "#f43f5e";
        readonly orange: "#fdab3d";
        readonly yellow: "#ffcb00";
        readonly yellowForeground: "#3b3f4a";
        readonly violet: "#784bd1";
        readonly pink: "#ff158a";
        readonly gray: "#676879";
    };
    readonly consumers: readonly ["packages/pro/plugins/column-add-popup/column-add-popup.style.scss"];
}, {
    readonly id: "pro-filter-syntax";
    readonly title: "Pro filter expression syntax";
    readonly usage: "Light/dark filter keyword, value, number, boolean, field, and property tokens.";
    readonly colors: {
        readonly keyword: "#315fdc";
        readonly value: "#0f766e";
        readonly number: "#a14b08";
        readonly boolean: "#7c3aed";
        readonly field: "#64748b";
        readonly property: "#9f1239";
        readonly darkKeyword: "#8fb0ff";
        readonly darkValue: "#6ee7b7";
        readonly darkNumber: "#fdba74";
        readonly darkBoolean: "#c4b5fd";
        readonly darkField: "rgba(255, 255, 255, 0.68)";
        readonly darkProperty: "#fda4af";
    };
    readonly consumers: readonly ["packages/pro/plugins/filter/filter.style.scss"];
}, {
    readonly id: "pro-formula-syntax";
    readonly title: "Pro formula syntax";
    readonly usage: "Formula syntax tokens and light/dark enter-hint SVG stroke colors.";
    readonly colors: {
        readonly function: "#7c3aed";
        readonly reference: "#2563eb";
        readonly number: "#059669";
        readonly punctuation: "#667085";
        readonly string: "#c2410c";
        readonly name: "#be123c";
        readonly enterHintLight: "#666";
        readonly enterHintDark: "#97a6ba";
    };
    readonly consumers: readonly ["packages/pro/plugins/formula/bar/formula-bar.style.scss"];
}, {
    readonly id: "pro-formula-dependencies";
    readonly title: "Pro formula dependencies";
    readonly usage: "Ordered reference highlight colors for formula dependencies.";
    readonly colors: {
        readonly blue: "#2563eb";
        readonly red: "#dc2626";
        readonly green: "#16a34a";
        readonly purple: "#9333ea";
        readonly orange: "#ea580c";
        readonly cyan: "#0891b2";
    };
    readonly consumers: readonly ["packages/pro/plugins/formula/dependencies/formula-dependency-highlight.ts"];
}, {
    readonly id: "pro-cell-charts";
    readonly title: "Pro cell charts";
    readonly usage: "Timeline event gradients, progress track/fill, threshold and progress label defaults.";
    readonly colors: {
        readonly rangePickerShadow: "#0003";
        readonly bar: "#3f3f46";
        readonly event: "#22c55e";
        readonly eventEnd: "#16a34a";
        readonly eventHoverEnd: "#15803d";
        readonly progress: "rgb(14, 79, 229)";
        readonly progressTrack: "lightgray";
        readonly threshold: "#3b82f6";
        readonly progressText: "#ffffff";
    };
    readonly consumers: readonly ["packages/pro/plugins/charts/timeline.style.scss", "packages/pro/plugins/column-type-progress/progress.style.scss", "packages/pro/plugins/editor-timeline/editor-timeline.styles.scss"];
}, {
    readonly id: "pro-excel-named";
    readonly title: "Excel named colors";
    readonly usage: "Spreadsheet format-code named colors; names are parsing identifiers.";
    readonly colors: {
        readonly black: "#000000";
        readonly blue: "#0000ff";
        readonly cyan: "#00ffff";
        readonly green: "#008000";
        readonly magenta: "#ff00ff";
        readonly red: "#ff0000";
        readonly white: "#ffffff";
        readonly yellow: "#ffff00";
    };
    readonly consumers: readonly ["packages/pro/plugins/data-grid-formatting/format/code/parser.ts"];
}, {
    readonly id: "pro-excel-indexed";
    readonly title: "Excel indexed colors";
    readonly usage: "Exact ordered Excel Color1 through Color56 palette.";
    readonly colors: {
        readonly color1: "#000000";
        readonly color2: "#ffffff";
        readonly color3: "#ff0000";
        readonly color4: "#00ff00";
        readonly color5: "#0000ff";
        readonly color6: "#ffff00";
        readonly color7: "#ff00ff";
        readonly color8: "#00ffff";
        readonly color9: "#800000";
        readonly color10: "#008000";
        readonly color11: "#000080";
        readonly color12: "#808000";
        readonly color13: "#800080";
        readonly color14: "#008080";
        readonly color15: "#c0c0c0";
        readonly color16: "#808080";
        readonly color17: "#9999ff";
        readonly color18: "#993366";
        readonly color19: "#ffffcc";
        readonly color20: "#ccffff";
        readonly color21: "#660066";
        readonly color22: "#ff8080";
        readonly color23: "#0066cc";
        readonly color24: "#ccccff";
        readonly color25: "#000080";
        readonly color26: "#ff00ff";
        readonly color27: "#ffff00";
        readonly color28: "#00ffff";
        readonly color29: "#800080";
        readonly color30: "#800000";
        readonly color31: "#008080";
        readonly color32: "#0000ff";
        readonly color33: "#00ccff";
        readonly color34: "#ccffff";
        readonly color35: "#ccffcc";
        readonly color36: "#ffff99";
        readonly color37: "#99ccff";
        readonly color38: "#ff99cc";
        readonly color39: "#cc99ff";
        readonly color40: "#ffcc99";
        readonly color41: "#3366ff";
        readonly color42: "#33cccc";
        readonly color43: "#99cc00";
        readonly color44: "#ffcc00";
        readonly color45: "#ff9900";
        readonly color46: "#ff6600";
        readonly color47: "#666699";
        readonly color48: "#969696";
        readonly color49: "#003366";
        readonly color50: "#339966";
        readonly color51: "#003300";
        readonly color52: "#333300";
        readonly color53: "#993300";
        readonly color54: "#993366";
        readonly color55: "#333399";
        readonly color56: "#333333";
    };
    readonly consumers: readonly ["packages/pro/plugins/data-grid-formatting/format/code/parser.ts"];
}];
