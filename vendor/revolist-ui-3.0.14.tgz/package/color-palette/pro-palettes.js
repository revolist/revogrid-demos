import { commonColors as e } from "./common-palettes.js";
//#region src/color-palette/pro-palettes.ts
var t = {
	white: e.watermarkForeground,
	black: e.blackKeyword
}, n = {
	border: e.hex64748b,
	borderLabel: e.hex64748B,
	accent: e.blue600,
	negative: e.red600,
	scaleMid: e.hexfacc15,
	scaleHigh: e.green600,
	black: e.black,
	conditionalFill: e.hexfff3a3,
	conditionalText: e.hex111111
}, r = {
	headerFill: e.hexF3F4F6,
	headerBorder: e.hexD1D5DB
}, i = {
	none: e.hex9ca3af,
	info: e.blue600,
	warning: e.hexd97706,
	blocker: e.red600,
	resolved: e.green600
}, a = {
	default: e.blue600,
	outlineLight: e.rgba_255_255_255_0_88,
	white: e.hexfff,
	surface: e.rgba_255_255_255_0_18,
	surfaceStrong: e.rgba_255_255_255_0_72,
	outlineDark: e.rgba_22_22_26_0_9
}, o = {
	lightHighlight: e.rgba_255_238_0_0_58,
	lightRowHighlight: e.rgba_255_238_0_0_20,
	lightUp: e.hex15803d,
	lightDown: e.red600,
	darkHighlight: e.rgba_250_204_21_0_34,
	darkRowHighlight: e.rgba_250_204_21_0_16,
	darkUp: e.hex4ade80,
	darkDown: e.hexf87171
}, s = {
	foreground: e.hexfff,
	green: e.hex00ca72,
	blue: e.hex0b63f6,
	cyan: e.hex24b7f3,
	red: e.hexf43f5e,
	orange: e.hexfdab3d,
	yellow: e.hexffcb00,
	yellowForeground: e.hex3b3f4a,
	violet: e.hex784bd1,
	pink: e.hexff158a,
	gray: e.hex676879
}, c = {
	keyword: e.hex315fdc,
	value: e.hex0f766e,
	number: e.hexa14b08,
	boolean: e.hex7c3aed,
	field: e.hex64748b,
	property: e.hex9f1239,
	darkKeyword: e.hex8fb0ff,
	darkValue: e.hex6ee7b7,
	darkNumber: e.hexfdba74,
	darkBoolean: e.hexc4b5fd,
	darkField: e.rgba_255_255_255_0_68,
	darkProperty: e.hexfda4af
}, l = {
	function: e.hex7c3aed,
	reference: e.blue600,
	number: e.hex059669,
	punctuation: e.hex667085,
	string: e.hexc2410c,
	name: e.rose700,
	enterHintLight: e.hex666,
	enterHintDark: e.hex97a6ba
}, u = {
	blue: e.blue600,
	red: e.red600,
	green: e.green600,
	purple: e.purple600,
	orange: e.orange600,
	cyan: e.cyan600
}, d = {
	rangePickerShadow: e.hex0003,
	bar: e.hex3f3f46,
	event: e.hex22c55e,
	eventEnd: e.green600,
	eventHoverEnd: e.hex15803d,
	progress: e.rgb_14_79_229,
	progressTrack: e.lightgrayKeyword,
	threshold: e.hex3b82f6,
	progressText: e.white
}, f = {
	black: e.black,
	blue: e.hex0000ff,
	cyan: e.hex00ffff,
	green: e.hex008000,
	magenta: e.hexff00ff,
	red: e.hexff0000,
	white: e.white,
	yellow: e.hexffff00
}, p = {
	color1: e.black,
	color2: e.white,
	color3: e.hexff0000,
	color4: e.hex00ff00,
	color5: e.hex0000ff,
	color6: e.hexffff00,
	color7: e.hexff00ff,
	color8: e.hex00ffff,
	color9: e.hex800000,
	color10: e.hex008000,
	color11: e.hex000080,
	color12: e.hex808000,
	color13: e.hex800080,
	color14: e.hex008080,
	color15: e.hexc0c0c0,
	color16: e.hex808080,
	color17: e.hex9999ff,
	color18: e.hex993366,
	color19: e.hexffffcc,
	color20: e.hexccffff,
	color21: e.hex660066,
	color22: e.hexff8080,
	color23: e.hex0066cc,
	color24: e.hexccccff,
	color25: e.hex000080,
	color26: e.hexff00ff,
	color27: e.hexffff00,
	color28: e.hex00ffff,
	color29: e.hex800080,
	color30: e.hex800000,
	color31: e.hex008080,
	color32: e.hex0000ff,
	color33: e.hex00ccff,
	color34: e.hexccffff,
	color35: e.hexccffcc,
	color36: e.hexffff99,
	color37: e.hex99ccff,
	color38: e.hexff99cc,
	color39: e.hexcc99ff,
	color40: e.hexffcc99,
	color41: e.hex3366ff,
	color42: e.hex33cccc,
	color43: e.hex99cc00,
	color44: e.hexffcc00,
	color45: e.hexff9900,
	color46: e.hexff6600,
	color47: e.hex666699,
	color48: e.hex969696,
	color49: e.hex003366,
	color50: e.hex339966,
	color51: e.hex003300,
	color52: e.hex333300,
	color53: e.hex993300,
	color54: e.hex993366,
	color55: e.hex333399,
	color56: e.hex333333
}, m = [
	{
		id: "pro-base",
		title: "Pro utility colors",
		usage: "Icon mask contrast and legacy fallback surfaces.",
		colors: t,
		consumers: [
			"packages/pro/plugins/audit-history-panel/_audit-history-panel.scss",
			"packages/pro/plugins/column-group-panel/delete.icon.ts",
			"packages/pro/plugins/loader/loader.style.scss"
		]
	},
	{
		id: "pro-formatting",
		title: "Pro data formatting",
		usage: "Formatting editor defaults, conditional scales, negative values, and Excel border fallback.",
		colors: n,
		consumers: [
			"packages/pro/plugins/conditional-formatting/conditional-formatting.editor.ts",
			"packages/pro/plugins/data-grid-formatting/editor/advanced-format-panel.tsx",
			"packages/pro/plugins/data-grid-formatting/editor/borders-section.tsx",
			"packages/pro/plugins/data-grid-formatting/editor/format-preview.tsx",
			"packages/pro/plugins/data-grid-formatting/editor/index.tsx",
			"packages/pro/plugins/data-grid-formatting/format/advanced.ts",
			"packages/pro/plugins/data-grid-formatting/format/excel.ts",
			"packages/pro/plugins/data-grid-formatting/rendering/index.ts"
		]
	},
	{
		id: "pro-export",
		title: "Pro spreadsheet export",
		usage: "Portable spreadsheet header fill and border values.",
		colors: r,
		consumers: ["packages/pro/plugins/export-excel/internal/export-transforms.ts"]
	},
	{
		id: "pro-notes",
		title: "Pro note severity",
		usage: "None, information, warning, blocker, and resolved note indicators.",
		colors: i,
		consumers: ["packages/pro/plugins/grid-notes/grid-notes.plugin.ts", "packages/pro/plugins/grid-notes/grid-notes.style.scss"]
	},
	{
		id: "pro-presence",
		title: "Pro collaborative presence",
		usage: "Collaborator fallback, marker outlines, and translucent marker surfaces.",
		colors: a,
		consumers: ["packages/pro/plugins/collaborative-presence/collaborative-presence.layer.ts", "packages/pro/plugins/collaborative-presence/collaborative-presence.style.scss"]
	},
	{
		id: "pro-cell-flash",
		title: "Pro cell feedback",
		usage: "Unchanged light/dark flash highlight and positive/negative movement colors.",
		colors: o,
		consumers: ["packages/pro/plugins/cell-flash/cell-flash.style.scss"]
	},
	{
		id: "pro-column-types",
		title: "Pro column type icons",
		usage: "Colored badges identifying built-in column types.",
		colors: s,
		consumers: ["packages/pro/plugins/column-add-popup/column-add-popup.style.scss"]
	},
	{
		id: "pro-filter-syntax",
		title: "Pro filter expression syntax",
		usage: "Light/dark filter keyword, value, number, boolean, field, and property tokens.",
		colors: c,
		consumers: ["packages/pro/plugins/filter/filter.style.scss"]
	},
	{
		id: "pro-formula-syntax",
		title: "Pro formula syntax",
		usage: "Formula syntax tokens and light/dark enter-hint SVG stroke colors.",
		colors: l,
		consumers: ["packages/pro/plugins/formula/bar/formula-bar.style.scss"]
	},
	{
		id: "pro-formula-dependencies",
		title: "Pro formula dependencies",
		usage: "Ordered reference highlight colors for formula dependencies.",
		colors: u,
		consumers: ["packages/pro/plugins/formula/dependencies/formula-dependency-highlight.ts"]
	},
	{
		id: "pro-cell-charts",
		title: "Pro cell charts",
		usage: "Timeline event gradients, progress track/fill, threshold and progress label defaults.",
		colors: d,
		consumers: [
			"packages/pro/plugins/charts/timeline.style.scss",
			"packages/pro/plugins/column-type-progress/progress.style.scss",
			"packages/pro/plugins/editor-timeline/editor-timeline.styles.scss"
		]
	},
	{
		id: "pro-excel-named",
		title: "Excel named colors",
		usage: "Spreadsheet format-code named colors; names are parsing identifiers.",
		colors: f,
		consumers: ["packages/pro/plugins/data-grid-formatting/format/code/parser.ts"]
	},
	{
		id: "pro-excel-indexed",
		title: "Excel indexed colors",
		usage: "Exact ordered Excel Color1 through Color56 palette.",
		colors: p,
		consumers: ["packages/pro/plugins/data-grid-formatting/format/code/parser.ts"]
	}
];
//#endregion
export { t as proBaseColors, d as proCellChartsColors, o as proCellFlashColors, s as proColumnTypesColors, p as proExcelIndexedColors, f as proExcelNamedColors, r as proExportColors, c as proFilterSyntaxColors, n as proFormattingColors, u as proFormulaDependenciesColors, l as proFormulaSyntaxColors, i as proNotesColors, m as proPalettes, a as proPresenceColors };
