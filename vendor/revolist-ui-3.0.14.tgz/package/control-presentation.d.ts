/** Compatibility entry; markup is owned by the Preact TSX implementation. */
export * from './control-presentation.view';
