import { createPreactElement as e } from "./preact-mount.js";
import { h as t } from "preact";
import { jsx as n } from "preact/jsx-runtime";
//#region src/control-presentation.view.tsx
function r(...e) {
	e = e.map((e) => e && typeof e == "object" && "value" in e && "subscribe" in e ? e.value : e);
	let t = e.flatMap((e) => typeof e == "string" ? e.split(/\s+/) : e && typeof e == "object" ? Object.entries(e).filter(([, e]) => e).map(([e]) => e) : []);
	return [...new Set(t.filter(Boolean))].join(" ");
}
function i(e, t = {}) {
	let { class: n, className: i, unstyled: a, busy: o, ...s } = t, c = e === "button" && o === !0;
	if (c) {
		for (let e of Object.keys(s)) /^on/i.test(e) && delete s[e];
		s.disabled = !0, s["aria-busy"] = !0, s.onClickCapture = (e) => {
			e.preventDefault(), e.stopPropagation();
		};
	}
	let l = e === "input" ? t.type ?? "text" : void 0, u = e === "button" ? a ? "" : "rv-btn" : e === "summary" ? "rv-disclosure-summary" : l === "checkbox" ? "rv-checkbox" : l === "radio" ? "rv-radio" : l === "range" ? "rv-native-slider" : l === "hidden" ? "" : "rv-control";
	return {
		...e === "button" ? { type: "button" } : {},
		...s,
		class: r(u, n, i, c && "rv-btn-busy", c && t.disabled && "rv-btn-busy-disabled")
	};
}
function a(e, t, n, ...r) {
	let a = n ?? {};
	if (t === "button" && a.busy === !0) {
		let n = r.length ? r : [a.children];
		return e(t, i(t, a), e("span", {
			class: "rv-button-spinner",
			"aria-hidden": "true"
		}), ...n);
	}
	return e(t, i(t, a), ...r);
}
function o(n, r, i = {}) {
	let o = a(t, r, i);
	return i.onChange && !(r === "button" && i.busy) && Object.assign(o.props, { onChange: i.onChange }), e(n, o);
}
var s = /* @__PURE__ */ new WeakMap();
function c(e, t) {
	return s.set(e, t), e;
}
function l(e) {
	return typeof e == "string" ? e : e && (typeof e == "function" || typeof e == "object") ? s.get(e) : void 0;
}
function u(t, r) {
	t.classList.add("rv-btn", "rv-btn-ghost", "rv-btn-icon"), t.setAttribute("aria-label", r), t.title = r, t.querySelector(".rv-control-tooltip")?.remove(), t.append(e(t.ownerDocument, /* @__PURE__ */ n("span", {
		class: "rv-control-tooltip",
		"aria-hidden": "true",
		children: r
	})));
}
//#endregion
export { i as controlAttributes, r as controlClassName, o as createControl, u as decorateIconAction, l as nativeControlTag, c as registerControl, a as renderControl };
