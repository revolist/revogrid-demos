/** Native control presentation shared by Preact, Stencil, DOM and Charts. */
export type ControlTag = 'button' | 'input' | 'select' | 'textarea' | 'summary';
export type ControlAttributes = Record<string, any>;
export declare function controlClassName(...values: unknown[]): string;
export declare function controlAttributes(tag: ControlTag, attributes?: ControlAttributes): ControlAttributes;
export declare function renderControl<H extends (...args: any[]) => any>(h: H, tag: ControlTag, attributes?: ControlAttributes | null, ...children: any[]): ReturnType<H>;
export declare function createControl<K extends ControlTag>(document: Document, tag: K, attributes?: ControlAttributes): HTMLElementTagNameMap[K];
export declare function registerControl<T extends object>(component: T, tag: ControlTag): T;
export declare function nativeControlTag(type: unknown): string | undefined;
/** Decorate a native icon control after installing its trusted bundled SVG. */
export declare function decorateIconAction(element: HTMLElement, label: string): void;
