import { h, ComponentChildren, JSX } from 'preact';
import { SegmentedSwitchProps, SegmentedSwitchValue } from './segmented-switch';
import { EditorPane, EditorSplitLayout } from './editor-layout';
import { ResizeOptions } from './surfaces';
type ButtonAttributes = Omit<JSX.IntrinsicElements['button'], 'className'>;
export type ButtonProps = ButtonAttributes & {
    /** Show progress and block activation until cleared, preserving variant colors. */
    busy?: boolean;
    className?: string;
    variant?: 'default' | 'primary' | 'secondary' | 'danger' | 'danger-outline' | 'ghost' | 'link' | 'solid';
    size?: 'compact' | 'default';
};
export declare const Button: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<ButtonProps> & {
    ref?: import('preact').Ref<HTMLButtonElement> | undefined;
}>;
/** Preact convenience composition of the shared SVG command button owner. */
export declare function IconButton({ label, icon, badge, children, className, variant, size, ...props }: ButtonProps & {
    label: string;
    icon?: string;
    badge?: string | number;
}): h.JSX.Element;
export declare function ToggleButton({ pressed, onPressedChange, ...props }: ButtonProps & {
    pressed: boolean;
    onPressedChange: (value: boolean) => void;
}): h.JSX.Element;
type ShellProps = {
    children?: ComponentChildren;
    className?: string;
    label?: string;
};
export declare function ButtonGroup({ children, className, label }: ShellProps): h.JSX.Element;
export declare function SegmentedControl<T extends SegmentedSwitchValue>(props: SegmentedSwitchProps<T>): h.JSX.Element;
export declare function Tabs<T extends SegmentedSwitchValue>(props: SegmentedSwitchProps<T>): h.JSX.Element;
export declare function TabPanel({ id, labelledBy, active, children, }: {
    id: string;
    labelledBy: string;
    active: boolean;
    children?: ComponentChildren;
}): h.JSX.Element;
export interface RadioOption<T extends string | number> {
    value: T;
    label: ComponentChildren;
    disabled?: boolean;
}
export declare function RadioGroup<T extends string | number>({ className, value, options, onChange, label, disabled, name, }: {
    value: T;
    options: readonly RadioOption<T>[];
    className?: string;
    onChange: (value: T) => void;
    label: string;
    disabled?: boolean;
    name?: string;
}): h.JSX.Element;
export type TextInputProps = Omit<JSX.IntrinsicElements['input'], 'className'> & {
    className?: string;
    onValueChange?: (value: string) => void;
};
export declare function TextInput({ className, class: nativeClass, onValueChange, onInput, ...props }: TextInputProps): h.JSX.Element;
export declare function Textarea({ className, class: nativeClass, onValueChange, onInput, ...props }: Omit<JSX.IntrinsicElements['textarea'], 'className'> & {
    className?: string;
    onValueChange?: (value: string) => void;
}): h.JSX.Element;
export declare function NumberInput({ onValueChange, ...props }: Omit<TextInputProps, 'type' | 'onValueChange'> & {
    onValueChange?: (value: number | undefined) => void;
}): h.JSX.Element;
export declare function NumberStepper({ value, min, max, step, onChange, label, decreaseLabel, increaseLabel, disabled, readOnly, }: {
    value: number;
    min?: number;
    max?: number;
    step?: number;
    onChange: (value: number) => void;
    label: string;
    decreaseLabel: string;
    increaseLabel: string;
    disabled?: boolean;
    readOnly?: boolean;
}): h.JSX.Element;
export declare function DateInput(props: Omit<TextInputProps, 'type'>): h.JSX.Element;
export declare function TimeInput(props: Omit<TextInputProps, 'type'>): h.JSX.Element;
export declare function DateTimeInput(props: Omit<TextInputProps, 'type'>): h.JSX.Element;
export declare function NativeSelect({ className, class: nativeClass, onValueChange, onChange, ...props }: Omit<JSX.IntrinsicElements['select'], 'className'> & {
    className?: string;
    onValueChange?: (value: string) => void;
}): h.JSX.Element;
export declare function Chip({ children, className }: ShellProps): h.JSX.Element;
export declare function FieldHint({ children, id }: ShellProps & {
    id?: string;
}): h.JSX.Element;
export declare function FieldError({ children, id }: ShellProps & {
    id?: string;
}): h.JSX.Element;
export declare function FormSection({ children, title, description, }: ShellProps & {
    title?: string;
    description?: string;
}): h.JSX.Element;
export declare function Disclosure({ children, className, summary, open, onToggle, }: ShellProps & {
    summary: ComponentChildren;
    open?: boolean;
    onToggle?: JSX.GenericEventHandler<HTMLDetailsElement>;
}): h.JSX.Element;
export { EditorPane as Pane, EditorSplitLayout as SplitLayout, };
export declare function Panel({ children, className, label }: ShellProps): h.JSX.Element;
export declare function Toolbar({ children, className, label }: ShellProps): h.JSX.Element;
export declare function ToolbarGroup({ children, className, label }: ShellProps): h.JSX.Element;
export declare function ToolbarSeparator(): h.JSX.Element;
export declare function Badge({ children, className }: ShellProps): h.JSX.Element;
export declare function CountBadge({ count, label }: {
    count: number;
    label: string;
}): h.JSX.Element;
export { Alert } from './alert';
export declare function Spinner({ label }: {
    label: string;
}): import('preact').VNode<import('preact').Attributes>;
export declare function LoadingOverlay({ busy, label, children, }: {
    busy: boolean;
    label: string;
    children?: ComponentChildren;
}): h.JSX.Element;
export declare function EmptyState({ title, description, children, }: {
    title: string;
    description?: string;
    children?: ComponentChildren;
}): h.JSX.Element;
export declare function Menu({ children, label, onClose, }: ShellProps & {
    onClose?: () => void;
}): h.JSX.Element;
export declare function MenuItem({ children, ...props }: ButtonProps): h.JSX.Element;
export declare function MenuSeparator(): h.JSX.Element;
export declare function Submenu({ label, children }: ShellProps & {
    label: string;
}): h.JSX.Element;
export declare function ResizeHandle(props: ResizeOptions): h.JSX.Element;
export declare function Pagination({ page, pageCount, onChange, label, previousLabel, nextLabel, variant, disabled, navigation, }: {
    page: number;
    pageCount: number;
    onChange: (page: number) => void;
    label: string;
    previousLabel: string;
    nextLabel: string;
    variant?: 'compact' | 'numbered' | 'icons';
    disabled?: boolean;
    navigation?: boolean;
}): h.JSX.Element;
export declare function CircularProgress({ value, min, max, label, }: {
    value: number;
    min?: number;
    max?: number;
    label: string;
}): h.JSX.Element;
export declare function Rating({ value, max, label, onChange, disabled, }: {
    value: number;
    max?: number;
    label: string;
    onChange?: (value: number) => void;
    disabled?: boolean;
}): h.JSX.Element;
export * from './selection-list';
