import { createControlId as e } from "./core/control-id.js";
import { registerControl as t } from "./control-presentation.js";
import { ButtonControl as n, Input as r, Select as i, TextArea as a } from "./native-control.js";
import { attachMenuKeyboard as o, attachResizeHandle as s } from "./surfaces.js";
import { normalizeProgressRange as c } from "./progress/range.js";
import { a as l, t as u } from "./_chunks/alert-BjgGD4ar.js";
import { paginationItems as d, renderPaginationButton as f } from "./pagination.js";
import { n as p } from "./_chunks/rating-choice-BX20k8iz.js";
import { SvgButton as m } from "./buttons/svg-button.js";
import { SegmentedSwitch as h } from "./segmented-switch/index.js";
import { EditorList as g, EditorListGroup as _, EditorListItem as v, EditorListItemContent as y, EditorPane as b, EditorSplitLayout as ee } from "./editor-layout/index.js";
import { h as x } from "preact";
import { forwardRef as S } from "preact/compat";
import { Fragment as C, jsx as w, jsxs as T } from "preact/jsx-runtime";
import { useLayoutEffect as E, useRef as D, useState as O } from "preact/hooks";
//#region src/controls.tsx
var k = t(S(function({ variant: e = "default", size: t = "default", className: r = "", class: i, ...a }, o) {
	return /* @__PURE__ */ w(n, {
		ref: o,
		type: "button",
		...a,
		class: [
			e === "default" ? "rv-btn" : `rv-btn-${e}`,
			t === "compact" ? "rv-btn-sm" : "",
			i,
			r
		].filter(Boolean).join(" ")
	});
}), "button");
function te({ label: e, icon: t, badge: n, children: r, className: i = "", variant: a = "ghost", size: o = "default", ...s }) {
	return /* @__PURE__ */ w(m, {
		...s,
		label: e,
		icon: t,
		badge: n,
		className: `rv-btn-icon ${a === "default" ? "rv-btn" : `rv-btn-${a}`} ${o === "compact" ? "rv-btn-sm" : ""} ${i}`,
		children: r
	});
}
function ne({ pressed: e, onPressedChange: t, ...n }) {
	return /* @__PURE__ */ w(k, {
		...n,
		"aria-pressed": e,
		onClick: (r) => {
			n.onClick?.(r), r.defaultPrevented || t(!e);
		}
	});
}
function A({ children: e, className: t = "", label: n }) {
	return /* @__PURE__ */ w("div", {
		role: "group",
		"aria-label": n,
		class: `rv-btn-group ${t}`,
		children: e
	});
}
function j(e) {
	return /* @__PURE__ */ w(h, {
		...e,
		role: "radiogroup"
	});
}
function M(e) {
	return /* @__PURE__ */ w(h, {
		...e,
		role: "tablist"
	});
}
function N({ id: e, labelledBy: t, active: n, children: r }) {
	return /* @__PURE__ */ w("div", {
		id: e,
		role: "tabpanel",
		"aria-labelledby": t,
		hidden: !n,
		children: r
	});
}
function P({ className: t = "", value: n, options: i, onChange: a, label: o, disabled: s, name: c }) {
	let [l] = O(() => e("rv-ui"));
	return /* @__PURE__ */ T("fieldset", {
		class: `rv-radio-group ${t}`,
		disabled: s,
		children: [/* @__PURE__ */ w("legend", { children: o }), i.map((e) => /* @__PURE__ */ T("label", { children: [/* @__PURE__ */ w(r, {
			type: "radio",
			name: c ?? l,
			checked: n === e.value,
			disabled: e.disabled,
			onChange: () => a(e.value)
		}), e.label] }, e.value))]
	});
}
function F({ className: e = "", class: t, onValueChange: n, onInput: i, ...a }) {
	return /* @__PURE__ */ w(r, {
		type: "text",
		...a,
		class: `rv-control ${t ?? ""} ${e}`,
		onInput: (e) => {
			i?.(e), e.defaultPrevented || n?.(e.currentTarget.value);
		}
	});
}
function I({ className: e = "", class: t, onValueChange: n, onInput: r, ...i }) {
	return /* @__PURE__ */ w(a, {
		...i,
		class: `rv-control ${t ?? ""} ${e}`,
		onInput: (e) => {
			r?.(e), e.defaultPrevented || n?.(e.currentTarget.value);
		}
	});
}
function L({ onValueChange: e, ...t }) {
	return /* @__PURE__ */ w(F, {
		...t,
		type: "number",
		onValueChange: (t) => {
			t === "" ? e?.(void 0) : Number.isFinite(Number(t)) && e?.(Number(t));
		}
	});
}
function R({ value: e, min: t = -Infinity, max: n = Infinity, step: r = 1, onChange: i, label: a, decreaseLabel: o, increaseLabel: s, disabled: c, readOnly: l }) {
	let u = (e) => {
		Number.isFinite(e) && i(Math.max(t, Math.min(n, e)));
	};
	return /* @__PURE__ */ T("div", {
		class: "rv-number-stepper",
		role: "group",
		"aria-label": a,
		children: [
			/* @__PURE__ */ w(k, {
				disabled: c || l || e <= t,
				"aria-label": o,
				onClick: () => u(e - r),
				children: "−"
			}),
			/* @__PURE__ */ w(L, {
				"aria-label": a,
				value: e,
				min: Number.isFinite(t) ? t : void 0,
				max: Number.isFinite(n) ? n : void 0,
				step: r,
				disabled: c,
				readOnly: l,
				onValueChange: (e) => {
					e !== void 0 && u(e);
				}
			}),
			/* @__PURE__ */ w(k, {
				disabled: c || l || e >= n,
				"aria-label": s,
				onClick: () => u(e + r),
				children: "+"
			})
		]
	});
}
function z(e) {
	return /* @__PURE__ */ w(F, {
		...e,
		type: "date"
	});
}
function B(e) {
	return /* @__PURE__ */ w(F, {
		...e,
		type: "time"
	});
}
function V(e) {
	return /* @__PURE__ */ w(F, {
		...e,
		type: "datetime-local"
	});
}
function H({ className: e = "", class: t, onValueChange: n, onChange: r, ...a }) {
	return /* @__PURE__ */ w(i, {
		...a,
		class: `rv-control ${t ?? ""} ${e}`,
		onChange: (e) => {
			r?.(e), e.defaultPrevented || n?.(e.currentTarget.value);
		}
	});
}
function U({ children: e, className: t = "" }) {
	return /* @__PURE__ */ w("span", {
		class: `rv-btn-pill ${t}`,
		children: e
	});
}
function W({ children: e, id: t }) {
	return /* @__PURE__ */ w("span", {
		class: "rv-field__hint",
		id: t,
		children: e
	});
}
function G({ children: e, id: t }) {
	return /* @__PURE__ */ w("span", {
		class: "rv-field__error",
		id: t,
		role: "alert",
		children: e
	});
}
function re({ children: e, title: t, description: n }) {
	return /* @__PURE__ */ T("fieldset", {
		class: "rv-form-section",
		children: [
			t && /* @__PURE__ */ w("legend", {
				class: "rv-form-section__title",
				children: t
			}),
			n && /* @__PURE__ */ w("p", {
				class: "rv-form-description",
				children: n
			}),
			e
		]
	});
}
function K({ children: e, className: t = "", summary: n, open: r, onToggle: i }) {
	return /* @__PURE__ */ T("details", {
		class: `rv-disclosure ${t}`.trim(),
		open: r,
		onToggle: i,
		children: [/* @__PURE__ */ w("summary", {
			class: "rv-disclosure-summary",
			children: n
		}), e]
	});
}
function q({ children: e, className: t = "", label: n }) {
	return /* @__PURE__ */ w("section", {
		class: `rv-panel ${t}`,
		"aria-label": n,
		children: e
	});
}
function J({ children: e, className: t = "", label: n }) {
	return /* @__PURE__ */ w("div", {
		class: `rv-toolbar ${t}`,
		role: "toolbar",
		"aria-label": n,
		children: e
	});
}
function Y({ children: e, className: t = "", label: n }) {
	return /* @__PURE__ */ w("div", {
		class: `rv-toolbar-group ${t}`,
		role: "group",
		"aria-label": n,
		children: e
	});
}
function X() {
	return /* @__PURE__ */ w("span", {
		class: "rv-toolbar-separator",
		role: "separator",
		"aria-orientation": "vertical"
	});
}
function ie({ children: e, className: t = "" }) {
	return /* @__PURE__ */ w("span", {
		class: `rv-badge rv-badge--inline ${t}`,
		children: e
	});
}
function ae({ count: e, label: t }) {
	return /* @__PURE__ */ w("span", {
		class: "rv-count",
		"aria-label": t,
		children: e
	});
}
function Z({ label: e }) {
	return l(x, {
		label: e,
		showSpinner: !0
	});
}
function oe({ busy: e, label: t, children: n }) {
	return /* @__PURE__ */ T("div", {
		class: "rv-loading-container",
		"aria-busy": e,
		children: [n, e && /* @__PURE__ */ w("div", {
			class: "rv-loading-overlay",
			children: /* @__PURE__ */ w(Z, { label: t })
		})]
	});
}
function se({ title: e, description: t, children: n }) {
	return /* @__PURE__ */ T("div", {
		class: "rv-empty-state",
		children: [
			/* @__PURE__ */ w("strong", { children: e }),
			t && /* @__PURE__ */ w("p", { children: t }),
			n
		]
	});
}
function Q({ children: e, label: t, onClose: n }) {
	let r = D(null);
	return E(() => r.current ? o(r.current, n) : void 0, [n]), /* @__PURE__ */ w("div", {
		ref: r,
		class: "rv-menu",
		role: "menu",
		"aria-label": t,
		children: e
	});
}
function ce({ children: e, ...t }) {
	return /* @__PURE__ */ w(k, {
		variant: "ghost",
		...t,
		role: "menuitem",
		children: e
	});
}
function le() {
	return /* @__PURE__ */ w("div", {
		role: "separator",
		class: "rv-menu-separator"
	});
}
function $({ label: t, children: n }) {
	let [r, i] = O(!1), a = D(null), o = D(null), [s] = O(() => e("rv-ui"));
	E(() => {
		r && a.current?.querySelector("[role=\"menu\"]")?.querySelector("[role=\"menuitem\"]:not(:disabled)")?.focus();
	}, [r]);
	let c = () => {
		i(!1), o.current?.focus();
	};
	return /* @__PURE__ */ T("div", {
		ref: a,
		class: "rv-submenu",
		onKeyDown: (e) => {
			r && (e.key === "ArrowLeft" || e.key === "Escape") && (e.preventDefault(), e.stopPropagation(), c());
		},
		children: [/* @__PURE__ */ w(k, {
			ref: o,
			variant: "ghost",
			role: "menuitem",
			"aria-haspopup": "menu",
			"aria-expanded": r,
			"aria-controls": s,
			onClick: () => i(!r),
			onKeyDown: (e) => {
				e.key === "ArrowRight" && (e.preventDefault(), i(!0));
			},
			children: t
		}), r && /* @__PURE__ */ w("div", {
			id: s,
			children: /* @__PURE__ */ w(Q, {
				label: t,
				onClose: c,
				children: n
			})
		})]
	});
}
function ue(e) {
	let t = D(null), n = D(e);
	return n.current = e, E(() => t.current ? s(t.current, () => n.current) : void 0, []), /* @__PURE__ */ w("div", {
		class: "rv-resize-handle",
		ref: t,
		role: "separator",
		tabIndex: 0,
		"aria-orientation": "vertical",
		"aria-label": e.label,
		"aria-valuenow": e.value,
		"aria-valuemin": e.min,
		"aria-valuemax": e.max
	});
}
function de({ page: e, pageCount: t, onChange: n, label: r, previousLabel: i, nextLabel: a, variant: o = "compact", disabled: s = !1, navigation: c = !0 }) {
	let l = Math.max(0, Math.floor(t) || 0), u = Math.min(Math.max(0, Math.floor(e) || 0), Math.max(0, l - 1)), p = (e, t) => f(x, {
		text: t,
		label: t,
		kind: e,
		disabled: s || !l || (e === "previous" ? u === 0 : u === l - 1),
		onClick: () => n(u + (e === "previous" ? -1 : 1))
	});
	return /* @__PURE__ */ T("nav", {
		class: `rv-pagination ${o === "numbered" ? "rv-pagination--numbered" : ""}`,
		"aria-label": r,
		children: [
			c && p("previous", i),
			o === "numbered" ? /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w("span", {
				class: `rv-pagination-pages ${l <= 5 ? "rv-pagination-pages--compact" : ""}`,
				children: d(u, l, 3).map((e, t) => e === "ellipsis" ? /* @__PURE__ */ w("span", {
					class: "rv-pagination-ellipsis",
					"aria-label": "More pages",
					children: "…"
				}, `gap-${t}`) : f(x, {
					text: String(e + 1),
					label: `${e + 1}`,
					active: e === u,
					disabled: s,
					onClick: () => {
						e !== u && n(e);
					}
				}))
			}), l > 5 && /* @__PURE__ */ T("span", {
				class: "rv-pagination-summary rv-pagination-summary--responsive",
				"aria-live": "polite",
				children: [
					l ? u + 1 : 0,
					" / ",
					l
				]
			})] }) : o === "compact" ? /* @__PURE__ */ T("span", {
				class: "rv-pagination-summary",
				"aria-live": "polite",
				children: [
					l ? u + 1 : 0,
					" / ",
					l
				]
			}) : null,
			c && p("next", a)
		]
	});
}
function fe({ value: e, min: t = 0, max: n = 100, label: r }) {
	let i = c(e, t, n);
	return /* @__PURE__ */ T("svg", {
		viewBox: "0 0 36 36",
		class: "rv-circular-progress",
		role: "progressbar",
		"aria-label": r,
		"aria-valuemin": i.min,
		"aria-valuemax": i.max,
		"aria-valuenow": i.min + (i.max - i.min) * i.percent / 100,
		children: [/* @__PURE__ */ w("circle", {
			cx: "18",
			cy: "18",
			r: "16",
			fill: "none",
			stroke: "currentColor",
			opacity: "0.15"
		}), /* @__PURE__ */ w("circle", {
			cx: "18",
			cy: "18",
			r: "16",
			fill: "none",
			stroke: "currentColor",
			pathLength: "100",
			"stroke-dasharray": `${i.percent} 100`,
			transform: "rotate(-90 18 18)"
		})]
	});
}
function pe({ value: e, max: t = 5, label: n, onChange: r, disabled: i }) {
	let a = Array.from({ length: Math.max(0, Math.min(100, Math.floor(t))) }, (e, t) => t + 1);
	return r ? /* @__PURE__ */ w(P, {
		className: "rv-rating",
		label: n,
		value: e,
		disabled: i,
		options: a.map((t) => ({
			value: t,
			label: /* @__PURE__ */ T(C, { children: [/* @__PURE__ */ w(p, { filled: t <= e }), /* @__PURE__ */ w("span", {
				class: "rv-visually-hidden",
				children: t
			})] })
		})),
		onChange: r
	}) : /* @__PURE__ */ w("span", {
		class: "rv-rating",
		role: "img",
		"aria-label": `${n}: ${e} / ${t}`,
		children: a.map((t) => /* @__PURE__ */ w(p, { filled: t <= e }))
	});
}
t(F, "input"), t(L, "input"), t(z, "input"), t(B, "input"), t(V, "input"), t(I, "textarea"), t(H, "select");
//#endregion
export { u as Alert, ie as Badge, k as Button, A as ButtonGroup, U as Chip, fe as CircularProgress, ae as CountBadge, z as DateInput, V as DateTimeInput, K as Disclosure, se as EmptyState, G as FieldError, W as FieldHint, re as FormSection, te as IconButton, g as Listbox, _ as ListboxGroup, v as ListboxOption, y as ListboxOptionContent, oe as LoadingOverlay, Q as Menu, ce as MenuItem, le as MenuSeparator, H as NativeSelect, L as NumberInput, R as NumberStepper, de as Pagination, b as Pane, q as Panel, P as RadioGroup, pe as Rating, ue as ResizeHandle, j as SegmentedControl, Z as Spinner, ee as SplitLayout, $ as Submenu, N as TabPanel, M as Tabs, F as TextInput, I as Textarea, B as TimeInput, ne as ToggleButton, J as Toolbar, Y as ToolbarGroup, X as ToolbarSeparator };
