export interface AnchoredPopoverPosition {
    left: number;
    top: number;
    placementX: 'left' | 'right';
    placementY: 'above' | 'below';
}
/** Pure positioning helper shared by portalled grid popups. */
export declare function calculateAnchoredPopoverPosition(anchor: Pick<DOMRect, 'left' | 'right' | 'top' | 'bottom'>, popup: Pick<DOMRect, 'width' | 'height'>, viewport: {
    width: number;
    height: number;
}, gap?: number, inset?: number): AnchoredPopoverPosition;
