//#region src/core/anchored-popover.ts
function e(e, t, n, r = 4, i = 8) {
	let a = e.bottom + r, o = e.top - t.height - r, s = a + t.height <= n.height - i || o < i ? "below" : "above", c = e.left, l = e.right - t.width, u = c + t.width <= n.width - i || l < i ? "left" : "right";
	return {
		left: Math.min(Math.max(u === "left" ? c : l, i), Math.max(i, n.width - t.width - i)),
		top: Math.min(Math.max(s === "below" ? a : o, i), Math.max(i, n.height - t.height - i)),
		placementX: u,
		placementY: s
	};
}
//#endregion
export { e as calculateAnchoredPopoverPosition };
