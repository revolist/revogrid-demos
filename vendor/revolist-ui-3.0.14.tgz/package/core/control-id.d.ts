/** IDs for controls mounted in independent roots that share one document. */
export declare function createControlId(prefix?: string): string;
