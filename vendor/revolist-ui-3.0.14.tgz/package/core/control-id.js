//#region src/core/control-id.ts
function e(e = "rv-control") {
	return `${e}-${globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`}`;
}
//#endregion
export { e as createControlId };
