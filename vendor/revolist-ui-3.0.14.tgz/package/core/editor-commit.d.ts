export type EditorCommit = () => boolean | void;
/** A popup registers one draft owner. Programmatic close and Escape never commit. */
export declare const EditorCommitContext: import('preact').Context<((commit: EditorCommit) => () => void) | undefined>;
export declare function useEditorAutoApply(commit: EditorCommit, enabled?: boolean): void;
