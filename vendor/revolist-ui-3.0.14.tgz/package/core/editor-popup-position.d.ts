/** Keep the owning field visible, scrolling the popup on the roomier side when necessary. */
export declare function calculateEditorPopupPosition(anchor: Pick<DOMRect, 'left' | 'right' | 'top' | 'bottom'>, popup: Pick<DOMRect, 'width' | 'height'>, viewport: {
    width: number;
    height: number;
}, gap?: number, inset?: number): {
    placementY: string;
    maxHeight: number;
    top: number;
    left: number;
    placementX: "left" | "right";
};
