import { ComponentChildren } from 'preact';
export interface EditorPopupHandle {
    readonly element: HTMLElement;
    close(): void;
}
export interface EditorPopupOptions {
    label: string;
    className?: string;
    onClose?: () => void;
    isAvailable?: () => boolean;
}
/** Shared non-modal editor lifecycle. The anchor owns the popup across virtualization and theme inheritance. */
export declare function mountEditorPopup(anchor: HTMLElement, content: (close: () => void) => ComponentChildren, options: EditorPopupOptions): EditorPopupHandle;
