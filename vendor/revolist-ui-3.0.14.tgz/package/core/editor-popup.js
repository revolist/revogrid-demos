export { t as mountEditorPopup } from "../_chunks/editor-popup-BkaZnvXI.js";
