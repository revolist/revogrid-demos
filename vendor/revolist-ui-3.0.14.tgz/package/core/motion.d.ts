/** Shared motion policy for CSS transitions, overlays and Web Animations. */
export type UiMotionTiming = 'fast' | 'normal' | 'enter' | 'exit';
export declare function isUiMotionEnabled(element?: Element | null): boolean;
export declare function getUiMotionDuration(element: Element, timing: UiMotionTiming, fallback: number): number;
/** Listeners exist only for an open portal or a currently running animation. */
export declare function watchUiMotionPolicy(element: Element, update: () => void): () => void;
/** Preserve opt-out policy when a surface leaves its original DOM subtree. */
export declare function inheritUiMotion(source: Element | null | undefined, target: Element): () => void;
