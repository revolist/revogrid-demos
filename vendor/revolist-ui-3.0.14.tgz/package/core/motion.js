//#region src/core/motion.ts
function e(e) {
	let t = [];
	for (let n = e; n;) {
		t.push(n);
		let e = n.getRootNode();
		n = n.parentElement ?? (e.nodeType === 11 && "host" in e ? e.host : null);
	}
	return t;
}
function t(t) {
	if (!t) return !0;
	let n = t.ownerDocument.defaultView;
	return n?.matchMedia?.("(prefers-reduced-motion: reduce)").matches || e(t).some((e) => e.getAttribute("data-rv-ui-motion") === "off") ? !1 : n?.getComputedStyle(t).getPropertyValue("--rv-ui-motion-enabled").trim() !== "0";
}
function n(e, t, n) {
	let r = (e.ownerDocument.defaultView?.getComputedStyle(e).getPropertyValue(`--rv-ui-motion-${t}`).trim() ?? "").match(/^((?:\d+(?:\.\d*)?|\.\d+))(ms|s)$/);
	return r ? Number(r[1]) * (r[2] === "s" ? 1e3 : 1) : n;
}
function r(t, n) {
	let r = t.ownerDocument.defaultView, i = r?.MutationObserver ? new r.MutationObserver(n) : void 0;
	for (let n of e(t)) i?.observe(n, {
		attributes: !0,
		attributeFilter: ["data-rv-ui-motion", "style"]
	});
	let a = r?.matchMedia?.("(prefers-reduced-motion: reduce)");
	return a?.addEventListener?.("change", n), () => {
		i?.disconnect(), a?.removeEventListener?.("change", n);
	};
}
function i(e, n) {
	let i = n.getAttribute("data-rv-ui-motion"), a = () => {
		i === null ? n.removeAttribute("data-rv-ui-motion") : n.setAttribute("data-rv-ui-motion", i);
	};
	if (e === n || !e) return () => {};
	let o = () => {
		i === "off" || !t(e) ? n.setAttribute("data-rv-ui-motion", "off") : a();
	};
	o();
	let s = r(e, o);
	return () => {
		s(), a();
	};
}
//#endregion
export { n as getUiMotionDuration, i as inheritUiMotion, t as isUiMotionEnabled, r as watchUiMotionPolicy };
