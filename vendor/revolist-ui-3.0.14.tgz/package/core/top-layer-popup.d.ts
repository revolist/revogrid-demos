export type TopLayerPopupMode = 'popover' | 'fallback';
export type TopLayerPopupElement = HTMLElement & {
    showPopover?: () => void;
    hidePopover?: () => void;
};
/** Opens an overlay in the browser top layer when supported. */
export declare function showTopLayerPopup(element: TopLayerPopupElement, visibleDisplay?: string): TopLayerPopupMode;
/** Hides an overlay opened by `showTopLayerPopup`; safe to call repeatedly. */
export declare function hideTopLayerPopup(element: TopLayerPopupElement, mode?: TopLayerPopupMode): void;
