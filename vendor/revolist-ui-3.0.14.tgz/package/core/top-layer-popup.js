//#region src/core/top-layer-popup.ts
var e = /* @__PURE__ */ new WeakMap();
function t(t, n = "flex") {
	if (e.has(t) || e.set(t, t.getAttribute("data-rv-ui-surface")), t.setAttribute("data-rv-ui-surface", ""), t.style.display = n, typeof t.showPopover == "function") {
		t.setAttribute("popover", "manual");
		try {
			return t.showPopover(), "popover";
		} catch {
			t.removeAttribute("popover");
		}
	}
	return t.style.display = n, "fallback";
}
function n(t, n) {
	let r = e.get(t);
	if (r !== void 0 && (r === null ? t.removeAttribute("data-rv-ui-surface") : t.setAttribute("data-rv-ui-surface", r), e.delete(t)), n === "popover" && typeof t.hidePopover == "function") try {
		t.hidePopover(), t.style.removeProperty("display");
		return;
	} catch {}
	t.style.display = "none";
}
//#endregion
export { n as hideTopLayerPopup, t as showTopLayerPopup };
