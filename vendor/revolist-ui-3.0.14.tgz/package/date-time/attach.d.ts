import { TemporalPickerOptions } from './types';
/** Adds the shared picker to an existing native input without changing its draft/commit owner. */
export declare function attachTemporalPicker(input: HTMLInputElement, options: TemporalPickerOptions, commit: (value: string) => void): () => void;
