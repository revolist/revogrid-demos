import { DateEntryOptions } from '../_shared/dates/index';
export interface DateInputOptions extends DateEntryOptions {
    placeholder?: string;
    /** Date-only multiple selection uses a semicolon-separated list by default. */
    multipleSeparator?: string;
}
export declare function DateControl({ value, label, options, multiple, invalid, errorId, onChange, onFocus }: {
    value: string | string[];
    label: string;
    options?: DateInputOptions;
    multiple?: boolean;
    invalid?: boolean;
    errorId?: string;
    onFocus?: () => void;
    onChange: (date: string | string[]) => void;
}): import("preact").JSX.Element;
