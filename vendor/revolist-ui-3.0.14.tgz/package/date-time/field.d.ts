import { DateTimeFieldProps, TemporalPickerOptions } from './types';
import { TemporalControlValue } from '../_shared/dates/index';
export declare function TemporalDraft({ value, options, apply, cancel, clearable, }: {
    clearable?: boolean;
    value: TemporalControlValue;
    options: TemporalPickerOptions;
    apply: (value: TemporalControlValue) => void | string;
    cancel: () => void;
}): import("preact").JSX.Element;
/** Native text entry plus the original shared CalendarPicker, usable in any product form. */
export declare function DateTimeField({ value, kind, picker, onValueChange, onInput, formatValue, parseValue, ...input }: DateTimeFieldProps): import("preact").JSX.Element;
