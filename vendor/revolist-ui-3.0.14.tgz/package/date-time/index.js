import { createControlId as e } from "../core/control-id.js";
import { createPreactElement as t, releasePreactElement as n } from "../preact-mount.js";
import { Input as r } from "../native-control.js";
import { t as i } from "../_chunks/alert-BjgGD4ar.js";
import { SvgIcon as a } from "../icons/icon.js";
import { i as o, s } from "../_chunks/iso-B0YHBK7m.js";
import { f as c, h as l, m as u, p as d, u as f } from "../_chunks/model-mPO2tG2f.js";
import { t as p } from "../_chunks/picker-PiJmfr-8.js";
import { Button as m } from "../controls.js";
import { t as h } from "../_chunks/calendar-CQs8vcpq.js";
import { t as g } from "../_chunks/editor-popup-BkaZnvXI.js";
import { n as _ } from "../_chunks/editor-commit-D6Rf5rGz.js";
import { EditorActions as v } from "../editor-actions.js";
import { Fragment as y, jsx as b, jsxs as x } from "preact/jsx-runtime";
import { useEffect as S, useLayoutEffect as C, useRef as w, useState as T } from "preact/hooks";
//#region ../dates/src/date-controls.ts
var E = /^(\d{4})-(\d{2})-(\d{2})$/, D = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?$/, O = /^(\d{2}):(\d{2})(?::(\d{2}))?$/;
function k(e, t, n = "minute") {
	if (Number.isNaN(t.getTime())) return "";
	let r = `${j(t.getHours())}:${j(t.getMinutes())}${n === "second" ? `:${j(t.getSeconds())}` : ""}`;
	if (e === "time") return r;
	let i = o(t);
	return e === "date" ? i : `${i}T${r}`;
}
function A(e, t, n = /* @__PURE__ */ new Date()) {
	if (e === "time") {
		let e = O.exec(t);
		if (!e) return;
		let r = Number(e[1]), i = Number(e[2]), a = Number(e[3] ?? 0);
		if (r > 23 || i > 59 || a > 59 || Number.isNaN(n.getTime())) return;
		let o = new Date(n.getTime());
		return o.setHours(r, i, a, 0), o;
	}
	let r = e === "date" ? E.exec(t) : D.exec(t);
	if (!r) return;
	let i = Number(r[1]), a = Number(r[2]), o = Number(r[3]), s = Number(r[4] ?? 0), c = Number(r[5] ?? 0), l = Number(r[6] ?? 0), u = Number((r[7] ?? "").padEnd(3, "0")), d = /* @__PURE__ */ new Date(0);
	if (d.setFullYear(i, a - 1, o), d.setHours(s, c, l, u), !(a < 1 || a > 12 || o < 1 || d.getFullYear() !== i || d.getMonth() !== a - 1 || d.getDate() !== o || d.getHours() !== s || d.getMinutes() !== c || d.getSeconds() !== l || d.getMilliseconds() !== u)) return d;
}
function j(e) {
	return String(e).padStart(2, "0");
}
//#endregion
//#region ../dates/src/civil-time.ts
var M = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
function N(e) {
	let t = /* @__PURE__ */ new Date(0);
	return t.setUTCFullYear(e.year, e.month - 1, e.day), t.setUTCHours(e.hour, e.minute, e.second, 0), t.getTime();
}
function P(e) {
	let t = M.exec(e);
	if (!t) return;
	let n = {
		year: Number(t[1]),
		month: Number(t[2]),
		day: Number(t[3]),
		hour: Number(t[4]),
		minute: Number(t[5]),
		second: Number(t[6] ?? 0)
	}, r = new Date(N(n)), i = {
		year: r.getUTCFullYear(),
		month: r.getUTCMonth() + 1,
		day: r.getUTCDate(),
		hour: r.getUTCHours(),
		minute: r.getUTCMinutes(),
		second: r.getUTCSeconds()
	};
	return Object.keys(n).every((e) => n[e] === i[e]) ? n : void 0;
}
//#endregion
//#region ../dates/src/temporal-controls.ts
function F(e) {
	return e.split("T")[0];
}
function I(e) {
	return e.includes("T") ? e.split("T")[1] : e;
}
function L(e, t, n) {
	return n === "datetime" ? `${e}T${t.includes("T") ? I(t) : "00:00"}` : e;
}
function R(e, t, n) {
	return n === "datetime" ? `${F(e)}T${t}` : t;
}
function z(e, t) {
	return e === "date" ? s(t) : e === "datetime" ? !!P(t.replace(/(\d{2}:\d{2}:\d{2})\.\d{1,3}$/, "$1")) : !!A(e, t);
}
function B(e) {
	let t = A("time", e);
	return t ? t.getHours() * 3600 + t.getMinutes() * 60 + t.getSeconds() : void 0;
}
function V(e, t) {
	let n = B(e);
	if (n === void 0) return !1;
	let r = t.min ? B(t.min) : void 0, i = t.max ? B(t.max) : void 0;
	return (r === void 0 || n >= r) && (i === void 0 || n <= i) && (t.step === void 0 || t.step > 0 && (n - (r ?? 0)) % t.step === 0);
}
function H(e, t, n = "minute", r) {
	let i = A("time", e);
	return i ? new Intl.DateTimeFormat(r ?? (t === "12h" ? "en-US" : "en-GB"), {
		hour: "2-digit",
		minute: "2-digit",
		...n === "second" ? { second: "2-digit" } : {},
		hourCycle: t === "12h" ? "h12" : "h23"
	}).format(i) : e;
}
function U(e, t = "minute", n) {
	if (e = e.replace(/[\u200e\u200f\u061c]/g, "").trim(), n) {
		let t = new Intl.NumberFormat(n, { useGrouping: !1 });
		for (let n = 0; n < 10; n++) e = e.split(t.format(n)).join(String(n));
		let r = new Intl.DateTimeFormat(n, {
			hour: "numeric",
			hourCycle: "h12"
		});
		for (let [t, n] of [[1, "AM"], [13, "PM"]]) {
			let i = r.formatToParts(new Date(2e3, 0, 1, t)).find((e) => e.type === "dayPeriod")?.value;
			i && (e = e.replace(i, n));
		}
		let i = new Intl.DateTimeFormat(n, {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hourCycle: "h23"
		}).formatToParts(new Date(2e3, 0, 1, 13, 45, 20));
		for (let t of i) t.type === "literal" && t.value.trim() && (e = e.split(t.value).join(":"));
		e = e.replace(/^\s*(AM|PM)\s*(.*)$/i, "$2 $1");
	}
	let r = A("time", e.trim());
	if (r) return k("time", r, t);
	let i = /^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([ap])\.?m\.?$/i.exec(e.trim());
	if (!i) return;
	let a = Number(i[1]);
	if (a < 1 || a > 12) return;
	let o = A("time", `${String(a % 12 + (i[4].toLowerCase() === "p" ? 12 : 0)).padStart(2, "0")}:${i[2]}:${i[3] ?? "00"}`);
	return o ? k("time", o, t) : void 0;
}
//#endregion
//#region ../dates/src/date-entry.ts
function W(e) {
	return e.format === "eu" ? "en-GB" : e.format === "us" ? "en-US" : e.locale;
}
function G(e) {
	return new Intl.DateTimeFormat(W(e), {
		calendar: "gregory",
		timeZone: "UTC",
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}).formatToParts(/* @__PURE__ */ new Date("2006-11-22T00:00:00Z"));
}
function K(e = {}) {
	return !e.format || e.format === "iso" ? "YYYY-MM-DD" : G(e).map((e) => e.type === "year" ? "YYYY" : e.type === "month" ? "MM" : e.type === "day" ? "DD" : e.value).join("");
}
function q(e, t = {}) {
	return s(e) ? t.formatValue ? t.formatValue(e) : !t.format || t.format === "iso" ? e : f(e, W(t) ?? new Intl.DateTimeFormat().resolvedOptions().locale, {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}) : e;
}
function J(e, t = {}) {
	let n = e.trim();
	if (s(n)) return n;
	if (t.parse) {
		let e = t.parse(n);
		return s(e) ? e : void 0;
	}
	if (!t.format || t.format === "iso") return;
	let r = n.normalize("NFKC").replace(/[\u200e\u200f\u061c]/g, ""), i = new Intl.NumberFormat(W(t), { useGrouping: !1 });
	for (let e = 0; e < 10; e++) r = r.split(i.format(e)).join(String(e));
	let a = r.split(/[./\-\s]+/), o = G(t).filter((e) => [
		"year",
		"month",
		"day"
	].includes(e.type));
	if (a.length !== 3 || a.some((e) => !/^\d{1,4}$/.test(e))) return;
	let c = Object.fromEntries(o.map((e, t) => [e.type, a[t]]));
	if (c.year.length !== 4) return;
	let l = `${c.year}-${c.month.padStart(2, "0")}-${c.day.padStart(2, "0")}`;
	return s(l) ? l : void 0;
}
//#endregion
//#region src/date-time/types.ts
var Y = {
	date: "Date",
	dates: "Dates",
	invalidDate: "Enter a valid date in the indicated format.",
	outOfRange: "The date is outside the allowed range.",
	disabledDate: "This date is unavailable.",
	invalidRange: "Enter a complete range with the start before or equal to the end.",
	selectionCount: "The selection does not meet the allowed count or length.",
	requiredValue: "A value is required.",
	startDate: "Start date",
	endDate: "End date",
	startTime: "Start time",
	endTime: "End time",
	time: "Time",
	invalid: "Enter a valid value within the allowed range.",
	chooseDate: "Choose date",
	chooseTime: "Choose time"
};
function X(e, t) {
	return (e === "time" ? t?.chooseTime ?? t?.chooseDate : t?.chooseDate) ?? (e === "time" ? Y.chooseTime : Y.chooseDate);
}
//#endregion
//#region src/date-time/validation.ts
function Z(e, t, n = "") {
	let { kind: r = "date", selection: i = "single", value: a, calendar: o = {} } = e, l = {
		...Y,
		...e.text
	}, f = a && !Array.isArray(a) && typeof a == "object" ? a : void 0, p = typeof a == "string" ? a : "", m = f?.from ?? "", h = f?.to ?? "", g = e.required ?? o.required ?? !1, _ = f ? [m, h] : Array.isArray(a) ? a : p ? [p] : [], v = (e) => s(e) && (!o.minDate || e >= o.minDate) && (!o.maxDate || e <= o.maxDate) && !o.isDateDisabled?.(e) && !o.isMonthDisabled?.(c(e, o.calendarSystem)), y = (t) => z(r, t) && (r === "time" || v(F(t))) && (r === "date" || V(I(t), {
		min: e.minTime,
		max: e.maxTime,
		step: e.timeStep
	})), b = f && h ? u(F(m), F(h)) : 0, x = i === "multiple" ? _.length : b, S = !_.length && !g || i === "single" || (!o.min || x >= o.min) && (o.max === void 0 || x <= o.max), C = (() => {
		if (r === "time" || !f?.to || !o.excludeDisabled || !_.every(y)) return !0;
		if (b > 366e3) return !1;
		for (let e = F(m); e <= F(h); e = d(e, 1)) if (!v(e)) return !1;
		return !0;
	})(), w = "", T = r === "time" || _.every((e) => {
		let n = F(e);
		if (!s(n)) return !1;
		let r = o.validateSelection?.(n, {
			month: o.month ?? t,
			view: o.defaultView ?? "month",
			referenceDate: o.referenceDate,
			selection: f ? {
				from: F(m),
				to: F(h || m)
			} : {
				from: n,
				to: n
			}
		});
		return typeof r == "string" && (w = r), r !== !1 && typeof r != "string";
	}), E = !n && S && T && C && (!g || _.length > 0) && _.every(y) && (i !== "multiple" || new Set(_).size === _.length) && (!f || !!h && m <= h) && (i !== "multiple" || r === "date"), D = (t) => e.text?.[t] ?? e.text?.invalid ?? l[t] ?? l.invalid, O = r === "time" ? [] : _.map(F);
	return {
		valid: E,
		errorMessage: n || w || (!_.length && g ? D("requiredValue") : f && (!m || !h) ? D("invalidRange") : O.some((e) => !s(e)) ? D("invalidDate") : O.some((e) => o.minDate && e < o.minDate || o.maxDate && e > o.maxDate) ? D("outOfRange") : O.some((e) => !v(e)) || !C ? D("disabledDate") : f && (!h || m > h) ? D("invalidRange") : !S || i === "multiple" && new Set(_).size !== _.length ? D("selectionCount") : l.invalid),
		validDate: v
	};
}
//#endregion
//#region src/date-time/date-control.tsx
function Q({ value: e, label: t, options: n = {}, multiple: i, invalid: a, errorId: o, onChange: s, onFocus: c }) {
	let [l, u] = T(!1), [d, f] = T(""), p = n.multipleSeparator?.trim() || ";", m = Array.isArray(e) ? e.map((e) => q(e, n)).join(`${p} `) : q(e, n);
	return /* @__PURE__ */ b(r, {
		type: "text",
		autoComplete: "off",
		spellcheck: !1,
		"aria-label": t,
		"aria-invalid": a,
		"aria-describedby": a ? o : void 0,
		placeholder: n.placeholder ?? K(n),
		value: l ? d : m,
		onFocus: () => {
			u(!0), f(m), c?.();
		},
		onBlur: () => u(!1),
		onInput: (e) => {
			let t = e.currentTarget.value;
			f(t);
			let r = (e) => J(e, n) ?? e.trim();
			s(i ? t.trim() ? t.split(p).map(r) : [] : r(t));
		}
	});
}
//#endregion
//#region src/date-time/time-control.tsx
function ee({ value: e, label: t, format: n = "locale", precision: i = "minute", locale: a, min: o, max: s, step: c, onChange: l }) {
	let [u, d] = T(!1), [f, p] = T("");
	if (n === "locale") return /* @__PURE__ */ b(r, {
		type: "time",
		"aria-label": t,
		value: e,
		min: o,
		max: s,
		step: c ?? (i === "second" ? 1 : 60),
		onInput: (e) => l(e.currentTarget.value)
	});
	let m = H(e, n, i, a);
	return /* @__PURE__ */ b(r, {
		type: "text",
		"aria-label": t,
		value: u ? f : m,
		"aria-invalid": !!e && !V(e, {
			min: o,
			max: s,
			step: c
		}),
		placeholder: n === "12h" ? "09:00 AM" : "09:00",
		onFocus: () => {
			d(!0), p(m);
		},
		onBlur: () => d(!1),
		onInput: (e) => {
			let t = e.currentTarget.value;
			p(t), l(t ? U(t, i, a) ?? t : "");
		}
	});
}
//#endregion
//#region src/date-time/picker.tsx
function te(t) {
	let { kind: n = "date", selection: r = "single", value: a, onChange: o, calendar: u = {} } = t, d = {
		...Y,
		...t.text
	}, [f] = T(() => e("rv-date-error")), h = (e) => n === "date" ? e : F(e), g = {
		locale: u.locale,
		...typeof t.dateInput == "object" ? t.dateInput : {}
	}, [_, v] = T(t.endpoint === "to" ? "to" : void 0), [C, w] = T(""), E = a && !Array.isArray(a) && typeof a == "object" ? a : void 0, D = typeof a == "string" ? a : "", O = Array.isArray(a) ? a : [], k = E?.from ?? "", A = E?.to ?? "", j = F(n === "time" ? l() : t.endpoint === "to" ? A : k || D || O[0] || ""), [M, N] = T(() => u.defaultMonth ?? c(s(j) ? j : l(), u.calendarSystem)), P = t.required ?? u.required ?? !1, { valid: z, errorMessage: B, validDate: V } = Z(t, M, C);
	S(() => t.onValidityChange?.(!!z), [z]);
	let H = (e) => {
		w(""), o(e);
	}, U = (e) => {
		H(e), n === "date" && r !== "multiple" && Z({
			...t,
			value: e
		}, M).valid && t.onSelectionComplete?.(e);
	}, W = (e) => {
		if (!V(e)) return;
		let t = c(e, u.calendarSystem);
		t !== (u.month ?? M) && (N(t), u.onMonthChange?.(t));
	}, G = (e, t) => {
		if (typeof t != "string") return;
		W(t);
		let r = {
			from: k,
			to: A,
			[e]: t ? L(t, e === "from" ? k : A, n) : ""
		};
		H(!r.from && !r.to ? null : r);
	}, K = (e, n, r, i = !0) => /* @__PURE__ */ x("label", {
		class: `rv-temporal-picker__time${i ? "" : " rv-temporal-picker__time--single"}`,
		children: [i && /* @__PURE__ */ b("span", { children: n }), /* @__PURE__ */ b(ee, {
			label: n,
			value: e ? I(e) : "",
			min: t.minTime,
			max: t.maxTime,
			step: t.timeStep,
			precision: t.precision,
			format: t.timeFormat,
			locale: u.locale,
			onChange: r
		})]
	}), q = {
		...u,
		month: u.month ?? M,
		onMonthChange: (e) => {
			N(e), u.onMonthChange?.(e);
		},
		required: P,
		onInvalidSelection: (e, t) => {
			w(e || d.invalid), u.onInvalidSelection?.(e, t);
		}
	}, J;
	if (r === "multiple") J = {
		...q,
		mode: "multiple",
		selected: O.filter(s),
		onSelectionChange: (e) => U([...e])
	};
	else if (r === "range" && !_) J = {
		...q,
		mode: "range",
		selected: k && s(F(k)) ? {
			from: F(k),
			...A && s(F(A)) ? { to: F(A) } : {}
		} : void 0,
		onSelectionChange: (e) => U(e ? {
			from: L(e.from, k, n),
			...e.to ? { to: L(e.to, A, n) } : {}
		} : null)
	};
	else {
		let e = r === "range" ? _ === "to" ? A : k : D;
		J = {
			...q,
			mode: "single",
			selected: e && s(F(e)) ? F(e) : void 0,
			onSelectionChange: (t) => {
				U(r === "range" ? t ? {
					from: k,
					to: A,
					[_ ?? "from"]: L(t, e, n)
				} : null : t ? L(t, D, n) : null);
			}
		};
	}
	return /* @__PURE__ */ x("div", {
		class: "rv-temporal-picker",
		children: [
			t.dateInput === !1 && r === "range" && n !== "time" && /* @__PURE__ */ x("div", {
				class: `rv-temporal-picker__endpoints ${t.classNames?.endpoints ?? ""}`,
				children: [/* @__PURE__ */ b(m, {
					"aria-label": `${d.startDate}: ${k}`,
					"aria-pressed": _ !== "to",
					onClick: () => {
						v(void 0), k && N(c(F(k), u.calendarSystem)), w("");
					},
					children: k ? F(k) : "—"
				}), /* @__PURE__ */ b(m, {
					"aria-label": `${d.endDate}: ${A}`,
					"aria-pressed": _ === "to",
					onClick: () => {
						v("to"), A && N(c(F(A), u.calendarSystem)), w("");
					},
					children: A ? F(A) : "—"
				})]
			}),
			/* @__PURE__ */ x("div", {
				class: "rv-temporal-picker__header",
				children: [n !== "time" && t.dateInput !== !1 && /* @__PURE__ */ b("div", {
					class: `rv-temporal-picker__dates ${r === "range" ? `rv-temporal-picker__endpoints ${t.classNames?.endpoints ?? ""}` : ""}`,
					children: r === "range" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("div", {
						class: "rv-temporal-picker__endpoint",
						role: "group",
						"aria-label": d.startDate,
						children: [/* @__PURE__ */ b(Q, {
							label: d.startDate,
							value: h(k),
							options: g,
							invalid: !z,
							errorId: f,
							onFocus: () => v(void 0),
							onChange: (e) => G("from", e)
						}), n === "datetime" && K(k, d.startTime, (e) => H({
							from: R(k, e, n),
							...A ? { to: A } : {}
						}), !1)]
					}), /* @__PURE__ */ x("div", {
						class: "rv-temporal-picker__endpoint",
						role: "group",
						"aria-label": d.endDate,
						children: [/* @__PURE__ */ b(Q, {
							label: d.endDate,
							value: h(A),
							options: g,
							invalid: !z,
							errorId: f,
							onFocus: () => v("to"),
							onChange: (e) => G("to", e)
						}), n === "datetime" && K(A, d.endTime, (e) => H({
							from: k,
							to: R(A, e, n)
						}), !1)]
					})] }) : /* @__PURE__ */ b(Q, {
						label: r === "multiple" ? d.dates : d.date,
						value: r === "multiple" ? O : h(D),
						multiple: r === "multiple",
						options: g,
						invalid: !z,
						errorId: f,
						onChange: (e) => {
							typeof e == "string" && W(e), H(Array.isArray(e) ? e : e ? L(e, D, n) : null);
						}
					})
				}), n !== "date" && r !== "range" && K(D, d.time, (e) => H(R(D, e, n)), !1)]
			}),
			n !== "time" && /* @__PURE__ */ b(p, { ...J }),
			n !== "date" && r === "range" && (n === "time" || t.dateInput === !1) && /* @__PURE__ */ x("div", {
				class: "rv-temporal-picker__times",
				children: [K(k, d.startTime, (e) => H({
					from: R(k, e, n),
					...A ? { to: A } : {}
				})), K(A, d.endTime, (e) => H({
					from: k,
					to: R(A, e, n)
				}))]
			}),
			!z && /* @__PURE__ */ b(i, {
				tone: "danger",
				children: /* @__PURE__ */ b("span", {
					id: f,
					children: B
				})
			})
		]
	});
}
//#endregion
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/regular/clock.svg?raw
var ne = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0 256 256 0 1 0 -512 0zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z\"/></svg>";
//#endregion
//#region src/date-time/field.tsx
function $({ value: e, options: t, apply: n, cancel: r, clearable: a = !0 }) {
	let [o, s] = T(e), [c, l] = T(!1), [u, d] = T(""), f = (e) => {
		s(e), d("");
	}, p = t.autoApply !== !1, m = JSON.stringify(o) !== JSON.stringify(e), h = (e) => {
		let t = n(e) || "";
		return d(t), !t;
	}, g = () => c ? h(o) : !1;
	return _(() => !m || g(), p), /* @__PURE__ */ x("div", {
		onKeyDown: (e) => {
			e.key === "Enter" && !e.isComposing && (e.ctrlKey || e.metaKey || p && e.target instanceof HTMLInputElement) && (e.preventDefault(), g());
		},
		children: [
			/* @__PURE__ */ b(te, {
				...t,
				value: o,
				onChange: f,
				onValidityChange: l,
				onSelectionComplete: p ? h : void 0
			}),
			u && /* @__PURE__ */ b(i, {
				tone: "danger",
				children: u
			}),
			/* @__PURE__ */ b(v, {
				text: t.actions,
				showConfirm: t.showActions ?? !p,
				disabled: !c,
				apply: g,
				cancel: r,
				clear: !a || (t.required ?? t.calendar?.required) ? void 0 : () => {
					let e = t.selection === "multiple" ? [] : null;
					f(e), p && h(e);
				}
			})
		]
	});
}
function re({ value: e, kind: t = "date", picker: n, onValueChange: i, onInput: o, formatValue: s, parseValue: c, ...l }) {
	let u = w(null), d = w(), f = w({
		value: e,
		kind: t,
		picker: n,
		onValueChange: i,
		input: l
	});
	return f.current = {
		value: e,
		kind: t,
		picker: n,
		onValueChange: i,
		input: l
	}, C(() => () => d.current?.close(), []), C(() => {
		(l.disabled || l.readOnly) && d.current?.close();
	}, [l.disabled, l.readOnly]), /* @__PURE__ */ x("span", {
		class: "rv-date-time-field",
		children: [/* @__PURE__ */ b(r, {
			...l,
			type: "text",
			value: s?.(e) ?? e,
			placeholder: l.placeholder ?? (t === "date" ? "YYYY-MM-DD" : t === "time" ? "HH:mm" : "YYYY-MM-DDTHH:mm"),
			onInput: (e) => {
				o?.(e);
				let t = c ? c(e.currentTarget.value) : e.currentTarget.value;
				t !== void 0 && i?.(t);
			}
		}), /* @__PURE__ */ b(m, {
			ref: u,
			variant: "ghost",
			"aria-label": X(t, n?.text),
			disabled: l.disabled || l.readOnly,
			onClick: () => {
				u.current && !d.current && (d.current = g(u.current, (r) => /* @__PURE__ */ b($, {
					value: e || null,
					options: {
						...n,
						required: n?.required ?? l.required,
						kind: t,
						selection: "single"
					},
					cancel: r,
					apply: (e) => {
						!f.current.input.disabled && !f.current.input.readOnly && f.current.onValueChange?.(typeof e == "string" ? e : ""), r();
					}
				}), {
					label: X(t, n?.text),
					onClose: () => {
						d.current = void 0;
					}
				}));
			},
			children: /* @__PURE__ */ b(a, { svg: t === "time" ? ne : h })
		})]
	});
}
//#endregion
//#region src/date-time/attach.tsx
function ie(e, r, i) {
	let o, s = t(e.ownerDocument, /* @__PURE__ */ b(m, {
		variant: "ghost",
		disabled: e.disabled || e.readOnly,
		"aria-label": X(r.kind ?? "date", r.text),
		onClick: () => {
			e.disabled || e.readOnly || o || (o = g(e, (t) => /* @__PURE__ */ b($, {
				value: e.value || null,
				options: {
					...r,
					selection: "single",
					required: r.required ?? r.calendar?.required ?? e.required
				},
				cancel: t,
				apply: (n) => {
					!e.disabled && !e.readOnly && i(typeof n == "string" ? n : ""), t();
				}
			}), {
				label: X(r.kind ?? "date", r.text),
				onClose: () => {
					o = void 0;
				}
			}));
		},
		children: /* @__PURE__ */ b(a, { svg: h })
	}));
	e.after(s);
	let c = e.ownerDocument.defaultView?.MutationObserver, l = c ? new c(() => {
		s.disabled = e.disabled || e.readOnly, s.disabled && o?.close();
	}) : void 0;
	return l?.observe(e, {
		attributes: !0,
		attributeFilter: ["disabled", "readonly"]
	}), () => {
		l?.disconnect(), o?.close(), n(s), s.remove();
	};
}
//#endregion
//#region src/date-time/value.tsx
function ae(e, t) {
	let n = Number.isFinite(t.maxVisibleDates) ? Math.max(1, Math.floor(t.maxVisibleDates)) : 2, r = t.multiple ? t.values.slice(0, n) : t.values, i = t.values.length - r.length;
	return e("span", {
		class: "rv-temporal-value",
		role: t.fullValue ? "group" : void 0,
		dir: t.dir ?? "auto",
		title: t.fullValue || void 0,
		"data-tooltip": t.fullValue || void 0,
		"aria-label": t.fullValue || void 0
	}, [...r.map((t) => e("span", {
		class: "rv-badge rv-temporal-value__item",
		"aria-hidden": "true"
	}, t)), i > 0 ? e("span", {
		class: "rv-badge rv-temporal-value__more",
		"aria-hidden": "true"
	}, `+${i}`) : null]);
}
//#endregion
export { re as DateTimeField, $ as TemporalDraft, te as TemporalPicker, ie as attachTemporalPicker, Y as defaultTemporalPickerText, ae as renderTemporalValue, X as temporalPickerLabel };
