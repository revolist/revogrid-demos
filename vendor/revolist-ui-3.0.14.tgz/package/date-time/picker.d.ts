import { TemporalPickerProps } from './types';
export declare function TemporalPicker(props: TemporalPickerProps): import("preact").JSX.Element;
