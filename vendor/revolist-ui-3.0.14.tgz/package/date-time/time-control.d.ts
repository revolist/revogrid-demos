export declare function TimeControl({ value, label, format, precision, locale, min, max, step, onChange, }: {
    value: string;
    label: string;
    format?: 'locale' | '12h' | '24h';
    precision?: 'minute' | 'second';
    locale?: string;
    min?: string;
    max?: string;
    step?: number;
    onChange: (value: string) => void;
}): import("preact").JSX.Element;
