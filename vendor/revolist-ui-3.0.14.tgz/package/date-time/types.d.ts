import { DateInputOptions } from './date-control';
import { JSX } from 'preact';
import { CalendarPickerProps } from '../calendar/picker';
import { LocalDateControlKind, TemporalControlValue } from '../_shared/dates/index';
import { EditorActionText, EditorCommitOptions } from '../editor-actions';
export type { DateInputOptions } from './date-control';
type CalendarOptions<T> = T extends unknown ? Omit<T, 'mode' | 'selected' | 'onSelectionChange'> : never;
/** Complete shared picker options except controlled selection, which belongs to the field. */
export type TemporalCalendarOptions = CalendarOptions<CalendarPickerProps>;
export interface TemporalPickerText {
    date?: string;
    dates?: string;
    invalidDate?: string;
    outOfRange?: string;
    disabledDate?: string;
    invalidRange?: string;
    selectionCount?: string;
    requiredValue?: string;
    startDate: string;
    endDate: string;
    startTime: string;
    endTime: string;
    time: string;
    invalid: string;
    chooseDate: string;
    chooseTime?: string;
}
export declare const defaultTemporalPickerText: TemporalPickerText;
export interface TemporalPickerOptions extends EditorCommitOptions {
    kind?: LocalDateControlKind;
    /** Typed date entry is enabled by default; false retains calendar-only controls. */
    dateInput?: boolean | DateInputOptions;
    selection?: 'single' | 'range' | 'multiple';
    calendar?: TemporalCalendarOptions;
    required?: boolean;
    minTime?: string;
    maxTime?: string;
    timeStep?: number;
    precision?: 'minute' | 'second';
    timeFormat?: 'locale' | '12h' | '24h';
    text?: Partial<TemporalPickerText>;
    actions?: Partial<EditorActionText>;
    /** Endpoint-only adjustment, for the existing Timeline end-arrow interaction. */
    classNames?: {
        endpoints?: string;
    };
    endpoint?: 'from' | 'to';
}
export interface TemporalPickerProps extends TemporalPickerOptions {
    value: TemporalControlValue;
    onChange: (value: TemporalControlValue) => void;
    onValidityChange?: (valid: boolean) => void;
    /** Complete calendar selection, distinct from an in-progress keyboard draft. */
    onSelectionComplete?: (value: TemporalControlValue) => void;
}
export interface DateTimeFieldProps extends Omit<JSX.InputHTMLAttributes<HTMLInputElement>, 'type' | 'value' | 'onChange' | 'required' | 'disabled' | 'readOnly'> {
    kind?: LocalDateControlKind;
    value: string;
    required?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    picker?: Omit<TemporalPickerOptions, 'kind' | 'selection'>;
    onValueChange?: (value: string) => void;
    /** Existing product text adapters can keep their custom display/parser. */
    formatValue?: (value: string) => string;
    parseValue?: (text: string) => string | undefined;
}
/** One accessible name for both trigger and popup; chooseDate remains a compatibility fallback. */
export declare function temporalPickerLabel(kind: LocalDateControlKind, text?: Partial<TemporalPickerText>): string;
