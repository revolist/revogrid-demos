import { ISODateString } from '../_shared/dates/index';
import { TemporalPickerProps } from './types';
/** One validation path for keyboard drafts and calendar selections. */
export declare function validateTemporalSelection(props: TemporalPickerProps, month: ISODateString, selectionError?: string): {
    valid: boolean;
    errorMessage: string;
    validDate: (date: string) => boolean;
};
