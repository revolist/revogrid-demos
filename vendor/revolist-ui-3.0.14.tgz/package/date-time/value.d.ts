import { ElementFactory } from '../native-controls';
export interface TemporalValuePresentation {
    values: readonly string[];
    fullValue: string;
    multiple?: boolean;
    dir?: 'ltr' | 'rtl' | 'auto';
    maxVisibleDates?: number;
}
/** Shared read-only presentation, usable with Stencil, Preact or another element factory. */
export declare function renderTemporalValue(h: ElementFactory, options: TemporalValuePresentation): any;
