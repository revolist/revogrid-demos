import { h } from 'preact';
import { ElementFactory } from '../native-controls';
export interface NativeDialogAction {
    label?: string;
    disabled?: boolean;
    onClick?: () => void;
}
export interface NativeDialogActionFooterProps {
    cancel?: NativeDialogAction | false;
    save?: NativeDialogAction | false;
    deleteAction?: NativeDialogAction | false;
    reset?: NativeDialogAction | false;
}
/** One TSX composition for Preact consumers and element-returning host adapters. */
export declare function ActionFooterView({ cancel, save, deleteAction, reset, start, end, children, actionsClass, class: className, ...props }: Record<string, any>): h.JSX.Element;
/** Compatibility signature retained for existing Preact consumers. */
export declare function renderDialogActionFooter<H extends ElementFactory>(_h: H, props: Record<string, any>): ReturnType<H>;
export declare function mountDialogActionFooter(host: HTMLElement, props: NativeDialogActionFooterProps): {
    destroy(): void;
};
