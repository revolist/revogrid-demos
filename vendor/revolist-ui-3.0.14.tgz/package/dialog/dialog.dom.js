import { createPreactElement as e } from "../preact-mount.js";
import { ButtonControl as t } from "../native-control.js";
import { a as n, i as r, n as i, r as a, s as o } from "../_chunks/dialog.parts-Wr0Lpt6Z.js";
import { jsx as s, jsxs as c } from "preact/jsx-runtime";
//#region src/dialog/dialog.dom.view.tsx
function l(t, l, u) {
	let d = p(), f, m, h, g, _;
	return {
		root: e(t, /* @__PURE__ */ s("div", {
			class: ["rv-dialog-overlay", l.overlayClass].filter(Boolean).join(" "),
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": d,
			"aria-describedby": l.ariaDescribedBy,
			tabIndex: -1,
			children: /* @__PURE__ */ c("section", {
				ref: (e) => {
					f = e;
				},
				class: ["rv-dialog__surface", l.surfaceClass].filter(Boolean).join(" "),
				children: [
					/* @__PURE__ */ c(o, {
						ref: (e) => {
							m = e;
						},
						children: [/* @__PURE__ */ s("div", {
							class: "rv-dialog__heading",
							children: /* @__PURE__ */ s("h3", {
								id: d,
								class: "rv-dialog__title",
								children: l.title
							})
						}), /* @__PURE__ */ s(r, {
							"aria-label": l.closeLabel,
							title: l.closeLabel,
							onClick: u
						})]
					}),
					/* @__PURE__ */ s(a, { ref: (e) => {
						h = e;
					} }),
					/* @__PURE__ */ s(n, {
						ref: (e) => {
							g = e;
						},
						children: /* @__PURE__ */ s(i, { ref: (e) => {
							_ = e;
						} })
					})
				]
			})
		})),
		surface: f,
		header: m,
		body: h,
		footer: g,
		actions: _
	};
}
function u(t, n, i) {
	return e(t, /* @__PURE__ */ s(r, {
		"aria-label": n,
		title: n,
		onClick: i
	}));
}
function d(n, r, i, a = "default") {
	return e(n, /* @__PURE__ */ s(t, {
		title: r || void 0,
		class: a === "default" ? "rv-btn" : `rv-btn-${a}`,
		onClick: i,
		children: r
	}));
}
var f = 0;
function p() {
	return f += 1, `rv-dialog-title-${f}`;
}
function m(e, t) {
	let n = h(e);
	if (!n.length) {
		t.preventDefault(), e.focus();
		return;
	}
	let r = e.ownerDocument.activeElement, i = n.findIndex((e) => e === r), a = i < 0 ? t.shiftKey ? n.length - 1 : 0 : t.shiftKey ? (i - 1 + n.length) % n.length : (i + 1) % n.length;
	t.preventDefault(), n[a].focus();
}
function h(e) {
	return Array.from(e.querySelectorAll("a[href], area[href], button:not([disabled]), input:not([disabled]):not([type=\"hidden\"]), select:not([disabled]), textarea:not([disabled]), iframe, object, embed, summary, audio[controls], video[controls], [contenteditable]:not([contenteditable=\"false\"]), [tabindex]:not([tabindex=\"-1\"])")).filter((e) => !e.hidden && !e.closest("[hidden], [inert], [aria-hidden=\"true\"]") && !e.matches("[tabindex=\"-1\"], :disabled, input[type=\"hidden\"]"));
}
//#endregion
export { d as createDialogButton, u as createDialogCloseButton, l as createDialogElements, h as getDialogFocusableElements, m as trapDialogFocus };
