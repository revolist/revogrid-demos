import { DialogButtonVariant, DialogOpenOptions } from './dialog.types';
export interface DialogElements {
    readonly root: HTMLElement;
    readonly surface: HTMLElement;
    readonly header: HTMLElement;
    readonly body: HTMLElement;
    readonly footer: HTMLElement;
    readonly actions: HTMLElement;
}
/** Element-returning compatibility API; shared TSX owns the entire dialog chrome. */
export declare function createDialogElements(document: Document, options: DialogOpenOptions, close: () => void): DialogElements;
export declare function createDialogCloseButton(document: Document, label: string, close: () => void): HTMLButtonElement;
export declare function createDialogButton(document: Document, label: string, action: () => void, variant?: DialogButtonVariant): HTMLButtonElement;
export declare function trapDialogFocus(root: HTMLElement, event: KeyboardEvent): void;
export declare function getDialogFocusableElements(root: HTMLElement): HTMLElement[];
