export interface DialogDragOptions {
    readonly target: HTMLElement;
    readonly handle: HTMLElement;
    readonly margin?: number;
    readonly ignoreSelector?: string;
}
/**
 * Makes a dialog movable from a dedicated header without owning its rendering.
 */
export declare function attachDialogDrag({ target, handle, margin, ignoreSelector, }: DialogDragOptions): () => void;
