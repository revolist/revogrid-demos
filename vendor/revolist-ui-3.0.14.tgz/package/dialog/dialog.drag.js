//#region src/dialog/dialog.drag.ts
var e = [
	"a",
	"button",
	"input",
	"select",
	"textarea",
	"[contenteditable=\"true\"]",
	"[data-dialog-drag-ignore]"
].join(",");
function t({ target: t, handle: o, margin: s = 8, ignoreSelector: c = e }) {
	let l = t.ownerDocument.defaultView;
	if (!l) return () => void 0;
	let u = 0, d = 0, f, p = () => {
		t.style.setProperty("--rv-dialog-translate-x", `${u}px`), t.style.setProperty("--rv-dialog-translate-y", `${d}px`);
	}, m = (e) => {
		if (!f || e && "pointerId" in e && typeof e.pointerId == "number" && e.pointerId !== f.pointerId) return;
		let n = f.pointerId;
		f = void 0, t.classList.remove("rv-dialog__dragging"), l.removeEventListener("pointermove", h), l.removeEventListener("pointerup", m), l.removeEventListener("pointercancel", m), l.removeEventListener("blur", m), o.removeEventListener("lostpointercapture", m), o.hasPointerCapture?.(n) && o.releasePointerCapture(n);
	}, h = (e) => {
		if (!f || e.pointerId !== f.pointerId) return;
		let t = r(f.rect.left, f.rect.right, l.innerWidth, s), n = r(f.rect.top, f.rect.bottom, l.innerHeight, s), i = f.translateX + a(e.clientX - f.clientX, t.min, t.max), o = f.translateY + a(e.clientY - f.clientY, n.min, n.max);
		e.preventDefault(), (i !== u || o !== d) && (u = i, d = o, p());
	}, g = (e) => {
		if (!(e.button !== 0 || e.isPrimary === !1 || n(e.target, o, c))) {
			m(), f = {
				clientX: e.clientX,
				clientY: e.clientY,
				pointerId: e.pointerId,
				rect: t.getBoundingClientRect(),
				translateX: u,
				translateY: d
			}, t.classList.add("rv-dialog__dragging"), l.addEventListener("pointermove", h, { passive: !1 }), l.addEventListener("pointerup", m), l.addEventListener("pointercancel", m), l.addEventListener("blur", m), o.addEventListener("lostpointercapture", m);
			try {
				o.setPointerCapture?.(e.pointerId);
			} catch {}
			e.preventDefault();
		}
	}, _ = () => {
		m();
		let e = t.getBoundingClientRect(), n = i(e.left, e.right, l.innerWidth, s), r = i(e.top, e.bottom, l.innerHeight, s);
		(n || r) && (u += n, d += r, p());
	};
	t.classList.add("rv-dialog__draggable"), o.classList.add("rv-dialog__drag-handle"), o.addEventListener("pointerdown", g), l.addEventListener("resize", _), l.visualViewport?.addEventListener("resize", _);
	let v = l.ResizeObserver ? new l.ResizeObserver(_) : void 0;
	return v?.observe(t), () => {
		m(), o.removeEventListener("pointerdown", g), l.removeEventListener("resize", _), l.visualViewport?.removeEventListener("resize", _), v?.disconnect(), o.classList.remove("rv-dialog__drag-handle"), t.classList.remove("rv-dialog__draggable", "rv-dialog__dragging"), t.style.removeProperty("--rv-dialog-translate-x"), t.style.removeProperty("--rv-dialog-translate-y");
	};
}
function n(e, t, n) {
	let r = t.ownerDocument.defaultView?.Element;
	if (!r || !(e instanceof r)) return !1;
	let i = e.closest(n);
	return !!i && t.contains(i);
}
function r(e, t, n, r) {
	return t - e >= n - r * 2 ? {
		min: -e,
		max: n - t
	} : {
		min: r - e,
		max: n - r - t
	};
}
function i(e, t, n, r) {
	return t - e >= n - r * 2 ? -e : e < r ? r - e : t > n - r ? n - r - t : 0;
}
function a(e, t, n) {
	return Math.min(Math.max(e, Math.min(t, n)), Math.max(t, n));
}
//#endregion
export { t as attachDialogDrag };
