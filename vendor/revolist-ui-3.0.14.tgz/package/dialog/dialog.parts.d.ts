import { h, JSX } from 'preact';
/** Composable chrome: consumers retain native dialog lifecycle and form policy. */
export declare const DialogHeader: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<h.JSX.HTMLAttributes<HTMLElement>> & {
    ref?: import('preact').Ref<HTMLElement> | undefined;
}>;
export declare function DialogForm({ class: className, ...props }: JSX.IntrinsicElements['form']): h.JSX.Element;
export declare const DialogBody: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<h.JSX.HTMLAttributes<HTMLDivElement>> & {
    ref?: import('preact').Ref<HTMLDivElement> | undefined;
}>;
export declare const DialogFooter: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<h.JSX.HTMLAttributes<HTMLElement>> & {
    ref?: import('preact').Ref<HTMLElement> | undefined;
}>;
export declare const DialogActions: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<h.JSX.HTMLAttributes<HTMLDivElement>> & {
    ref?: import('preact').Ref<HTMLDivElement> | undefined;
}>;
export declare function DialogCloseButton({ class: className, iconClass, ...props }: Omit<JSX.IntrinsicElements['button'], 'ref'> & {
    'aria-label': string;
    iconClass?: string;
}): h.JSX.Element;
/** A native input with shared title styling; labels and commit policy stay explicit. */
export declare const DialogTitleInput: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<Omit<h.JSX.InputHTMLAttributes<HTMLInputElement>, "ref">> & {
    ref?: import('preact').Ref<HTMLInputElement> | undefined;
}>;
export interface EditableDialogHeaderProps extends Omit<JSX.IntrinsicElements['header'], 'title'> {
    readonly titleId: string;
    readonly title: string;
    /** Optional dialog name above the editable item title. */
    readonly name?: string;
    readonly description?: import('preact').ComponentChildren;
    readonly inputLabel: string;
    readonly titleHidden?: boolean;
    readonly headingClass?: string;
    readonly kickerClass?: string;
    readonly titleClass?: string;
    /** false renders a static title while retaining the same header layout. */
    readonly inputProps?: false | (Omit<JSX.IntrinsicElements['input'], 'ref'> & {
        [attribute: `data-${string}`]: unknown;
    });
    readonly closeLabel: string;
    readonly closeProps?: Omit<JSX.IntrinsicElements['button'], 'ref'>;
    readonly onClose?: () => void;
}
/** One owner for editable item names, dialog captions, close actions and spacing. */
export declare const EditableDialogHeader: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<EditableDialogHeaderProps> & {
    ref?: import('preact').Ref<HTMLElement> | undefined;
}>;
export type DialogAction = Omit<JSX.IntrinsicElements['button'], 'children' | 'ref'> & {
    readonly label?: import('preact').ComponentChildren;
    [attribute: `data-${string}`]: unknown;
};
export type DialogActionFooterProps = JSX.IntrinsicElements['footer'] & {
    readonly cancel?: DialogAction | false;
    readonly save?: DialogAction | false;
    readonly deleteAction?: DialogAction | false;
    readonly reset?: DialogAction | false;
    /** Custom actions on either side of the standard bottom panel. */
    readonly start?: import('preact').ComponentChildren;
    readonly end?: import('preact').ComponentChildren;
    readonly actionsClass?: string;
};
/** Default Cancel/Save, opt-in Delete/Reset; false hides any standard action. */
export declare function DialogActionFooter(props: DialogActionFooterProps): import('preact').VNode<import('preact').Attributes>;
