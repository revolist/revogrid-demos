import { RefObject } from 'preact';
export interface UseDialogDragOptions<Target extends HTMLElement, Handle extends HTMLElement> {
    readonly targetRef: RefObject<Target>;
    readonly handleRef: RefObject<Handle>;
    readonly enabled?: boolean;
}
/**
 * Connects Preact-rendered dialog refs to the framework-neutral drag owner.
 */
export declare function useDialogDrag<Target extends HTMLElement, Handle extends HTMLElement>({ targetRef, handleRef, enabled, }: UseDialogDragOptions<Target, Handle>): void;
