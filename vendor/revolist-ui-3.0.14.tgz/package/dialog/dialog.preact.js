import { attachDialogDrag as e } from "./dialog.drag.js";
import { useEffect as t } from "preact/hooks";
//#region src/dialog/dialog.preact.ts
function n({ targetRef: n, handleRef: r, enabled: i = !0 }) {
	t(() => {
		let t = n.current, a = r.current;
		if (i && t && a) return e({
			target: t,
			handle: a
		});
	}, [
		i,
		r,
		n
	]);
}
//#endregion
export { n as useDialogDrag };
