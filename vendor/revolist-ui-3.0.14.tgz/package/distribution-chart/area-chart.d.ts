import { h } from 'preact';
import { StandaloneChartProps } from './types';
export type AreaChartProps = StandaloneChartProps;
export declare function AreaChart(props: AreaChartProps): h.JSX.Element;
