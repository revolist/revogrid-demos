import { i as e, n as t, r as n, t as r } from "../_chunks/chart-frame-2L8EjKll.js";
import { jsx as i, jsxs as a } from "preact/jsx-runtime";
import { useId as o } from "preact/hooks";
//#region src/distribution-chart/area-chart.tsx
function s(s) {
	let c = `rv-area-${o().replace(/[^a-zA-Z0-9_-]/g, "")}`, { points: l } = n(s.data), u = s.data.some((e) => e.selected !== void 0), d = l.slice(1).map((t, n) => {
		let r = l[n], i = e(r, t, s.interpolation);
		return {
			key: s.data[n].key,
			selected: !u || !!(s.data[n].selected && s.data[n + 1].selected),
			line: i,
			area: `${i} L ${t.x} 100 L ${r.x} 100 Z`
		};
	});
	return /* @__PURE__ */ i(r, {
		...s,
		variant: "area",
		positions: l,
		renderDatum: () => s.showPoints === !1 ? null : /* @__PURE__ */ i("span", {
			class: "rv-distribution-chart__point",
			"aria-hidden": "true"
		}),
		children: l.length > 0 && /* @__PURE__ */ a(t, { children: [s.areaFill === "gradient" && /* @__PURE__ */ i("defs", { children: [!0, !1].map((e) => {
			let t = e ? "var(--rv-distribution-accent, var(--rv-ui-accent))" : "var(--rv-distribution-muted, var(--rv-ui-border))";
			return /* @__PURE__ */ a("linearGradient", {
				id: `${c}${e ? "" : "-muted"}`,
				gradientUnits: "userSpaceOnUse",
				x1: "0",
				y1: "8",
				x2: "0",
				y2: "100",
				children: [/* @__PURE__ */ i("stop", {
					offset: "0%",
					"stop-color": t,
					"stop-opacity": "0.4"
				}), /* @__PURE__ */ i("stop", {
					offset: "100%",
					"stop-color": t,
					"stop-opacity": "0.02"
				})]
			}, String(e));
		}) }), d.map((e) => /* @__PURE__ */ a("g", { children: [/* @__PURE__ */ i("path", {
			class: `rv-distribution-chart__area${e.selected ? " is-selected" : ""}`,
			d: e.area,
			style: s.areaFill === "gradient" ? { fill: `url(#${c}${e.selected ? "" : "-muted"})` } : void 0
		}), /* @__PURE__ */ i("path", {
			class: `rv-distribution-chart__series rv-distribution-chart__segment${e.selected ? " is-selected" : ""}`,
			d: e.line,
			"vector-effect": "non-scaling-stroke"
		})] }, e.key))] })
	});
}
//#endregion
export { s as AreaChart };
