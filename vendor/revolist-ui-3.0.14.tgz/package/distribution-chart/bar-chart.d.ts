import { h } from 'preact';
import { StandaloneChartProps } from './types';
export type BarChartProps = StandaloneChartProps;
/** Compact bar chart, independent of sliders, filters and grid instances. */
export declare function BarChart(props: BarChartProps): h.JSX.Element;
