import { r as e, t } from "../_chunks/chart-frame-2L8EjKll.js";
import { jsx as n } from "preact/jsx-runtime";
//#region src/distribution-chart/bar-chart.tsx
function r(r) {
	let { values: i, max: a } = e(r.data);
	return /* @__PURE__ */ n(t, {
		...r,
		variant: "bar",
		renderDatum: (e, t) => /* @__PURE__ */ n("span", {
			class: "rv-distribution-chart__bar",
			style: { height: `${Math.max(3, i[t] / a * 100)}%` },
			"aria-hidden": "true"
		})
	});
}
//#endregion
export { r as BarChart };
