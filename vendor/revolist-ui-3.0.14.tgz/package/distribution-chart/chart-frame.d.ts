import { h, ComponentChildren } from 'preact';
import { DistributionChartDatum, DistributionChartType, StandaloneChartProps } from './types';
export interface ChartPoint {
    readonly x: number;
    readonly y: number;
}
/** Shared accessibility, focus and tooltip lifecycle for the chart primitives. */
export declare function ChartFrame({ data, ariaLabel, variant, height, className, showGrid, showLabels, showValues, legend, formatValue, tooltip, tooltipIndicator, renderTooltip, positions, renderDatum, children }: StandaloneChartProps & {
    variant: DistributionChartType;
    positions?: readonly ChartPoint[];
    renderDatum: (datum: DistributionChartDatum, index: number) => ComponentChildren;
    children?: ComponentChildren;
}): h.JSX.Element;
export declare function ChartPlot({ children }: {
    children: ComponentChildren;
}): h.JSX.Element;
