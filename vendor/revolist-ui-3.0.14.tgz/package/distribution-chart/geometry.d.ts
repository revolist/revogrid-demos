import { DistributionChartDatum } from './types';
export declare function chartGeometry(data: readonly DistributionChartDatum[]): {
    values: number[];
    max: number;
    points: {
        x: number;
        y: number;
    }[];
};
type ChartPoint = {
    readonly x: number;
    readonly y: number;
};
/** Step-after keeps the category value until the next category. */
export declare function chartSegment(from: ChartPoint, to: ChartPoint, interpolation?: 'linear' | 'step'): string;
export declare function chartPath(points: readonly ChartPoint[], interpolation?: 'linear' | 'step'): string;
export {};
