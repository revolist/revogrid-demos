import { h } from 'preact';
import { DistributionChartProps } from './types';
export * from './types';
export { BarChart, type BarChartProps } from './bar-chart';
export { LineChart, type LineChartProps } from './line-chart';
export { AreaChart, type AreaChartProps } from './area-chart';
/** Compatibility composition; each presentation has its own standalone owner. */
export declare function DistributionChart({ type, ...props }: DistributionChartProps): h.JSX.Element;
