import { BarChart as e } from "./bar-chart.js";
import { LineChart as t } from "./line-chart.js";
import { AreaChart as n } from "./area-chart.js";
import { jsx as r } from "preact/jsx-runtime";
//#region src/distribution-chart/index.tsx
function i({ type: i = "bar", ...a }) {
	return r(i === "line" ? t : i === "area" ? n : e, { ...a });
}
//#endregion
export { n as AreaChart, e as BarChart, i as DistributionChart, t as LineChart };
