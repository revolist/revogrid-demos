import { h } from 'preact';
import { StandaloneChartProps } from './types';
export type LineChartProps = StandaloneChartProps;
/** Compact line chart with independently selected intervals and optional points. */
export declare function LineChart(props: LineChartProps): h.JSX.Element;
