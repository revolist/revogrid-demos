import { i as e, n as t, r as n, t as r } from "../_chunks/chart-frame-2L8EjKll.js";
import { jsx as i } from "preact/jsx-runtime";
//#region src/distribution-chart/line-chart.tsx
function a(a) {
	let { points: o } = n(a.data);
	return /* @__PURE__ */ i(r, {
		...a,
		variant: "line",
		positions: o,
		renderDatum: () => a.showPoints === !1 ? null : /* @__PURE__ */ i("span", {
			class: "rv-distribution-chart__point",
			"aria-hidden": "true"
		}),
		children: o.length > 0 && /* @__PURE__ */ i(t, { children: o.slice(1).map((t, n) => /* @__PURE__ */ i("path", {
			class: `rv-distribution-chart__series rv-distribution-chart__segment${a.data[n].selected && a.data[n + 1].selected ? " is-selected" : ""}`,
			d: e(o[n], t, a.interpolation),
			"vector-effect": "non-scaling-stroke"
		}, a.data[n].key)) })
	});
}
//#endregion
export { a as LineChart };
