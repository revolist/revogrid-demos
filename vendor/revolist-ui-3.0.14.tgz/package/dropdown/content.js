import { useDropdownService as e } from "./dropdown.service.js";
import { Button as t } from "../controls.js";
import { h as n } from "preact";
import { useCallback as r, useEffect as i, useRef as a } from "preact/compat";
import { Fragment as o, jsx as s, jsxs as c } from "preact/jsx-runtime";
//#region src/dropdown/content.tsx
function l({ options: n, selectedValues: r, remote: o, value: l, onChange: d, config: f, multiSelect: p, search: m, searchPlaceholder: h, listboxId: g, searchId: _, renderOption: v, renderNoResults: y, onClose: b, theme: x }) {
	let S = a(null), C = a(null), w = a(null), { searchValue: T, focusedIndex: E, selectedOptions: D, filteredOptions: O, handleSelect: k, handleKeyDown: A, handleSearchChange: j, setFocusedIndex: M } = e(n, l, d, f, b, o && {
		selected: r ?? [],
		search: o.search
	}), N = E >= 0 && E < O.length && !O[E].disabled ? `${g}-option-${E}` : void 0;
	return i(() => {
		if (!f.autoFocus) return;
		let e = () => {
			m && S.current ? S.current.focus({ preventScroll: !0 }) : C.current?.focus({ preventScroll: !0 });
		}, t = C.current?.ownerDocument.defaultView ?? (typeof window < "u" ? window : void 0);
		if (!t) return;
		e();
		let n = t.setTimeout(e, 0), r = t.requestAnimationFrame(e), i = t.setTimeout(e, 16);
		return () => {
			t.clearTimeout(n), t.cancelAnimationFrame(r), t.clearTimeout(i);
		};
	}, [f.autoFocus, m]), /* @__PURE__ */ c("div", {
		ref: C,
		className: "dropdown-listbox",
		"data-theme": x ?? "default",
		role: "listbox",
		id: g,
		"aria-multiselectable": p,
		"aria-activedescendant": N,
		tabIndex: -1,
		"aria-busy": o?.loading,
		onScrollCapture: (e) => {
			let t = e.target;
			o && t.scrollHeight - t.scrollTop - t.clientHeight < 48 && o.loadMore();
		},
		onKeyUp: (e) => e.stopPropagation(),
		onKeyDown: (e) => {
			e.stopPropagation(), e.key === "Escape" ? (e.preventDefault(), e.stopPropagation(), b(!1)) : e.key === "Tab" ? (e.preventDefault(), e.stopPropagation(), f.closeOnTab && b(!0)) : (e.key !== " " || e.target !== S.current) && A(e);
		},
		children: [
			m && /* @__PURE__ */ s("div", {
				className: "dropdown-search",
				children: /* @__PURE__ */ s("input", {
					ref: S,
					type: "text",
					id: _,
					className: `dropdown-search-input ${x ? `theme-${x}` : ""}`,
					placeholder: h,
					value: T,
					onChange: j,
					onInput: j,
					"aria-label": f.searchAriaLabel ?? "Search options"
				})
			}),
			o?.loading && /* @__PURE__ */ s("div", {
				role: "status",
				children: o.text.loading
			}),
			o?.error && /* @__PURE__ */ c("div", {
				role: "alert",
				children: [
					o.text.error,
					" ",
					/* @__PURE__ */ s(t, {
						onClick: o.retry,
						children: o.text.retry
					})
				]
			}),
			/* @__PURE__ */ s(u, {
				options: n,
				filteredOptions: O,
				multiSelect: p,
				focusedIndex: E,
				selectedOptions: D,
				onKeyDown: A,
				onSelect: k,
				onFocusChange: M,
				renderOption: v,
				renderNoResults: o ? () => o.loading || o.error ? null : o.text.empty : y,
				dropdownListRef: w,
				theme: x,
				optionIdPrefix: g
			}),
			o?.hasMore && /* @__PURE__ */ s(t, {
				disabled: o.loading,
				onClick: o.loadMore,
				children: o.text.loadMore
			})
		]
	});
}
function u({ options: e, filteredOptions: t, multiSelect: i, focusedIndex: a, selectedOptions: l, onKeyDown: u, onSelect: d, onFocusChange: f, renderOption: p, renderNoResults: m, dropdownListRef: h, theme: g, optionIdPrefix: _ }) {
	let v = r((e) => l.some((t) => JSON.stringify(t.value) === JSON.stringify(e.value)), [l]), y = r((e, t) => {
		let r = v(e), o = a === t;
		return /* @__PURE__ */ s("li", {
			id: `${_}-option-${t}`,
			role: "option",
			"aria-selected": r,
			"aria-disabled": e.disabled,
			tabIndex: -1,
			className: `dropdown-option ${r ? "selected" : ""} ${o ? "focused" : ""} ${e.disabled ? "disabled" : ""} ${g ? `theme-${g}` : ""}`,
			onClick: () => d(e),
			onMouseEnter: () => {
				e.disabled || f(t);
			},
			children: p ? p(n, e, r) : /* @__PURE__ */ c("div", {
				className: "option-content",
				children: [i && /* @__PURE__ */ s("input", {
					type: "checkbox",
					checked: r,
					readOnly: !0,
					disabled: e.disabled,
					tabIndex: -1,
					"aria-hidden": "true"
				}), /* @__PURE__ */ s("span", { children: e.label })]
			})
		}, `${e.label}-${t}`);
	}, [
		a,
		d,
		v,
		i,
		p,
		f,
		g
	]);
	return /* @__PURE__ */ s(o, { children: /* @__PURE__ */ s("ul", {
		ref: h,
		className: "dropdown-options",
		role: "presentation",
		tabIndex: -1,
		children: t.length > 0 ? t.map(y) : /* @__PURE__ */ s("li", {
			className: "no-results",
			children: m ? m(n) : /* @__PURE__ */ s("span", { children: "No results found" })
		})
	}) });
}
//#endregion
export { u as DropdownContent, l as DropdownPopupContent };
