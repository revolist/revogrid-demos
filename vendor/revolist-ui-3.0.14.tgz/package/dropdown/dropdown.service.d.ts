import { DropdownConfig, DropdownOption } from './dropdown.types';
type DropdownInputEvent = Event & {
    currentTarget: HTMLInputElement;
};
export declare function useDropdownService<T = any>(options: DropdownOption<T>[], value: T | T[] | undefined, onChange: (value: T | T[]) => void, config?: DropdownConfig<T>, onClose?: () => void, remote?: {
    selected: DropdownOption<T>[];
    search: (query: string) => void;
}): {
    searchValue: string;
    focusedIndex: number;
    selectedOptions: DropdownOption<T>[];
    filteredOptions: DropdownOption<T>[];
    handleSelect: (option: DropdownOption<T>) => void;
    handleKeyDown: (e: KeyboardEvent) => void;
    handleSearchChange: (e: DropdownInputEvent) => void;
    isOptionSelected: (option: DropdownOption<T>) => boolean;
    setFocusedIndex: import('preact/hooks').Dispatch<import('preact/hooks').StateUpdater<number>>;
};
export {};
