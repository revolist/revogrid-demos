import { useCallback as e, useEffect as t, useMemo as n, useRef as r, useState as i } from "preact/hooks";
//#region src/dropdown/dropdown.service.ts
var a = (e, t) => e.label.toLowerCase().includes(t.toLowerCase()), o = (e, t, n) => {
	if (n === "none") return 0;
	let r = e.label.localeCompare(t.label);
	return n === "asc" ? r : -r;
};
function s(e, t, n) {
	if (t === void 0) return [];
	if (n && Array.isArray(t)) return e.filter((e) => t.some((t) => JSON.stringify(t) === JSON.stringify(e.value)));
	let r = e.find((e) => JSON.stringify(e.value) === JSON.stringify(t));
	return r ? [r] : [];
}
function c(c, l, u, d = {}, f, p) {
	let { search: m = !1, filterFunction: h = a, sortDirection: g = "none", sortFunction: _ = o, multiSelect: v = !1, autocomplete: y = !1, initialSearch: b = "" } = d, [x, S] = i(b), [C, w] = i(-1), [T, E] = i(() => s(c, l, v)), D = r(!1);
	t(() => {
		E(p?.selected ?? s(c, l, v));
	}, [
		l,
		c,
		v,
		p?.selected
	]);
	let O = n(() => {
		if (p) return c;
		let e = [...c];
		return m && x && (e = e.filter((e) => h(e, x))), g !== "none" && e.sort((e, t) => _(e, t, g)), e;
	}, [
		c,
		m,
		x,
		h,
		g,
		_,
		!!p
	]);
	t(() => {
		D.current = !1, S(b);
	}, [b]), t(() => {
		O.length ? w((e) => {
			if (D.current && e >= 0 && e < O.length && !O[e].disabled) return e;
			let t = O.findIndex((e) => !e.disabled && T.some((t) => JSON.stringify(t.value) === JSON.stringify(e.value)));
			if (t >= 0) {
				let n = O[e];
				if (!T.some((e) => JSON.stringify(e.value) === JSON.stringify(n?.value))) return t;
			}
			return e >= 0 && e < O.length && !O[e].disabled ? e : t >= 0 ? t : O.findIndex((e) => !e.disabled);
		}) : w(-1);
	}, [O, T]);
	let k = e((e) => {
		if (!e.disabled) {
			if (v) {
				let t = T.some((t) => JSON.stringify(t.value) === JSON.stringify(e.value)), n;
				n = t ? T.filter((t) => JSON.stringify(t.value) !== JSON.stringify(e.value)) : [...T, e], E(n), u(n.map((e) => e.value)), y && S("");
			} else E([e]), u(e.value), f && f();
		}
	}, [
		v,
		T,
		u,
		y,
		f
	]), A = (e, t) => {
		let n = O.length, r = e < 0 ? t === 1 ? -1 : n : e;
		for (let e = 1; e <= n; e++) {
			let i = ((r + t * e) % n + n) % n;
			if (!O[i].disabled) return i;
		}
		return -1;
	};
	return {
		searchValue: x,
		focusedIndex: C,
		selectedOptions: T,
		filteredOptions: O,
		handleSelect: k,
		handleKeyDown: e((e) => {
			switch (e.key) {
				case "Escape":
					e.preventDefault(), e.stopPropagation();
					break;
				case "ArrowDown":
					e.preventDefault(), e.stopPropagation(), D.current = !0, w((e) => A(e, 1));
					break;
				case "ArrowUp":
					e.preventDefault(), e.stopPropagation(), D.current = !0, w((e) => A(e, -1));
					break;
				case "Enter":
				case " ": e.preventDefault(), e.stopPropagation(), C >= 0 && C < O.length && k(O[C]);
			}
		}, [
			O,
			C,
			k
		]),
		handleSearchChange: e((e) => {
			let t = e.currentTarget.value;
			t !== x && (D.current = !1, S(t), p?.search(t), w(-1));
		}, [p, x]),
		isOptionSelected: e((e) => T.some((t) => JSON.stringify(t.value) === JSON.stringify(e.value)), [T]),
		setFocusedIndex: w
	};
}
//#endregion
export { c as useDropdownService };
