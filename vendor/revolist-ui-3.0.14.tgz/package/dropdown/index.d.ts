import { DropdownProps } from './dropdown.types';
export * from './dropdown.types';
export { DropdownPopup } from './popup';
export { DropdownPopupContent } from './content';
export type { DropdownPopupProps } from './popup';
/**
 * Dropdown component
 */
export declare function Dropdown<T = any>({ source: localSource, dataSource, dataContext, remoteText, value, onChange, placeholder, disabled, name, id, className, style, config, renderContent, renderOption, renderValue, renderPlaceholder, renderSelectedValue, renderNoResults, onClose, beforeOutsideClose, environment, }: DropdownProps<T>): any;
/**
 * Define the dropdown component
 * @param el - The element to render the dropdown
 * @param props - The props of the dropdown
 */
export declare const defineDropdown: (el: HTMLElement, props: DropdownProps) => void;
export declare const destroyDropdown: (el: HTMLElement) => void;
