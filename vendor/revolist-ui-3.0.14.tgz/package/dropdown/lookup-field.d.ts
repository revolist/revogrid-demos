import { DropdownDataSource, DropdownOption, DropdownRemoteText, LookupId } from './dropdown.types';
import { EditorActionText, EditorCommitOptions } from '../editor-actions';
export interface LookupFieldText extends Partial<DropdownRemoteText> {
    popupLabel?: string;
    label?: string;
    placeholder?: string;
    searchPlaceholder?: string;
    searchLabel?: string;
    removeLabel?: (label: string) => string;
    requiredValue?: string;
}
export interface LookupFieldOptions extends EditorCommitOptions {
    dataSource: DropdownDataSource<LookupId>;
    multiple?: boolean;
    placeholder?: string;
    required?: boolean;
    source?: DropdownOption<LookupId>[];
    text?: LookupFieldText;
    actions?: Partial<EditorActionText>;
    renderOption?: import('./dropdown.types').DropdownProps<LookupId>['renderOption'];
    renderValue?: import('./dropdown.types').DropdownProps<LookupId>['renderValue'];
}
export declare function LookupField({ initial, options, context, apply, cancel, }: {
    initial: LookupId | LookupId[] | null;
    options: LookupFieldOptions;
    context: unknown;
    apply: (value: LookupId | LookupId[] | null) => void;
    cancel: () => void;
}): import("preact").JSX.Element;
