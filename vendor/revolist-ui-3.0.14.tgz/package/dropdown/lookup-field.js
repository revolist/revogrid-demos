import { t as e } from "../_chunks/dropdown-B1_emHGN.js";
import { n as t } from "../_chunks/editor-commit-D6Rf5rGz.js";
import { EditorActions as n } from "../editor-actions.js";
import { jsx as r, jsxs as i } from "preact/jsx-runtime";
import { useRef as a, useState as o } from "preact/hooks";
//#region src/dropdown/lookup-field.tsx
function s({ initial: s, options: c, context: l, apply: u, cancel: d }) {
	let [f, p] = o(s), [m, h] = o(!1), g = c.autoApply !== !1, _ = a(!1), v = a(s), y = f === null || Array.isArray(f) && !f.length;
	return t(() => {
		if (!_.current) return !0;
		let e = v.current;
		return c.required && (e === null || Array.isArray(e) && !e.length) ? !1 : (_.current && (_.current = !1, u(e)), !0);
	}, g), /* @__PURE__ */ i("div", {
		class: "rv-lookup-editor",
		onKeyDown: (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "Enter" && !(c.required && y) && (e.preventDefault(), u(f));
		},
		children: [
			/* @__PURE__ */ r(e, {
				source: c.source ?? [],
				dataSource: c.dataSource,
				dataContext: l,
				remoteText: c.text,
				value: f === null ? void 0 : f,
				onChange: (e) => {
					_.current = !0, h(!0), v.current = e, p(e);
					let t = e === null || Array.isArray(e) && !e.length;
					g && !c.multiple && !(c.required && t) && (_.current = !1, u(e));
				},
				placeholder: c.placeholder ?? c.text?.placeholder,
				renderOption: c.renderOption,
				renderValue: c.renderValue,
				config: {
					search: !0,
					multiSelect: c.multiple,
					topLayer: !0,
					autoFocus: !0,
					ariaLabel: c.text?.label ?? "Linked records",
					searchPlaceholder: c.text?.searchPlaceholder,
					searchAriaLabel: c.text?.searchLabel,
					removeLabel: c.text?.removeLabel
				}
			}),
			c.required && y && m && /* @__PURE__ */ r("span", {
				role: "alert",
				class: "rv-editor-error",
				children: c.text?.requiredValue ?? "Select at least one record."
			}),
			/* @__PURE__ */ r(n, {
				showConfirm: c.showActions ?? !g,
				text: c.actions,
				disabled: c.required && y,
				cancel: d,
				apply: () => u(f),
				clear: c.required ? void 0 : () => {
					let e = c.multiple ? [] : null;
					g ? u(e) : (v.current = e, p(e));
				}
			})
		]
	});
}
//#endregion
export { s as LookupField };
