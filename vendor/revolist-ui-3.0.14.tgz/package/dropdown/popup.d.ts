import { ComponentChildren, RefObject } from 'preact';
export type DropdownPopupProps = {
    onPointerRelease?: (event: MouseEvent | TouchEvent) => void;
    triggerRef: RefObject<HTMLDivElement>;
    children: ComponentChildren;
    portalTarget?: HTMLElement | null;
    theme?: string | null;
    dropdownMenuId?: string;
    popupClassName?: string;
    closeOnClickOutside?: boolean;
    onClose?: () => void;
    align?: 'start' | 'end';
    matchTriggerWidth?: boolean;
    maxHeight?: number;
    observePopupResize?: boolean;
    /** Promotes the popup above modal dialogs without joining an ancestor's scroll context. */
    topLayer?: boolean;
};
/**
 * Dropdown popup component
 * @param triggerRef - The reference to the trigger element
 * @param children - The children of the dropdown
 * @param portalTarget - The target element to render the dropdown
 * @param theme - The theme of the dropdown
 * @param dropdownMenuId - The id of the dropdown menu
 */
export declare function DropdownPopup({ onPointerRelease, triggerRef, children, portalTarget, theme, dropdownMenuId, popupClassName, closeOnClickOutside, onClose, align, matchTriggerWidth, maxHeight, observePopupResize, topLayer, }: DropdownPopupProps): import('preact').VNode<any>;
