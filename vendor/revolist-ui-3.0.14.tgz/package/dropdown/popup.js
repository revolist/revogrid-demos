import { hideTopLayerPopup as e, showTopLayerPopup as t } from "../core/top-layer-popup.js";
import { inheritUiMotion as n } from "../core/motion.js";
import { createPortal as r, useEffect as i, useLayoutEffect as a, useRef as o, useState as s } from "preact/compat";
import { jsx as c } from "preact/jsx-runtime";
//#region src/dropdown/popup.tsx
var l = 5, u = 4;
function d(e, t, n) {
	let r = e.ownerDocument.defaultView;
	if (!r || r.getComputedStyle(e).position === "fixed") return {
		top: t,
		left: n,
		scaleX: 1,
		scaleY: 1
	};
	let i = e.offsetParent, a = e.ownerDocument;
	if (!i || i === a.body || i === a.documentElement) return {
		top: t + r.scrollY,
		left: n + r.scrollX,
		scaleX: 1,
		scaleY: 1
	};
	let o = i.getBoundingClientRect(), s = i, c = s.offsetWidth > 0 ? o.width / s.offsetWidth : 1, l = s.offsetHeight > 0 ? o.height / s.offsetHeight : 1, u = Number.isFinite(c) && c > 0 ? c : 1, d = Number.isFinite(l) && l > 0 ? l : 1;
	return {
		top: (t - o.top) / d - s.clientTop + s.scrollTop,
		left: (n - o.left) / u - s.clientLeft + s.scrollLeft,
		scaleX: u,
		scaleY: d
	};
}
function f({ onPointerRelease: f, triggerRef: p, children: m, portalTarget: h, theme: g, dropdownMenuId: _, popupClassName: v, closeOnClickOutside: y = !1, onClose: b, align: x = "start", matchTriggerWidth: S = !1, maxHeight: C, observePopupResize: w = !0, topLayer: T = !1 }) {
	let E = o(null), [D, O] = s({
		top: 0,
		left: 0,
		display: "none"
	});
	a(() => {
		let e = p.current, t = E.current;
		if (e && t) return n(e, t);
	}, [h, p]), i(() => {
		let e = p.current;
		if (!e) return;
		let t = e.ownerDocument.defaultView ?? window, n = () => {
			let t = E.current;
			if (!t) return;
			let n = e.getBoundingClientRect(), r = d(t, n.bottom + u, n.left);
			O({
				top: r.top,
				left: r.left,
				display: "flex",
				...S ? { width: n.width / r.scaleX } : {}
			});
		}, r = () => {
			let n = E.current;
			if (!n) return;
			let r = e.getBoundingClientRect(), i = n.style.maxHeight;
			n.style.maxHeight = "";
			let a = n.getBoundingClientRect(), o = d(n, 0, 0), s = Math.max(a.height, n.offsetHeight * o.scaleY, n.scrollHeight * o.scaleY);
			n.style.maxHeight = i;
			let c = Math.max(a.width, n.offsetWidth * o.scaleX), f = Math.min(s, typeof C == "number" ? Math.max(0, C * o.scaleY) : Infinity), p = t.innerHeight, m = t.innerWidth, h = Math.max(0, r.top - u - l), g = Math.max(0, p - r.bottom - u - l), _ = f > g && h > g, v = Math.min(f, _ ? h : g), y = _ ? r.top - u - v : r.bottom + u, b = x === "end" ? r.right - c : r.left;
			y = Math.max(l, Math.min(y, p - l - v)), b = Math.max(l, Math.min(b, m - c - l));
			let w = d(n, y, b);
			O({
				top: w.top,
				left: w.left,
				display: "flex",
				maxHeight: v / w.scaleY,
				...S ? { width: r.width / w.scaleX } : {}
			});
		};
		n();
		let i = t.setTimeout(r, 0);
		t.addEventListener("resize", r), t.addEventListener("scroll", r, !0);
		let a = t.ResizeObserver, o = a ? new a(r) : void 0;
		o?.observe(e);
		let s = e.closest(".rv-dialog__surface, dialog");
		return s && o?.observe(s), w && E.current && o?.observe(E.current), () => {
			t.clearTimeout(i), t.removeEventListener("resize", r), t.removeEventListener("scroll", r, !0), o?.disconnect();
		};
	}, [
		x,
		S,
		C,
		w,
		h,
		p
	]), a(() => {
		let n = E.current;
		if (!T || !n) return;
		let r = t(n);
		return () => {
			e(n, r);
		};
	}, [h, T]), a(() => {
		if (!y || !b) return;
		let e = h?.ownerDocument ?? E.current?.ownerDocument ?? p.current?.ownerDocument ?? (typeof document < "u" ? document : void 0);
		if (!e) return;
		let t = (e) => {
			let t = e.target;
			t && (E.current?.contains(t) || p.current?.contains(t) || b());
		};
		e.addEventListener("mousedown", t);
		let n = (t) => {
			if (t.key !== "Escape") return;
			let n = e.activeElement;
			n && (E.current?.contains(n) || p.current?.contains(n)) && (t.preventDefault(), t.stopPropagation(), b(), p.current?.querySelector("button, input, select")?.focus());
		};
		return e.addEventListener("keydown", n), () => {
			e.removeEventListener("mousedown", t), e.removeEventListener("keydown", n);
		};
	}, [
		y,
		b,
		h,
		p
	]);
	let k = /* @__PURE__ */ c("div", {
		ref: E,
		id: _,
		className: `revo-dropdown-menu ${v || ""}`,
		"data-theme": g ?? "default",
		onMouseUp: f,
		onTouchEnd: f,
		style: {
			top: `${D.top}px`,
			left: `${D.left}px`,
			...T ? {
				right: "auto",
				bottom: "auto",
				margin: "0"
			} : {},
			display: D.display,
			maxHeight: D.maxHeight === void 0 ? void 0 : `${D.maxHeight}px`,
			width: D.width === void 0 ? void 0 : `${D.width}px`
		},
		children: m
	});
	return h ? r(k, h) : k;
}
//#endregion
export { f as DropdownPopup };
