import { DropdownProps } from './dropdown.types';
export declare function useRemoteDropdown<T>(props: Pick<DropdownProps<T>, 'dataSource' | 'dataContext' | 'remoteText' | 'value' | 'disabled'> & {
    source: import('./dropdown.types').DropdownOption<T>[];
    open: boolean;
    initialQuery: string;
}): {
    text: {
        loading: string;
        empty: string;
        error: string;
        retry: string;
        loadMore: string;
        unavailable: (id: unknown) => string;
    };
    search: (query: string) => void | undefined;
    loadMore: () => void | undefined;
    retry: () => void | undefined;
    items: import('./dropdown.types').DropdownOption<T>[];
    selected: import('./dropdown.types').DropdownOption<T>[];
    loading: boolean;
    error: boolean;
    hasMore: boolean;
};
