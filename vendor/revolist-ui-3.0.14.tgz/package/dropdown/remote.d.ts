import { DropdownOption } from './dropdown.types';
export type LookupId = string | number;
export type LookupCursor = string | number;
export interface DropdownDataSource<T = LookupId> {
    search(request: {
        query: string;
        cursor?: LookupCursor;
        pageSize: number;
        signal: AbortSignal;
        context: unknown;
    }): Promise<{
        items: readonly DropdownOption<T>[];
        nextCursor?: LookupCursor | null;
    }>;
    resolve(request: {
        ids: readonly T[];
        signal: AbortSignal;
        context: unknown;
    }): Promise<readonly DropdownOption<T>[]>;
}
export interface DropdownRemoteText {
    loading: string;
    empty: string;
    error: string;
    retry: string;
    loadMore: string;
    unavailable: (id: unknown) => string;
}
export declare const defaultDropdownRemoteText: DropdownRemoteText;
export interface RemoteDropdownState<T> {
    items: DropdownOption<T>[];
    selected: DropdownOption<T>[];
    loading: boolean;
    error: boolean;
    hasMore: boolean;
}
/** One contextual session. Aborts and generation checks protect against non-cooperative adapters. */
export declare class RemoteDropdownController<T> {
    private source;
    private context;
    private changed;
    private text;
    private settings;
    private cache;
    private ids;
    private items;
    private query;
    private cursor?;
    private seen;
    private searchAbort?;
    private resolveAbort?;
    private timer?;
    private generation;
    private resolution;
    private disposed;
    private loading;
    private searchFailed;
    private failedCursor?;
    private resolveFailed;
    private opened;
    constructor(source: DropdownDataSource<T>, context: unknown, changed: (state: RemoteDropdownState<T>) => void, text?: DropdownRemoteText, settings?: {
        debounceMs?: number;
        pageSize?: number;
    });
    private remember;
    private emit;
    setSelected(ids: readonly T[], seed?: readonly DropdownOption<T>[]): void;
    search(query: string, immediate?: boolean): void;
    private page;
    loadMore(): void;
    retry(): void;
    close(): void;
    destroy(): void;
}
