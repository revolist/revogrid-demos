import { DurationUnit } from '../_shared/dates/index';
import { DurationFieldOptions } from './index';
/** Optional presentation controls. Numeric conversion and validation stay in the dates owner. */
export declare function DurationControls(props: DurationFieldOptions & {
    unit: DurationUnit;
    amount: number;
    draft: string;
    elapsed: boolean;
    label?: string;
    disabled?: boolean;
    onChange: (value: number, unit?: DurationUnit, elapsed?: boolean) => void;
    onCommit?: (value: number, unit?: DurationUnit, elapsed?: boolean) => void;
}): import("preact").JSX.Element;
