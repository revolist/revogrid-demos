import { EditorCommitOptions } from '../editor-actions';
import { DurationControlOptions, ParsedDuration, DurationUnit } from '../_shared/dates/index';
export interface DurationSliderOptions {
    /** Slider upper limit; the duration's max validation bound takes precedence. */
    max?: number;
    step?: number;
}
export interface DurationFieldOptions extends DurationControlOptions, EditorCommitOptions {
    slider?: boolean | DurationSliderOptions;
    unitButtons?: boolean;
    unitLabels?: Partial<Record<DurationUnit, string>>;
    unitLabel?: string;
    /** Override the input hint, independently of the configured default unit. */
    placeholder?: string;
    modeLabel?: string;
    workingLabel?: string;
    elapsedLabel?: string;
}
export interface DurationFieldProps extends DurationFieldOptions {
    value: ParsedDuration | string | number | null;
    onChange: (value: ParsedDuration | null) => void;
    /** A completed slider or unit/mode interaction, distinct from text entry. */
    onCommit?: (value: ParsedDuration | null) => void;
    onValidityChange?: (valid: boolean) => void;
    /** Product forms can keep raw invalid drafts for their existing error/commit pipeline. */
    onDraftChange?: (text: string) => void;
    label?: string;
    invalidText?: string;
    disabled?: boolean;
    readOnly?: boolean;
    className?: string;
}
export declare function DurationField(props: DurationFieldProps): import("preact").JSX.Element;
export type { DurationControlOptions, ParsedDuration };
/** Shared staged duration form for grid adapters; scheduling stays in product commands. */
export declare function DurationDraft({ value, options, apply, cancel, }: {
    value: DurationFieldProps['value'];
    options: DurationFieldOptions & {
        label?: string;
        invalidText?: string;
        actions?: Partial<import('../editor-actions').EditorActionText>;
    };
    apply: (value: ParsedDuration | null) => void;
    cancel: () => void;
}): import("preact").JSX.Element;
