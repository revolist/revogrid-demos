import { Input as e, Select as t } from "../native-control.js";
import { SegmentedSwitch as n } from "../segmented-switch/index.js";
import { SingleValueSlider as r } from "../filter/filters/slider/single.js";
import { n as i } from "../_chunks/editor-commit-D6Rf5rGz.js";
import { EditorActions as a } from "../editor-actions.js";
import { Fragment as o, jsx as s, jsxs as c } from "preact/jsx-runtime";
import { useEffect as l, useRef as u, useState as d } from "preact/hooks";
//#region ../dates/src/duration.ts
var f = {
	m: "minute",
	min: "minute",
	mins: "minute",
	minute: "minute",
	minutes: "minute",
	h: "hour",
	hr: "hour",
	hrs: "hour",
	hour: "hour",
	hours: "hour",
	d: "day",
	day: "day",
	days: "day",
	w: "week",
	wk: "week",
	wks: "week",
	week: "week",
	weeks: "week",
	mo: "month",
	mon: "month",
	mons: "month",
	month: "month",
	months: "month",
	q: "quarter",
	qr: "quarter",
	qtr: "quarter",
	qtrs: "quarter",
	quarter: "quarter",
	quarters: "quarter",
	y: "year",
	yr: "year",
	yrs: "year",
	year: "year",
	years: "year"
}, p = {
	minute: ["minute", "minutes"],
	hour: ["hour", "hours"],
	day: ["day", "days"],
	week: ["week", "weeks"],
	month: ["month", "months"],
	quarter: ["quarter", "quarters"],
	year: ["year", "years"]
};
function m(e) {
	return typeof e == "number" && Number.isFinite(e) ? Math.min(20, Math.max(0, Math.floor(e))) : 1;
}
function h(e, t) {
	let n = t?.defaultUnit ?? "day";
	if (typeof e == "number") return Number.isFinite(e) && e >= 0 ? {
		value: e,
		unit: n,
		elapsed: !1
	} : null;
	if (typeof e != "string") return null;
	let r = e.trim().toLowerCase();
	if (!r) return null;
	let i = r.match(/^([+]?(?:\d+(?:\.\d+)?|\.\d+))\s*(.*)$/);
	if (!i) return null;
	let a = Number(i[1]);
	if (!Number.isFinite(a) || a < 0) return null;
	let o = i[2].trim().replace(/\s+/g, " "), s = !1;
	if (o.startsWith("elapsed ") ? (s = !0, o = o.slice(8).trim()) : o.startsWith("e") && o.length > 1 && f[o.slice(1)] && (s = !0, o = o.slice(1)), s && t?.allowElapsed === !1) return null;
	let c = o ? f[o] : n;
	return c ? {
		value: a,
		unit: c,
		elapsed: s
	} : null;
}
function g(e, t) {
	return Number(e.toFixed(m(t)));
}
function _(e, t, n) {
	let r = g(e, n?.maximumFractionDigits ?? 1), i = p[t], a = Math.abs(Math.abs(r) - 1) < 1e-9 ? i[0] : i[1];
	return `${r} ${n?.elapsed ? "elapsed " : ""}${a}`;
}
//#endregion
//#region ../dates/src/duration-control.ts
function v(e, t) {
	if (e == null || typeof e == "string" && !e.trim()) return {
		valid: !t.required,
		value: null
	};
	let n = h(typeof e == "object" && e && "unit" in e && "value" in e ? `${String(e.value)}${"elapsed" in e && e.elapsed ? " elapsed " : " "}${String(e.unit)}` : e, {
		...t,
		allowElapsed: t.allowElapsed ?? !1
	}), r = !!n && (!t.allowedUnits || t.allowedUnits.includes(n.unit)) && (t.min === void 0 || n.value >= t.min) && (t.max === void 0 || n.value <= t.max);
	return {
		valid: r,
		value: r ? n : null
	};
}
//#endregion
//#region src/duration/controls.tsx
var y = {
	minute: "min",
	hour: "hour",
	day: "day",
	week: "week",
	month: "month",
	quarter: "qtr",
	year: "year"
};
function b(e) {
	let { unit: i, amount: a } = e, l = e.onCommit ?? e.onChange, u = [...new Set(e.allowedUnits ?? Object.keys(y))], d = typeof e.slider == "object" ? e.slider : {}, f = Number.isFinite(e.min) ? Math.max(0, e.min) : 0, p = Math.max(f + 100, a), m = Number.isFinite(e.max) ? e.max : Number.isFinite(d.max) ? d.max : p, h = Number.isFinite(d.step) && d.step > 0 ? d.step : 1;
	return /* @__PURE__ */ c(o, { children: [e.slider && /* @__PURE__ */ c("span", {
		class: "rv-duration-field__slider",
		children: [/* @__PURE__ */ s(r, {
			min: f,
			max: m,
			step: h,
			value: e.amount,
			disabled: e.disabled || m <= f,
			ariaLabel: e.label ?? "Duration",
			ariaValueText: e.draft,
			onChange: (t) => e.onChange(t),
			onCommit: e.onCommit ? (t) => e.onCommit?.(t) : void 0
		}), /* @__PURE__ */ c("span", {
			class: "rv-duration-field__bounds",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ s("span", { children: f }), /* @__PURE__ */ c("span", { children: [
				m,
				" ",
				e.unitLabels?.[i] ?? y[i]
			] })]
		})]
	}), e.unitButtons && /* @__PURE__ */ c("span", {
		class: "rv-duration-field__modes",
		children: [u.length === 0 ? null : u.length > 5 ? /* @__PURE__ */ s(t, {
			"aria-label": e.unitLabel ?? "Duration unit",
			value: i,
			disabled: e.disabled,
			onChange: (e) => l(a, e.currentTarget.value),
			children: u.map((t) => /* @__PURE__ */ s("option", {
				value: t,
				children: e.unitLabels?.[t] ?? y[t]
			}, t))
		}) : /* @__PURE__ */ s(n, {
			role: "radiogroup",
			ariaLabel: e.unitLabel ?? "Duration unit",
			value: i,
			options: u.map((t) => ({
				value: t,
				label: e.unitLabels?.[t] ?? y[t],
				ariaLabel: e.unitLabels?.[t] ?? t
			})),
			disabled: e.disabled,
			onChange: (e) => l(a, e)
		}), e.allowElapsed && /* @__PURE__ */ s(n, {
			role: "radiogroup",
			ariaLabel: e.modeLabel ?? "Duration mode",
			value: e.elapsed ? "elapsed" : "working",
			options: [{
				value: "working",
				label: e.workingLabel ?? "Working"
			}, {
				value: "elapsed",
				label: e.elapsedLabel ?? "Elapsed"
			}],
			disabled: e.disabled,
			onChange: (e) => l(a, i, e === "elapsed")
		})]
	})] });
}
//#endregion
//#region src/duration/index.tsx
function x(t) {
	let n = (e) => e && typeof e == "object" ? _(e.value, e.unit, {
		elapsed: e.elapsed,
		maximumFractionDigits: t.maximumFractionDigits ?? 10
	}) : e === null ? "" : String(e), [r, i] = d(() => v(t.value, t).value?.unit ?? t.defaultUnit), [a, o] = d(() => n(t.value)), f = u(t.value);
	l(() => {
		t.value !== f.current && (f.current = t.value, o(n(t.value)), i(v(t.value, t).value?.unit ?? t.defaultUnit));
	}, [t.value]);
	let p = {
		...t,
		defaultUnit: t.unitButtons ? r : t.defaultUnit
	}, m = v(a, p);
	l(() => t.onValidityChange?.(m.valid), [m.valid]);
	let h = t.disabled || t.readOnly, g = m.value, y = g?.unit ?? r, x = g?.value ?? 0, S = (e) => {
		o(e), t.onDraftChange?.(e);
		let n = v(e, p);
		n.valid && (n.value && i(n.value.unit), f.current = n.value, t.onChange(n.value));
	}, C = (e, n = y, r = g?.elapsed ?? !1, i = !1) => {
		if (h) return;
		let a = _(e, n, {
			elapsed: r,
			maximumFractionDigits: t.maximumFractionDigits ?? 10
		});
		S(a);
		let o = v(a, p);
		i && o.valid && t.onCommit?.(o.value);
	};
	return /* @__PURE__ */ c("span", {
		class: `rv-duration-field ${t.className ?? ""}`,
		children: [
			/* @__PURE__ */ s(e, {
				type: "text",
				"aria-label": t.label ?? "Duration",
				"aria-invalid": !m.valid,
				value: a,
				disabled: t.disabled,
				readOnly: t.readOnly,
				placeholder: t.placeholder ?? `2 ${t.unitLabels?.[t.defaultUnit] ?? t.defaultUnit}`,
				onInput: (e) => S(e.currentTarget.value)
			}),
			/* @__PURE__ */ s(b, {
				...t,
				unit: y,
				amount: x,
				draft: a,
				elapsed: g?.elapsed ?? !1,
				disabled: h || !m.valid && !!a.trim(),
				onChange: C,
				onCommit: (e, t, n) => C(e, t, n, !0)
			}),
			!m.valid && /* @__PURE__ */ s("span", {
				role: "alert",
				class: "rv-editor-error",
				children: t.invalidText ?? "Enter a valid duration within the allowed units and bounds."
			})
		]
	});
}
function S({ value: e, options: t, apply: n, cancel: r }) {
	let [o, l] = d(!1), [f, p] = d(e), [m, h] = d(0), g = t.autoApply !== !1, _ = u(!1), y = u(e), b = (e = !1) => {
		let r = v(y.current, t);
		return r.valid ? ((e || !g || _.current) && (_.current = !1, n(r.value)), !0) : !1;
	};
	return i(b, g), /* @__PURE__ */ c("div", {
		onKeyDown: (e) => {
			let t = e.target instanceof HTMLInputElement && e.target.type === "text";
			!e.isComposing && e.key === "Enter" && (g && t || e.ctrlKey || e.metaKey) && (e.preventDefault(), b(!0));
		},
		children: [/* @__PURE__ */ s(x, {
			...t,
			value: f,
			onChange: (e) => {
				_.current = !0, p(e);
			},
			onDraftChange: (e) => {
				_.current = !0, y.current = e;
			},
			onCommit: g ? (e) => {
				_.current = !1, n(e);
			} : void 0,
			onValidityChange: l
		}, m), /* @__PURE__ */ s(a, {
			showConfirm: t.showActions ?? !g,
			text: t.actions,
			disabled: !o,
			apply: () => b(!0),
			cancel: r,
			clear: t.required ? void 0 : () => {
				g ? n(null) : (y.current = null, p(null), h((e) => e + 1));
			}
		})]
	});
}
//#endregion
export { S as DurationDraft, x as DurationField };
