export interface EditorCommitOptions {
    /** Apply completed edits automatically. Set false to require explicit Apply. */
    autoApply?: boolean;
    /** Show Apply/Cancel buttons. Defaults to true only when autoApply is false. */
    showActions?: boolean;
}
export interface EditorActionText {
    apply: string;
    cancel: string;
    clear: string;
}
export declare const defaultEditorActionText: EditorActionText;
export declare function EditorActions({ apply, cancel, clear, disabled, text, showConfirm, }: {
    apply: () => void;
    cancel: () => void;
    clear?: () => void;
    disabled?: boolean;
    text?: Partial<EditorActionText>;
    showConfirm?: boolean;
}): import("preact").JSX.Element | null;
