import { Button as e } from "./controls.js";
import { Fragment as t, jsx as n, jsxs as r } from "preact/jsx-runtime";
//#region src/editor-actions.tsx
var i = {
	apply: "Apply",
	cancel: "Cancel",
	clear: "Clear"
};
function a({ apply: a, cancel: o, clear: s, disabled: c, text: l = i, showConfirm: u = !0 }) {
	if (!u && !s) return null;
	let d = {
		apply: l.apply ?? i.apply,
		cancel: l.cancel ?? i.cancel,
		clear: l.clear ?? i.clear
	};
	return /* @__PURE__ */ r("div", {
		class: "rv-editor-actions",
		children: [s && /* @__PURE__ */ n(e, {
			variant: "ghost",
			onClick: s,
			children: d.clear
		}), u && /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ n(e, {
			onClick: o,
			children: d.cancel
		}), /* @__PURE__ */ n(e, {
			variant: "primary",
			disabled: c,
			onClick: a,
			children: d.apply
		})] })]
	});
}
//#endregion
export { a as EditorActions, i as defaultEditorActionText };
