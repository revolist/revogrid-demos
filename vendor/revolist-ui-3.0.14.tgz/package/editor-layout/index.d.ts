import { h, ComponentChildren, JSX, Ref } from 'preact';
type ShellProps = {
    readonly children: ComponentChildren;
    readonly className?: string;
};
/** Shared editor geometry. Consumers supply column widths and feature policy. */
export declare function EditorSplitLayout({ children, className }: ShellProps): h.JSX.Element;
export declare function EditorPane({ children, className, scrollable }: ShellProps & {
    readonly scrollable?: boolean;
}): h.JSX.Element;
export interface EditorListProps extends ShellProps {
    readonly label: string;
    readonly onSelect: (value: string) => void;
    readonly listRef?: Ref<HTMLDivElement>;
    /** Omit the inner frame when the list sits inside an editor pane. */
    readonly variant?: 'default' | 'plain';
    /** Additional room around icon/description rows. */
    readonly spacing?: 'default' | 'comfortable';
}
/** Single-selection listbox with one keyboard/focus owner across editors. */
export declare function EditorList({ children, className, label, onSelect, listRef, variant, spacing }: EditorListProps): h.JSX.Element;
export type EditorListItemProps = Omit<JSX.IntrinsicElements['button'], 'value' | 'className'> & {
    readonly value: string;
    readonly selected: boolean;
    readonly className?: string;
    readonly icon?: ComponentChildren;
    readonly label?: ComponentChildren;
    readonly description?: ComponentChildren;
    readonly contentClassNames?: EditorListItemContentProps['classNames'];
};
export declare function EditorListItem({ value, selected, icon, label, description, contentClassNames, children, className, ...props }: EditorListItemProps): h.JSX.Element;
export interface EditorListItemContentProps {
    readonly icon?: ComponentChildren;
    readonly label: ComponentChildren;
    readonly description?: ComponentChildren;
    readonly classNames?: {
        readonly icon?: string;
        readonly copy?: string;
        readonly label?: string;
        readonly description?: string;
    };
}
/** Reusable row presentation; the enclosing list item owns selection and focus. */
export declare function EditorListItemContent({ icon, label, description, classNames }: EditorListItemContentProps): h.JSX.Element;
export declare function EditorListGroup({ label, children, className, labelClassName }: ShellProps & {
    readonly label: string;
    readonly labelClassName?: string;
}): h.JSX.Element;
export {};
