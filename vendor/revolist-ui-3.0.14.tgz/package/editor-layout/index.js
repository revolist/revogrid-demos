import { jsx as e, jsxs as t } from "preact/jsx-runtime";
//#region src/editor-layout/index.tsx
function n({ children: t, className: n = "" }) {
	return /* @__PURE__ */ e("div", {
		class: `rv-editor-split ${n}`,
		children: t
	});
}
function r({ children: t, className: n = "", scrollable: r = !1 }) {
	return /* @__PURE__ */ e("section", {
		class: `rv-editor-pane${r ? " rv-editor-pane--scrollable" : ""} ${n}`,
		children: t
	});
}
function i({ children: t, className: n = "", label: r, onSelect: i, listRef: a, variant: o = "default", spacing: s = "default" }) {
	return /* @__PURE__ */ e("div", {
		ref: a,
		class: `rv-editor-list${o === "plain" ? " rv-editor-list--plain" : ""}${s === "comfortable" ? " rv-editor-list--comfortable" : ""} ${n}`,
		role: "listbox",
		"aria-label": r,
		onKeyDown: (e) => {
			if (![
				"ArrowDown",
				"ArrowUp",
				"Home",
				"End"
			].includes(e.key)) return;
			let t = Array.from(e.currentTarget.querySelectorAll("[data-editor-value]:not(:disabled)"));
			if (!t.length) return;
			let n = Math.max(0, t.indexOf(e.target)), r = e.key === "Home" ? 0 : e.key === "End" ? t.length - 1 : (n + (e.key === "ArrowDown" ? 1 : -1) + t.length) % t.length;
			e.preventDefault(), t[r].focus(), i(t[r].dataset.editorValue);
		},
		children: t
	});
}
function a({ value: t, selected: n, icon: r, label: i, description: a, contentClassNames: s, children: c, className: l = "", ...u }) {
	return /* @__PURE__ */ e("button", {
		...u,
		type: "button",
		role: "option",
		"data-editor-value": t,
		"aria-selected": n,
		tabIndex: n ? 0 : -1,
		class: `rv-editor-list__item${n ? " rv-editor-list__item--selected" : ""} ${l}`,
		children: i === void 0 ? c : /* @__PURE__ */ e(o, {
			icon: r,
			label: i,
			description: a,
			classNames: s
		})
	});
}
function o({ icon: n, label: r, description: i, classNames: a = {} }) {
	return /* @__PURE__ */ t("span", {
		class: `rv-editor-list__content${n ? "" : " rv-editor-list__content--text"}`,
		children: [n && /* @__PURE__ */ e("span", {
			class: `rv-editor-list__icon ${a.icon ?? ""}`,
			"aria-hidden": "true",
			children: n
		}), /* @__PURE__ */ t("span", {
			class: `rv-editor-list__copy ${a.copy ?? ""}`,
			children: [/* @__PURE__ */ e("span", {
				class: `rv-editor-list__label ${a.label ?? ""}`,
				children: r
			}), i !== void 0 && /* @__PURE__ */ e("span", {
				class: `rv-editor-list__description ${a.description ?? ""}`,
				children: i
			})]
		})]
	});
}
function s({ label: n, children: r, className: i = "", labelClassName: a = "" }) {
	return /* @__PURE__ */ t("div", {
		class: `rv-editor-list__group ${i}`,
		role: "group",
		"aria-label": n,
		children: [/* @__PURE__ */ e("div", {
			class: `rv-editor-list__group-label ${a}`,
			children: n
		}), r]
	});
}
//#endregion
export { i as EditorList, s as EditorListGroup, a as EditorListItem, o as EditorListItemContent, r as EditorPane, n as EditorSplitLayout };
