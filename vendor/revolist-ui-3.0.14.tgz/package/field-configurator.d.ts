import { RemoveButton } from './buttons/remove-button';
import { h, ComponentChildren, JSX } from 'preact';
export declare function FieldIcon({ svg, className, }: {
    svg: string;
    className?: string;
}): h.JSX.Element;
export declare function FieldSummary({ children, className, ...attributes }: Omit<JSX.IntrinsicElements['summary'], 'children'> & {
    children: ComponentChildren;
    className?: string;
}): h.JSX.Element;
export declare function FieldLibrary({ title, count, children, className, }: {
    title: string;
    count?: ComponentChildren;
    children: ComponentChildren;
    className?: string;
}): h.JSX.Element;
export declare function FieldGroupHeading({ children, actions, className, }: {
    children: ComponentChildren;
    actions?: ComponentChildren;
    className?: string;
}): h.JSX.Element;
export declare function FieldGroup({ heading, actions, headingClassName, className, children, ...props }: Omit<JSX.HTMLAttributes<HTMLElement>, 'class' | 'title'> & {
    heading: ComponentChildren;
    actions?: ComponentChildren;
    headingClassName?: string;
    className?: string;
}): h.JSX.Element;
export declare function FieldList({ empty, placeholder, className, children, ...props }: Omit<JSX.HTMLAttributes<HTMLUListElement>, 'class'> & {
    empty: boolean;
    placeholder: ComponentChildren;
    className?: string;
}): h.JSX.Element;
export declare function FieldRow({ className, children, indicator, dropPosition, ...props }: Omit<JSX.HTMLAttributes<HTMLLIElement>, 'class'> & {
    className?: string;
    indicator?: ComponentChildren;
    dropPosition?: 'before' | 'after';
}): h.JSX.Element;
export declare function FieldContent({ icon, children, className, }: {
    icon?: ComponentChildren;
    children: ComponentChildren;
    className?: string;
}): h.JSX.Element;
/** Neutral row shell; consumers supply actions, selection and update policy. */
export declare function FieldItem({ as, children, className, ...props }: Omit<JSX.HTMLAttributes<HTMLElement>, 'class'> & {
    as?: 'div' | 'label';
    className?: string;
}): JSX.Element;
export declare function FieldLibraryList({ children, ...props }: JSX.HTMLAttributes<HTMLDivElement>): h.JSX.Element;
/** Selected field row; product adapters retain drag, settings and remove policy. */
export declare function SelectedField({ label, icon, actions, contentClassName, ...row }: Omit<Parameters<typeof FieldRow>[0], 'children'> & {
    label: ComponentChildren;
    icon?: ComponentChildren;
    actions?: ComponentChildren;
    contentClassName?: string;
}): h.JSX.Element;
export declare function FieldActions({ children, className, ...props }: Omit<JSX.HTMLAttributes<HTMLDivElement>, 'class'> & {
    className?: string;
}): h.JSX.Element;
export declare function FieldStatusBadge({ children, active, label, className, }: {
    children: ComponentChildren;
    active?: boolean;
    label: string;
    className?: string;
}): h.JSX.Element;
/** Animated remove control shared by selected-field rows and section actions. */
export declare function FieldRemoveButton(props: Parameters<typeof RemoveButton>[0]): h.JSX.Element;
/** The same removal glyph for native policy adapters and field remove buttons. */
export declare function FieldRemoveIcon(): h.JSX.Element;
export { reorderFields, fieldDropIndex } from './field-reorder';
export { useFieldReorder, useFieldDropTarget } from './field-reorder.hook';
export declare function FieldDropIndicator({ position, index, className, }: {
    position: 'before' | 'after';
    index?: number;
    className?: string;
}): h.JSX.Element;
