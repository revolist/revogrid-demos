import { SvgIcon as e } from "./icons/icon.js";
import { n as t } from "./_chunks/delete-button-DnpmDNEJ.js";
import { RemoveButton as n } from "./buttons/remove-button.js";
import { DisclosureSummary as r } from "./form-controls/presentation.js";
import { t as i } from "./_chunks/chevron-right-sxHQMSkq.js";
import { fieldDropIndex as a, reorderFields as o } from "./field-reorder.js";
import { useFieldDropTarget as s, useFieldReorder as c } from "./field-reorder.hook.js";
import { h as l } from "preact";
import { jsx as u, jsxs as d } from "preact/jsx-runtime";
//#region src/field-configurator.tsx
function f({ svg: t, className: n = "" }) {
	return /* @__PURE__ */ u(e, {
		svg: t,
		className: `rv-configurator-icon ${n}`
	});
}
function p({ children: e, className: t = "", ...n }) {
	return /* @__PURE__ */ u(r, {
		...n,
		className: `rv-configurator-summary ${t}`,
		iconPosition: "after",
		icon: /* @__PURE__ */ u(f, { svg: i }),
		children: e
	});
}
function m({ title: e, count: t, children: n, className: r = "" }) {
	return /* @__PURE__ */ d("details", {
		class: `rv-configurator-available-fields ${r}`,
		open: !0,
		children: [/* @__PURE__ */ d(p, { children: [e, t != null && /* @__PURE__ */ u("span", {
			class: "rv-configurator-field-count",
			children: t
		})] }), /* @__PURE__ */ u("div", {
			class: "rv-configurator-library-content",
			children: n
		})]
	});
}
function h({ children: e, actions: t, className: n = "" }) {
	return /* @__PURE__ */ d("div", {
		class: `rv-configurator-zone-heading ${n}`,
		children: [/* @__PURE__ */ u("span", {
			class: "rv-configurator-zone-label",
			children: e
		}), t && /* @__PURE__ */ u("span", {
			class: "rv-configurator-zone-actions",
			children: t
		})]
	});
}
function g({ heading: e, actions: t, headingClassName: n, className: r = "", children: i, ...a }) {
	return /* @__PURE__ */ d("section", {
		...a,
		className: `rv-configurator-zone ${r}`,
		children: [/* @__PURE__ */ u(h, {
			className: n,
			actions: t,
			children: e
		}), i]
	});
}
function _({ empty: e, placeholder: t, className: n = "", children: r, ...i }) {
	return /* @__PURE__ */ u("ul", {
		...i,
		className: `rv-configurator-field-list ${e ? "empty" : ""} ${n}`,
		children: e ? /* @__PURE__ */ u("li", {
			className: "rv-configurator-empty-zone empty",
			children: t
		}) : r
	});
}
function v({ className: e = "", children: t, indicator: n, dropPosition: r, ...i }) {
	return /* @__PURE__ */ d("li", {
		...i,
		className: `rv-configurator-field rv-configurator-field-row ${e}`,
		children: [
			n ?? (r && /* @__PURE__ */ u(D, { position: r })),
			/* @__PURE__ */ u("span", {
				className: "rv-configurator-drag-handle",
				"aria-hidden": "true"
			}),
			t
		]
	});
}
function y({ icon: e, children: t, className: n = "" }) {
	return /* @__PURE__ */ d("span", {
		class: `rv-configurator-field-content ${n}`,
		children: [e, /* @__PURE__ */ u("span", {
			class: "rv-configurator-field-caption",
			children: t
		})]
	});
}
function b({ as: e = "div", children: t, className: n = "", ...r }) {
	return l(e, {
		...r,
		class: `rv-configurator-field ${n}`
	}, t);
}
function x({ children: e, ...t }) {
	return /* @__PURE__ */ u("div", {
		...t,
		className: `rv-configurator-library-list ${t.className ?? ""}`,
		children: e
	});
}
function S({ label: e, icon: t, actions: n, contentClassName: r, ...i }) {
	return /* @__PURE__ */ d(v, {
		...i,
		children: [/* @__PURE__ */ u(y, {
			className: r,
			icon: t,
			children: e
		}), n]
	});
}
function C({ children: e, className: t = "", ...n }) {
	return /* @__PURE__ */ u("div", {
		...n,
		className: `rv-configurator-field-actions ${t}`,
		children: e
	});
}
function w({ children: e, active: t = !1, label: n, className: r = "" }) {
	return /* @__PURE__ */ u("span", {
		className: `rv-configurator-status-badge ${r}`,
		"data-active": t ? "true" : void 0,
		title: n,
		"aria-label": n,
		children: e
	});
}
function T(e) {
	return /* @__PURE__ */ u(n, {
		...e,
		className: `rv-configurator-remove-button ${e.className ?? ""}`
	});
}
function E() {
	return /* @__PURE__ */ u(e, { svg: t });
}
function D({ position: e, index: t, className: n = "" }) {
	return /* @__PURE__ */ u("span", {
		className: `rv-configurator-drop-indicator ${n}`,
		"data-position": e,
		"data-drop-index": t,
		"aria-hidden": "true"
	});
}
//#endregion
export { C as FieldActions, y as FieldContent, D as FieldDropIndicator, g as FieldGroup, h as FieldGroupHeading, f as FieldIcon, b as FieldItem, m as FieldLibrary, x as FieldLibraryList, _ as FieldList, T as FieldRemoveButton, E as FieldRemoveIcon, v as FieldRow, w as FieldStatusBadge, p as FieldSummary, S as SelectedField, a as fieldDropIndex, o as reorderFields, s as useFieldDropTarget, c as useFieldReorder };
