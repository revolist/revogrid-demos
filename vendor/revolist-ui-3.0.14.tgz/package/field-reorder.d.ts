/** Move an item to a boundary in the original list (0 = before first, length = after last). */
export declare function reorderFields<T>(items: readonly T[], from: number, boundary: number): T[];
/** Shared midpoint hit testing, with a stable side while the pointer crosses the dead zone. */
export declare function fieldDropIndex(pointer: number, start: number, size: number, index: number, previous?: number | null, tolerance?: number): number;
/** Resolves list background and inter-row gaps using the same boundaries as row hit testing. */
export declare function fieldListDropIndex(pointer: number, rows: readonly {
    top: number;
    height: number;
}[], previous?: number | null, endBoundary?: number): number;
