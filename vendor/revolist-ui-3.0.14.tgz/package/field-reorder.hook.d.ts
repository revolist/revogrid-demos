type FieldDropOptions = {
    enabled?: boolean;
    active?: boolean;
    canDrop?: (event: DragEvent) => boolean;
    onDragOver?: (event: DragEvent) => void;
    onDrop: (boundary: number, event: DragEvent) => void;
};
/** One owner for list/row hit testing, gap drops, insertion feedback and cleanup. */
export declare function useFieldDropTarget(count: number, options: FieldDropOptions): {
    clear: () => void;
    start(index: number): void;
    boundary: number | null;
    overBoundary: (event: DragEvent, boundary: number) => void;
    dropBoundary: (event: DragEvent, boundary: number) => void;
    position: (index: number) => "before" | "after" | undefined;
    isOver: boolean;
    list: {
        onDragOver: (event: DragEvent) => void;
        onDrop: (event: DragEvent) => void;
        onDragLeave(event: DragEvent): void;
    };
    row(index: number): {
        dropPosition: "before" | "after" | undefined;
        onDragOver: (event: DragEvent) => void;
        onDrop: (event: DragEvent) => void;
    };
};
/** Same-section adapter; consumers own ordered values, policy and the commit. */
export declare function useFieldReorder<T>(items: readonly T[], onChange: (next: T[]) => void, enabled?: boolean, options?: {
    onMove?: (item: T) => void;
    dragPreview?: 'row';
}): {
    move: (from: number, boundary: number) => void;
    draggedIndex: number | null;
    dropIndex: number | undefined;
    overBoundary: (event: DragEvent, boundary: number) => void;
    dropBoundary: (event: DragEvent, boundary: number) => void;
    list: {
        onDragOver: (event: DragEvent) => void;
        onDrop: (event: DragEvent) => void;
        onDragLeave(event: DragEvent): void;
    };
    row(index: number): {
        draggable: boolean;
        onDragStart(event: DragEvent): void;
        onDragEnd(): void;
        onKeyDown(event: KeyboardEvent): void;
        dropPosition: "before" | "after" | undefined;
        onDragOver: (event: DragEvent) => void;
        onDrop: (event: DragEvent) => void;
    };
};
export {};
