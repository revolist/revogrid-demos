import { fieldDropIndex as e, fieldListDropIndex as t, reorderFields as n } from "./field-reorder.js";
import { useLayoutEffect as r, useRef as i, useState as a } from "preact/hooks";
//#region src/field-reorder.hook.ts
function o(n, o) {
	let s = i({
		count: n,
		...o
	});
	s.current = {
		count: n,
		...o
	};
	let c = i(null), l = i(null), [u, d] = a(null), f = () => {
		c.current = null, l.current = null, d(null);
	};
	r(() => {
		(o.enabled === !1 || o.active === !1) && f();
	}, [o.enabled, o.active]);
	let p = (e) => s.current.enabled !== !1 && (s.current.canDrop?.(e) ?? !0), m = (n, r) => {
		let i = n.currentTarget;
		if (r !== void 0) {
			let t = i.getBoundingClientRect();
			return e(n.clientY, t.top, t.height, r, l.current);
		}
		let a = Array.from(i.querySelectorAll(":scope > .rv-configurator-field-row, :scope > .rv-configurator-field-list > .rv-configurator-field-row"));
		return t(n.clientY, a.map((e) => e.getBoundingClientRect()), l.current, s.current.count);
	}, h = (e, t, n) => {
		p(e) ? (e.preventDefault(), e.stopPropagation(), l.current = n ?? m(e, t), d(l.current), e.dataTransfer && (e.dataTransfer.dropEffect = "move"), s.current.onDragOver?.(e)) : (l.current = null, d(null));
	}, g = (e, t, n) => {
		if (!p(e)) {
			f();
			return;
		}
		e.preventDefault(), e.stopPropagation(), e.dataTransfer && (e.dataTransfer.dropEffect = "move");
		let r = n ?? m(e, t);
		l.current = null, d(null), s.current.onDrop(r, e), c.current = null;
	}, _ = (e) => {
		if (u !== null && (c.current === null || u !== c.current && u !== c.current + 1)) {
			if (u === e) return "before";
			if (u === n && e === n - 1) return "after";
		}
	};
	return {
		clear: f,
		start(e) {
			c.current = e;
		},
		boundary: u,
		overBoundary: (e, t) => h(e, void 0, t),
		dropBoundary: (e, t) => g(e, void 0, t),
		position: _,
		isOver: u !== null,
		list: {
			onDragOver: (e) => h(e),
			onDrop: (e) => g(e),
			onDragLeave(e) {
				let t = e.relatedTarget;
				(!(t instanceof Node) || !e.currentTarget.contains(t)) && (l.current = null, d(null));
			}
		},
		row(e) {
			return {
				dropPosition: _(e),
				onDragOver: (t) => h(t, e),
				onDrop: (t) => g(t, e)
			};
		}
	};
}
function s(e, t, s = !0, c = {}) {
	let l = i({
		items: e,
		onChange: t,
		enabled: s,
		...c
	});
	l.current = {
		items: e,
		onChange: t,
		enabled: s,
		...c
	};
	let [u, d] = a(null), f = i(null), p = () => {
		let e = f.current, t = l.current;
		return !e || !t.enabled || e.items.length !== t.items.length || e.items.some((e, n) => e !== t.items[n]) ? (f.current = null, null) : e;
	}, m = o(e.length, {
		enabled: s,
		canDrop: () => !!p(),
		onDrop(e) {
			let t = p();
			if (!t) return;
			f.current = null, d(null);
			let r = n(l.current.items, t.from, e);
			r !== l.current.items && (l.current.onChange(r), l.current.onMove?.(t.items[t.from]));
		}
	});
	r(() => {
		p() || (m.clear(), d(null));
	}, [e, s]);
	let h = (e, t) => {
		let r = l.current;
		if (!r.enabled) return;
		let i = n(r.items, e, t);
		i !== r.items && (r.onChange(i), r.onMove?.(r.items[e]));
	};
	return {
		move: h,
		draggedIndex: u,
		dropIndex: m.boundary !== null && u !== null && m.boundary !== u && m.boundary !== u + 1 ? m.boundary : void 0,
		overBoundary: m.overBoundary,
		dropBoundary: m.dropBoundary,
		list: m.list,
		row(e) {
			return {
				...m.row(e),
				draggable: s,
				onDragStart(t) {
					if (!l.current.enabled) t.preventDefault();
					else if (f.current = {
						items: l.current.items,
						from: e
					}, d(e), m.start(e), t.dataTransfer?.setData("text/plain", String(e)), t.dataTransfer && (t.dataTransfer.effectAllowed = "move", l.current.dragPreview === "row")) {
						let e = t.currentTarget.closest?.(".rv-reorder-row, .rv-configurator-field-row");
						if (e) {
							let n = e.getBoundingClientRect();
							t.dataTransfer.setDragImage(e, Math.min(n.width, Math.max(0, t.clientX - n.left)), Math.min(n.height, Math.max(0, t.clientY - n.top)));
						}
					}
				},
				onDragEnd() {
					f.current = null, d(null), m.clear();
				},
				onKeyDown(t) {
					if (!l.current.enabled || !t.altKey || !["ArrowUp", "ArrowDown"].includes(t.key)) return;
					t.preventDefault();
					let n = t.currentTarget;
					h(e, t.key === "ArrowUp" ? e - 1 : e + 2), queueMicrotask(() => {
						n.isConnected && n.focus();
					});
				}
			};
		}
	};
}
//#endregion
export { o as useFieldDropTarget, s as useFieldReorder };
