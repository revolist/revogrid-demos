//#region src/field-reorder.ts
function e(e, t, n) {
	if (!Number.isInteger(t) || !Number.isInteger(n) || t < 0 || t >= e.length || n < 0 || n > e.length || t === n || t + 1 === n) return e;
	let r = [...e], [i] = r.splice(t, 1);
	return r.splice(t < n ? n - 1 : n, 0, i), r;
}
function t(e, t, n, r, i = null, a = 4) {
	let o = t + n / 2;
	return Math.abs(e - o) <= a && (i === r || i === r + 1) ? i : e <= o ? r : r + 1;
}
function n(e, n, r = null, i = n.length) {
	for (let i = 0; i < n.length; i++) {
		let a = n[i];
		if (e <= a.top + a.height) return t(e, a.top, a.height, i, r);
	}
	return i;
}
//#endregion
export { t as fieldDropIndex, n as fieldListDropIndex, e as reorderFields };
