import { h, ComponentChildren, JSX } from 'preact';
import { FilterChipProps } from './form-controls/presentation';
/** Shared click-only details action; consumers provide localized labels. */
export declare function FilterBadgeInfoButton(props: Omit<JSX.IntrinsicElements['button'], 'children'>): h.JSX.Element;
/** Active-filter presentation, independent of grid/filter state. */
export declare function FilterBadge({ label, details, detailsLabel, descriptionId, className, ...props }: Omit<FilterChipProps, 'children'> & {
    label: ComponentChildren;
    color?: string;
    details?: string;
    detailsLabel?: string;
    descriptionId?: string;
}): h.JSX.Element;
