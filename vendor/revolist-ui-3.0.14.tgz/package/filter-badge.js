import { n as e, t } from "./_chunks/choice-chips-CJKUg_0I.js";
import { Fragment as n, jsx as r, jsxs as i } from "preact/jsx-runtime";
import { useId as a } from "preact/hooks";
//#region src/filter-badge.tsx
function o(t) {
	return /* @__PURE__ */ r(e, {
		...t,
		type: "button",
		class: `rv-filter-badge-info ${t.className ?? t.class ?? ""}`.trim()
	});
}
function s({ label: e, details: s, detailsLabel: c, descriptionId: l, className: u = "", ...d }) {
	let f = a(), p = l ?? `rv-filter-badge-${f}`;
	return /* @__PURE__ */ r(t, {
		...d,
		selected: !0,
		className: `rv-filter-badge ${u}`.trim(),
		info: s ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r(o, {
			"aria-label": c,
			"aria-describedby": p,
			"data-tooltip": s,
			"tooltip-position": "bottom"
		}), /* @__PURE__ */ r("span", {
			class: "rv-filter-badge-description",
			id: p,
			children: s
		})] }) : void 0,
		children: /* @__PURE__ */ r("span", {
			class: "rv-filter-badge-label",
			children: e
		})
	});
}
//#endregion
export { s as FilterBadge, o as FilterBadgeInfoButton };
