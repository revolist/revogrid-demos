import { h, ComponentChildren, JSX } from 'preact';
/** A selected action with a trailing, caller-formatted summary. */
export declare function OptionButton({ label, detail, selected, className, detailClassName, ...props }: Omit<JSX.IntrinsicElements['button'], 'className' | 'children'> & {
    label: ComponentChildren;
    detail?: ComponentChildren;
    selected?: boolean;
    className?: string;
    detailClassName?: string;
}): h.JSX.Element;
export { Legend, type LegendItem } from './legend';
/** Caller supplies highlighting; UI owns overlay geometry and scroll synchronization. */
export declare function HighlightedTextInput({ highlight, className, inputClassName, highlightClassName, ...props }: Omit<JSX.IntrinsicElements['textarea'], 'className'> & {
    highlight: ComponentChildren;
    className?: string;
    inputClassName?: string;
    highlightClassName?: string;
}): h.JSX.Element;
export declare function InlineFieldGroup({ children, className, label, }: {
    children: ComponentChildren;
    className?: string;
    label?: string;
}): h.JSX.Element;
