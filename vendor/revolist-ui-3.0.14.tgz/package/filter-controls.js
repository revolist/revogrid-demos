import { ButtonControl as e, TextArea as t } from "./native-control.js";
import { Legend as n } from "./legend.js";
import { jsx as r, jsxs as i } from "preact/jsx-runtime";
import { useRef as a } from "preact/hooks";
//#region src/filter-controls.tsx
function o({ label: t, detail: n, selected: a, className: o = "", detailClassName: s = "", ...c }) {
	return /* @__PURE__ */ i(e, {
		...c,
		class: `rv-option-button ${o}`,
		"aria-pressed": a,
		children: [/* @__PURE__ */ r("strong", { children: t }), /* @__PURE__ */ r("span", {
			class: `rv-option-button__detail ${s}`,
			children: n
		})]
	});
}
function s({ highlight: e, className: n = "", inputClassName: o = "", highlightClassName: s = "", ...c }) {
	let l = a(null);
	return /* @__PURE__ */ i("div", {
		class: `rv-highlighted-input ${n}`,
		"data-invalid": c["aria-invalid"] || void 0,
		children: [/* @__PURE__ */ r("pre", {
			class: `rv-highlighted-input__highlight ${s}`,
			"aria-hidden": "true",
			ref: l,
			children: e
		}), /* @__PURE__ */ r(t, {
			...c,
			class: `rv-highlighted-input__input ${o}`,
			spellcheck: c.spellcheck ?? !1,
			onScroll: (e) => {
				l.current && (l.current.scrollTop = e.currentTarget.scrollTop, l.current.scrollLeft = e.currentTarget.scrollLeft), c.onScroll?.(e);
			}
		})]
	});
}
function c({ children: e, className: t = "", label: n }) {
	return /* @__PURE__ */ r("div", {
		role: "group",
		"aria-label": n,
		class: `rv-inline-field-group ${t}`,
		children: e
	});
}
//#endregion
export { s as HighlightedTextInput, c as InlineFieldGroup, n as Legend, o as OptionButton };
