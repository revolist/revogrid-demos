import { RangeSliderProps } from './types';
export type RangeSliderElementFactory = (type: string, props: Record<string, unknown> | null, ...children: unknown[]) => unknown;
/** Renderer shared by the Stencil filter shell and Preact structured editors. */
export declare function renderRangeSlider(h: RangeSliderElementFactory, props: RangeSliderProps): unknown;
