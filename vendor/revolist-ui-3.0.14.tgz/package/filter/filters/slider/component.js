import { formatSliderInputValue as e, formatSliderValue as t, normalizeSliderState as n, parseSliderInputValue as r, scaleSliderValue as i, unscaleSliderValue as a } from "./logic.js";
import { syncVisuals as o } from "./runtime.js";
import { renderSliderControl as s } from "./control.js";
import { renderRangeInputs as c } from "./inputs.js";
//#region src/filter/filters/slider/component.ts
function l(e, t) {
	let { fromValueInt: n, toValueInt: r } = t.state, { scaleFactor: i } = t;
	return e("div", { className: "range-values" }, e("span", { ref: (e) => {
		t.refs.fromLabel = e, e && (e.textContent = t.formatFromValue(a(n, i)));
	} }, t.formatFromValue(a(n, i))), e("span", { ref: (e) => {
		t.refs.toLabel = e, e && (e.textContent = t.formatToValue(a(r, i)));
	} }, t.formatToValue(a(r, i))));
}
function u(a, u) {
	let { min: d, max: f, fromValue: p, toValue: m, showTooltips: h = !1, showRangeDisplay: g = !1, showRangeInputs: _ = !1, disabled: v = !1, scaleFactor: y, step: b, className: x, controlClassName: S, fromClassName: C, toClassName: w, fromAriaLabel: T, toAriaLabel: E, onRangeChange: D, onRangeCommit: O, formatValue: k = t, formatFromValue: A = k, formatToValue: j = k, formatInputValue: M = e, parseInputValue: N } = u, P = Number.isFinite(y) && Number(y) > 0 ? Number(y) : 100, F = {}, I = n({
		min: d,
		max: f,
		fromValue: p,
		toValue: m,
		scaleFactor: P
	}), L = Number.isFinite(b) && Number(b) > 0 ? Math.max(1, i(Number(b), P)) : 1, R = (I.maxInt - I.minInt) % L === 0 ? L : 1, z = 0, B = {
		refs: F,
		state: I,
		scaleFactor: P,
		nativeStep: R,
		formatValue: k,
		formatFromValue: A,
		formatToValue: j,
		formatInputValue: M,
		parseInputValue: N ?? r,
		showTooltips: h,
		onRangeChange: D,
		onRangeCommit: O,
		disabled: v,
		controlClassName: S,
		fromClassName: C,
		toClassName: w,
		fromAriaLabel: T,
		toAriaLabel: E,
		syncVisuals: () => o(B),
		scheduleSyncVisuals: () => {
			z && cancelAnimationFrame(z), z = requestAnimationFrame(() => {
				z = 0, B.syncVisuals();
			});
		}
	};
	return a("div", { className: `range_container${x ? ` ${x}` : ""}` }, g ? l(a, B) : null, s(a, B), _ ? c(a, B) : null);
}
//#endregion
export { u as renderRangeSlider };
