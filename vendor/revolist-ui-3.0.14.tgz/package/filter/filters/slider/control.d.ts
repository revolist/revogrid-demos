import { RangeSliderRuntime } from './runtime';
import { RangeSliderElementFactory } from './component';
/**
 * Renders the dual native range inputs used as slider handles.
 * Shared runtime helpers keep handle position, highlighted track, labels,
 * tooltips, and optional editable inputs synchronized.
 */
export declare function renderSliderControl(h: RangeSliderElementFactory, runtime: RangeSliderRuntime): unknown;
