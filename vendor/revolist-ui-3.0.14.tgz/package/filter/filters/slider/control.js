import { normalizeFromSlider as e, normalizeToSlider as t } from "./logic.js";
import { emitRangeChange as n, emitRangeCommit as r, hideTooltip as i, setToggleAccessible as a, updateTooltip as o } from "./runtime.js";
//#region src/filter/filters/slider/control.ts
var s = /* @__PURE__ */ new WeakMap();
function c(e, t) {
	let n = s.get(e);
	n && e.removeEventListener("change", n);
	let i = () => r(t);
	s.set(e, i), e.addEventListener("change", i);
}
function l(r, s) {
	let l = [], { minInt: u, maxInt: d, fromValueInt: f, toValueInt: p } = s.state;
	return s.showTooltips && l.push(r("div", {
		className: "slider-tooltip",
		ref: (e) => s.refs.fromTooltip = e
	})), l.push(r("input", {
		ref: (e) => {
			s.refs.fromSlider = e, e && (e.value = String(f), c(e, s), s.scheduleSyncVisuals());
		},
		className: `fromSlider${s.fromClassName ? ` ${s.fromClassName}` : ""}`,
		type: "range",
		value: String(f),
		min: u,
		max: d,
		step: s.nativeStep,
		disabled: s.disabled,
		"aria-label": s.fromAriaLabel,
		"aria-valuetext": s.formatFromValue(s.state.fromValueInt / s.scaleFactor),
		onInput: () => {
			s.refs.fromSlider && s.refs.toSlider && (s.refs.fromSlider.value = String(e(Number(s.refs.fromSlider.value), Number(s.refs.toSlider.value))), s.syncVisuals(), s.showTooltips && s.refs.fromTooltip && o(s.refs.fromSlider, s.refs.fromTooltip, s.state, s.formatFromValue, s.scaleFactor), n(s));
		},
		onMouseOver: () => s.showTooltips && s.refs.fromSlider && s.refs.fromTooltip && o(s.refs.fromSlider, s.refs.fromTooltip, s.state, s.formatFromValue, s.scaleFactor),
		onMouseOut: () => s.showTooltips && s.refs.fromTooltip && i(s.refs.fromTooltip)
	})), s.showTooltips && l.push(r("div", {
		className: "slider-tooltip",
		ref: (e) => s.refs.toTooltip = e
	})), l.push(r("input", {
		ref: (e) => {
			s.refs.toSlider = e, e && (e.value = String(p), c(e, s), s.scheduleSyncVisuals());
		},
		className: `toSlider${s.toClassName ? ` ${s.toClassName}` : ""}`,
		type: "range",
		value: String(p),
		min: u,
		max: d,
		step: s.nativeStep,
		disabled: s.disabled,
		"aria-label": s.toAriaLabel,
		"aria-valuetext": s.formatToValue(s.state.toValueInt / s.scaleFactor),
		onInput: () => {
			s.refs.fromSlider && s.refs.toSlider && (s.refs.toSlider.value = String(t(Number(s.refs.fromSlider.value), Number(s.refs.toSlider.value))), s.syncVisuals(), a(s), s.showTooltips && s.refs.toTooltip && o(s.refs.toSlider, s.refs.toTooltip, s.state, s.formatToValue, s.scaleFactor), n(s));
		},
		onMouseOver: () => s.showTooltips && s.refs.toSlider && s.refs.toTooltip && o(s.refs.toSlider, s.refs.toTooltip, s.state, s.formatToValue, s.scaleFactor),
		onMouseOut: () => s.showTooltips && s.refs.toTooltip && i(s.refs.toTooltip)
	})), r("div", { className: `sliders_control range-slider-control${s.controlClassName ? ` ${s.controlClassName}` : ""}` }, l);
}
//#endregion
export { l as renderSliderControl };
