import { RangeSliderRuntime } from './runtime';
import { RangeSliderElementFactory } from './component';
/**
 * Renders optional editable range inputs for the selected slider range.
 * Inputs intentionally use `type="text"` with `inputMode="decimal"` so custom
 * formatters control comma/dot decimals instead of browser-localized number UI.
 */
export declare function renderRangeInputs(h: RangeSliderElementFactory, runtime: RangeSliderRuntime): unknown;
