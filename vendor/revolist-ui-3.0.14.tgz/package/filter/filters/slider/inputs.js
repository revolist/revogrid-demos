import { renderControl as e } from "../../../control-presentation.js";
import { normalizeFromInputValue as t, normalizeToInputValue as n, unscaleSliderValue as r } from "./logic.js";
import { emitRangeChange as i, preventInvalidNumberKey as a } from "./runtime.js";
//#region src/filter/filters/slider/inputs.ts
function o(o, s) {
	let { fromValueInt: c, toValueInt: l } = s.state, u = {
		type: "text",
		inputMode: "decimal",
		disabled: s.disabled,
		onKeyDown: a
	};
	return o("div", { className: "range-inputs" }, [
		e(o, "input", {
			...u,
			ref: (e) => {
				s.refs.fromInput = e, e && (e.value = s.formatInputValue(r(c, s.scaleFactor)));
			},
			"aria-label": s.fromAriaLabel ?? "Minimum value",
			className: "range-input from-range-input",
			value: s.formatInputValue(r(c, s.scaleFactor)),
			onInput: (e) => {
				if (!s.refs.fromSlider || !s.refs.toSlider) return;
				let n = s.parseInputValue(e.target.value);
				Number.isFinite(n) && (s.refs.fromSlider.value = String(t(n, Number(s.refs.toSlider.value), s.state)), s.syncVisuals(), i(s));
			}
		}),
		o("span", { className: "range-input-separator" }, "-"),
		e(o, "input", {
			...u,
			ref: (e) => {
				s.refs.toInput = e, e && (e.value = s.formatInputValue(r(l, s.scaleFactor)));
			},
			"aria-label": s.toAriaLabel ?? "Maximum value",
			className: "range-input to-range-input",
			value: s.formatInputValue(r(l, s.scaleFactor)),
			onInput: (e) => {
				if (!s.refs.fromSlider || !s.refs.toSlider) return;
				let t = s.parseInputValue(e.target.value);
				Number.isFinite(t) && (s.refs.toSlider.value = String(n(t, Number(s.refs.fromSlider.value), s.state)), s.syncVisuals(), i(s));
			}
		})
	]);
}
//#endregion
export { o as renderRangeInputs };
