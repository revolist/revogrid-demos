import { RangeSliderProps, SliderRange } from './types';
/**
 * Range inputs can contain decimals while native range inputs work most
 * predictably with integers. Slider logic stores values as scaled integers and
 * converts back to numbers only when displaying values or emitting filter state.
 *
 * @example
 * ```ts
 * const state = normalizeSliderState({
 *   min: 0,
 *   max: 1000,
 *   fromValue: 250,
 *   toValue: 640.42,
 * });
 *
 * const range = toSliderRange(state.fromValueInt, state.toValueInt);
 * // { fromValue: 250, toValue: 640.42 }
 * ```
 */
export declare const SLIDER_SCALE_FACTOR = 100;
export type ScaledSliderState = {
    minInt: number;
    maxInt: number;
    fromValueInt: number;
    toValueInt: number;
};
export type SliderStateInput = {
    min: number;
    max: number;
    fromValue: number;
    toValue: number;
    scaleFactor?: number;
};
export declare function scaleSliderValue(value: number, scaleFactor?: number): number;
/** Compares ranges in the same scaled space used by the native handles. */
export declare function isFullSliderRange(range: SliderRange, bounds: Pick<RangeSliderProps, 'min' | 'max' | 'scaleFactor'>): boolean;
export declare function unscaleSliderValue(value: number, scaleFactor?: number): number;
export declare function normalizeSliderState({ min, max, fromValue, toValue, scaleFactor, }: SliderStateInput): ScaledSliderState;
export declare function clampScaledValue(value: number, minInt: number, maxInt: number): number;
export declare function normalizeFromSlider(fromValueInt: number, toValueInt: number): number;
export declare function normalizeToSlider(fromValueInt: number, toValueInt: number): number;
export declare function normalizeFromInputValue(value: number, currentToValueInt: number, state: Pick<ScaledSliderState, 'minInt' | 'maxInt'>, scaleFactor?: number): number;
export declare function normalizeToInputValue(value: number, currentFromValueInt: number, state: Pick<ScaledSliderState, 'minInt' | 'maxInt'>, scaleFactor?: number): number;
export declare function toSliderRange(fromValueInt: number, toValueInt: number, scaleFactor?: number): SliderRange;
export declare function toSliderDisplayValue(valueInt: number, scaleFactor?: number): string;
export declare function formatSliderInputValue(value: number): string;
/** Default formatter shared by slider labels, tooltips, and header ranges. */
export declare function formatSliderValue(value?: number): string;
/**
 * Default editable input parser.
 * Accepts both `640.42` and `640,42`; returns `NaN` for empty text so partial
 * edits do not reset the current slider selection while the user is typing.
 */
export declare function parseSliderInputValue(value: string): number;
