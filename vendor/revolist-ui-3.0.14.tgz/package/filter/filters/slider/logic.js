//#region src/filter/filters/slider/logic.ts
var e = 100;
function t(e, t = 100) {
	return Math.round(Number(e) * t);
}
function n(e, n) {
	let r = Number.isFinite(n.scaleFactor) && Number(n.scaleFactor) > 0 ? Number(n.scaleFactor) : 100;
	return t(e.fromValue, r) <= t(n.min, r) && t(e.toValue, r) >= t(n.max, r);
}
function r(e, t = 100) {
	return Number(e) / t;
}
function i({ min: e, max: n, fromValue: r, toValue: i, scaleFactor: o = 100 }) {
	let s = Math.min(t(e, o), t(n, o)), c = Math.max(t(e, o), t(n, o)), l = a(t(r, o), s, c), u = a(t(i, o), s, c);
	return {
		minInt: s,
		maxInt: c,
		fromValueInt: Math.min(l, u),
		toValueInt: Math.max(l, u)
	};
}
function a(e, t, n) {
	return Math.min(Math.max(e, t), n);
}
function o(e, t) {
	return Math.min(e, t);
}
function s(e, t) {
	return Math.max(t, e);
}
function c(e, n, r, i = 100) {
	return Math.min(a(t(e, i), r.minInt, r.maxInt), n);
}
function l(e, n, r, i = 100) {
	return Math.max(a(t(e, i), r.minInt, r.maxInt), n);
}
function u(e, t, n = 100) {
	return {
		fromValue: r(e, n),
		toValue: r(t, n)
	};
}
function d(e, t = 100) {
	return String(r(e, t));
}
function f(e) {
	return String(e);
}
function p(e) {
	return e === void 0 ? "" : e % 1 == 0 ? e.toString() : e.toFixed(2);
}
function m(e) {
	let t = e.trim().replace(",", ".");
	return t ? Number(t) : NaN;
}
//#endregion
export { e as SLIDER_SCALE_FACTOR, a as clampScaledValue, f as formatSliderInputValue, p as formatSliderValue, n as isFullSliderRange, c as normalizeFromInputValue, o as normalizeFromSlider, i as normalizeSliderState, l as normalizeToInputValue, s as normalizeToSlider, m as parseSliderInputValue, t as scaleSliderValue, d as toSliderDisplayValue, u as toSliderRange, r as unscaleSliderValue };
