import { RangeSliderProps } from './types';
/** Preact adapter for the shared slider renderer. */
export declare function PreactRangeSlider(props: RangeSliderProps): preact.VNode;
