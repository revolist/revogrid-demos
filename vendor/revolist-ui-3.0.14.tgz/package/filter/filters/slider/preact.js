import { renderRangeSlider as e } from "./component.js";
import { h as t } from "preact";
//#region src/filter/filters/slider/preact.tsx
function n(n) {
	return e(t, n);
}
//#endregion
export { n as PreactRangeSlider };
