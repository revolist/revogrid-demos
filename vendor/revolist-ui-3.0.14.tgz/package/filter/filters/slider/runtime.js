import { toSliderRange as e, unscaleSliderValue as t } from "./logic.js";
//#region src/filter/filters/slider/runtime.ts
function n(t) {
	return e(Number(t.refs.fromSlider?.value ?? t.state.fromValueInt), Number(t.refs.toSlider?.value ?? t.state.toValueInt), t.scaleFactor);
}
function r(e) {
	let { fromValue: t, toValue: r } = n(e), i = e.formatFromValue(t), a = e.formatToValue(r);
	e.refs.fromLabel && (e.refs.fromLabel.textContent = i), e.refs.toLabel && (e.refs.toLabel.textContent = a), e.refs.fromInput && (e.refs.fromInput.value = e.formatInputValue(t)), e.refs.toInput && (e.refs.toInput.value = e.formatInputValue(r)), e.refs.fromSlider?.setAttribute("aria-valuetext", i), e.refs.toSlider?.setAttribute("aria-valuetext", a);
}
function i(e, n, r, i, o = 100) {
	n.textContent = i(t(Number(e.value), o));
	let s = r.maxInt - r.minInt || 1, c = (Number(e.value) - r.minInt) / s * 100, l = n.parentElement?.getBoundingClientRect(), u = n.getBoundingClientRect();
	l && u ? n.style.left = `${a(c, l.width, u.width)}px` : n.style.left = `${c}%`, n.style.opacity = "1";
}
function a(e, t, n, r = 8) {
	let i = n / 2, a = r + i, o = t - r - i;
	if (a > o) return t / 2;
	let s = Math.min(Math.max(e, 0), 100) / 100 * t;
	return Math.min(Math.max(s, a), o);
}
function o(e) {
	e.style.opacity = "0";
}
function s(e, t, n) {
	let r = getComputedStyle(n), i = r.getPropertyValue("--slider-color").trim() || r.getPropertyValue("--rv-ui-border").trim() || "var(--rv-ui-border)", a = r.getPropertyValue("--range-color").trim() || r.getPropertyValue("--rv-ui-accent").trim() || "var(--rv-ui-accent)", o = parseInt(t.max, 10) - parseInt(t.min, 10) || 1, s = parseInt(e.value, 10) - parseInt(e.min, 10), c = parseInt(t.value, 10) - parseInt(t.min, 10), l = s / o * 100, u = c / o * 100;
	n.style.background = `linear-gradient(
        to right,
        ${i} 0%,
        ${i} ${l}%,
        ${a} ${l}%,
        ${a} ${u}%,
        ${i} ${u}%,
        ${i} 100%) center / 100% 4px no-repeat`;
}
function c(e) {
	let { fromSlider: t, toSlider: n } = e.refs;
	t && n && (s(t, n, n), r(e));
}
function l(e) {
	e.refs.toSlider && (e.refs.toSlider.style.zIndex = Number(e.refs.toSlider.value) <= e.state.minInt ? "2" : "0");
}
function u(e) {
	e.onRangeChange(n(e));
}
function d(e) {
	e.onRangeCommit?.(n(e));
}
function f(e) {
	e.metaKey || e.ctrlKey || [
		"ArrowDown",
		"ArrowLeft",
		"ArrowRight",
		"ArrowUp",
		"Backspace",
		"Delete",
		"End",
		"Enter",
		"Home",
		"Tab"
	].includes(e.key) || /^[\d.,-]$/.test(e.key) || e.preventDefault();
}
//#endregion
export { u as emitRangeChange, d as emitRangeCommit, s as fillSlider, n as getCurrentRange, a as getTooltipCenterPosition, o as hideTooltip, f as preventInvalidNumberKey, l as setToggleAccessible, r as syncRangeText, c as syncVisuals, i as updateTooltip };
