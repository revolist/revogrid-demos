import { h } from 'preact';
export type SingleValueSliderProps = {
    min: number;
    max: number;
    value: number;
    step?: number | string;
    disabled?: boolean;
    id?: string;
    className?: string;
    ariaLabel: string;
    ariaValueText?: string;
    ariaDescribedBy?: string;
    onChange: (value: number, event: Event & {
        currentTarget: HTMLInputElement;
    }) => void;
    onCommit?: (value: number, event: Event & {
        currentTarget: HTMLInputElement;
    }) => void;
    onKeyDown?: (event: KeyboardEvent) => void;
};
/** Shared native single-thumb slider for scalar thresholds and tolerances. */
export declare function SingleValueSlider({ min, max, value, step, disabled, id, className, ariaLabel, ariaValueText, ariaDescribedBy, onChange, onCommit, onKeyDown, }: SingleValueSliderProps): any;
export interface SliderFieldProps extends SingleValueSliderProps {
    label: string;
    layout?: 'inline' | 'stacked';
    valuePlacement?: 'end' | 'thumb' | 'none';
    formatValue?: (value: number) => string;
    /** Number of evenly spaced decorative tick marks, bounded to 2–101. */
    ticks?: number;
    accentColor?: string;
}
/** Label/value composition over the same native single-thumb input. */
export declare function SliderField({ label, layout, valuePlacement, formatValue, ticks, accentColor, ...slider }: SliderFieldProps): h.JSX.Element;
