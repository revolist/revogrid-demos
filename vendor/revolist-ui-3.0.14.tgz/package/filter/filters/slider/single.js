import { Input as e } from "../../../native-control.js";
import { jsx as t, jsxs as n } from "preact/jsx-runtime";
//#region src/filter/filters/slider/single.tsx
function r({ min: n, max: r, value: i, step: a = 1, disabled: o = !1, id: s, className: c = "", ariaLabel: l, ariaValueText: u, ariaDescribedBy: d, onChange: f, onCommit: p, onKeyDown: m }) {
	let h = r - n, g = h > 0 ? Math.max(0, Math.min(100, (i - n) / h * 100)) : 0;
	return /* @__PURE__ */ t(e, {
		class: `rv-single-slider ${c}`.trim(),
		id: s,
		type: "range",
		min: n,
		max: r,
		step: a,
		value: i,
		disabled: o,
		style: { "--rv-single-slider-value": `${g}%` },
		"aria-label": l,
		"aria-valuetext": u,
		"aria-describedby": d,
		onKeyDown: m,
		onInput: (e) => f(Number(e.currentTarget.value), e),
		onChange: (e) => p?.(Number(e.currentTarget.value), e)
	});
}
function i({ label: e, layout: i = "inline", valuePlacement: a = "end", formatValue: o = String, ticks: s, accentColor: c, ...l }) {
	let u = o(l.value), d = l.max > l.min ? Math.max(0, Math.min(100, (l.value - l.min) / (l.max - l.min) * 100)) : 0, f = s && Number.isFinite(s) ? Math.max(2, Math.min(101, Math.floor(s))) : 0;
	return /* @__PURE__ */ n("label", {
		class: `rv-slider-field rv-slider-field--${i} rv-slider-field--${a}${l.disabled ? " is-disabled" : ""}`,
		style: c ? { "--rv-slider-field-accent": c } : void 0,
		children: [
			/* @__PURE__ */ t("span", {
				class: "rv-slider-field__label",
				children: e
			}),
			/* @__PURE__ */ n("span", {
				class: "rv-slider-field__track",
				style: { "--rv-slider-field-position": `${d / 100}` },
				children: [
					/* @__PURE__ */ t(r, {
						...l,
						ariaValueText: l.ariaValueText ?? u
					}),
					f > 0 && /* @__PURE__ */ t("span", {
						class: "rv-slider-field__ticks",
						"aria-hidden": "true",
						children: Array.from({ length: f }, (e, n) => /* @__PURE__ */ t("i", {}, n))
					}),
					a === "thumb" && /* @__PURE__ */ t("span", {
						class: "rv-slider-field__thumb-value",
						"aria-hidden": "true",
						children: u
					})
				]
			}),
			a === "end" && /* @__PURE__ */ t("span", {
				class: "rv-slider-field__value rv-badge rv-badge--inline",
				"aria-hidden": "true",
				children: u
			})
		]
	});
}
//#endregion
export { r as SingleValueSlider, i as SliderField };
