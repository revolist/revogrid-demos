import { createPreactElement as e } from "../preact-mount.js";
import { Input as t, Select as n } from "../native-control.js";
import { jsx as r, jsxs as i } from "preact/jsx-runtime";
//#region src/form-controls/index.view.tsx
function a(t, n) {
	return e(t, /* @__PURE__ */ i("label", {
		class: ["rv-field", n.className].filter(Boolean).join(" "),
		children: [
			/* @__PURE__ */ r("span", {
				class: "rv-field__label",
				children: n.label
			}),
			/* @__PURE__ */ r("span", {
				style: { display: "contents" },
				ref: (e) => {
					e && e.append(n.control);
				}
			}),
			n.hint && /* @__PURE__ */ r("span", {
				class: "rv-field__hint",
				children: n.hint
			})
		]
	}));
}
function o(n, i) {
	return e(n, /* @__PURE__ */ r(t, {
		type: "text",
		placeholder: i
	}));
}
function s(t, i) {
	return e(t, /* @__PURE__ */ r(n, { children: i.map((e) => /* @__PURE__ */ r("option", {
		value: e.value,
		children: e.label
	}, e.value)) }));
}
//#endregion
export { a as createFormField, s as createSelectControl, o as createTextControl };
