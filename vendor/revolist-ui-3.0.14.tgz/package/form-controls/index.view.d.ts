export interface FormFieldOptions {
    readonly label: string;
    readonly control: HTMLElement;
    readonly hint?: string;
    readonly className?: string;
}
export declare function createFormField(document: Document, options: FormFieldOptions): HTMLLabelElement;
export declare function createTextControl(document: Document, placeholder: string): HTMLInputElement;
export declare function createSelectControl(document: Document, options: readonly {
    value: string;
    label: string;
}[]): HTMLSelectElement;
