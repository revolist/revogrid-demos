import { h, ComponentChildren, JSX } from 'preact';
export type FilterChipProps = {
    readonly children: ComponentChildren;
    readonly removeLabel?: string;
    readonly onRemove?: () => void;
    readonly className?: string;
    readonly removeClassName?: string;
    readonly role?: 'listitem';
};
/** Removable chip shell; consumers retain filter policy and label/detail slots. */
export declare function FilterChip({ children, removeLabel, onRemove, className, removeClassName, role }: FilterChipProps): h.JSX.Element;
export interface FormFieldContentOptions {
    readonly label: ComponentChildren;
    readonly children: ComponentChildren;
    readonly hint?: ComponentChildren;
    /** Supply an instance-unique ID when rendering a hint through the native helper. */
    readonly hintId?: string;
    readonly labelId?: string;
}
/** Native VNodes keep controls visible to consumer-owned policy/render adapters. */
export declare function renderFormFieldContent({ label, children, hint, hintId, labelId, }: FormFieldContentOptions): ComponentChildren;
export type FormFieldProps = FormFieldContentOptions & Omit<JSX.IntrinsicElements['label'], 'children' | 'className'> & {
    readonly className?: string;
    /** Associates a separately identified control; implicit labels need no ID. */
    readonly controlId?: string;
};
/** Preact adapter over the existing framework-neutral form presentation. */
export declare function FormField({ label, children, hint, hintId, labelId, controlId, className, class: nativeClass, ...attributes }: FormFieldProps): h.JSX.Element;
export type DisclosureSummaryProps = Omit<JSX.IntrinsicElements['summary'], 'children' | 'className'> & {
    readonly children: ComponentChildren;
    readonly className?: string;
    readonly icon?: ComponentChildren;
    readonly iconClassName?: string;
    readonly iconPosition?: 'before' | 'after';
};
/** Presentation only: native details remains the open-state and keyboard owner. */
export declare function DisclosureSummary({ children, icon, iconClassName, iconPosition, className, class: nativeClass, ...attributes }: DisclosureSummaryProps): h.JSX.Element;
