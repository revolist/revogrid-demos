import { createControlId as e } from "../core/control-id.js";
import { nativeControlTag as t } from "../control-presentation.js";
import { Fragment as n, cloneElement as r, isValidElement as i } from "preact";
import { jsx as a, jsxs as o } from "preact/jsx-runtime";
import { useState as s } from "preact/hooks";
//#region src/form-controls/presentation.tsx
function c({ children: e, removeLabel: t, onRemove: n, className: r = "", removeClassName: i = "", role: s }) {
	return /* @__PURE__ */ o("span", {
		class: `rv-btn-pill ${r}`.trim(),
		role: s,
		children: [e, n && /* @__PURE__ */ a("button", {
			type: "button",
			class: `rv-chip-remove ${i}`.trim(),
			"aria-label": t,
			onClick: n,
			children: "×"
		})]
	});
}
function l({ label: e, children: t, hint: n, hintId: r, labelId: i = r ? `${r}-label` : void 0 }) {
	let o = n != null && n !== !1;
	return [
		/* @__PURE__ */ a("span", {
			class: "rv-field__label",
			id: i,
			children: e
		}),
		o && r ? d(t, r, i) : t,
		o ? /* @__PURE__ */ a("span", {
			class: "rv-field__hint",
			id: r,
			children: n
		}) : null
	];
}
function u({ label: t, children: n, hint: r, hintId: i, labelId: o, controlId: c, className: u = "", class: d, ...f }) {
	let [p] = s(() => e("rv-field"));
	return /* @__PURE__ */ a("label", {
		...f,
		htmlFor: c ?? f.htmlFor,
		class: [
			"rv-field",
			u,
			d
		].filter(Boolean).join(" "),
		children: l({
			label: t,
			children: n,
			hint: r,
			labelId: o,
			hintId: i ?? `rv-field-hint-${p}`
		})
	});
}
function d(e, a, o) {
	if (Array.isArray(e)) return e.map((e) => d(e, a, o));
	if (!i(e)) return e;
	if (e.type === n) return r(e, { children: d(e.props.children, a, o) });
	let s = t(e.type);
	if (!s) return e;
	let c = e;
	if ([
		"input",
		"select",
		"textarea"
	].includes(s)) {
		let e = new Set(`${c.props["aria-describedby"] ?? ""} ${a}`.trim().split(/\s+/));
		return r(c, {
			"aria-describedby": [...e].join(" "),
			"aria-labelledby": c.props["aria-labelledby"] ?? (c.props["aria-label"] ? void 0 : o)
		});
	}
	return r(c, { children: d(c.props.children, a, o) });
}
function f({ children: e, icon: t, iconClassName: n = "", iconPosition: r = "before", className: i = "", class: s, ...c }) {
	let l = t == null ? null : /* @__PURE__ */ a("span", {
		class: ["rv-disclosure-summary__icon", n].filter(Boolean).join(" "),
		"aria-hidden": "true",
		children: t
	});
	return /* @__PURE__ */ o("summary", {
		...c,
		class: [
			"rv-disclosure-summary",
			i,
			s
		].filter(Boolean).join(" "),
		children: [
			r === "before" && l,
			/* @__PURE__ */ a("span", {
				class: "rv-disclosure-summary__label",
				children: e
			}),
			r === "after" && l
		]
	});
}
//#endregion
export { f as DisclosureSummary, c as FilterChip, u as FormField, l as renderFormFieldContent };
