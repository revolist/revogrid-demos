import { h, ComponentChildren, JSX } from 'preact';
/** Pure comparison presentation; the caller formats values and styles. */
export declare function ComparisonPreview({ originalValue, formatted, formattedStyle, visual, formattedClassName, labels, }: {
    readonly originalValue: string;
    readonly formatted: ComponentChildren;
    readonly formattedStyle?: JSX.CSSProperties;
    readonly visual?: boolean;
    readonly formattedClassName?: string;
    readonly labels: {
        readonly title: string;
        readonly original: string;
        readonly formatted: string;
        readonly hint: string;
    };
}): h.JSX.Element;
