import { h, TargetedEvent } from 'preact';
export declare function useControlTooltip(text: string, floating?: boolean, presentation?: {
    className?: string;
    placement?: 'above';
}): {
    readonly id: string;
    readonly triggerProps: {
        readonly 'aria-describedby': string;
        readonly onFocus: (event: TargetedEvent<HTMLElement>) => void;
        readonly onBlur: () => void;
        readonly onMouseEnter: (event: TargetedEvent<HTMLElement>) => void;
        readonly onMouseLeave: () => void;
        readonly onPointerDown: (event: TargetedEvent<HTMLElement>) => void;
        readonly onPointerCancel: () => void;
        readonly onKeyDown: (event: KeyboardEvent) => void;
    };
    readonly tooltip: h.JSX.Element;
};
export declare function ControlTooltip({ id, text, visible, anchor, className, placement, }: {
    readonly id: string;
    readonly text: string;
    readonly visible: boolean;
    readonly anchor?: HTMLElement | null;
    readonly className?: string;
    readonly placement?: 'above';
}): h.JSX.Element;
