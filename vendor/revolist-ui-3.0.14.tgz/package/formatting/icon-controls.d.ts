import { h } from 'preact';
export interface SegmentedOption<Value extends string> {
    readonly value: Value;
    readonly label: string;
    readonly icon: string;
}
export declare function IconChoiceGroup<Value extends string>({ value, options, ariaLabel, onChange, }: {
    readonly value: Value;
    readonly options: readonly SegmentedOption<Value>[];
    readonly ariaLabel: string;
    readonly onChange: (value: Value) => void;
}): h.JSX.Element;
export declare function IconToggleButton({ value, label, icon, onChange, }: {
    readonly value: boolean;
    readonly label: string;
    readonly icon: string;
    readonly onChange: (value: boolean) => void;
}): h.JSX.Element;
