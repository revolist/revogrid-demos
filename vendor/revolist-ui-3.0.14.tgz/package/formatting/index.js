import { ButtonControl as e, Input as t, Select as n, Summary as r } from "../native-control.js";
import { n as i, t as a } from "../_chunks/control-tooltip-DYksNy2m.js";
import { t as o } from "../_chunks/chevron-down-GbplLa6s.js";
import { SvgIcon as s } from "../icons/icon.js";
import { Fragment as c, jsx as l, jsxs as u } from "preact/jsx-runtime";
import { useState as d } from "preact/hooks";
//#region src/formatting/inspector-section.tsx
function f({ title: e, icon: t, expandLabel: n, collapseLabel: a, open: c = !1, children: f }) {
	let [p, m] = d(c), h = p ? a : n, g = i(h);
	return /* @__PURE__ */ u("details", {
		class: "rv-format-inspector-section",
		open: p,
		onToggle: (e) => m(e.currentTarget.open),
		children: [/* @__PURE__ */ u(r, {
			class: "rv-format-inspector-section__summary",
			"aria-label": h,
			"aria-expanded": p,
			...g.triggerProps,
			children: [
				/* @__PURE__ */ u("span", {
					class: "rv-format-inspector-section__title",
					children: [/* @__PURE__ */ l(s, {
						svg: t,
						className: "rv-format-icon"
					}), e]
				}),
				/* @__PURE__ */ l(s, {
					svg: o,
					className: "rv-format-icon rv-format-inspector-section__chevron"
				}),
				g.tooltip
			]
		}), /* @__PURE__ */ l("div", {
			class: "rv-format-inspector-section__content",
			children: f
		})]
	});
}
//#endregion
//#region src/formatting/icon-controls.tsx
var p = ({ icon: e }) => /* @__PURE__ */ l(s, {
	svg: e,
	className: "rv-format-icon"
});
function m({ value: e, options: t, ariaLabel: n, onChange: r }) {
	return /* @__PURE__ */ l("div", {
		class: "rv-format-segmented",
		role: "group",
		"aria-label": n,
		children: t.map((t) => /* @__PURE__ */ l(g, {
			selected: t.value === e,
			label: t.label,
			icon: t.icon,
			onClick: () => r(t.value)
		}, t.value))
	});
}
function h({ value: e, label: t, icon: n, onChange: r }) {
	return /* @__PURE__ */ l(g, {
		selected: e,
		label: t,
		icon: n,
		onClick: () => r(!e)
	});
}
function g({ selected: t, label: n, icon: r, onClick: a }) {
	let o = i(n);
	return /* @__PURE__ */ u(e, {
		type: "button",
		class: `rv-format-segmented__button${t ? " rv-format-segmented__button--selected" : ""}`,
		"aria-label": n,
		"aria-pressed": t,
		onClick: a,
		...o.triggerProps,
		children: [/* @__PURE__ */ l(p, { icon: r }), o.tooltip]
	});
}
//#endregion
//#region src/formatting/typography-controls.tsx
var _ = [
	"Inter",
	"Arial",
	"Helvetica",
	"Georgia",
	"Times New Roman",
	"Courier New"
];
function v({ value: e, fonts: r = _, labels: i, icons: a, onChange: o }) {
	return /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ u("div", {
		class: "rv-form-grid",
		children: [/* @__PURE__ */ u("label", {
			class: "rv-field",
			children: [/* @__PURE__ */ l("span", {
				class: "rv-field__label",
				children: i.fontFamily
			}), /* @__PURE__ */ u(n, {
				class: "rv-control",
				value: e.fontFamily ?? "",
				onChange: (e) => o({ fontFamily: e.currentTarget.value || void 0 }),
				children: [/* @__PURE__ */ l("option", {
					value: "",
					children: i.defaultFont
				}), r.map((e) => /* @__PURE__ */ l("option", {
					value: e,
					children: e
				}, e))]
			})]
		}), /* @__PURE__ */ u("label", {
			class: "rv-field",
			children: [/* @__PURE__ */ l("span", {
				class: "rv-field__label",
				children: i.fontSize
			}), /* @__PURE__ */ l(t, {
				type: "number",
				class: "rv-control",
				min: 8,
				max: 72,
				value: e.fontSize ?? "",
				onInput: (e) => o({ fontSize: Number.isFinite(e.currentTarget.valueAsNumber) ? e.currentTarget.valueAsNumber : void 0 })
			})]
		})]
	}), /* @__PURE__ */ u("div", {
		class: "rv-format-segmented rv-format-typography-toolbar",
		role: "group",
		"aria-label": i.typographySection,
		children: [
			/* @__PURE__ */ l(h, {
				value: e.bold ?? !1,
				label: i.bold,
				icon: a.bold,
				onChange: (e) => o({ bold: e })
			}),
			/* @__PURE__ */ l(h, {
				value: e.italic ?? !1,
				label: i.italic,
				icon: a.italic,
				onChange: (e) => o({ italic: e })
			}),
			/* @__PURE__ */ l(h, {
				value: e.underline ?? !1,
				label: i.underline,
				icon: a.underline,
				onChange: (e) => o({ underline: e })
			}),
			/* @__PURE__ */ l(h, {
				value: e.strike ?? !1,
				label: i.strike,
				icon: a.strike,
				onChange: (e) => o({ strike: e })
			})
		]
	})] });
}
//#endregion
//#region src/formatting/comparison-preview.tsx
function y({ originalValue: e, formatted: t, formattedStyle: n, visual: r = !1, formattedClassName: i = "", labels: a }) {
	return /* @__PURE__ */ u("section", {
		class: `rv-format-preview${r ? " rv-format-preview--visual" : ""}`,
		children: [
			/* @__PURE__ */ l("h3", {
				class: "rv-format-pane-title",
				children: a.title
			}),
			/* @__PURE__ */ u("div", {
				class: "rv-format-preview__grid",
				role: "table",
				"aria-label": a.title,
				children: [/* @__PURE__ */ u("div", {
					class: "rv-format-preview__row",
					role: "row",
					children: [
						/* @__PURE__ */ l("span", {
							class: "rv-format-preview__corner",
							role: "cell"
						}),
						/* @__PURE__ */ l("span", {
							class: "rv-format-preview__columnheader",
							role: "columnheader",
							children: a.original
						}),
						/* @__PURE__ */ l("span", {
							class: "rv-format-preview__columnheader",
							role: "columnheader",
							children: a.formatted
						})
					]
				}), /* @__PURE__ */ u("div", {
					class: "rv-format-preview__row",
					role: "row",
					children: [
						/* @__PURE__ */ l("span", {
							class: "rv-format-preview__rowheader",
							role: "rowheader",
							children: "1"
						}),
						/* @__PURE__ */ l("span", {
							class: "rv-format-preview__gridcell",
							role: "cell",
							title: e,
							children: /* @__PURE__ */ l("span", {
								class: "rv-format-preview__original-value",
								children: e
							})
						}),
						/* @__PURE__ */ l("span", {
							class: `rv-format-preview__gridcell rv-format-preview__formatted ${i}`,
							role: "cell",
							style: n,
							children: /* @__PURE__ */ l("span", {
								role: "status",
								"aria-live": "polite",
								children: t
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ l("p", {
				class: "rv-format-preview__hint",
				children: a.hint
			})
		]
	});
}
//#endregion
export { y as ComparisonPreview, a as ControlTooltip, m as IconChoiceGroup, h as IconToggleButton, f as InspectorSection, v as TypographyControls, i as useControlTooltip };
