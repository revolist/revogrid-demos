import { h, ComponentChildren } from 'preact';
export declare function InspectorSection({ title, icon, expandLabel, collapseLabel, open, children, }: {
    readonly title: string;
    readonly icon: string;
    readonly expandLabel: string;
    readonly collapseLabel: string;
    readonly open?: boolean;
    readonly children: ComponentChildren;
}): h.JSX.Element;
