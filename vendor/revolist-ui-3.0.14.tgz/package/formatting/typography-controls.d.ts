import { h } from 'preact';
export interface TypographyValue {
    readonly fontFamily?: string;
    readonly fontSize?: number;
    readonly bold?: boolean;
    readonly italic?: boolean;
    readonly underline?: boolean;
    readonly strike?: boolean;
}
export interface TypographyControlsProps {
    readonly value: TypographyValue;
    readonly fonts?: readonly string[];
    readonly labels: {
        readonly fontFamily: string;
        readonly defaultFont: string;
        readonly fontSize: string;
        readonly typographySection: string;
        readonly bold: string;
        readonly italic: string;
        readonly underline: string;
        readonly strike: string;
    };
    readonly icons: Record<'bold' | 'italic' | 'underline' | 'strike', string>;
    readonly onChange: (patch: Partial<TypographyValue>) => void;
}
export declare function TypographyControls({ value: appearance, fonts, labels: locale, icons, onChange, }: TypographyControlsProps): h.JSX.Element;
