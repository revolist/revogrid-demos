/** Apply shared control presentation to existing HTML without replacing nodes,
 * values, event listeners, or framework ownership. Call again after replacing
 * HTML or changing an input type. No observer or lifecycle cleanup is needed. */
export declare function applyControlPresentation(root: ParentNode): void;
