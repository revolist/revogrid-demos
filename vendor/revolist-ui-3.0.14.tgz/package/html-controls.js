import { controlAttributes as e } from "./control-presentation.js";
//#region src/html-controls.ts
var t = "button,input,select,textarea,summary", n = [
	"rv-btn",
	"rv-control",
	"rv-checkbox",
	"rv-radio",
	"rv-native-slider",
	"rv-disclosure-summary"
];
function r(r) {
	let i = Array.from(r.querySelectorAll(t));
	"matches" in r && typeof r.matches == "function" && r.matches(t) && i.unshift(r);
	for (let t of i) {
		let r = t.localName, i = e(r, {
			class: [...t.classList].filter((e) => !n.includes(e)).join(" "),
			...r === "input" ? { type: t.type } : {},
			...r === "button" && t.hasAttribute("type") ? { type: t.getAttribute("type") } : {}
		});
		t.className = i.class, r === "button" && !t.hasAttribute("type") && t.setAttribute("type", i.type);
	}
}
//#endregion
export { r as applyControlPresentation };
