import { h } from 'preact';
/** Presentation for trusted, bundled SVG assets shared by plugin controls. */
export declare function SvgIcon({ svg, className, size }: {
    svg: string;
    className?: string;
    size?: number;
}): h.JSX.Element;
