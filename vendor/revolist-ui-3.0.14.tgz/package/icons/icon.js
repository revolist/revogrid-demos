import { jsx as e } from "preact/jsx-runtime";
//#region src/icons/icon.tsx
function t({ svg: t, className: n = "rv-svg-icon", size: r }) {
	return /* @__PURE__ */ e("span", {
		class: n,
		style: r === void 0 ? void 0 : { "--rv-icon-size": `${r}px` },
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: t }
	});
}
//#endregion
export { t as SvgIcon };
