import { h } from 'preact';
export interface LegendItem {
    id: string;
    label: string;
    tone?: 'selected' | 'outside' | 'muted';
    className?: string;
    /** Any CSS color, including the host's semantic theme variables. */
    color?: string;
    marker?: 'solid' | 'outline' | 'dashed';
}
/** Inline, wrapping key for calendars, filters and other compact visual controls. */
export declare function Legend({ label, items, className, itemClassName }: {
    label: string;
    items: readonly LegendItem[];
    className?: string;
    itemClassName?: string;
}): h.JSX.Element;
