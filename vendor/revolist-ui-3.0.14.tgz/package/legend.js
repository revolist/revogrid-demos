import { jsx as e, jsxs as t } from "preact/jsx-runtime";
//#region src/legend.tsx
function n({ label: n, items: r, className: i = "", itemClassName: a = "" }) {
	return /* @__PURE__ */ e("div", {
		class: `rv-legend ${i}`,
		role: "list",
		"aria-label": n,
		children: r.map((n) => /* @__PURE__ */ t("span", {
			role: "listitem",
			class: `rv-legend__item ${a} ${n.className ?? ""}`,
			"data-tone": n.tone ?? "muted",
			style: n.color ? { "--rv-legend-marker-color": n.color } : void 0,
			children: [/* @__PURE__ */ e("i", {
				"aria-hidden": "true",
				"data-marker": n.marker ?? "solid"
			}), /* @__PURE__ */ e("span", {
				class: "rv-legend__label",
				children: n.label
			})]
		}, n.id))
	});
}
//#endregion
export { n as Legend };
