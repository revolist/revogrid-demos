import { MaskedInputOptions, MaskedParseResult } from './model';
export interface MaskedEditResult {
    value: string;
    caret: number;
    accepted: boolean;
}
/** Keep the entire pattern visible, including empty slots and fixed separators. */
export declare function formatMaskedDraft(value: string, options: MaskedInputOptions): string;
export declare function maskedDraftCaret(value: string, options: MaskedInputOptions): number;
/** Placeholders are draft state only; they never enter the saved identifier. */
export declare function parseMaskedDraft(value: string, options: MaskedInputOptions): MaskedParseResult;
/** Edit fixed slots without moving later characters into different positions. */
export declare function editMaskedInput(value: string, start: number, end: number, inputType: string, data: string | null, options: MaskedInputOptions): MaskedEditResult;
/** Native input bridge shared by grid adapters and standalone fields. */
export declare function applyMaskedEdit(input: HTMLInputElement, inputType: string, data: string | null, options: MaskedInputOptions): boolean;
/** Autofill/composition fallback: format compatible input without discarding characters. */
export declare function normalizeMaskedInput(input: HTMLInputElement, options: MaskedInputOptions): void;
/** Handle supported native edits while leaving composition and platform operations intact. */
export declare function handleMaskedBeforeInput(input: HTMLInputElement, event: InputEvent, options: MaskedInputOptions): boolean;
export declare function handleMaskedPaste(input: HTMLInputElement, event: ClipboardEvent, options: MaskedInputOptions): boolean;
/** Preserve draft undo/redo when generated separators require programmatic text edits. */
export declare function handleMaskedHistory(input: HTMLInputElement, event: KeyboardEvent): boolean;
