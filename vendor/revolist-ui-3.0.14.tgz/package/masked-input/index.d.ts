import { MaskedInputOptions } from './model';
export * from './model';
export * from './edit';
/** Fixed-slot identifier field with immutable separators and staged string saves. */
export declare function MaskedDraft({ value, options, apply, cancel, }: {
    value: unknown;
    options: MaskedInputOptions;
    apply: (value: string | null) => void;
    cancel: () => void;
}): import("preact").JSX.Element;
