import { Input as e } from "../native-control.js";
import { EditorActions as t } from "../editor-actions.js";
import { jsx as n, jsxs as r } from "preact/jsx-runtime";
import { useId as i, useRef as a, useState as o } from "preact/hooks";
//#region src/masked-input/model.ts
function s(e) {
	if (typeof e != "string") return;
	let t = [], n = Array.from(e);
	for (let e = 0; e < n.length; e++) {
		let r = n[e];
		if (r === "\\") {
			if (++e === n.length) return;
			t.push({ literal: n[e] });
		} else r === "0" || r === "A" || r === "*" ? t.push({ token: r }) : t.push({ literal: r });
	}
	return t.some((e) => "token" in e) ? t : void 0;
}
function c(e, t) {
	return e === "0" ? /^[0-9]$/.test(t) : e === "A" ? /^[A-Za-z]$/.test(t) : /^[A-Za-z0-9]$/.test(t);
}
function l(e, t) {
	let n = "";
	for (let r = 0; r < e.length; r++) {
		let i = t[r];
		if (!i || ("literal" in i ? e[r] !== i.literal : !c(i.token, e[r]))) return {
			complete: !1,
			prefix: !1,
			raw: n
		};
		"token" in i && (n += e[r]);
	}
	return {
		complete: e.length === t.length,
		prefix: !0,
		raw: n
	};
}
function u(e, t) {
	let n = (e) => ({
		valid: !1,
		value: null,
		raw: null,
		formatted: null,
		error: e
	}), r = s(t.mask);
	if (!r || t.store !== void 0 && t.store !== "raw" && t.store !== "formatted") return n("configuration");
	if (e == null || e === "") return t.required ? n("required") : {
		valid: !0,
		value: null,
		raw: null,
		formatted: null
	};
	if (typeof e != "string") return n("invalid");
	let i = Array.from(e), a = l(i, r.filter((e) => "token" in e)), o = l(i, r), c = a.complete ? a : o.complete ? o : void 0;
	if (!c) return n(a.prefix || o.prefix ? "incomplete" : "invalid");
	let u = c.raw, d = Array.from(u), f = 0, p = r.map((e) => "literal" in e ? e.literal : d[f++]).join("");
	return {
		valid: !0,
		raw: u,
		formatted: p,
		value: t.store === "formatted" ? p : u
	};
}
function d(e, t) {
	let n = u(e, t);
	return n.valid ? n.formatted ?? "" : e == null ? "" : String(e);
}
//#endregion
//#region src/masked-input/edit.ts
var f = "_";
function p(e, t) {
	let n = t.filter((e) => "token" in e), r = Array.from(e), i = n.map(() => "");
	if (!r.length) return i;
	if (r.length === t.length) {
		let e = 0;
		if (t.every((t, n) => {
			let a = r[n];
			return "literal" in t ? a === t.literal : a !== f && !c(t.token, a) ? !1 : (i[e++] = a === f ? "" : a, !0);
		})) return i;
	}
	if (r.length <= n.length && r.every((e, t) => "token" in n[t] && c(n[t].token, e))) return i.map((e, t) => r[t] ?? "");
	let a = 0;
	for (let e = 0; e < r.length; e++) {
		let n = t[e], o = r[e];
		if (!n) return;
		if ("literal" in n) {
			if (o !== n.literal) return;
		} else {
			if (o !== f && !c(n.token, o)) return;
			i[a++] = o === f ? "" : o;
		}
	}
	return i;
}
function m(e, t) {
	let n = "", r = 0, i = [], a = [];
	for (let o of t) "literal" in o ? n += o.literal : (i.push(n.length), n += e[r++] || f, a.push(n.length));
	return {
		value: n,
		starts: i,
		ends: a
	};
}
function h(e, t) {
	let n = s(t.mask);
	if (!n) return e;
	let r = p(e, n);
	return r ? m(r, n).value : e;
}
function g(e, t) {
	let n = s(t.mask), r = n && p(e, n);
	if (!n || !r) return e.length;
	let i = m(r, n), a = r.indexOf("");
	return i.starts[a] ?? i.value.length;
}
function _(e, t) {
	let n = u("", t);
	if (n.error === "configuration") return n;
	let r = s(t.mask), i = p(e, r);
	return i ? i.every((e) => !e) ? n : i.some((e) => !e) ? {
		valid: !1,
		value: null,
		raw: null,
		formatted: null,
		error: "incomplete"
	} : u(m(i, r).value, t) : u(e, t);
}
function v(e, t, n, r, i, a) {
	let o = {
		value: e,
		caret: t,
		accepted: !1
	}, l = s(a.mask);
	if (!l) return o;
	let u = p(e, l);
	if (!u) {
		if (t !== 0 || n !== e.length) return o;
		u = l.filter((e) => "token" in e).map(() => "");
	}
	let d = m(u, l), f = d.ends.filter((e) => e <= t).length, h = d.starts.filter((e) => e < n).length, g = [...u];
	for (let e = f; e < h; e++) g[e] = "";
	let _ = f;
	if ([
		"deleteContentBackward",
		"deleteContentForward",
		"deleteByCut"
	].includes(r)) t === n && r !== "deleteByCut" && (_ = r === "deleteContentBackward" ? Math.max(0, f - 1) : f, _ < g.length && (g[_] = ""));
	else if (r.startsWith("insert") && i !== null) {
		let e = l.flatMap((e, t) => "token" in e ? [t] : []), r = e[f] ?? l.length, a = l.slice(f === 0 ? 0 : r), s = a.filter((e) => "token" in e), u = Array.from(i), m;
		if (u.length <= s.length && u.every((e, t) => "token" in s[t] && c(s[t].token, e))) m = u;
		else {
			let o = l.slice(f ? e[f - 1] + 1 : 0, r).map((e) => "literal" in e ? e.literal : "").join("");
			if (t === n && i && o.includes(i)) return {
				value: d.value,
				caret: d.starts[f] ?? d.value.length,
				accepted: !0
			};
			let s = p(i, a);
			if (s) {
				let e = s.findLastIndex(Boolean) + 1;
				s.slice(0, e).every(Boolean) && (m = s.slice(0, e));
			}
		}
		if (!m || f + m.length > g.length) return o;
		m.forEach((e, t) => {
			g[f + t] = e;
		}), _ = f + m.length;
	} else return o;
	let v = m(g, l);
	return {
		value: v.value,
		caret: v.starts[_] ?? v.value.length,
		accepted: !0
	};
}
var y = /* @__PURE__ */ new WeakMap(), b = (e) => ({
	value: e.value,
	start: e.selectionStart ?? 0,
	end: e.selectionEnd ?? 0
});
function x(e, t, n, r) {
	let i = v(e.value, e.selectionStart ?? 0, e.selectionEnd ?? e.value.length, t, n, r);
	if (i.accepted) {
		if (i.value !== e.value) {
			let t = y.get(e);
			(!t || t.current !== e.value) && (t = {
				current: e.value,
				past: [],
				future: []
			}, y.set(e, t)), t.past.push(b(e)), t.past.length > 100 && t.past.shift(), t.future = [], t.current = i.value;
		}
		e.value = i.value, e.setSelectionRange(i.caret, i.caret);
	}
	return i.accepted;
}
function S(e, t) {
	let n = h(e.value, t);
	if (n === e.value) return;
	let r = s(t.mask), i = p(e.value, r);
	if (!i) return;
	let a = m(i, r), o = (t) => {
		let i = p(e.value.slice(0, t), r)?.filter(Boolean).length ?? 0;
		return a.starts[i] ?? n.length;
	}, c = o(e.selectionStart ?? e.value.length), l = o(e.selectionEnd ?? e.value.length);
	e.value = n, e.setSelectionRange(c, l);
}
function C(e, t, n) {
	return t.isComposing || !t.cancelable || ![
		"insertText",
		"insertReplacementText",
		"insertFromPaste",
		"deleteContentBackward",
		"deleteContentForward",
		"deleteByCut"
	].includes(t.inputType) || t.inputType.startsWith("insert") && t.data === null ? !1 : (t.preventDefault(), x(e, t.inputType, t.data, n), !0);
}
function w(e, t, n) {
	return t.clipboardData ? (t.preventDefault(), x(e, "insertFromPaste", t.clipboardData.getData("text/plain"), n), !0) : !1;
}
function T(e, t) {
	if (t.isComposing || !(t.ctrlKey || t.metaKey) || t.altKey) return !1;
	let n = t.key.toLowerCase();
	if (n !== "z" && n !== "y") return !1;
	t.preventDefault(), t.stopPropagation();
	let r = y.get(e);
	if (!r || r.current !== e.value) return !0;
	let i = n === "y" || t.shiftKey, a = (i ? r.future : r.past).pop();
	return a && ((i ? r.past : r.future).push(b(e)), r.current = e.value = a.value, e.setSelectionRange(a.start, a.end)), !0;
}
//#endregion
//#region src/masked-input/index.tsx
var E = {
	required: "Enter a value.",
	invalid: "Use only the characters and separators specified by the mask.",
	incomplete: "Complete every position in the mask.",
	configuration: "Configure a mask with 0, A, or * positions and valid escapes.",
	preview: "Formatted value"
};
function D({ value: s, options: c, apply: l, cancel: u }) {
	let [d, f] = o(() => h(String(s ?? ""), c)), [p, m] = o(!1), [g, v] = o(!1), y = a(!1), b = i(), x = {
		...E,
		...c.text
	}, D = _(d, c), O = p || D.error === "invalid" || D.error === "configuration", k = () => {
		m(!0), !y.current && D.valid && l(D.value);
	};
	return /* @__PURE__ */ r("div", {
		class: "rv-masked-draft",
		onKeyDown: (e) => {
			!y.current && e.target instanceof HTMLInputElement && T(e.target, e) ? f(e.target.value) : e.key === "Enter" && (e.ctrlKey || e.metaKey || e.target instanceof HTMLInputElement) && !e.isComposing && !y.current && (e.preventDefault(), k());
		},
		children: [
			/* @__PURE__ */ n(e, {
				type: "text",
				value: d,
				"aria-label": c.label ?? "Masked identifier",
				"aria-invalid": O && !D.valid,
				"aria-describedby": `${b}-hint${O && D.error ? ` ${b}-error` : ""}`,
				required: c.required,
				placeholder: c.placeholder ?? c.mask,
				onBeforeInput: (e) => {
					!y.current && C(e.currentTarget, e, c) && f(e.currentTarget.value);
				},
				onPaste: (e) => {
					!y.current && w(e.currentTarget, e, c) && f(e.currentTarget.value);
				},
				onInput: (e) => {
					y.current || S(e.currentTarget, c), f(e.currentTarget.value);
				},
				onCompositionStart: () => {
					y.current = !0, v(!0);
				},
				onCompositionEnd: (e) => {
					y.current = !1, v(!1), S(e.currentTarget, c), f(e.currentTarget.value);
				}
			}),
			/* @__PURE__ */ r("span", {
				id: `${b}-hint`,
				class: "rv-masked-draft__preview",
				children: [
					x.preview,
					": ",
					/* @__PURE__ */ n("output", { children: D.formatted ?? c.mask })
				]
			}),
			O && D.error && /* @__PURE__ */ n("span", {
				id: `${b}-error`,
				role: "alert",
				class: "rv-editor-error",
				children: x[D.error]
			}),
			/* @__PURE__ */ n(t, {
				text: c.actions,
				disabled: !D.valid || g,
				apply: k,
				cancel: u,
				clear: c.required ? void 0 : () => f(h("", c))
			})
		]
	});
}
//#endregion
export { D as MaskedDraft, c as acceptsMaskToken, x as applyMaskedEdit, v as editMaskedInput, h as formatMaskedDraft, d as formatMaskedValue, C as handleMaskedBeforeInput, T as handleMaskedHistory, w as handleMaskedPaste, s as maskParts, g as maskedDraftCaret, S as normalizeMaskedInput, _ as parseMaskedDraft, u as parseMaskedInput };
