import { EditorActionText } from '../editor-actions';
export interface MaskedInputText {
    required: string;
    invalid: string;
    incomplete: string;
    configuration: string;
    preview: string;
}
export interface MaskedInputOptions {
    /** 0 = ASCII digit, A = ASCII letter, * = ASCII alphanumeric. Escape literals with \\. */
    mask: string;
    /** Preserve the entered token characters, or include the mask's literal characters. */
    store?: 'raw' | 'formatted';
    required?: boolean;
    label?: string;
    placeholder?: string;
    text?: Partial<MaskedInputText>;
    actions?: Partial<EditorActionText>;
}
export interface MaskedParseResult {
    valid: boolean;
    value: string | null;
    raw: string | null;
    formatted: string | null;
    error?: 'required' | 'invalid' | 'incomplete' | 'configuration';
}
type MaskPart = {
    literal: string;
} | {
    token: '0' | 'A' | '*';
};
export declare function maskParts(mask: string): MaskPart[] | undefined;
export declare function acceptsMaskToken(token: '0' | 'A' | '*', character: string): boolean;
/** Strict, complete parsing of raw token characters or the complete formatted mask. */
export declare function parseMaskedInput(value: unknown, options: MaskedInputOptions): MaskedParseResult;
/** Display complete identifiers; preserve invalid source text for correction. */
export declare function formatMaskedValue(value: unknown, options: MaskedInputOptions): string;
export {};
