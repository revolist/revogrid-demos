import { h, JSX } from 'preact';
type NativeAttributes<K extends keyof JSX.IntrinsicElements> = Omit<JSX.IntrinsicElements[K], 'class' | 'className' | 'ref'> & {
    class?: JSX.IntrinsicElements[K]['class'] | Record<string, boolean | undefined>;
    className?: JSX.IntrinsicElements[K]['className'];
};
/** Transparent adapters preserve native event signatures and DOM refs. */
export declare const Input: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<NativeAttributes<"input">> & {
    ref?: import('preact').Ref<HTMLInputElement> | undefined;
}>;
export declare const Select: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<NativeAttributes<"select">> & {
    ref?: import('preact').Ref<HTMLSelectElement> | undefined;
}>;
export declare const TextArea: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<NativeAttributes<"textarea">> & {
    ref?: import('preact').Ref<HTMLTextAreaElement> | undefined;
}>;
export declare const ButtonControl: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<Omit<h.JSX.ButtonHTMLAttributes<HTMLButtonElement>, "class" | "className" | "ref"> & {
    class?: h.JSX.Signalish<string | undefined> | Record<string, boolean | undefined>;
    className?: h.JSX.Signalish<string | undefined>;
} & {
    unstyled?: boolean;
    busy?: boolean;
}> & {
    ref?: import('preact').Ref<HTMLButtonElement> | undefined;
}>;
export declare const Summary: import('preact').FunctionalComponent<import('preact/compat').PropsWithoutRef<NativeAttributes<"summary">> & {
    ref?: import('preact').Ref<HTMLElement> | undefined;
}>;
export { nativeControlTag } from './control-presentation';
