import { nativeControlTag as e, registerControl as t, renderControl as n } from "./control-presentation.js";
import { h as r } from "preact";
import { forwardRef as i } from "preact/compat";
//#region src/native-control.tsx
function a(e, t, ...i) {
	let { onChange: a, ...o } = t, s = n(r, e, o, ...i);
	return a && !(e === "button" && t.busy) && Object.assign(s.props, { onChange: a }), s;
}
var o = t(i((e, t) => a("input", {
	...e,
	ref: t
})), "input"), s = t(i(({ children: e, ...t }, n) => a("select", {
	...t,
	ref: n
}, e)), "select"), c = t(i(({ children: e, ...t }, n) => a("textarea", {
	...t,
	ref: n
}, e)), "textarea"), l = t(i(({ children: e, ...t }, n) => a("button", {
	...t,
	ref: n
}, e)), "button"), u = t(i(({ children: e, ...t }, n) => a("summary", {
	...t,
	ref: n
}, e)), "summary");
//#endregion
export { l as ButtonControl, o as Input, s as Select, u as Summary, c as TextArea, e as nativeControlTag };
