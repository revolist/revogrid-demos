/** Compatibility entry; markup is owned by the Preact TSX implementation. */
export * from './native-controls.view';
