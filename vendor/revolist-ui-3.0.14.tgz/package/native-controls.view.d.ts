/** Renderer-neutral controls shared by native DOM, Stencil and Preact hosts. */
export type ElementFactory = (...args: any[]) => any;
export declare function renderLoadingIndicator<H extends ElementFactory>(h: H, options: {
    className?: string;
    label?: string;
    ref?: (element?: HTMLElement) => void;
    showSpinner?: boolean;
}): ReturnType<H>;
export declare function createButtonElement(document: Document, options: {
    label: string;
    text?: string;
    disabled?: boolean;
    className?: string;
    onClick?: (event: MouseEvent) => void;
}): HTMLButtonElement;
export declare function renderMenuItem<H extends ElementFactory>(h: H, options: {
    label: string;
    disabled: boolean;
    submenu: boolean;
    onActivate: () => void;
    style?: string;
}): ReturnType<H>;
export declare function renderRatingStars<H extends ElementFactory>(h: H, value: number, maximum?: number): ReturnType<H>[];
export interface ScalarSliderOptions {
    min: number;
    max: number;
    step: number;
    value: number;
    hideValue?: boolean;
    displayValue?: string | number;
    formatValue?: (value: number) => string | number;
    thresholdClassNames?: string;
    thresholds?: readonly {
        value: number;
        className: string;
    }[];
    label?: string;
    onChange: (value: number, event: Event) => void;
    onMouseDown?: (event: MouseEvent) => void;
}
/** Shared scalar slider presentation; edit commits and threshold policy are caller-owned. */
export declare function renderScalarSlider<H extends ElementFactory>(h: H, options: ScalarSliderOptions): ReturnType<H>;
export interface CounterOptions {
    value: number;
    min: number;
    max: number;
    step: number;
    hideValue?: boolean;
    onChange: (value: number, event: MouseEvent) => void;
    decreaseLabel?: string;
    increaseLabel?: string;
    onMouseDown?: (event: MouseEvent) => void;
}
export declare function renderCounter<H extends ElementFactory>(h: H, options: CounterOptions): ReturnType<H>;
