import { calculateAnchoredPopoverPosition as e } from "./core/anchored-popover.js";
import { hideTopLayerPopup as t, showTopLayerPopup as n } from "./core/top-layer-popup.js";
import { createControlId as ee } from "./core/control-id.js";
import { createPreactElement as r, releasePreactElement as i, renderPreactInto as a } from "./preact-mount.js";
import { controlAttributes as te, controlClassName as ne, createControl as o, decorateIconAction as s, nativeControlTag as c, registerControl as l, renderControl as u } from "./control-presentation.js";
import { createFormField as d, createSelectControl as f, createTextControl as p } from "./form-controls/index.js";
import { AVATAR_CELL_BACKGROUNDS as m } from "./color-palette/common-palettes.js";
import { AvatarElement as h, avatarTemplate as g, avatarWithTextTemplate as _, createAvatarElement as v, getAvatarCellBackground as y, getAvatarIndex as b, getAvatarInitials as x } from "./avatar/index.js";
import { d as S, f as C, u as w } from "./_chunks/dialog.parts-Wr0Lpt6Z.js";
import { createDialogButton as T, createDialogCloseButton as E, createDialogElements as D, getDialogFocusableElements as O, trapDialogFocus as k } from "./dialog/dialog.dom.js";
import { attachDialogDrag as A } from "./dialog/dialog.drag.js";
import "./dialog/dialog.types.js";
import { getUiMotionDuration as j, inheritUiMotion as M, isUiMotionEnabled as N } from "./core/motion.js";
import { DialogController as P, PopoverController as F, TooltipController as I, attachMenuKeyboard as L, attachResizeHandle as R, createTooltipElement as z } from "./surfaces.js";
import { normalizeProgressRange as B } from "./progress/range.js";
import { renderProgressBar as V } from "./progress/bar.js";
import { renderRangeSlider as H } from "./filter/filters/slider/component.js";
import "./filter/filters/slider/types.js";
import { a as U, c as W, i as G, n as re, o as K, r as q, s as J, t as Y } from "./_chunks/alert-BjgGD4ar.js";
import { PaginationPanel as X, paginationItems as ie, renderPaginationButton as ae } from "./pagination.js";
import { renderCircularProgress as oe } from "./progress/circular.js";
import { applyControlPresentation as se } from "./html-controls.js";
import { n as ce, t as le } from "./_chunks/native.view-DY6ldYWP.js";
import { a as ue, c as de, d as fe, f as pe, h as me, i as he, l as ge, m as _e, n as ve, o as ye, p as be, r as xe, s as Se, t as Z, u as Ce } from "./_chunks/cell-visuals-CLDzZdbQ.js";
import { t as we } from "./_chunks/color-picker-DeEYxlEk.js";
import { jsx as Q } from "preact/jsx-runtime";
import { useState as Te } from "preact/hooks";
//#region src/icons/drawing-tools.ts
var Ee = {
	link: "M10 13a5 5 0 0 0 7 .5l3-3a5 5 0 0 0-7-7l-2 2 M14 11a5 5 0 0 0-7-.5l-3 3a5 5 0 0 0 7 7l2-2",
	select: "M5 3 19 12 12 13 9 20Z M12 13l5 7",
	rectangle: "M4 5h16v14H4Z",
	line: "M5 19 19 5 M4 18l2 2 M18 4l2 2",
	arrow: "M5 19 19 5 M9 5h10v10",
	note: "M5 3h14v14l-4 4H5Z M15 21v-4h4 M8 8h8 M8 12h6"
};
//#endregion
//#region src/color-palette/native.view.tsx
function De(e) {
	let [t, n] = Te(e.value);
	return /* @__PURE__ */ Q(we, {
		...e,
		value: t,
		customHexLabel: e.customLabel,
		onChange: (t) => {
			n(t), e.onChange(t);
		}
	});
}
function Oe(e, t) {
	let n = r(e.ownerDocument, /* @__PURE__ */ Q(De, { ...t }));
	return e.append(n), { destroy() {
		i(n);
	} };
}
//#endregion
//#region src/alert-native.tsx
function $(e, { content: t, ...n }) {
	a(e, /* @__PURE__ */ Q(Y, {
		...n,
		children: t === void 0 ? n.children : typeof t == "string" ? t : /* @__PURE__ */ Q("span", { ref: (e) => {
			e && e.replaceChildren(t);
		} })
	}));
}
function ke(e, t) {
	let n = r(e, /* @__PURE__ */ Q("div", {}));
	return $(n, t), n;
}
function Ae(e) {
	a(e, null), i(e);
}
//#endregion
export { m as AVATAR_CELL_BACKGROUNDS, w as ActionFooterView, h as AvatarElement, Ee as DRAWING_TOOL_PATHS, P as DialogController, X as PaginationPanel, F as PopoverController, I as TooltipController, se as applyControlPresentation, A as attachDialogDrag, L as attachMenuKeyboard, R as attachResizeHandle, g as avatarTemplate, _ as avatarWithTextTemplate, e as calculateAnchoredPopoverPosition, te as controlAttributes, ne as controlClassName, ke as createAlertElement, v as createAvatarElement, q as createButtonElement, o as createControl, ee as createControlId, T as createDialogButton, E as createDialogCloseButton, D as createDialogElements, d as createFormField, le as createSearchInput, f as createSelectControl, p as createTextControl, z as createTooltipElement, s as decorateIconAction, ve as formatTimelineEvents, y as getAvatarCellBackground, b as getAvatarIndex, x as getAvatarInitials, O as getDialogFocusableElements, j as getUiMotionDuration, t as hideTopLayerPopup, M as inheritUiMotion, N as isUiMotionEnabled, Oe as mountColorPicker, S as mountDialogActionFooter, c as nativeControlTag, B as normalizeProgressRange, ie as paginationItems, l as registerControl, Ae as releaseAlertElement, Se as renderAggregateSummary, re as renderAlert, $ as renderAlertInto, de as renderBadgeValue, ge as renderChange, oe as renderCircularProgress, u as renderControl, G as renderCounter, C as renderDialogActionFooter, he as renderHeatmap, Ce as renderLabelledIcon, U as renderLoadingIndicator, K as renderMenuItem, ue as renderMiniBarChart, ae as renderPaginationButton, fe as renderPercentageSummary, Z as renderPie, V as renderProgressBar, pe as renderProgressLine, be as renderProgressLineValue, H as renderRangeSlider, J as renderRatingStars, W as renderScalarSlider, ce as renderSearchInput, ye as renderSparkline, _e as renderThumbs, xe as renderTimeline, me as renderTypeIcon, n as showTopLayerPopup, k as trapDialogFocus };
