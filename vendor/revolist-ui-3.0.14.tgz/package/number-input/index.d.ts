import { NumberInputOptions } from './model';
export { formatNumberValue, formatNumberDraft, parseNumberInput, stepNumberInput } from './model';
export type { NumberInputOptions, NumberInputResult, NumberInputText, } from './model';
/** Staged numeric input shared by number, currency and ratio editor adapters. */
export declare function NumberDraft({ value, options, apply, cancel, initialSelection, }: {
    value: unknown;
    options: NumberInputOptions;
    apply: (value: number | null) => void;
    cancel: () => void;
    /** Printable-key editors keep the initiating character and continue at its end. */
    initialSelection?: 'all' | 'end';
}): import("preact").JSX.Element;
