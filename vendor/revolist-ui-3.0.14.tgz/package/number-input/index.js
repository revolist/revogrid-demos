import { createControlId as e } from "../core/control-id.js";
import { Input as t } from "../native-control.js";
import { Button as n } from "../controls.js";
import { EditorActions as r } from "../editor-actions.js";
import { jsx as i, jsxs as a } from "preact/jsx-runtime";
import { useEffect as o, useRef as s, useState as c } from "preact/hooks";
//#region src/number-input/model.ts
var l = {
	invalid: "Enter a valid number in the configured locale.",
	configuration: "The number input configuration is unsupported or invalid.",
	required: "Enter a value.",
	precision: "Too many decimal places for this field.",
	minimum: "The value is below the minimum.",
	maximum: "The value is above the maximum.",
	increase: "Increase",
	decrease: "Decrease"
}, u = /[\u061c\u200e\u200f]/g, d = (e) => e.replace(u, "").trim(), f = (e) => typeof e == "number" && Number.isFinite(e);
function p(e) {
	let t = e.kind ?? "number", n = e.precision ?? 2;
	if (![
		"number",
		"currency",
		"percent"
	].includes(t) || !Number.isInteger(n) || n < 0 || n > 20 || e.min !== void 0 && !f(e.min) || e.max !== void 0 && !f(e.max) || e.step !== void 0 && (!f(e.step) || e.step <= 0) || e.min !== void 0 && e.max !== void 0 && e.min > e.max || e.useGrouping !== void 0 && typeof e.useGrouping != "boolean" || e.required !== void 0 && typeof e.required != "boolean" || e.locale !== void 0 && (typeof e.locale != "string" || !e.locale.trim() || !Intl.NumberFormat.supportedLocalesOf(e.locale).length)) throw RangeError();
	let r = e.currency ?? "USD";
	if (t === "currency" && (typeof r != "string" || !/^[A-Z]{3}$/.test(r))) throw RangeError();
	if (e.step !== void 0) {
		let [r, i = "0"] = String(e.step).split("e");
		if ((r.split(".")[1]?.length ?? 0) - Number(i) - (t === "percent" ? 2 : 0) > n) throw RangeError();
	}
	let i = t === "number" ? "decimal" : t, a = new Intl.NumberFormat(e.locale, {
		style: i,
		...t === "currency" ? { currency: r } : {},
		minimumFractionDigits: n,
		maximumFractionDigits: n,
		useGrouping: e.useGrouping ?? !0
	}), o = e.locale ? new Intl.Locale(e.locale).numberingSystem : void 0;
	if (o && a.resolvedOptions().numberingSystem !== o) throw RangeError();
	return {
		kind: t,
		precision: n,
		currency: r,
		formatter: a
	};
}
function m(e, t = {}) {
	let { formatter: n } = p(t);
	if (e == null) return "";
	if (!f(e)) throw TypeError("Expected a finite number or null.");
	return n.format(e);
}
function h(e, t) {
	let { kind: n, currency: r } = p(t);
	if (e == null) return "";
	if (!f(e)) return String(e);
	let i = new Intl.NumberFormat(t.locale, {
		style: n === "number" ? "decimal" : n,
		...n === "currency" ? { currency: r } : {},
		useGrouping: t.useGrouping ?? !0,
		minimumFractionDigits: 0,
		maximumFractionDigits: 20
	}).format(e), a = g(i, {
		...t,
		precision: 20,
		min: void 0,
		max: void 0,
		step: void 0
	});
	return a.error === void 0 && Object.is(a.value, e) ? i : e.toExponential();
}
function g(e, t = {}) {
	let n = {
		...l,
		...t.text
	};
	try {
		let { kind: r, precision: i, currency: a } = p(t), o = d(e);
		if (!o) return t.required ? { error: n.required } : { value: null };
		let s = new Intl.NumberFormat(t.locale, {
			useGrouping: !1,
			minimumFractionDigits: 1
		}).formatToParts(1.1).find((e) => e.type === "decimal").value, c = new Intl.NumberFormat(t.locale, { useGrouping: !1 }), l = new Map(Array.from({ length: 10 }, (e, t) => [d(c.format(t)), String(t)])), u = (e) => [...e].map((e) => l.get(e) ?? e).join(""), f = new Intl.NumberFormat(t.locale, {
			useGrouping: !0,
			maximumFractionDigits: 0
		}), m = f.formatToParts(123456789).find((e) => e.type === "group")?.value, h = c.formatToParts(-1).find((e) => e.type === "minusSign")?.value ?? "-", g = !1, _ = !1;
		r === "currency" && o.startsWith("(") && o.endsWith(")") && (g = !0, _ = !0, o = d(o.slice(1, -1)));
		let v = () => {
			let e = [
				h,
				"-",
				"+"
			].find((e) => o.startsWith(e));
			return !e || !_ && (_ = !0, g = e !== "+", o = d(o.slice(e.length)), !0);
		};
		if (!v()) return { error: n.invalid };
		if (r === "currency") {
			let e = /* @__PURE__ */ new Set([a]);
			for (let n of ["symbol", "narrowSymbol"]) for (let r of new Intl.NumberFormat(t.locale, {
				style: "currency",
				currency: a,
				currencyDisplay: n
			}).formatToParts(1)) r.type === "currency" && e.add(r.value);
			for (let t of [...e].sort((e, t) => t.length - e.length)) {
				if (o.startsWith(t)) {
					o = d(o.slice(t.length));
					break;
				}
				if (o.endsWith(t)) {
					o = d(o.slice(0, -t.length));
					break;
				}
			}
			if (!v()) return { error: n.invalid };
		} else if (r === "percent") {
			let e = new Intl.NumberFormat(t.locale, { style: "percent" }).formatToParts(1).find((e) => e.type === "percentSign").value;
			o.endsWith(e) ? o = d(o.slice(0, -e.length)) : o.startsWith(e) && (o = d(o.slice(e.length)));
		}
		o = u(o);
		let y = o.split(s);
		if (y.length > 2) return { error: n.invalid };
		let b = y[0], x = y[1] ?? "";
		if (!/^\d*$/.test(x) || y.length === 2 && !x) return { error: n.invalid };
		if (m && b.includes(m)) {
			let e = b.split(m).join("");
			if (!/^\d+$/.test(e) || u(d(f.format(BigInt(e)))) !== b) return { error: n.invalid };
			b = e;
		}
		if (!/^\d*$/.test(b) || !b && !x) return { error: n.invalid };
		if (x.length > i) return { error: n.precision };
		let S = `${g ? "-" : ""}${b || "0"}${x ? `.${x}` : ""}`, C = Number(r === "percent" ? `${S}e-2` : S);
		return !Number.isFinite(C) || Math.abs(C) > 2 ** 53 - 1 || C === 0 && /[1-9]/.test(S) ? { error: n.invalid } : t.min !== void 0 && C < t.min ? { error: n.minimum } : t.max !== void 0 && C > t.max ? { error: n.maximum } : { value: C };
	} catch {
		return { error: n.configuration };
	}
}
function _(e, t) {
	let n = (e) => {
		let [t, n = "0"] = String(e).split("e"), r = t.split(".")[1]?.length ?? 0;
		return {
			integer: BigInt(t.replace(".", "")),
			scale: r - Number(n)
		};
	}, r = n(e), i = n(t), a = Math.max(r.scale, i.scale, 0), o = r.integer * 10n ** BigInt(a - r.scale) + i.integer * 10n ** BigInt(a - i.scale);
	return Number(`${o}e-${a}`);
}
function v(e, t, n = {}) {
	let r = g(e, n);
	if (r.error !== void 0) return r;
	let { kind: i, precision: a } = p(n), o = n.step ?? 10 ** -(a + (i === "percent" ? 2 : 0)), s = r.value ?? Math.max(n.min ?? -Infinity, Math.min(n.max ?? Infinity, 0)), c = Math.max(n.min ?? -Infinity, Math.min(n.max ?? Infinity, _(s, t * o)));
	return !Number.isFinite(c) || Math.abs(c) > 2 ** 53 - 1 ? { error: n.text?.invalid ?? l.invalid } : g(h(c, n), n);
}
//#endregion
//#region src/number-input/index.tsx
function y({ value: u, options: d, apply: f, cancel: p, initialSelection: m = "all" }) {
	let [_, y] = c(() => {
		try {
			return h(u, d);
		} catch {
			return String(u ?? "");
		}
	}), [b, x] = c(""), [S] = c(() => e("rv-number")), C = s(null), w = s(!1), T = {
		...l,
		...d.text
	}, E = g(_, d), D = E.error ?? b, O = E.error !== void 0 || !!b, k = () => {
		if (w.current) return;
		let e = g(_, d);
		e.error === void 0 && !b && f(e.value);
	}, A = (e) => {
		x(""), y(e);
	}, j = (e) => {
		if (w.current) return;
		let t = v(_, e, d);
		t.error === void 0 ? (x(""), y(h(t.value, d))) : x(t.error || T.invalid);
	};
	return o(() => {
		if (C.current?.focus(), m === "end") {
			let e = C.current?.value.length ?? 0;
			C.current?.setSelectionRange(e, e);
		} else C.current?.select();
	}, []), /* @__PURE__ */ a("div", {
		class: "rv-number-draft",
		onKeyDown: (e) => {
			e.isComposing || w.current || (e.key === "Enter" && (e.target === C.current || e.ctrlKey || e.metaKey) ? (e.preventDefault(), k()) : e.target === C.current && ["ArrowUp", "ArrowDown"].includes(e.key) && (e.preventDefault(), j(e.key === "ArrowUp" ? 1 : -1)));
		},
		children: [
			/* @__PURE__ */ i("label", {
				htmlFor: S,
				children: d.label ?? (d.kind === "currency" ? "Currency amount" : d.kind === "percent" ? "Percentage" : "Number")
			}),
			/* @__PURE__ */ a("div", {
				class: "rv-number-draft__entry",
				children: [
					/* @__PURE__ */ i(t, {
						ref: C,
						id: S,
						class: "rv-control",
						type: "text",
						inputMode: "decimal",
						value: _,
						"aria-invalid": O,
						"aria-describedby": O ? `${S}-error` : void 0,
						required: d.required,
						onCompositionStart: () => {
							w.current = !0;
						},
						onCompositionEnd: () => {
							w.current = !1;
						},
						onInput: (e) => A(e.currentTarget.value)
					}),
					/* @__PURE__ */ i(n, {
						"aria-label": T.decrease,
						disabled: E.error !== void 0,
						onClick: () => j(-1),
						children: "−"
					}),
					/* @__PURE__ */ i(n, {
						"aria-label": T.increase,
						disabled: E.error !== void 0,
						onClick: () => j(1),
						children: "+"
					})
				]
			}),
			O && /* @__PURE__ */ i("p", {
				class: "rv-editor-error",
				id: `${S}-error`,
				role: "alert",
				children: D || T.invalid || l.invalid
			}),
			/* @__PURE__ */ i(r, {
				text: d.actions,
				apply: k,
				cancel: p,
				disabled: O,
				clear: d.required ? void 0 : () => A("")
			})
		]
	});
}
//#endregion
export { y as NumberDraft, h as formatNumberDraft, m as formatNumberValue, g as parseNumberInput, v as stepNumberInput };
