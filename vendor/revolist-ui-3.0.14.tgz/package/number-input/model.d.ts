import { EditorActionText } from '../editor-actions';
export interface NumberInputText {
    invalid: string;
    configuration: string;
    required: string;
    precision: string;
    minimum: string;
    maximum: string;
    increase: string;
    decrease: string;
}
export interface NumberInputOptions {
    kind?: 'number' | 'currency' | 'percent';
    /** Maximum fraction digits in display units, from 0 to 20. Defaults to 2. */
    precision?: number;
    locale?: string;
    currency?: string;
    useGrouping?: boolean;
    /** Bounds and step use source units (ratios for percent). */
    min?: number;
    max?: number;
    /** Defaults to the smallest displayed precision unit. */
    step?: number;
    required?: boolean;
    label?: string;
    text?: Partial<NumberInputText>;
    actions?: Partial<EditorActionText>;
}
export type NumberInputResult = {
    value: number | null;
    error?: never;
} | {
    error: string;
    value?: never;
};
export declare const defaultNumberInputText: NumberInputText;
/** Formats finite source numbers; nullish values remain blank. Invalid options throw. */
export declare function formatNumberValue(value: unknown, options?: NumberInputOptions): string;
/** Preserve existing precision in the draft instead of rounding a value on open. */
export declare function formatNumberDraft(value: unknown, options: NumberInputOptions): string;
/** Strict full-string locale parser. Bare percent input is also in percentage units. */
export declare function parseNumberInput(text: string, options?: NumberInputOptions): NumberInputResult;
export declare function stepNumberInput(text: string, direction: 1 | -1, options?: NumberInputOptions): NumberInputResult;
