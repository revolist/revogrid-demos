export type PaginationItem = number | 'ellipsis';
/** A bounded page window with first/last anchors and no redundant ellipses. */
export declare function paginationItems(page: number, pageCount: number, count?: number): PaginationItem[];
export declare function renderPaginationButton<T>(h: PaginationElementFactory<T>, options: {
    text: string;
    label?: string;
    kind?: 'first' | 'previous' | 'next' | 'last';
    active?: boolean;
    disabled?: boolean;
    onClick: () => void;
}): T;
export type PaginationElementFactory<T> = (...args: any[]) => T;
export interface PaginationViewConfig {
    itemsPerPage: number;
    initialPage: number;
    total: number;
    buttonCount?: number;
    info?: boolean;
    totalInfo?: boolean;
    pageSizes?: boolean | number[];
    position?: 'top' | 'bottom';
    navigation?: boolean;
    locales?: {
        previous?: string;
        next?: string;
        first?: string;
        last?: string;
        page?: string;
        of?: string;
        items?: string;
        loading?: string;
    };
}
/** Renderer-neutral pagination state and presentation. Remote loading stays with the host. */
export declare class PaginationPanel<T = any> {
    private onPageChange;
    private readonly h;
    private config;
    private currentPage;
    private loading;
    private totalPages;
    private locales;
    refresh?: () => void;
    constructor(config: PaginationViewConfig, onPageChange: (page: number) => void, h: PaginationElementFactory<T>);
    setLoading(loading: boolean): void;
    setRefresh(refresh?: () => void): void;
    setPage(page: number, emitChange?: boolean): void;
    private createButton;
    render(): T;
    update(config: PaginationViewConfig): void;
}
