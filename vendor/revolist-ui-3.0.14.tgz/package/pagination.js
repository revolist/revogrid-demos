import { controlClassName as e, renderControl as t } from "./control-presentation.js";
//#region src/pagination.ts
function n(e, t, n = 5) {
	let r = Math.max(0, Math.floor(t));
	if (!Number.isFinite(r) || !r) return [];
	let i = Math.min(r, Math.max(1, Math.floor(n) || 5)), a = Math.min(r - 1, Math.max(0, Math.floor(e) || 0)), o = Math.min(Math.max(0, a - Math.floor(i / 2)), r - i), s = /* @__PURE__ */ new Set([0, r - 1]);
	for (let e = o; e < o + i; e++) s.add(e);
	let c = [], l = -1;
	for (let e of [...s].sort((e, t) => e - t)) l >= 0 && e - l === 2 ? c.push(l + 1) : l >= 0 && e - l > 2 && c.push("ellipsis"), c.push(e), l = e;
	return c;
}
function r(n, r) {
	return t(n, "button", {
		class: e("rv-button small rv-pagination-button rv-btn-ghost", {
			"rv-pagination-button--icon": !!r.kind,
			disabled: r.disabled
		}),
		disabled: r.disabled,
		"aria-label": r.label,
		"aria-current": r.active ? "page" : void 0,
		onClick: r.onClick
	}, ...r.kind ? [n("svg", {
		viewBox: "0 0 24 24",
		width: 16,
		height: 16,
		fill: "none",
		stroke: "currentColor",
		"stroke-width": 1.8,
		"stroke-linecap": "round",
		"stroke-linejoin": "round",
		"aria-hidden": "true",
		class: "rv-pagination-chevron"
	}, n("path", { d: {
		first: "M11 6l-6 6 6 6M19 6l-6 6 6 6",
		previous: "M15 6l-6 6 6 6",
		next: "M9 6l6 6-6 6",
		last: "M5 6l6 6-6 6M13 6l6 6-6 6"
	}[r.kind] })), n("span", {
		class: "rv-pagination-sr",
		"aria-hidden": "true"
	}, r.text)] : [r.text]);
}
var i = class {
	onPageChange;
	h;
	config = {
		itemsPerPage: 0,
		initialPage: 0,
		total: 0
	};
	currentPage = 0;
	loading = !1;
	totalPages = 0;
	locales = {
		previous: "‹",
		next: "›",
		first: "«",
		last: "»",
		page: "Page",
		of: "of",
		items: "items",
		loading: "Loading…"
	};
	refresh;
	constructor(e, t, n) {
		this.onPageChange = t, this.h = n, this.update(e);
	}
	setLoading(e) {
		this.loading !== e && (this.loading = e, this.refresh?.());
	}
	setRefresh(e) {
		this.refresh = e;
	}
	setPage(e, t = !0) {
		let n = Math.max(0, this.totalPages - 1), r = Math.min(Math.max(0, e), n);
		this.currentPage = r, this.refresh?.(), t && this.onPageChange(this.currentPage);
	}
	createButton(e, t, n) {
		let i = {
			first: "«",
			previous: "‹",
			next: "›",
			last: "»"
		}, a = Object.keys(i).find((t) => i[t] === e), o = a ? {
			first: "First page",
			previous: "Previous page",
			next: "Next page",
			last: "Last page"
		}[a] : e;
		return r(this.h, {
			text: e,
			label: o,
			kind: a,
			disabled: n,
			onClick: () => t.call(this)
		});
	}
	render() {
		let e = this.h, i = [];
		if (this.config.navigation !== !1) {
			if (i.push(this.createButton(this.locales.first, () => {
				this.currentPage > 0 && this.setPage(0);
			}, this.currentPage === 0), this.createButton(this.locales.previous, () => {
				this.currentPage > 0 && this.setPage(this.currentPage - 1);
			}, this.currentPage === 0)), this.config.buttonCount) for (let t of n(this.currentPage, this.totalPages, this.config.buttonCount)) t === "ellipsis" ? i.push(e("span", {
				class: "rv-pagination-ellipsis",
				"aria-hidden": "true"
			}, "…")) : i.push(r(e, {
				text: String(t + 1),
				label: `${this.locales.page} ${t + 1}`,
				active: t === this.currentPage,
				disabled: t === this.currentPage,
				onClick: () => this.setPage(t)
			}));
			i.push(this.createButton(this.locales.next, () => {
				this.currentPage < this.totalPages - 1 && this.setPage(this.currentPage + 1);
			}, this.currentPage >= this.totalPages - 1), this.createButton(this.locales.last, () => {
				this.setPage(this.totalPages - 1);
			}, this.currentPage >= this.totalPages - 1));
		}
		if (this.totalPages > 1) {
			let n = [];
			this.config.info !== !1 && n.push(e("span", { class: "rv-pagination-label" }, this.locales.page)), n.push(t(e, "select", {
				"aria-label": this.locales.page,
				value: String(this.currentPage),
				onChange: (e) => {
					let t = e.target;
					this.setPage(parseInt(t.value, 10));
				}
			}, Array(this.totalPages).fill(null).map((t, n) => e("option", {
				value: n,
				selected: n === this.currentPage
			}, (n + 1).toString())))), this.config.info !== !1 && n.push(e("span", null, ` ${this.locales.of} ${this.totalPages}`)), i.push(e("span", { class: "rv-pagination-selector" }, n));
		}
		this.loading && i.push(e("span", {
			role: "status",
			"aria-live": "polite"
		}, this.locales.loading));
		let a = [];
		if (this.config.totalInfo !== !1) {
			let t = this.config.total > 0 && this.config.itemsPerPage > 0 ? this.currentPage * this.config.itemsPerPage + 1 : 0, n = Math.min((this.currentPage + 1) * this.config.itemsPerPage, this.config.total);
			a.push(e("span", { dir: "auto" }, `${t}-${n} ${this.locales.of} ${this.config.total} ${this.locales.items}`));
		}
		return e("div", {
			class: "rv-pagination-panel",
			role: "navigation",
			"aria-label": this.locales.page
		}, [e("span", null, i), e("span", null, a)]);
	}
	update(e) {
		let t = e.itemsPerPage > 0 && Number.isFinite(e.total) ? Math.max(0, Math.ceil(e.total / e.itemsPerPage)) : 0;
		this.currentPage = e.initialPage === this.config.initialPage ? t ? Math.min(this.currentPage, t - 1) : 0 : Math.min(Math.max(0, Math.floor(e.initialPage) || 0), Math.max(0, t - 1)), this.totalPages = t, this.config = e, this.locales = {
			...this.locales,
			...e.locales
		}, this.refresh?.();
	}
};
//#endregion
export { i as PaginationPanel, n as paginationItems, r as renderPaginationButton };
