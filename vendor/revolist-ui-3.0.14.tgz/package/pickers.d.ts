import { h, ComponentChildren } from 'preact';
import { ISODateString } from './_shared/dates/index';
import { CalendarDateRange, CalendarProps } from './calendar/types';
import { DropdownProps } from './dropdown';
import { AvatarTemplateOptions } from './avatar';
import { ProgressBarProps } from './progress/bar';
export declare function Combobox<T>(props: DropdownProps<T>): h.JSX.Element;
export declare function MultiSelect<T>(props: DropdownProps<T>): h.JSX.Element;
export declare function Avatar(props: AvatarTemplateOptions): any;
export declare function ProgressBar(props: ProgressBarProps): any;
export interface PopoverProps {
    open: boolean;
    anchor: HTMLElement | null;
    onClose: () => void;
    children?: ComponentChildren;
    label?: string;
    className?: string;
    role?: 'dialog' | 'menu';
}
export declare function Popover({ open, anchor, onClose, children, label, className, role, }: PopoverProps): h.JSX.Element;
export declare function Tooltip({ text, children, }: {
    text: string;
    children: ComponentChildren;
}): h.JSX.Element;
export interface DialogProps {
    open: boolean;
    title: string;
    closeLabel: string;
    onClose: () => void;
    children?: ComponentChildren;
    footer?: ComponentChildren;
    draggable?: boolean;
    returnFocus?: HTMLElement;
}
export declare function Dialog({ open, title, closeLabel, onClose, children, footer, draggable, returnFocus, }: DialogProps): h.JSX.Element;
export { DialogHeader, DialogBody, DialogFooter } from './dialog/dialog.parts';
export declare function ConfirmDialog({ onConfirm, confirmLabel, cancelLabel, pending, ...props }: DialogProps & {
    onConfirm: () => void;
    confirmLabel: string;
    cancelLabel: string;
    pending?: boolean;
}): h.JSX.Element;
/** Forward calendar presentation/validation options; selection and focus remain picker-owned. */
type CalendarOptions = Omit<CalendarProps, 'month' | 'focusedDate' | 'selection' | 'preview' | 'selectedDates' | 'onMonthChange' | 'onFocusedDateChange' | 'onSelect' | 'onPresetSelect' | 'onPreviewDateChange'>;
export interface DatePickerProps extends CalendarOptions {
    value?: ISODateString;
    onChange: (value?: ISODateString) => void;
    label: string;
    openLabel: string;
    disabled?: boolean;
    readOnly?: boolean;
}
export declare function DatePicker({ value, onChange, label, openLabel, disabled, readOnly, ...calendarOptions }: DatePickerProps): h.JSX.Element;
export interface DateRangePickerProps extends CalendarOptions {
    value?: CalendarDateRange;
    onChange: (value: CalendarDateRange) => void;
    label: string;
    fromLabel: string;
    toLabel: string;
    openLabel: string;
    disabled?: boolean;
    readOnly?: boolean;
}
export declare function DateRangePicker({ value, onChange, label, fromLabel, toLabel, openLabel, disabled, readOnly, ...calendarOptions }: DateRangePickerProps): h.JSX.Element;
