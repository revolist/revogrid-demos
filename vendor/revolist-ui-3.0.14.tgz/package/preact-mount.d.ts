import { ComponentChildren, VNode } from 'preact';
/** Compatibility boundary for hosts that accept an element instead of a VNode.
 * All markup is rendered by Preact; the fragment supplies the owning document. */
export declare function createPreactElement<T extends Element = HTMLElement>(document: Document, view: VNode<any>, existing?: Element): T;
/** Reattach a detached root before unmounting so Preact can release refs/effects. */
export declare function releasePreactElement(element: Element): void;
/** Renders into an existing native host, including isolated owner documents. */
export declare function renderPreactInto(host: Element, view: ComponentChildren): void;
