import { hydrate as e, render as t } from "preact";
//#region src/preact-mount.tsx
var n = /* @__PURE__ */ new WeakMap();
function r(r, i, a) {
	let s = r.createDocumentFragment();
	typeof i.type == "string" && [
		"g",
		"rect",
		"line",
		"text",
		"title",
		"path",
		"circle",
		"polyline"
	].includes(i.type) && Object.defineProperty(s, "namespaceURI", { value: "http://www.w3.org/2000/svg" }), a && s.append(a), o(r, () => {
		a ? e(i, s) : t(i, s);
	});
	let c = s.firstChild;
	if (!c || c.nodeType !== 1) throw Error("Expected one Preact element root");
	return n.set(c, s), c;
}
function i(e) {
	let r = n.get(e);
	r && (r.append(e), o(e.ownerDocument, () => t(null, r)), n.delete(e));
}
function a(e, n) {
	o(e.ownerDocument, () => t(n, e));
}
function o(e, t) {
	let n = Object.getOwnPropertyDescriptor(globalThis, "document"), r = globalThis.document === void 0;
	r && Object.defineProperty(globalThis, "document", {
		configurable: !0,
		value: e
	});
	try {
		t();
	} finally {
		r && (n ? Object.defineProperty(globalThis, "document", n) : Reflect.deleteProperty(globalThis, "document"));
	}
}
//#endregion
export { r as createPreactElement, i as releasePreactElement, a as renderPreactInto };
