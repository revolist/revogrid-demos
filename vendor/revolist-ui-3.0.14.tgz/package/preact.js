import { createControlId as e } from "./core/control-id.js";
import { controlAttributes as t, controlClassName as n, createControl as r, decorateIconAction as i, nativeControlTag as a, registerControl as o, renderControl as s } from "./control-presentation.js";
import { Input as c } from "./native-control.js";
import { createFormField as l, createSelectControl as u, createTextControl as d } from "./form-controls/index.js";
import { avatarTemplate as f } from "./avatar/index.js";
import { a as p, c as m, i as h, l as g, n as _, o as v, r as y, s as b, t as x } from "./_chunks/dialog.parts-Wr0Lpt6Z.js";
import { getUiMotionDuration as ee, inheritUiMotion as te, isUiMotionEnabled as ne } from "./core/motion.js";
import { DialogController as re, PopoverController as ie, TooltipController as ae, attachMenuKeyboard as oe } from "./surfaces.js";
import { renderProgressBar as se } from "./progress/bar.js";
import { t as ce } from "./_chunks/alert-BjgGD4ar.js";
import { a as le, c as ue, d as de, f as fe, h as pe, i as me, l as he, m as ge, n as _e, o as ve, p as ye, r as be, s as xe, t as Se, u as Ce } from "./_chunks/cell-visuals-CLDzZdbQ.js";
import { n as we, t as Te } from "./_chunks/color-palette-B2-d_Iss.js";
import { n as Ee, t as De } from "./_chunks/control-tooltip-DYksNy2m.js";
import { DEFAULT_COLOR_PALETTE_OPTIONS as Oe } from "./color-palette/palette.js";
import { t as ke } from "./_chunks/color-picker-DeEYxlEk.js";
import { n as Ae, t as je } from "./_chunks/rating-choice-BX20k8iz.js";
import { SvgIcon as S } from "./icons/icon.js";
import { t as Me } from "./_chunks/delete-button-DnpmDNEJ.js";
import { RemoveButton as Ne } from "./buttons/remove-button.js";
import { n as Pe, r as Fe, t as Ie } from "./_chunks/choice-chips-CJKUg_0I.js";
import { FilterBadge as Le, FilterBadgeInfoButton as Re } from "./filter-badge.js";
import { ActivityMessage as ze } from "./activity-message.js";
import { SvgButton as Be } from "./buttons/svg-button.js";
import { Checkbox as Ve, SHARED_CHECKBOX_CLASS as He, renderCheckbox as Ue } from "./checkbox/index.js";
import { Switch as We } from "./switch/index.js";
import { SegmentedSwitch as Ge } from "./segmented-switch/index.js";
import { SearchInput as Ke } from "./search-input/index.js";
import { DisclosureSummary as qe, FilterChip as C, FormField as Je, renderFormFieldContent as Ye } from "./form-controls/presentation.js";
import { EditorList as w, EditorListGroup as T, EditorListItem as E, EditorListItemContent as D, EditorPane as O, EditorSplitLayout as k } from "./editor-layout/index.js";
import { DEFAULT_CALENDAR_TRANSLATIONS as Xe } from "./calendar/translations.js";
import { s as A } from "./_chunks/iso-B0YHBK7m.js";
import { a as Ze, f as j, h as M, i as Qe, n as $e, o as N, r as et, t as tt } from "./_chunks/model-mPO2tG2f.js";
import { n as nt, t as rt } from "./_chunks/header-ChgiwXiD.js";
import { t as P } from "./_chunks/calendar-CdXe5aOT.js";
import { CalendarDay as it } from "./calendar/day.js";
import { CalendarMonthGrid as at } from "./calendar/month-grid.js";
import { CalendarYearGrid as ot } from "./calendar/year-grid.js";
import { t as st } from "./_chunks/picker-PiJmfr-8.js";
import "./calendar/index.js";
import { ResourcePickerAvatar as ct, getResourcePickerColor as lt, getResourcePickerForegroundColor as ut, getResourcePickerInitials as dt } from "./resource-picker/resource-picker-avatar.js";
import { DropdownPopup as ft } from "./dropdown/popup.js";
import { SharedResourcePicker as F } from "./resource-picker/resource-picker.js";
import { n as pt, r as mt, t as I } from "./_chunks/dropdown-B1_emHGN.js";
import { Badge as ht, Button as L, ButtonGroup as gt, Chip as _t, CircularProgress as vt, CountBadge as yt, DateInput as R, DateTimeInput as bt, Disclosure as xt, EmptyState as St, FieldError as Ct, FieldHint as wt, FormSection as Tt, IconButton as Et, LoadingOverlay as Dt, Menu as Ot, MenuItem as kt, MenuSeparator as At, NativeSelect as jt, NumberInput as Mt, NumberStepper as Nt, Pagination as Pt, Panel as Ft, RadioGroup as It, Rating as Lt, ResizeHandle as Rt, SegmentedControl as zt, Spinner as Bt, Submenu as Vt, TabPanel as Ht, Tabs as Ut, TextInput as Wt, Textarea as Gt, TimeInput as Kt, ToggleButton as qt, Toolbar as Jt, ToolbarGroup as Yt, ToolbarSeparator as Xt } from "./controls.js";
import { DropdownPopupContent as Zt } from "./dropdown/content.js";
import { useDialogDrag as Qt } from "./dialog/dialog.preact.js";
import { PreactRangeSlider as z } from "./filter/filters/slider/preact.js";
import { SingleValueSlider as B, SliderField as $t } from "./filter/filters/slider/single.js";
import { renderStatusBadge as en } from "./status-feedback/badge.js";
import { StatusBadge as tn, StatusFeedbackPanel as V, renderStatusFeedbackPanel as nn } from "./status-feedback/render.js";
import { StatusFeedbackPopoverController as rn } from "./status-feedback/popover.js";
import "./status-feedback/index.js";
import { t as H } from "./_chunks/calendar-CQs8vcpq.js";
import { BarChart as an } from "./distribution-chart/bar-chart.js";
import { LineChart as on } from "./distribution-chart/line-chart.js";
import { AreaChart as sn } from "./distribution-chart/area-chart.js";
import { DistributionChart as cn } from "./distribution-chart/index.js";
import { BrushRange as ln } from "./brush-range/component.js";
import { Legend as un } from "./legend.js";
import { HighlightedTextInput as dn, InlineFieldGroup as fn, OptionButton as pn } from "./filter-controls.js";
import { TimeGrid as mn, timeGridCellKey as hn, useTimeGridInteraction as gn } from "./time-grid.js";
import { fieldDropIndex as _n, reorderFields as vn } from "./field-reorder.js";
import { useFieldDropTarget as yn, useFieldReorder as bn } from "./field-reorder.hook.js";
import { FieldActions as xn, FieldContent as Sn, FieldDropIndicator as Cn, FieldGroup as wn, FieldGroupHeading as Tn, FieldIcon as En, FieldItem as Dn, FieldLibrary as On, FieldLibraryList as kn, FieldList as An, FieldRemoveButton as jn, FieldRemoveIcon as Mn, FieldRow as Nn, FieldStatusBadge as Pn, FieldSummary as Fn, SelectedField as In } from "./field-configurator.js";
import { ComparisonPreview as Ln, IconChoiceGroup as Rn, IconToggleButton as zn, InspectorSection as Bn, TypographyControls as Vn } from "./formatting/index.js";
import { n as Hn, t as Un } from "./_chunks/reorder-list-BV3kZXso.js";
import { eventOutsideRange as Wn, moveTimelineEvent as Gn, niceTimelineStep as Kn, resizeTimelineEvent as qn, timelineGeometry as Jn } from "./timeline-track/model.js";
import { TimelineTrack as Yn } from "./timeline-track/index.js";
import { h as U } from "preact";
import { createPortal as W } from "preact/compat";
import { Fragment as G, jsx as K, jsxs as q } from "preact/jsx-runtime";
import { useLayoutEffect as J, useRef as Y, useState as X } from "preact/hooks";
//#region src/pickers.tsx
function Xn(e) {
	return /* @__PURE__ */ K(I, {
		...e,
		className: `rv-combobox ${e.className ?? ""}`,
		config: {
			...e.config,
			search: !0,
			multiSelect: !1
		}
	});
}
function Zn(e) {
	return /* @__PURE__ */ K(I, {
		...e,
		className: `rv-multi-select ${e.className ?? ""}`,
		config: {
			...e.config,
			multiSelect: !0
		}
	});
}
function Z(e) {
	return f(U, e);
}
function Qn(e) {
	return se(U, e);
}
function Q({ open: e, anchor: t, onClose: n, children: r, label: i, className: a = "", role: o = "dialog" }) {
	let s = Y(null), c = Y(n);
	return c.current = n, J(() => {
		if (!e || !t || !s.current) return;
		let n = s.current, r = new ie(), i = !0;
		r.open({
			anchor: t,
			content: s.current,
			display: o === "menu" ? "grid" : void 0,
			onClose: () => {
				i && c.current();
			}
		});
		let a = o === "menu" ? oe(n, () => r.close()) : void 0;
		return () => {
			i = !1, a?.(), r.destroy(), n.hidden = !0;
		};
	}, [
		e,
		t,
		o
	]), /* @__PURE__ */ K("div", {
		ref: s,
		class: `rv-popover ${o === "menu" ? "rv-menu " : ""}${a}`,
		role: o,
		"aria-label": i,
		hidden: !e,
		children: e ? r : null
	});
}
function $n({ text: e, children: t }) {
	let n = Y(null);
	return J(() => {
		let t = n.current?.querySelector("button, input, a[href], [tabindex]") ?? n.current;
		if (!t) return;
		let r = new ae();
		return r.bind(t, e), () => r.destroy();
	}, [e]), /* @__PURE__ */ K("span", {
		ref: n,
		class: "rv-tooltip-anchor",
		children: t
	});
}
function $({ open: e, title: t, closeLabel: n, onClose: r, children: i, footer: a, draggable: o, returnFocus: s }) {
	let c = Y(null), l = Y(r);
	l.current = r;
	let [u, d] = X();
	return J(() => {
		if (!e || !c.current) {
			d(void 0);
			return;
		}
		let r = new re(c.current.ownerDocument), i = !0, a = r.open({
			title: t,
			closeLabel: n,
			draggable: o,
			returnFocus: s,
			surfaceClass: "rv-ui-dialog",
			onClose: () => {
				d(void 0), i && l.current();
			}
		});
		return d({
			body: a.body,
			footer: a.footer
		}), () => {
			i = !1, r.destroy();
		};
	}, [
		e,
		t,
		n,
		o,
		s
	]), /* @__PURE__ */ q(G, { children: [
		/* @__PURE__ */ K("span", {
			ref: c,
			hidden: !0
		}),
		u && W(i, u.body),
		u && a && W(a, u.footer)
	] });
}
function er({ onConfirm: e, confirmLabel: t, cancelLabel: n, pending: r, ...i }) {
	return /* @__PURE__ */ K($, {
		...i,
		footer: /* @__PURE__ */ q(G, { children: [/* @__PURE__ */ K(L, {
			disabled: r,
			onClick: i.onClose,
			children: n
		}), /* @__PURE__ */ K(L, {
			variant: "primary",
			disabled: r,
			onClick: e,
			children: t
		})] })
	});
}
function tr({ value: t, onChange: n, label: r, openLabel: i, disabled: a, readOnly: o, ...s }) {
	let [c, l] = X(!1), [u, d] = X(null), [f, p] = X(t && A(t) ? t : M()), [m, h] = X(j(f, s.calendarSystem)), [g] = X(() => e("rv-date-picker"));
	return J(() => {
		(a || o) && l(!1);
	}, [a, o]), /* @__PURE__ */ q("div", {
		class: "rv-date-picker",
		children: [
			/* @__PURE__ */ K(R, {
				"aria-label": r,
				value: t ?? "",
				min: s.minDate,
				max: s.maxDate,
				disabled: a,
				readOnly: o,
				onValueChange: (e) => {
					(!e || A(e)) && n(e || void 0);
				}
			}),
			/* @__PURE__ */ K(L, {
				ref: d,
				"aria-label": i,
				"aria-haspopup": "dialog",
				"aria-expanded": c,
				"aria-controls": g,
				disabled: a || o,
				onClick: () => {
					t && A(t) && (p(t), h(j(t, s.calendarSystem))), l(!c);
				},
				children: /* @__PURE__ */ K(S, { svg: H })
			}),
			/* @__PURE__ */ K(Q, {
				open: c,
				anchor: u,
				onClose: () => l(!1),
				label: r,
				children: /* @__PURE__ */ K("div", {
					id: g,
					children: /* @__PURE__ */ K(P, {
						...s,
						month: m,
						focusedDate: f,
						selection: t ? {
							from: t,
							to: t
						} : void 0,
						onMonthChange: h,
						onFocusedDateChange: p,
						onSelect: (e) => {
							n(e), l(!1), u?.focus();
						}
					})
				})
			})
		]
	});
}
function nr({ value: t, onChange: n, label: r, fromLabel: i, toLabel: a, openLabel: o, disabled: s, readOnly: c, ...l }) {
	let [u, d] = X(!1), [f, p] = X(null), [m, h] = X(), [g, _] = X(t?.from ?? M()), [v, y] = X(j(g, l.calendarSystem)), [b] = X(() => e("rv-date-picker"));
	J(() => {
		(s || c) && (d(!1), h(void 0));
	}, [s, c]);
	let x = (e, r) => {
		if (!A(r)) return;
		let i = r;
		n(N(e === "from" ? i : t?.from ?? i, e === "to" ? i : t?.to ?? i));
	};
	return /* @__PURE__ */ q("div", {
		class: "rv-date-range-picker",
		role: "group",
		"aria-label": r,
		children: [
			/* @__PURE__ */ K(R, {
				"aria-label": i,
				value: t?.from ?? "",
				disabled: s,
				readOnly: c,
				min: l.minDate,
				max: l.maxDate,
				onValueChange: (e) => x("from", e)
			}),
			/* @__PURE__ */ K(R, {
				"aria-label": a,
				value: t?.to ?? "",
				disabled: s,
				readOnly: c,
				min: l.minDate,
				max: l.maxDate,
				onValueChange: (e) => x("to", e)
			}),
			/* @__PURE__ */ K(L, {
				ref: p,
				disabled: s || c,
				"aria-label": o,
				"aria-haspopup": "dialog",
				"aria-expanded": u,
				"aria-controls": b,
				onClick: () => {
					h(void 0), t && (_(t.from), y(j(t.from, l.calendarSystem))), d(!u);
				},
				children: /* @__PURE__ */ K(S, { svg: H })
			}),
			/* @__PURE__ */ K(Q, {
				open: u,
				anchor: f,
				onClose: () => {
					d(!1), h(void 0);
				},
				label: r,
				children: /* @__PURE__ */ K("div", {
					id: b,
					children: /* @__PURE__ */ K(P, {
						...l,
						month: v,
						focusedDate: g,
						selection: m ? N(m, g) : t,
						onMonthChange: y,
						onFocusedDateChange: _,
						onSelect: (e) => {
							m ? (n(N(m, e)), h(void 0), d(!1), f?.focus()) : h(e);
						}
					})
				})
			})
		]
	});
}
//#endregion
export { ze as ActivityMessage, ce as Alert, sn as AreaChart, Z as Avatar, ht as Badge, an as BarChart, ln as BrushRange, L as Button, gt as ButtonGroup, P as Calendar, it as CalendarDay, rt as CalendarHeader, at as CalendarMonthGrid, st as CalendarPicker, nt as CalendarWeekdays, ot as CalendarYearGrid, Ve as Checkbox, _t as Chip, Ie as ChoiceChip, Pe as ChoiceChipInfoButton, Fe as ChoiceChips, vt as CircularProgress, Te as ColorPalette, ke as ColorPicker, Xn as Combobox, Ln as ComparisonPreview, er as ConfirmDialog, De as ControlTooltip, yt as CountBadge, Xe as DEFAULT_CALENDAR_TRANSLATIONS, Oe as DEFAULT_COLOR_PALETTE_OPTIONS, R as DateInput, tr as DatePicker, nr as DateRangePicker, bt as DateTimeInput, Me as DeleteButton, $ as Dialog, x as DialogActionFooter, _ as DialogActions, y as DialogBody, h as DialogCloseButton, p as DialogFooter, v as DialogForm, b as DialogHeader, m as DialogTitleInput, xt as Disclosure, qe as DisclosureSummary, cn as DistributionChart, I as Dropdown, ft as DropdownPopup, Zt as DropdownPopupContent, g as EditableDialogHeader, w as EditorList, w as Listbox, T as EditorListGroup, T as ListboxGroup, E as EditorListItem, E as ListboxOption, D as EditorListItemContent, D as ListboxOptionContent, O as EditorPane, O as Pane, k as EditorSplitLayout, k as SplitLayout, St as EmptyState, V as FeedbackPanel, V as StatusFeedbackPanel, xn as FieldActions, Sn as FieldContent, Cn as FieldDropIndicator, Ct as FieldError, wn as FieldGroup, Tn as FieldGroupHeading, wt as FieldHint, En as FieldIcon, Dn as FieldItem, On as FieldLibrary, kn as FieldLibraryList, An as FieldList, jn as FieldRemoveButton, Mn as FieldRemoveIcon, Nn as FieldRow, Pn as FieldStatusBadge, Fn as FieldSummary, Le as FilterBadge, Re as FilterBadgeInfoButton, C as FilterChip, C as RemovableChip, Je as FormField, Tt as FormSection, dn as HighlightedTextInput, S as Icon, S as SvgIcon, Et as IconButton, Rn as IconChoiceGroup, zn as IconToggleButton, fn as InlineFieldGroup, c as Input, Bn as InspectorSection, un as Legend, on as LineChart, Dt as LoadingOverlay, Ot as Menu, kt as MenuItem, At as MenuSeparator, Zn as MultiSelect, jt as NativeSelect, Mt as NumberInput, Nt as NumberStepper, pn as OptionButton, Pt as Pagination, Ft as Panel, Q as Popover, z as PreactRangeSlider, z as RangeSlider, Qn as ProgressBar, It as RadioGroup, Lt as Rating, je as RatingChoice, Ae as RatingStar, Ne as RemoveButton, Un as ReorderHandle, Hn as ReorderList, Rt as ResizeHandle, F as ResourcePicker, F as SharedResourcePicker, ct as ResourcePickerAvatar, He as SHARED_CHECKBOX_CLASS, Ke as SearchInput, zt as SegmentedControl, Ge as SegmentedSwitch, In as SelectedField, B as SingleValueSlider, B as Slider, $t as SliderField, Bt as Spinner, tn as StatusBadge, rn as StatusFeedbackPopoverController, Vt as Submenu, Be as SvgButton, We as Switch, Ht as TabPanel, Ut as Tabs, Wt as TextInput, Gt as Textarea, mn as TimeGrid, Kt as TimeInput, Yn as TimelineTrack, qt as ToggleButton, Jt as Toolbar, Yt as ToolbarGroup, Xt as ToolbarSeparator, $n as Tooltip, Vn as TypographyControls, t as controlAttributes, n as controlClassName, tt as createCalendarMonth, r as createControl, l as createFormField, u as createSelectControl, d as createTextControl, i as decorateIconAction, pt as defineDropdown, mt as destroyDropdown, Wn as eventOutsideRange, _n as fieldDropIndex, _e as formatTimelineEvents, lt as getResourcePickerColor, ut as getResourcePickerForegroundColor, dt as getResourcePickerInitials, ee as getUiMotionDuration, te as inheritUiMotion, $e as isCalendarDateDisabled, et as isCalendarMonthDisabled, Qe as isDateInCalendarRange, ne as isUiMotionEnabled, Ze as moveCalendarFocus, Gn as moveTimelineEvent, a as nativeControlTag, Kn as niceTimelineStep, we as normalizeHexColor, N as orderCalendarRange, o as registerControl, xe as renderAggregateSummary, ue as renderBadgeValue, he as renderChange, Ue as renderCheckbox, s as renderControl, Ye as renderFormFieldContent, me as renderHeatmap, Ce as renderLabelledIcon, le as renderMiniBarChart, de as renderPercentageSummary, Se as renderPie, fe as renderProgressLine, ye as renderProgressLineValue, ve as renderSparkline, en as renderStatusBadge, nn as renderStatusFeedbackPanel, ge as renderThumbs, be as renderTimeline, pe as renderTypeIcon, vn as reorderFields, qn as resizeTimelineEvent, hn as timeGridCellKey, Jn as timelineGeometry, Ee as useControlTooltip, Qt as useDialogDrag, yn as useFieldDropTarget, bn as useFieldReorder, gn as useTimeGridInteraction };
