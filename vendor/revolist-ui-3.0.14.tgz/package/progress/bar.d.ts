export interface ProgressBarProps {
    value: number;
    min?: number;
    max?: number;
    ariaLabel?: string;
    className?: string;
    fillClass?: string | Record<string, boolean>;
}
type ProgressHyperFunc = (tag: string, props: Record<string, unknown>, children?: any[]) => any;
/** Shared framework-neutral progress primitive used by chart cell renderers. */
export declare function renderProgressBar(h: ProgressHyperFunc, { value, min, max, ariaLabel, className, fillClass, }: ProgressBarProps): any;
export {};
