import { normalizeProgressRange as e } from "./range.js";
//#region src/progress/bar.ts
function t(e) {
	return typeof e == "string" ? `rv-progress-bar__fill ${e}` : ["rv-progress-bar__fill", ...Object.entries(e ?? {}).filter(([, e]) => e).map(([e]) => e)].join(" ");
}
function n(n, { value: r, min: i = 0, max: a = 100, ariaLabel: o, className: s, fillClass: c }) {
	let l = e(r, i, a), u = Number(l.percent.toFixed(8));
	return n("div", {
		class: ["rv-progress-bar", s].filter(Boolean).join(" "),
		role: "progressbar",
		"aria-valuemin": l.min,
		"aria-valuemax": l.max,
		"aria-valuenow": Math.min(l.max, Math.max(l.min, r)),
		"aria-label": o
	}, [n("span", { class: "rv-progress-bar__track" }, [n("span", {
		class: t(c),
		style: { width: `${u}%` }
	})])]);
}
//#endregion
export { n as renderProgressBar };
