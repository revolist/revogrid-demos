import { ElementFactory } from '../native-controls';
export declare function renderCircularProgress<H extends ElementFactory>(h: H, options: {
    percent: number;
    thresholdClasses?: Record<string, boolean>;
    showValue?: boolean;
    formattedValue?: string;
}): ReturnType<H>;
