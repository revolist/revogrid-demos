import { controlClassName as e } from "../control-presentation.js";
//#region src/progress/circular.ts
function t(t, n) {
	return t("div", { class: "circular-progress-container" }, [t("div", { class: "circular-progress" }, [t("svg", {
		class: "circular-progress-svg",
		viewBox: "0 0 36 36"
	}, [t("path", {
		class: "circular-progress-bg",
		d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
	}), t("path", {
		class: e("circular-progress-path", n.thresholdClasses),
		d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
		style: { "stroke-dasharray": `${n.percent}, 100` }
	})]), n.showValue && t("div", { class: "circular-progress-value" }, n.formattedValue)])]);
}
//#endregion
export { t as renderCircularProgress };
