export interface NormalizedProgressRange {
    readonly min: number;
    readonly max: number;
    readonly percent: number;
}
/** Normalize a numeric value into a finite, clamped 0–100 progress range. */
export declare function normalizeProgressRange(value: unknown, configuredMin?: unknown, configuredMax?: unknown): NormalizedProgressRange;
