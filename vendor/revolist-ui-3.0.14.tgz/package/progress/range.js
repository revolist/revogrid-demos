//#region src/progress/range.ts
function e(e, n = 0, r = 100) {
	let i = t(n, 0), a = t(r, 100), o = Math.min(i, a), s = Math.max(i, a), c = t(e, o);
	return {
		min: o,
		max: s,
		percent: o === s ? c >= s ? 100 : 0 : (Math.min(s, Math.max(o, c)) - o) / (s - o) * 100
	};
}
function t(e, t) {
	let n = Number(e);
	return Number.isFinite(n) ? n : t;
}
//#endregion
export { e as normalizeProgressRange };
