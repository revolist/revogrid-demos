import { h, JSX } from 'preact';
export declare function RatingStar({ filled }: {
    filled: boolean;
}): h.JSX.Element;
/** Native radio-style choice for rating domains, including fractional values. */
export declare function RatingChoice({ filled, selected, label, className, ...props }: Omit<JSX.IntrinsicElements['button'], 'class' | 'className' | 'children'> & {
    filled: boolean;
    selected: boolean;
    label: string;
    className?: string;
}): h.JSX.Element;
