export { t as RatingChoice, n as RatingStar } from "./_chunks/rating-choice-BX20k8iz.js";
