import { controlAttributes as e } from "./control-presentation.js";
import { createElement as t, forwardRef as n } from "react";
//#region src/react-control.ts
function r(r) {
	let i = n((n, i) => {
		let { class: a, ...o } = e(r, n);
		return t(r, {
			...o,
			className: a,
			ref: i
		});
	});
	return i.displayName = `Ui${r[0].toUpperCase()}${r.slice(1)}`, i;
}
var i = r("button"), a = r("input"), o = r("select"), s = r("textarea"), c = r("summary");
//#endregion
export { i as ButtonControl, a as Input, o as Select, c as Summary, s as TextArea };
