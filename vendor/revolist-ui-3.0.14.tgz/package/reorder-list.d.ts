import { h, ComponentChildren, JSX } from 'preact';
export interface ReorderListProps<T> {
    items: readonly T[];
    itemKey(item: T): string | number;
    renderItem(item: T, index: number): ComponentChildren;
    renderHandle?(item: T, index: number): ComponentChildren;
    itemAttributes?(item: T, index: number): JSX.HTMLAttributes<HTMLDivElement> & Record<string, unknown>;
    className?: string;
    rowClassName?: string | ((item: T, index: number) => string);
    endClassName?: string;
    draggedKey?: string | number;
    dropIndex?: number;
    empty?: ComponentChildren;
    onDragOver(event: DragEvent, boundary: number): void;
    onDrop(event: DragEvent, boundary: number): void;
}
/** Shared list geometry, event routing and insertion markers. Consumers own move policy and data. */
export declare function ReorderList<T>({ items, itemKey, renderItem, renderHandle, itemAttributes, className, rowClassName, endClassName, draggedKey, dropIndex, empty, onDragOver, onDrop }: ReorderListProps<T>): h.JSX.Element;
/** Native drag source; product adapters supply stable IDs, announcements and keyboard move policy. */
export declare function ReorderHandle({ className, children, ...props }: JSX.IntrinsicElements['button']): h.JSX.Element;
