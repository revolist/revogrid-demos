import { ResourcePickerAvatar as e, getResourcePickerColor as t, getResourcePickerForegroundColor as n, getResourcePickerInitials as r } from "./resource-picker-avatar.js";
import { SharedResourcePicker as i } from "./resource-picker.js";
export { e as ResourcePickerAvatar, i as SharedResourcePicker, t as getResourcePickerColor, n as getResourcePickerForegroundColor, r as getResourcePickerInitials };
