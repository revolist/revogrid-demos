import { h } from 'preact';
import { ResourcePickerId, ResourcePickerItem } from './resource-picker.types';
export interface ResourcePickerAvatarProps<Id extends ResourcePickerId> {
    readonly resource: ResourcePickerItem<Id>;
    readonly className?: string;
    readonly color?: string;
}
export declare function getResourcePickerInitials(name: string): string;
export declare function getResourcePickerColor(id: ResourcePickerId): string;
/**
 * Chooses readable initials for hex avatar colors. Unknown CSS color formats
 * retain the picker's dark foreground fallback instead of guessing.
 */
export declare function getResourcePickerForegroundColor(background: string): string;
export declare function ResourcePickerAvatar<Id extends ResourcePickerId>({ resource, className, color, }: ResourcePickerAvatarProps<Id>): h.JSX.Element;
