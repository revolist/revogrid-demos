import { getAvatarInitials as e } from "../avatar/index.js";
import { resourcePickerClasses as t } from "./resource-picker.utils.js";
import { jsx as n } from "preact/jsx-runtime";
import { useState as r } from "preact/hooks";
//#region src/resource-picker/resource-picker-avatar.tsx
var i = [
	"#22d3ee",
	"#34d399",
	"#facc15",
	"#fb7185",
	"#a78bfa",
	"#60a5fa",
	"#f97316",
	"#2dd4bf"
];
function a(t) {
	return e(t) || "?";
}
function o(e) {
	return i[[...String(e)].reduce((e, t) => e + t.charCodeAt(0), 0) % i.length];
}
function s(e) {
	let t = e.trim().match(/^#([\da-f]{3}|[\da-f]{6})$/i)?.[1];
	if (!t) return "#0f172a";
	let n = t.length === 3 ? [...t].map((e) => e.repeat(2)).join("") : t, r = [
		0,
		2,
		4
	].map((e) => Number.parseInt(n.slice(e, e + 2), 16) / 255).map((e) => e <= .04045 ? e / 12.92 : ((e + .055) / 1.055) ** 2.4).reduce((e, t, n) => e + t * ([
		.2126,
		.7152,
		.0722
	][n] ?? 0), 0);
	return r <= .179 ? "#fff" : r < .25 ? "#000" : "#0f172a";
}
function c({ resource: e, className: i, color: c }) {
	let [l, u] = r(), d = e.name.trim() || "Unnamed resource", f = !!e.avatarUrl && l === e.avatarUrl, p = c ?? e.color ?? o(e.id);
	return /* @__PURE__ */ n("span", {
		class: t("avatar-cell rv-resource-picker__avatar", i),
		style: {
			"--avatar-cell-background": p,
			"--avatar-cell-size": "30px",
			"--rv-resource-picker-avatar-color": s(p)
		},
		role: "img",
		"aria-label": d,
		children: e.avatarUrl && !f ? /* @__PURE__ */ n("img", {
			class: "avatar-cell__image",
			src: e.avatarUrl,
			alt: d,
			onError: () => u(e.avatarUrl)
		}) : a(e.name)
	});
}
//#endregion
export { c as ResourcePickerAvatar, o as getResourcePickerColor, s as getResourcePickerForegroundColor, a as getResourcePickerInitials };
