import { h } from 'preact';
import { ResourcePickerClassNames, ResourcePickerId, ResourcePickerItem } from './resource-picker.types';
export interface ResourcePickerOptionProps<Id extends ResourcePickerId, Resource extends ResourcePickerItem<Id>> {
    readonly resource: Resource;
    readonly selected: boolean;
    readonly selectedResourceIds: readonly Id[];
    readonly disabled: boolean;
    readonly readOnly?: boolean;
    readonly multiple: boolean;
    readonly resourceDataAttribute?: string;
    readonly classNames?: ResourcePickerClassNames;
    readonly isResourceDisabled?: (resource: Resource) => boolean;
    readonly getAvatarColor?: (resource: Resource) => string | undefined;
    readonly optionId?: string;
    readonly focused?: boolean;
    readonly onFocus?: () => void;
    readonly onChange: (resourceIds: readonly Id[]) => void;
}
export declare function ResourcePickerOption<Id extends ResourcePickerId, Resource extends ResourcePickerItem<Id>>({ resource, selected, selectedResourceIds, disabled, readOnly, multiple, resourceDataAttribute, classNames, isResourceDisabled, getAvatarColor, optionId, focused, onFocus, onChange, }: ResourcePickerOptionProps<Id, Resource>): h.JSX.Element;
