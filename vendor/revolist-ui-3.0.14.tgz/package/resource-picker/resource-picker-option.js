import { resourcePickerClasses as e, resourcePickerDataAttribute as t, resourcePickerIdKey as n, uniqueResourcePickerIds as r } from "./resource-picker.utils.js";
import { ResourcePickerAvatar as i } from "./resource-picker-avatar.js";
import { jsx as a, jsxs as o } from "preact/jsx-runtime";
//#region src/resource-picker/resource-picker-option.tsx
function s({ resource: s, selected: c, selectedResourceIds: l, disabled: u, readOnly: d = !1, multiple: f, resourceDataAttribute: p, classNames: m, isResourceDisabled: h, getAvatarColor: g, optionId: _, focused: v = !1, onFocus: y, onChange: b }) {
	let x = h?.(s) === !0;
	return /* @__PURE__ */ o("label", {
		class: e("rv-resource-picker__option", d ? "rv-resource-picker__option--readonly" : void 0, v ? "rv-resource-picker__option--focused" : void 0, m?.option),
		id: d ? _ : void 0,
		role: d && _ ? "option" : void 0,
		"aria-selected": d && _ ? c : void 0,
		"data-selected": c ? "true" : "false",
		onMouseEnter: y,
		children: [
			!d && /* @__PURE__ */ a("input", {
				type: "checkbox",
				id: _,
				role: _ ? "option" : void 0,
				"aria-selected": _ ? c : void 0,
				checked: c,
				disabled: u || x && !c,
				...t(p, String(s.id)),
				onChange: (e) => {
					let t = e.currentTarget;
					b(t.checked ? f ? r([...l, s.id]) : [s.id] : l.filter((e) => n(e) !== n(s.id)));
				}
			}),
			/* @__PURE__ */ a(i, {
				resource: s,
				className: m?.avatar,
				color: g?.(s)
			}),
			/* @__PURE__ */ o("span", {
				class: e("rv-resource-picker__details", m?.details),
				children: [/* @__PURE__ */ a("strong", { children: s.name }), s.role ? /* @__PURE__ */ a("em", { children: s.role }) : null]
			})
		]
	});
}
//#endregion
export { s as ResourcePickerOption };
