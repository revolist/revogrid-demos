import { h, ComponentChildren, RefObject } from 'preact';
type ResourcePickerPopupProps = {
    readonly triggerRef: RefObject<HTMLDivElement>;
    readonly portalTarget: HTMLElement;
    readonly popupId: string;
    readonly children: ComponentChildren;
};
/** Keep resource selection policy in the picker and geometry in the shared popup. */
export declare function ResourcePickerPopup({ triggerRef, portalTarget, popupId, children, }: ResourcePickerPopupProps): h.JSX.Element;
export {};
