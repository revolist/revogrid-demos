import { DropdownPopup as e } from "../dropdown/popup.js";
import { jsx as t } from "preact/jsx-runtime";
//#region src/resource-picker/resource-picker-popup.tsx
function n({ triggerRef: n, portalTarget: r, popupId: i, children: a }) {
	return /* @__PURE__ */ t(e, {
		triggerRef: n,
		portalTarget: r,
		dropdownMenuId: i,
		popupClassName: "rv-resource-picker__portal",
		matchTriggerWidth: !0,
		onPointerRelease: (e) => {
			e.type === "mouseup" ? e.preventDefault() : e.stopPropagation();
		},
		children: a
	});
}
//#endregion
export { n as ResourcePickerPopup };
