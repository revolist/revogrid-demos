import { h } from 'preact';
import { ResourcePickerId, ResourcePickerItem, SharedResourcePickerProps } from './resource-picker.types';
export declare function SharedResourcePicker<Id extends ResourcePickerId, Resource extends ResourcePickerItem<Id>>({ resources, selectedResourceIds, text, onChange, classNames, disabled, readOnly, presentation, multiple, preserveOrder, unassigned, resourceDataAttribute, isResourceDisabled, getAvatarColor, }: SharedResourcePickerProps<Id, Resource>): h.JSX.Element;
