import { createControlId as e } from "../core/control-id.js";
import { t } from "../_chunks/xmark-DD_PBvZI.js";
import { t as n } from "../_chunks/chevron-down-GbplLa6s.js";
import { SearchInput as r } from "../search-input/index.js";
import { resourcePickerClasses as i, resourcePickerDataAttribute as a, resourcePickerIdKey as o } from "./resource-picker.utils.js";
import { ResourcePickerAvatar as s } from "./resource-picker-avatar.js";
import { ResourcePickerOption as c } from "./resource-picker-option.js";
import { ResourcePickerPopup as l } from "./resource-picker-popup.js";
import { jsx as u, jsxs as d } from "preact/jsx-runtime";
import { useCallback as ee, useEffect as f, useMemo as p, useRef as m, useState as h } from "preact/hooks";
//#region src/resource-picker/resource-picker.tsx
function g({ resources: g, selectedResourceIds: y, text: b, onChange: x, classNames: S, disabled: C = !1, readOnly: w = !1, presentation: te = "inline", multiple: T = !0, preserveOrder: E = !1, unassigned: D, resourceDataAttribute: O, isResourceDisabled: k, getAvatarColor: A }) {
	let j = m(null), M = m(null), N = m(null), P = m(null), F = m(!1), [I] = h(() => e("rv-resource-list")), L = `${I}-popup`, R = te === "dropdown", [z, B] = h(!1), [V, H] = h(""), [U, W] = h(0), G = ee(() => {
		B(!1), H("");
	}, []), K = new Set(y.map(o)), q = p(() => E ? [...g] : [...g].sort((e, t) => e.name.localeCompare(t.name, void 0, {
		numeric: !0,
		sensitivity: "base"
	})), [E, g]), J = p(() => {
		let e = V.trim().toLocaleLowerCase();
		return e ? q.filter((t) => `${t.name} ${t.role ?? ""}`.toLocaleLowerCase().includes(e)) : q;
	}, [V, q]), Y = p(() => {
		let e = new Map(g.map((e) => [o(e.id), e]));
		return y.map((t) => e.get(o(t))).filter((e) => !!e);
	}, [g, y]), X = R && U >= 0 && U < J.length ? `${I}-option-${U}` : void 0;
	f(() => {
		if (!R || !z) return;
		let e = (e) => {
			let t = e.target, n = j.current?.ownerDocument.getElementById(L);
			!j.current?.contains(t) && !n?.contains(t) && G();
		}, t = (e) => {
			let t = j.current?.ownerDocument.getElementById(L), n = e.target;
			n instanceof Node && t?.contains(n) || G();
		}, n = () => G();
		document.addEventListener("pointerdown", e), document.addEventListener("scroll", t, !0), window.addEventListener("resize", n);
		let r = window.requestAnimationFrame(() => N.current?.focus());
		return () => {
			document.removeEventListener("pointerdown", e), document.removeEventListener("scroll", t, !0), window.removeEventListener("resize", n), window.cancelAnimationFrame(r);
		};
	}, [
		G,
		R,
		z,
		L
	]), f(() => {
		W(J.length > 0 ? 0 : -1);
	}, [J]), f(() => {
		if (!z || !X || !P.current || !F.current) return;
		let e = P.current.ownerDocument.getElementById(X);
		e && P.current.contains(e) && e.closest(".rv-resource-picker__option")?.scrollIntoView?.({ block: "nearest" });
	}, [X, z]);
	let Z = (e) => {
		w || (x(e), !T && R && G());
	}, ne = () => {
		let e = J[U];
		if (!e) return;
		let t = o(e.id);
		(!k?.(e) || K.has(t)) && Z(K.has(t) ? y.filter((e) => o(e) !== t) : T ? _([...y, e.id]) : [e.id]);
	}, re = (e) => {
		if (e.key === "Escape") e.preventDefault(), e.stopPropagation(), G(), M.current?.focus();
		else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
			if (e.preventDefault(), e.stopPropagation(), !J.length) return;
			F.current = !0, W((t) => e.key === "ArrowDown" ? t >= J.length - 1 ? 0 : t + 1 : t <= 0 ? J.length - 1 : t - 1);
		} else e.key === "Enter" && (e.preventDefault(), e.stopPropagation(), ne());
	}, Q = typeof document > "u" ? null : j.current?.closest("dialog, .rv-dialog-overlay") ?? document.body, $ = /* @__PURE__ */ d("div", {
		class: "rv-resource-picker__popover",
		onKeyDown: R ? re : void 0,
		children: [/* @__PURE__ */ u(r, {
			inputRef: N,
			rootClassName: "rv-resource-picker__search-control",
			inputClassName: i("rv-resource-picker__search", S?.search),
			value: V,
			disabled: C,
			placeholder: b.searchPlaceholder,
			"aria-label": b.searchAriaLabel,
			onValueChange: H
		}), /* @__PURE__ */ d("div", {
			ref: P,
			class: i("rv-resource-picker__list", S?.list),
			role: R ? "listbox" : "group",
			id: R ? I : void 0,
			"aria-multiselectable": R ? T : void 0,
			"aria-activedescendant": X,
			"aria-label": b.groupAriaLabel,
			children: [D && !w ? /* @__PURE__ */ d("label", {
				class: i("rv-resource-picker__option rv-resource-picker__option--unassigned", S?.option),
				children: [
					/* @__PURE__ */ u("input", {
						type: "checkbox",
						checked: y.length === 0,
						disabled: C,
						...a(D.dataAttribute, ""),
						onChange: () => x([])
					}),
					/* @__PURE__ */ u("span", {
						class: "rv-resource-picker__avatar-spacer",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ u("span", {
						class: i("rv-resource-picker__details", S?.details),
						children: /* @__PURE__ */ u("strong", { children: D.label })
					})
				]
			}) : null, g.length === 0 ? /* @__PURE__ */ u(v, {
				className: S?.muted,
				text: b.emptyResources
			}) : J.length === 0 ? /* @__PURE__ */ u(v, {
				className: S?.muted,
				text: b.emptySearch
			}) : J.map((e, t) => /* @__PURE__ */ u(c, {
				resource: e,
				selected: K.has(o(e.id)),
				selectedResourceIds: y,
				disabled: C,
				readOnly: w,
				multiple: T,
				resourceDataAttribute: O,
				classNames: S,
				isResourceDisabled: k,
				getAvatarColor: A,
				optionId: R ? `${I}-option-${t}` : void 0,
				focused: R && U === t,
				onFocus: () => {
					F.current = !1, W(t);
				},
				onChange: Z
			}, o(e.id)))]
		})]
	});
	return /* @__PURE__ */ d("div", {
		ref: j,
		class: i("rv-resource-picker", R ? "rv-resource-picker--dropdown" : void 0, z ? "rv-resource-picker--open" : void 0, S?.root),
		children: [R ? /* @__PURE__ */ d("div", {
			ref: M,
			class: "rv-resource-picker__control",
			role: "combobox",
			"aria-expanded": z,
			"aria-controls": I,
			"aria-haspopup": "listbox",
			"aria-label": b.groupAriaLabel,
			tabIndex: C ? -1 : 0,
			onClick: (e) => {
				C || (e.preventDefault(), z ? G() : B(!0));
			},
			onKeyDown: (e) => {
				C || e.target !== e.currentTarget || (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") && (e.preventDefault(), B(!0));
			},
			children: [/* @__PURE__ */ u("div", {
				class: "rv-resource-picker__chips",
				children: Y.length ? Y.map((e) => /* @__PURE__ */ d("span", {
					class: "rv-resource-picker__chip",
					children: [
						/* @__PURE__ */ u(s, {
							resource: e,
							className: S?.avatar,
							color: A?.(e)
						}),
						/* @__PURE__ */ u("span", {
							class: "rv-resource-picker__chip-label",
							children: e.name
						}),
						!C && !w ? /* @__PURE__ */ u("button", {
							type: "button",
							class: "rv-resource-picker__chip-remove",
							"aria-label": `Remove ${e.name}`,
							onClick: (t) => {
								t.stopPropagation(), x(y.filter((t) => o(t) !== o(e.id)));
							},
							children: /* @__PURE__ */ u("span", {
								"aria-hidden": "true",
								dangerouslySetInnerHTML: { __html: t }
							})
						}) : null
					]
				}, o(e.id))) : /* @__PURE__ */ u("span", {
					class: "rv-resource-picker__placeholder",
					children: b.searchPlaceholder
				})
			}), /* @__PURE__ */ u("span", {
				class: "rv-resource-picker__chevron",
				"aria-hidden": "true",
				dangerouslySetInnerHTML: { __html: n }
			})]
		}) : null, R ? z && Q ? /* @__PURE__ */ u(l, {
			triggerRef: M,
			portalTarget: Q,
			popupId: L,
			children: $
		}) : null : $]
	});
}
function _(e) {
	return [...new Map(e.map((e) => [o(e), e])).values()];
}
function v({ className: e, text: t }) {
	return /* @__PURE__ */ u("span", {
		class: i("rv-resource-picker__empty", e),
		children: t
	});
}
//#endregion
export { g as SharedResourcePicker };
