import { ResourcePickerId } from './resource-picker.types';
export declare function resourcePickerIdKey(id: ResourcePickerId): string;
export declare function uniqueResourcePickerIds<Id extends ResourcePickerId>(ids: readonly Id[]): readonly Id[];
export declare function resourcePickerDataAttribute(attribute: string | undefined, value: string): Record<string, string>;
export declare function resourcePickerClasses(...values: readonly (string | undefined)[]): string;
