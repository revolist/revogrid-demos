//#region src/resource-picker/resource-picker.utils.ts
function e(e) {
	return String(e);
}
function t(t) {
	return [...new Map(t.map((t) => [e(t), t])).values()];
}
function n(e, t) {
	return e ? { [e]: t } : {};
}
function r(...e) {
	return e.filter(Boolean).join(" ");
}
//#endregion
export { r as resourcePickerClasses, n as resourcePickerDataAttribute, e as resourcePickerIdKey, t as uniqueResourcePickerIds };
