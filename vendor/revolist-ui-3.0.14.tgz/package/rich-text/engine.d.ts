import { LexicalEditor, TextFormatType } from 'lexical';
export type MarkdownBlock = 'paragraph' | 'h1' | 'h2' | 'quote' | 'code' | 'bullet' | 'ordered';
export interface MarkdownSelection {
    formats: TextFormatType[];
    block: MarkdownBlock | null;
    link: boolean;
}
export declare const emptyMarkdownSelection: MarkdownSelection;
export interface MarkdownEngine {
    editor: LexicalEditor;
    setMarkdown(value: string): void;
    format(mark: TextFormatType): void;
    block(value: MarkdownBlock): void;
    captureSelection(): void;
    link(value: string): boolean;
    destroy(): void;
}
/** Framework-independent Lexical adapter; consumers own toolbar and mode presentation. */
export declare function createMarkdownEngine(root: HTMLElement, markdown: string, onChange: (value: string, unsafe: boolean) => void, onSelectionChange?: (selection: MarkdownSelection) => void): MarkdownEngine;
/** Parse through Lexical so escaped/entity-encoded Markdown link URLs are checked after decoding. */
export declare function hasUnsafeMarkdownLinks(markdown: string): boolean;
