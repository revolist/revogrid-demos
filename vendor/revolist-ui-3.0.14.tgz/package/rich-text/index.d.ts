import { EditorActionText, EditorCommitOptions } from '../editor-actions';
import { MarkdownEditorText } from './translations';
export { defaultMarkdownEditorText, type MarkdownEditorText, } from './translations';
export interface MarkdownEditorProps extends EditorCommitOptions {
    value: string;
    onApply: (value: string) => void;
    onCancel: () => void;
    required?: boolean;
    maxLength?: number;
    text?: Partial<MarkdownEditorText>;
    actions?: Partial<EditorActionText>;
}
export declare function MarkdownEditor(props: MarkdownEditorProps): import("preact").JSX.Element;
export { markdownVisualIssues, isSafeMarkdownLink } from './model';
export { markdownRenderNodes, type MarkdownRenderNode } from './render-model';
