import { Input as e, TextArea as t } from "../native-control.js";
import { SvgIcon as n } from "../icons/icon.js";
import { SegmentedSwitch as r } from "../segmented-switch/index.js";
import { Button as i, ToggleButton as a, Toolbar as o, ToolbarGroup as s, ToolbarSeparator as c } from "../controls.js";
import { n as l } from "../_chunks/editor-commit-D6Rf5rGz.js";
import { EditorActions as u } from "../editor-actions.js";
import { jsx as d, jsxs as f } from "preact/jsx-runtime";
import { useEffect as p, useRef as m, useState as h } from "preact/hooks";
import { $convertFromMarkdownString as g, $convertToMarkdownString as _, HIGHLIGHT as v, TRANSFORMERS as y, registerMarkdownShortcuts as b } from "@lexical/markdown";
import { $createParagraphNode as x, $getRoot as S, $getSelection as C, $isElementNode as w, $isRangeSelection as T, $isTextNode as E, $setSelection as D, COMMAND_PRIORITY_HIGH as O, FORMAT_TEXT_COMMAND as k, PASTE_COMMAND as A, createEditor as j } from "lexical";
import { $createHeadingNode as M, $createQuoteNode as ee, $isHeadingNode as N, $isQuoteNode as P, HeadingNode as F, QuoteNode as I, registerRichText as te } from "@lexical/rich-text";
import { $isListNode as L, INSERT_ORDERED_LIST_COMMAND as ne, INSERT_UNORDERED_LIST_COMMAND as re, ListItemNode as R, ListNode as z, REMOVE_LIST_COMMAND as ie, registerList as ae } from "@lexical/list";
import { $isLinkNode as B, $toggleLink as oe, LinkNode as V } from "@lexical/link";
import { $createCodeNode as se, $isCodeNode as H, CodeNode as U } from "@lexical/code";
import { $setBlocksType as ce } from "@lexical/selection";
import { createEmptyHistoryState as le, registerHistory as ue } from "@lexical/history";
//#region src/rich-text/syntax.ts
var W = y.filter((e) => e !== v);
//#endregion
//#region src/rich-text/model.ts
function G(e) {
	let t = e.replace(/^([`~])\1{2,}[^\n]*\n[\s\S]*?^\1{3,}[^\n]*$/gm, "").replace(/`[^`\n]+`/g, ""), n = [];
	return /!\[[^\]]*\](?:\(|\[)/.test(t) && n.push("Images"), /^\s*\|?.*\|.*\n\s*\|?\s*:?-{3,}:?\s*\|/m.test(t) && n.push("Tables"), /<\/?[A-Za-z][^>]*>/.test(t) && n.push("HTML"), (/^\s*\[[^\]]+\]:\s*\S+/m.test(t) || /\[[^\]]+\]\[[^\]]*\]/.test(t)) && n.push("Reference links"), /^\s*[-*+] \[[ xX]\]/m.test(t) && n.push("Task lists"), /^ {0,3}(?:(?:\*\s*){3,}|(?:-\s*){3,}|(?:_\s*){3,})$/m.test(t) && n.push("Horizontal rules"), /^.+\n {0,3}(?:={3,}|-{3,})\s*$/m.test(t) && n.push("Alternate headings"), /(?:^|\n[ \t]*\n)(?: {4}|\t)\S/.test(t) && n.push("Indented code"), /==[^=\n]+==/.test(t) && n.push("Highlight"), /^\s*:::|\[\^[^\]]+\]/m.test(t) && n.push("Extensions"), n;
}
function K(e) {
	if (!e || /[\u0000-\u0020\u007f]/.test(e)) return !1;
	try {
		return [
			"https:",
			"http:",
			"mailto:"
		].includes(new URL(e, "https://editor.invalid/").protocol);
	} catch {
		return !1;
	}
}
//#endregion
//#region src/rich-text/engine.ts
var q = {
	formats: [],
	block: null,
	link: !1
};
function de() {
	let e = C();
	if (!T(e)) return q;
	let t = e.anchor.getNode(), n = [t, ...t.getParents()], r = n.find((e) => N(e) || P(e) || H(e) || L(e));
	return {
		formats: [
			"bold",
			"italic",
			"strikethrough",
			"code"
		].filter((t) => e.hasFormat(t)),
		block: N(r) ? r.getTag() : L(r) ? r.getListType() === "number" ? "ordered" : "bullet" : P(r) ? "quote" : H(r) ? "code" : "paragraph",
		link: n.some(B)
	};
}
function fe(e, t, n, r = () => {}) {
	let i = j({
		namespace: "RevoMarkdown",
		nodes: [
			F,
			I,
			z,
			R,
			V,
			U
		],
		onError: (e) => {
			throw e;
		},
		theme: { text: {
			bold: "rv-markdown-bold",
			italic: "rv-markdown-italic",
			strikethrough: "rv-markdown-strike",
			code: "rv-markdown-inline-code"
		} }
	});
	i.setRootElement(e);
	let a = [
		i.registerCommand(k, (e) => ![
			"bold",
			"italic",
			"strikethrough",
			"code"
		].includes(e), O),
		te(i),
		ae(i),
		ue(i, le(), 300),
		b(i, W)
	];
	a.push(i.registerCommand(A, (e) => {
		if (!e || !("clipboardData" in e) || !e.clipboardData) return !1;
		let t = e.clipboardData.getData("text/plain");
		e.preventDefault();
		let n = C();
		return T(n) && n.insertRawText(t), !0;
	}, O));
	let o = null, s = (e) => i.update(() => {
		g(e, W);
	}, {
		tag: "markdown-source",
		discrete: !0
	});
	return s(t), a.push(i.registerUpdateListener(({ editorState: e, dirtyElements: t, dirtyLeaves: i, tags: a }) => {
		e.read(() => r(de())), !(a.has("markdown-source") || !t.size && !i.size) && e.read(() => {
			let e = S().getAllTextNodes().some((e) => {
				let t = e.getParent();
				return B(t) && !K(t.getURL());
			});
			n(_(W), e);
		});
	})), {
		editor: i,
		setMarkdown: s,
		format: (e) => {
			i.dispatchCommand(k, e), i.focus();
		},
		block: (e) => {
			e === "paragraph" && i.dispatchCommand(ie, void 0), e === "bullet" || e === "ordered" ? i.dispatchCommand(e === "bullet" ? re : ne, void 0) : i.update(() => ce(C(), () => e === "paragraph" ? x() : e === "code" ? se() : e === "quote" ? ee() : M(e))), i.focus();
		},
		captureSelection: () => i.getEditorState().read(() => {
			o = C()?.clone() ?? null;
		}),
		link: (e) => K(e) ? (i.update(() => {
			o && D(o.clone()), oe(e, { rel: "noopener noreferrer" });
		}), i.focus(), !0) : !1,
		destroy: () => {
			a.forEach((e) => e()), i.setRootElement(null);
		}
	};
}
function J(e) {
	let t = j({
		namespace: "RevoMarkdownValidation",
		nodes: [
			F,
			I,
			z,
			R,
			V,
			U
		],
		onError: (e) => {
			throw e;
		}
	}), n = !1;
	return t.update(() => {
		g(e, W), n = S().getAllTextNodes().some((e) => {
			let t = e.getParent();
			return B(t) && !K(t.getURL());
		});
	}, { discrete: !0 }), n;
}
//#endregion
//#region ../../node_modules/.pnpm/@fortawesome+fontawesome-free@7.3.1/node_modules/@fortawesome/fontawesome-free/svgs/solid/bold.svg?raw
var pe = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 384 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l32 0 0 320-32 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l224 0c70.7 0 128-57.3 128-128 0-46.5-24.8-87.3-62-109.7 18.7-22.3 30-51 30-82.3 0-70.7-57.3-128-128-128L32 32zM288 160c0 35.3-28.7 64-64 64l-96 0 0-128 96 0c35.3 0 64 28.7 64 64zM128 416l0-128 128 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-128 0z\"/></svg>", me = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 384 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M128 64c0-17.7 14.3-32 32-32l192 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-58.7 0-133.3 320 64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 480c-17.7 0-32-14.3-32-32s14.3-32 32-32l58.7 0 133.3-320-64 0c-17.7 0-32-14.3-32-32z\"/></svg>", he = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M96 157.5C96 88.2 152.2 32 221.5 32L368 32c17.7 0 32 14.3 32 32s-14.3 32-32 32L221.5 96c-34 0-61.5 27.5-61.5 61.5 0 31 23.1 57.2 53.9 61l44.1 5.5 222 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l83.1 0C103 204.6 96 181.8 96 157.5zM349.2 336l65.5 0c.9 6.1 1.4 12.2 1.4 18.5 0 69.3-56.2 125.5-125.5 125.5L144 480c-17.7 0-32-14.3-32-32s14.3-32 32-32l146.5 0c34 0 61.5-27.5 61.5-61.5 0-6.4-1-12.7-2.8-18.5z\"/></svg>", ge = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 576 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M360.8 1.2c-17-4.9-34.7 5-39.6 22l-128 448c-4.9 17 5 34.7 22 39.6s34.7-5 39.6-22l128-448c4.9-17-5-34.7-22-39.6zm64.6 136.1c-12.5 12.5-12.5 32.8 0 45.3l73.4 73.4-73.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l96-96c12.5-12.5 12.5-32.8 0-45.3l-96-96c-12.5-12.5-32.8-12.5-45.3 0zm-274.7 0c-12.5-12.5-32.8-12.5-45.3 0l-96 96c-12.5 12.5-12.5 32.8 0 45.3l96 96c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 150.6 182.6c12.5-12.5 12.5-32.8 0-45.3z\"/></svg>", Y = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 448 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M0 64C0 46.3 14.3 32 32 32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-16 0 0 112 224 0 0-112-16 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-16 0 0 320 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-96 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-144-224 0 0 144 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-96 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-320-16 0C14.3 96 0 81.7 0 64z\"/></svg>", _e = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 256 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l64 0 0 320-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l192 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-352c0-17.7-14.3-32-32-32L32 32z\"/></svg>", ve = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 384 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M48 64c0-17.7 14.3-32 32-32l171 0c60.2 0 109 48.8 109 109 0 43.8-26.2 83.3-66.4 100.4l-139.1 59C119 315.4 96 350.2 96 388.7l0 27.3 224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L64 480c-17.7 0-32-14.3-32-32l0-59.3c0-64.2 38.4-122.2 97.5-147.3l139.1-59c16.6-7.1 27.4-23.4 27.4-41.4 0-24.9-20.2-45-45-45L80 96C62.3 96 48 81.7 48 64z\"/></svg>", ye = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M48 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM192 64c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L192 64zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zM48 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM96 256a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z\"/></svg>", be = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M0 72C0 58.8 10.7 48 24 48l48 0c13.3 0 24 10.7 24 24l0 104 24 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-96 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l24 0 0-80-24 0C10.7 96 0 85.3 0 72zM30.4 301.2C41.8 292.6 55.7 288 70 288l4.9 0c33.7 0 61.1 27.4 61.1 61.1 0 19.6-9.4 37.9-25.2 49.4l-24 17.5 33.2 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-90.7 0C13.1 464 0 450.9 0 434.7 0 425.3 4.5 416.5 12.1 411l70.5-51.3c3.4-2.5 5.4-6.4 5.4-10.6 0-7.2-5.9-13.1-13.1-13.1L70 336c-3.9 0-7.7 1.3-10.8 3.6L38.4 355.2c-10.6 8-25.6 5.8-33.6-4.8S-1 324.8 9.6 316.8l20.8-15.6zM224 64l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32z\"/></svg>", xe = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 448 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M0 216C0 149.7 53.7 96 120 96l8 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-8 0c-30.9 0-56 25.1-56 56l0 8 64 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64L0 216zm256 0c0-66.3 53.7-120 120-120l8 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-8 0c-30.9 0-56 25.1-56 56l0 8 64 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-136z\"/></svg>", Se = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 384 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M0 64C0 28.7 28.7 0 64 0L213.5 0c17 0 33.3 6.7 45.3 18.7L365.3 125.3c12 12 18.7 28.3 18.7 45.3L384 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm208-5.5l0 93.5c0 13.3 10.7 24 24 24L325.5 176 208 58.5zM154.2 295.6c8.6-10.1 7.5-25.2-2.6-33.8s-25.2-7.5-33.8 2.6l-48 56c-7.7 9-7.7 22.2 0 31.2l48 56c8.6 10.1 23.8 11.2 33.8 2.6s11.2-23.8 2.6-33.8l-34.6-40.4 34.6-40.4zm112-31.2c-8.6-10.1-23.8-11.2-33.8-2.6s-11.2 23.8-2.6 33.8l34.6 40.4-34.6 40.4c-8.6 10.1-7.5 25.2 2.6 33.8s25.2 7.5 33.8-2.6l48-56c7.7-9 7.7-22.2 0-31.2l-48-56z\"/></svg>", Ce = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 576 512\"><!--! Font Awesome Free 7.3.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2026 Fonticons, Inc. --><path fill=\"currentColor\" d=\"M419.5 96c-16.6 0-32.7 4.5-46.8 12.7-15.8-16-34.2-29.4-54.5-39.5 28.2-24 64.1-37.2 101.3-37.2 86.4 0 156.5 70 156.5 156.5 0 41.5-16.5 81.3-45.8 110.6l-71.1 71.1c-29.3 29.3-69.1 45.8-110.6 45.8-86.4 0-156.5-70-156.5-156.5 0-1.5 0-3 .1-4.5 .5-17.7 15.2-31.6 32.9-31.1s31.6 15.2 31.1 32.9c0 .9 0 1.8 0 2.6 0 51.1 41.4 92.5 92.5 92.5 24.5 0 48-9.7 65.4-27.1l71.1-71.1c17.3-17.3 27.1-40.9 27.1-65.4 0-51.1-41.4-92.5-92.5-92.5zM275.2 173.3c-1.9-.8-3.8-1.9-5.5-3.1-12.6-6.5-27-10.2-42.1-10.2-24.5 0-48 9.7-65.4 27.1L91.1 258.2c-17.3 17.3-27.1 40.9-27.1 65.4 0 51.1 41.4 92.5 92.5 92.5 16.5 0 32.6-4.4 46.7-12.6 15.8 16 34.2 29.4 54.6 39.5-28.2 23.9-64 37.2-101.3 37.2-86.4 0-156.5-70-156.5-156.5 0-41.5 16.5-81.3 45.8-110.6l71.1-71.1c29.3-29.3 69.1-45.8 110.6-45.8 86.6 0 156.5 70.6 156.5 156.9 0 1.3 0 2.6 0 3.9-.4 17.7-15.1 31.6-32.8 31.2s-31.6-15.1-31.2-32.8c0-.8 0-1.5 0-2.3 0-33.7-18-63.3-44.8-79.6z\"/></svg>";
//#endregion
//#region src/rich-text/toolbar.tsx
function X({ engine: e, selection: t, text: r, showLink: i, onLink: l }) {
	let u = (e, t, r, i, o) => /* @__PURE__ */ f(a, {
		size: "compact",
		className: "rv-markdown-editor__command",
		"aria-label": e,
		title: e,
		pressed: r,
		onMouseDown: (e) => e.preventDefault(),
		onPressedChange: i,
		children: [/* @__PURE__ */ d(n, { svg: t }), o && /* @__PURE__ */ d(n, {
			svg: o,
			className: "rv-svg-icon rv-markdown-editor__level"
		})]
	}), p = (n, r, i, a) => u(n, r, t.block === i, () => e()?.block(t.block === i ? "paragraph" : i), a);
	return /* @__PURE__ */ f(o, {
		className: "rv-markdown-editor__toolbar",
		label: r.formatting,
		children: [
			/* @__PURE__ */ f(s, {
				label: r.inlineFormatting,
				children: [
					u(r.bold, pe, t.formats.includes("bold"), () => e()?.format("bold")),
					u(r.italic, me, t.formats.includes("italic"), () => e()?.format("italic")),
					u(r.strike, he, t.formats.includes("strikethrough"), () => e()?.format("strikethrough")),
					u(r.code, ge, t.formats.includes("code"), () => e()?.format("code"))
				]
			}),
			/* @__PURE__ */ d(c, {}),
			/* @__PURE__ */ f(s, {
				label: r.headings,
				children: [p(r.heading1, Y, "h1", _e), p(r.heading2, Y, "h2", ve)]
			}),
			/* @__PURE__ */ d(c, {}),
			/* @__PURE__ */ f(s, {
				label: r.structure,
				children: [
					p(r.bullets, ye, "bullet"),
					p(r.numberedList, be, "ordered"),
					p(r.quote, xe, "quote"),
					p(r.codeBlock, Se, "code")
				]
			}),
			/* @__PURE__ */ d(c, {}),
			/* @__PURE__ */ d(s, {
				label: r.links,
				children: u(r.link, Ce, i || t.link, l)
			})
		]
	});
}
//#endregion
//#region src/rich-text/translations.ts
var Z = {
	visual: "Visual",
	source: "Markdown",
	label: "Rich text",
	unsupported: "Keep this content in Markdown mode to preserve unsupported syntax:",
	unsafeLink: "Use an HTTP, HTTPS, mailto or relative link.",
	requiredValue: "Enter a value.",
	tooLong: "The value exceeds the maximum length.",
	link: "Add link",
	linkUrl: "Link URL",
	popupLabel: "Edit rich text",
	formatting: "Text formatting",
	inlineFormatting: "Inline formatting",
	headings: "Headings",
	structure: "Lists and blocks",
	links: "Links",
	bold: "Bold",
	italic: "Italic",
	strike: "Strike",
	code: "Code",
	heading1: "H1",
	heading2: "H2",
	bullets: "Bullets",
	numberedList: "Numbered list",
	quote: "Quote",
	codeBlock: "Code block",
	images: "Images",
	tables: "Tables",
	html: "HTML",
	referenceLinks: "Reference links",
	taskLists: "Task lists",
	horizontalRules: "Horizontal rules",
	alternateHeadings: "Alternate headings",
	highlight: "Highlight",
	extensions: "Extensions",
	indentedCode: "Indented code"
}, we = {
	Images: "images",
	Tables: "tables",
	HTML: "html",
	"Reference links": "referenceLinks",
	"Task lists": "taskLists",
	"Horizontal rules": "horizontalRules",
	"Alternate headings": "alternateHeadings",
	Highlight: "highlight",
	Extensions: "extensions",
	"Indented code": "indentedCode"
};
function Q(e, t) {
	return e.map((e) => t[we[e]] ?? e).join(", ");
}
//#endregion
//#region src/rich-text/render-model.ts
var $ = /* @__PURE__ */ new Map();
function Te(e) {
	let t = $.get(e);
	if (t) return t;
	let n;
	if (G(e).length) n = [{ text: e }];
	else {
		let t = j({
			namespace: "RevoMarkdownRenderer",
			nodes: [
				F,
				I,
				z,
				R,
				V,
				U
			],
			onError: (e) => {
				throw e;
			}
		}), r = (e) => {
			if (E(e)) {
				let t = { text: e.getTextContent() };
				for (let [n, r] of [
					["code", "code"],
					["strikethrough", "s"],
					["italic", "em"],
					["bold", "strong"]
				]) e.hasFormat(n) && (t = {
					tag: r,
					children: [t]
				});
				return t;
			}
			if (e.getType() === "linebreak") return { tag: "br" };
			let t = w(e) ? e.getChildren().map(r) : [{ text: e.getTextContent() }];
			if (B(e)) return K(e.getURL()) ? {
				tag: "a",
				attrs: {
					href: e.getURL(),
					rel: "noopener noreferrer"
				},
				children: t
			} : {
				tag: "span",
				children: t
			};
			if (N(e)) return {
				tag: e.getTag(),
				children: t
			};
			if (L(e)) return {
				tag: e.getListType() === "number" ? "ol" : "ul",
				attrs: e.getListType() === "number" ? { start: e.getStart() } : void 0,
				children: t
			};
			switch (e.getType()) {
				case "paragraph": return {
					tag: "p",
					children: t
				};
				case "quote": return {
					tag: "blockquote",
					children: t
				};
				case "listitem": return {
					tag: "li",
					children: t
				};
				case "code": return {
					tag: "pre",
					children: [{
						tag: "code",
						children: t
					}]
				};
				default: return {
					tag: "span",
					children: t
				};
			}
		};
		t.update(() => {
			g(e, W);
		}, { discrete: !0 }), n = t.getEditorState().read(() => S().getChildren().map(r));
	}
	return e.length <= 5e4 && ($.size >= 100 && $.delete($.keys().next().value), $.set(e, n)), n;
}
//#endregion
//#region src/rich-text/index.tsx
function Ee(n) {
	let a = {
		...Z,
		...n.text
	}, [o, s] = h(n.value), [c] = h(() => !G(n.value).length && !J(n.value)), [g, _] = h(c ? "visual" : "source"), [v, y] = h(""), [b, x] = h(q), [S, C] = h(""), [w, T] = h(!1), E = m(!1), D = m(null), O = m(), k = m(o);
	k.current = o, p(() => {
		if (D.current) return O.current = fe(D.current, c ? n.value : "", (e, t) => {
			E.current = !0, k.current = e, s(e), y(t ? a.unsafeLink : "");
		}, x), () => {
			O.current?.destroy(), O.current = void 0;
		};
	}, []);
	let A = () => {
		let e = E.current ? k.current : n.value;
		return J(e) ? (y(a.unsafeLink), !1) : n.required && !e.trim() ? (y(a.requiredValue), !1) : n.maxLength !== void 0 && e.length > n.maxLength ? (y(a.tooLong), !1) : (n.onApply(e), !0);
	};
	l(() => !E.current || k.current === n.value || A(), n.autoApply !== !1);
	let j = G(o), M = v === a.unsafeLink || !!n.required && !o.trim() || n.maxLength !== void 0 && o.length > n.maxLength;
	return /* @__PURE__ */ f("div", {
		class: "rv-markdown-editor",
		onKeyDown: (e) => {
			(e.ctrlKey || e.metaKey) && e.key === "Enter" && (e.preventDefault(), e.stopPropagation(), A());
		},
		children: [
			/* @__PURE__ */ d(r, {
				value: g,
				ariaLabel: a.label,
				options: [{
					value: "visual",
					label: a.visual
				}, {
					value: "source",
					label: a.source
				}],
				onChange: (e) => {
					if (e === "visual") {
						if (j.length) {
							y(`${a.unsupported} ${Q(j, a)}`);
							return;
						}
						if (J(o)) {
							y(a.unsafeLink);
							return;
						}
						O.current?.setMarkdown(o);
					}
					_(e), y("");
				}
			}),
			g === "visual" && /* @__PURE__ */ d(X, {
				engine: () => O.current,
				selection: b,
				text: a,
				showLink: w,
				onLink: () => {
					O.current?.captureSelection(), T(!w);
				}
			}),
			w && g === "visual" && /* @__PURE__ */ f("div", {
				class: "rv-markdown-editor__link",
				children: [/* @__PURE__ */ d(e, {
					"aria-label": a.linkUrl,
					value: S,
					onInput: (e) => C(e.currentTarget.value)
				}), /* @__PURE__ */ d(i, {
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => {
						O.current?.link(S) ? (T(!1), y("")) : y(a.unsafeLink);
					},
					children: a.link
				})]
			}),
			/* @__PURE__ */ d("div", {
				ref: D,
				hidden: g !== "visual",
				class: "rv-markdown-editor__visual",
				role: "textbox",
				"aria-label": a.label,
				"aria-multiline": "true",
				"aria-invalid": M || void 0,
				contentEditable: !0,
				onClick: (e) => {
					e.target.closest("a") && e.preventDefault();
				}
			}),
			g === "source" && /* @__PURE__ */ d(t, {
				class: "rv-markdown-editor__source",
				"aria-label": a.source,
				"aria-invalid": M || void 0,
				value: o,
				onInput: (e) => {
					E.current = !0, k.current = e.currentTarget.value, s(e.currentTarget.value), y("");
				}
			}),
			j.length > 0 && g === "source" && /* @__PURE__ */ f("p", {
				role: "status",
				children: [
					a.unsupported,
					" ",
					Q(j, a)
				]
			}),
			v && /* @__PURE__ */ d("p", {
				class: "rv-editor-error",
				role: "alert",
				children: v
			}),
			/* @__PURE__ */ d(u, {
				showConfirm: n.showActions ?? n.autoApply === !1,
				text: n.actions,
				disabled: M,
				cancel: n.onCancel,
				apply: A,
				clear: n.required ? void 0 : () => {
					E.current = !0, k.current = "", s(""), O.current?.setMarkdown(""), y(""), n.autoApply !== !1 && A();
				}
			})
		]
	});
}
//#endregion
export { Ee as MarkdownEditor, Z as defaultMarkdownEditorText, K as isSafeMarkdownLink, Te as markdownRenderNodes, G as markdownVisualIssues };
