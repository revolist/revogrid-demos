/** Supported Markdown boundaries: unsupported syntax remains editable as lossless source. */
export declare function markdownVisualIssues(markdown: string): string[];
export declare function isSafeMarkdownLink(value: string): boolean;
