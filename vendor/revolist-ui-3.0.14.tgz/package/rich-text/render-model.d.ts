/** Framework-neutral, allowlisted content. Text is always rendered as text, never HTML. */
export interface MarkdownRenderNode {
    tag?: string;
    text?: string;
    attrs?: Record<string, string | number>;
    children?: readonly MarkdownRenderNode[];
}
/** The renderer accepts exactly the same Markdown subset as the Visual editor. */
export declare function markdownRenderNodes(markdown: string): readonly MarkdownRenderNode[];
