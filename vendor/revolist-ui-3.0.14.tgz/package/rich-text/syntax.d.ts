/** Keep import, export and keyboard shortcuts on the same deliberately small subset. */
export declare const MARKDOWN_TRANSFORMERS: import('@lexical/markdown').Transformer[];
