import { MarkdownEngine, MarkdownSelection } from './engine';
import { MarkdownEditorText } from './translations';
export declare function MarkdownToolbar({ engine, selection, text, showLink, onLink }: {
    engine: () => MarkdownEngine | undefined;
    selection: MarkdownSelection;
    text: Required<MarkdownEditorText>;
    showLink: boolean;
    onLink: () => void;
}): import("preact").JSX.Element;
