export type SearchInputRenderable = any;
export type SearchInputRef<T> = {
    current: T | null;
} | ((instance: T | null) => void) | null;
export type SearchInputEvent<T extends EventTarget> = Event & {
    currentTarget: T;
};
export type SearchInputProps = {
    value?: string;
    inputRef?: SearchInputRef<HTMLInputElement>;
    rootClassName?: string;
    inputClassName?: string;
    iconClassName?: string;
    shortcutClassName?: string;
    shortcut?: SearchInputRenderable;
    icon?: SearchInputRenderable;
    leading?: SearchInputRenderable;
    hideIcon?: boolean;
    trailing?: SearchInputRenderable;
    testId?: string;
    onValueChange?: (value: string, event: SearchInputEvent<HTMLInputElement>) => void;
    onInput?: (event: SearchInputEvent<HTMLInputElement>) => void;
    type?: 'search' | 'text';
    [attribute: string]: any;
};
export declare function SearchInput({ value, inputRef, rootClassName, inputClassName, iconClassName, shortcutClassName, shortcut, icon, leading, hideIcon, trailing, testId, onValueChange, onInput, type, ...inputProps }: SearchInputProps): any;
