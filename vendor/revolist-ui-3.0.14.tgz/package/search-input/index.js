import { n as e } from "../_chunks/native.view-DY6ldYWP.js";
import { h as t } from "preact";
import { jsx as n, jsxs as r } from "preact/jsx-runtime";
//#region src/search-input/index.tsx
function i() {
	return /* @__PURE__ */ r("svg", {
		width: "13",
		height: "13",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		"stroke-width": "2",
		children: [/* @__PURE__ */ n("circle", {
			cx: "11",
			cy: "11",
			r: "8"
		}), /* @__PURE__ */ n("line", {
			x1: "21",
			y1: "21",
			x2: "16.65",
			y2: "16.65"
		})]
	});
}
function a({ value: r = "", inputRef: a, rootClassName: o = "", inputClassName: s = "", iconClassName: c = "", shortcutClassName: l = "", shortcut: u, icon: d, leading: f, hideIcon: p = !1, trailing: m, testId: h, onValueChange: g, onInput: _, type: v = "search", ...y }) {
	let b = (e) => {
		_?.(e), g?.(e.currentTarget.value, e);
	};
	return e(t, {
		rootClassName: o,
		inputClassName: s,
		iconClassName: c,
		shortcutClassName: l,
		shortcut: u,
		icon: d ?? /* @__PURE__ */ n(i, {}),
		hideIcon: p,
		leading: f,
		trailing: m,
		testId: h,
		inputAttributes: {
			...y,
			ref: a,
			type: v,
			value: r,
			onInput: b
		}
	});
}
//#endregion
export { a as SearchInput };
