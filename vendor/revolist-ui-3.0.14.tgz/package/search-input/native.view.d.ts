export interface SearchPresentation {
    rootClassName?: string;
    inputClassName?: string;
    iconClassName?: string;
    shortcutClassName?: string;
    hideIcon?: boolean;
    icon?: any;
    shortcut?: any;
    leading?: any;
    trailing?: any;
    testId?: string;
    inputAttributes?: Record<string, any>;
}
/** One search composition for native, grid and Preact rendering. */
export declare function renderSearchInput<H extends (...args: any[]) => any>(h: H, options: SearchPresentation): ReturnType<H>;
export declare function createSearchInput(document: Document, options: Omit<SearchPresentation, 'icon'> & {
    iconSvg: string;
}): {
    root: HTMLElement;
    input: HTMLInputElement;
};
