import { JSX } from 'preact';
export type SegmentedSwitchRenderable = any;
export type SegmentedSwitchValue = string | number;
export type SegmentedSwitchOption<T extends SegmentedSwitchValue = SegmentedSwitchValue> = {
    value: T;
    label: SegmentedSwitchRenderable;
    count?: number | string;
    title?: string;
    ariaLabel?: string;
    disabled?: boolean;
    className?: string;
    testId?: string;
    id?: string;
    ariaControls?: string;
    /** Consumer metadata; the switch retains ownership of behavior and tab semantics. */
    buttonAttributes?: Omit<JSX.IntrinsicElements['button'], 'children' | 'class' | 'className' | 'id' | 'type' | 'role' | 'tabIndex' | 'disabled' | 'onClick' | 'onKeyDown' | 'aria-selected' | 'aria-checked' | 'aria-controls'> & {
        [attribute: `data-${string}`]: string | number | boolean | undefined;
    };
};
export type SegmentedSwitchRole = 'tablist' | 'radiogroup' | 'group';
export type SegmentedSwitchProps<T extends SegmentedSwitchValue = SegmentedSwitchValue> = {
    value: T;
    options: SegmentedSwitchOption<T>[];
    onChange: (value: T, option: SegmentedSwitchOption<T>) => void;
    ariaLabel?: string;
    className?: string;
    itemClassName?: string;
    countClassName?: string;
    activeClassName?: string;
    disabled?: boolean;
    /** Compact icon layout. Supply icons through renderOption and text through option labels. */
    iconOnly?: boolean;
    title?: string;
    role?: SegmentedSwitchRole;
    testId?: string;
    renderOption?: (option: SegmentedSwitchOption<T>, state: {
        active: boolean;
        disabled: boolean;
    }) => SegmentedSwitchRenderable;
    renderCount?: (option: SegmentedSwitchOption<T>, state: {
        active: boolean;
        disabled: boolean;
    }) => SegmentedSwitchRenderable;
};
export declare function SegmentedSwitch<T extends SegmentedSwitchValue = SegmentedSwitchValue>({ value, options, onChange, ariaLabel, className, itemClassName, countClassName, activeClassName, disabled, iconOnly, title, role, testId, renderOption, renderCount, }: SegmentedSwitchProps<T>): any;
