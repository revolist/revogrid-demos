import { createElement as e } from "preact";
import { jsx as t } from "preact/jsx-runtime";
//#region src/segmented-switch/index.tsx
function n(e) {
	if (e === "tablist") return "tab";
	if (e === "radiogroup") return "radio";
}
function r({ value: r, options: i, onChange: a, ariaLabel: o, className: s = "", itemClassName: c = "", countClassName: l = "", activeClassName: u = "on", disabled: d = !1, iconOnly: f = !1, title: p, role: m = "tablist", testId: h, renderOption: g, renderCount: _ }) {
	let v = n(m), y = i.filter((e) => !d && !e.disabled), b = y.some((e) => e.value === r), x = (e, t) => {
		if (![
			"ArrowLeft",
			"ArrowRight",
			"ArrowUp",
			"ArrowDown",
			"Home",
			"End"
		].includes(e.key) || !y.length) return;
		e.preventDefault();
		let n = y.findIndex((e) => e.value === t), r = e.key === "ArrowLeft" || e.key === "ArrowUp", i = e.key === "Home" ? 0 : e.key === "End" ? y.length - 1 : (Math.max(0, n) + (r ? -1 : 1) + y.length) % y.length, o = y[i];
		a(o.value, o), (e.currentTarget.parentElement?.querySelectorAll(".rv-segmented-switch-item:not(:disabled)"))?.[i]?.focus();
	};
	return /* @__PURE__ */ t("div", {
		class: `rv-segmented-switch${f ? " rv-segmented-switch--icon-only" : ""} ${s}`.trim(),
		role: m,
		"aria-label": o,
		title: p,
		"data-testid": h,
		children: i.map((n) => {
			let i = n.value === r, o = d || !!n.disabled, s = {
				active: i,
				disabled: o
			};
			return /* @__PURE__ */ e("button", {
				...n.buttonAttributes,
				key: String(n.value),
				type: "button",
				role: v,
				id: n.id,
				"aria-controls": n.ariaControls,
				"aria-selected": v === "tab" ? i : void 0,
				"aria-checked": v === "radio" ? i : void 0,
				"aria-pressed": m === "group" ? i : void 0,
				"aria-label": n.ariaLabel ?? (f && typeof n.label == "string" ? n.label : void 0),
				title: n.title ?? (f && typeof n.label == "string" ? n.label : void 0),
				tabIndex: v && !o && (i || !b && n === y[0]) ? 0 : v ? -1 : void 0,
				class: `rv-segmented-switch-item ${i ? `on ${u}` : ""} ${c} ${n.className ?? ""}`.trim(),
				disabled: o,
				"data-value": String(n.value),
				"data-testid": n.testId,
				onKeyDown: (e) => x(e, n.value),
				onClick: () => {
					o || i || a(n.value, n);
				}
			}, /* @__PURE__ */ t("span", {
				class: "rv-segmented-switch-label",
				children: g ? g(n, s) : n.label
			}), n.count !== void 0 && /* @__PURE__ */ t("span", {
				class: `rv-segmented-switch-count ${l}`.trim(),
				children: _ ? _(n, s) : n.count
			}));
		})
	});
}
//#endregion
export { r as SegmentedSwitch };
