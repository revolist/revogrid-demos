import { StatusBadgeProps, StatusFeedbackH } from './types';
/** Stateless status badge; labels and status transitions belong to the consumer. */
export declare function renderStatusBadge<T>(h: StatusFeedbackH<T>, { label, tone, busy, className }: StatusBadgeProps): T;
