import { t as e } from "../_chunks/icons-Ci5mADVc.js";
//#region src/status-feedback/badge.ts
function t(t, { label: n, tone: r = "neutral", busy: i = !1, className: a }) {
	return t("span", {
		class: ["rv-status-badge", a].filter(Boolean).join(" "),
		"data-tone": r
	}, [e(t, r, i), t("span", {}, n)]);
}
//#endregion
export { t as renderStatusBadge };
