/** A short-lived inert snapshot allows exit motion after the renderer removes its node. */
export declare function statusFeedbackExit(panel: HTMLElement): (() => void) | undefined;
