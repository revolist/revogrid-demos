import { showTopLayerPopup as e } from "../core/top-layer-popup.js";
import { isUiMotionEnabled as t } from "../core/motion.js";
import { animateStatusFeedback as n } from "./motion.js";
//#region src/status-feedback/exit-snapshot.ts
function r(r) {
	let i = r.ownerDocument.defaultView;
	if (!i || typeof r.animate != "function" || !t(r)) return;
	let a = r.getBoundingClientRect(), o = r.cloneNode(!0), s = [r, ...r.querySelectorAll("*")], c = [o, ...o.querySelectorAll("*")];
	o.removeAttribute("popover"), o.removeAttribute("id"), o.querySelectorAll("[id]").forEach((e) => e.removeAttribute("id")), o.querySelectorAll("[role], [aria-live]").forEach((e) => {
		e.removeAttribute("role"), e.removeAttribute("aria-live");
	}), o.setAttribute("aria-hidden", "true"), o.inert = !0, o.dataset.statusFeedbackExit = "";
	let l = i.getComputedStyle(r);
	for (let e of Array.from(l)) e.startsWith("--rv-") && o.style.setProperty(e, l.getPropertyValue(e));
	Object.assign(o.style, {
		position: "fixed",
		left: `${a.left}px`,
		top: `${a.top}px`,
		width: `${a.width}px`,
		height: `${a.height}px`,
		display: "flex",
		pointerEvents: "none",
		color: l.color,
		backgroundColor: l.backgroundColor,
		borderColor: l.borderColor,
		fontFamily: l.fontFamily,
		boxShadow: l.boxShadow
	}), r.ownerDocument.body.append(o), e(o), s.forEach((e, t) => {
		e.scrollTop && (c[t].scrollTop = e.scrollTop), e.scrollLeft && (c[t].scrollLeft = e.scrollLeft);
	});
	let u = () => {
		o.remove();
	}, d = n(o, [{ opacity: 1 }, { opacity: 0 }], "rv-status-exit", 140);
	if (!d) u();
	else return d.onfinish = u, d.oncancel = u, () => {
		d.cancel(), u();
	};
}
//#endregion
export { r as statusFeedbackExit };
