import { StatusFeedbackH, StatusFeedbackPanelProps } from './types';
export declare function renderHeader<T>(h: StatusFeedbackH<T>, props: StatusFeedbackPanelProps, collapsed: boolean, collapsible: boolean, setCollapsed: (collapsed: boolean, event: Event) => void): T;
