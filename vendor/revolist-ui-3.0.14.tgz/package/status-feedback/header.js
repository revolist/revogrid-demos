export { t as renderHeader } from "../_chunks/header-BbKV08Tn.js";
