import { StatusFeedbackH, StatusFeedbackTone } from './types';
export declare function statusIcon<T>(h: StatusFeedbackH<T>, tone: StatusFeedbackTone, busy: boolean): T | null;
