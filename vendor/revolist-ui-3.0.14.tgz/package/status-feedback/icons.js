export { t as statusIcon } from "../_chunks/icons-Ci5mADVc.js";
