import { StatusFeedbackH, StatusFeedbackItem } from './types';
export declare function renderItem<T>(h: StatusFeedbackH<T>, item: StatusFeedbackItem): T;
