import { t as e } from "../_chunks/icons-Ci5mADVc.js";
//#region src/status-feedback/item.ts
function t(t, n) {
	let r = n.tone ?? "neutral", i = n.actions ?? [];
	return t("div", {
		...n.data,
		key: n.id,
		class: [
			"rv-status-feedback__item",
			i.length > 1 ? "rv-status-feedback__item--multiple-actions" : "",
			n.className
		].filter(Boolean).join(" "),
		"data-tone": r,
		role: r === "warning" || r === "danger" ? "alert" : "status",
		"aria-atomic": "true"
	}, [
		e(t, r, !!n.busy),
		t("div", { class: "rv-status-feedback__copy" }, [
			t("div", { class: "rv-status-feedback__title" }, n.title),
			n.description ? t("div", { class: "rv-status-feedback__description" }, n.description) : null,
			n.detail ? t("div", { class: "rv-status-feedback__detail" }, n.detail) : null
		]),
		i.length ? t("div", { class: "rv-status-feedback__actions" }, i.map((e) => t("button", {
			key: e.id,
			type: "button",
			disabled: e.disabled,
			class: `${e.appearance === "primary" ? "rv-btn-solid" : e.appearance === "ghost" ? "rv-btn-ghost" : "rv-btn"} rv-status-feedback__action`,
			"aria-label": e.ariaLabel,
			onClick: (t) => {
				t.stopPropagation(), e.disabled || e.onClick(t);
			}
		}, e.label))) : null
	]);
}
//#endregion
export { t as renderItem };
