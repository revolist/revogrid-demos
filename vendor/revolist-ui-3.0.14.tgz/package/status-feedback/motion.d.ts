/** Overlay-only motion; request state and renderer ownership stay with the consumer. */
export declare function animateStatusFeedback(panel: HTMLElement, frames: Keyframe[], id: string, duration?: number): Animation | undefined;
