import { getUiMotionDuration as e, isUiMotionEnabled as t, watchUiMotionPolicy as n } from "../core/motion.js";
//#region src/status-feedback/motion.ts
function r(r, i, a, o = 180) {
	if (typeof r.animate != "function" || !t(r)) return;
	let s = a.includes("exit") ? "exit" : a.includes("resize") ? "normal" : "enter", c = e(r, s, o);
	if (c <= 0) return;
	let l = r.animate(i, {
		duration: c,
		easing: r.ownerDocument.defaultView?.getComputedStyle(r).getPropertyValue("--rv-ui-motion-ease").trim() || "cubic-bezier(.2, 0, 0, 1)"
	});
	l.id = a;
	let u = n(r, () => {
		t(r) || l.cancel();
	});
	return l.finished.then(u, u), l;
}
//#endregion
export { r as animateStatusFeedback };
