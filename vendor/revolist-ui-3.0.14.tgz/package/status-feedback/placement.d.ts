export interface StatusFeedbackSizeOptions {
    readonly width?: number;
    readonly collapsedWidth?: number;
}
/** Size the surface before the shared anchor helper positions it. */
export declare function statusFeedbackSize(viewport: {
    width: number;
    height: number;
}, boundary: {
    width: number;
    height: number;
} | undefined, collapsed: boolean, options: StatusFeedbackSizeOptions): {
    width: number;
    maxHeight: number;
};
