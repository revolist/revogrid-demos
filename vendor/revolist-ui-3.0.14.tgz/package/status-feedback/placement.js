//#region src/status-feedback/placement.ts
function e(e, t, n, r) {
	return {
		width: Math.max(0, Math.min(n ? r.collapsedWidth ?? 260 : r.width ?? 560, e.width - 16, t ? t.width - 16 : Infinity)),
		maxHeight: Math.max(0, Math.min(e.height - 16, Math.max(48, t ? t.height * .45 : e.height * .6)))
	};
}
//#endregion
export { e as statusFeedbackSize };
