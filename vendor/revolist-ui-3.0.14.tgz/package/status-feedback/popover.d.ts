export interface StatusFeedbackPopoverOptions {
    readonly onChange: () => void;
    readonly boundary?: HTMLElement;
    readonly width?: number;
    readonly collapsedWidth?: number;
    readonly collapsed?: boolean;
}
/** Shared positioning and lifecycle for persistent, non-modal activity popovers. */
export declare class StatusFeedbackPopoverController {
    private readonly options;
    readonly id: string;
    private anchor;
    private panel;
    private window;
    private observer?;
    private frame?;
    private mode?;
    private disposed;
    private isCollapsed;
    private animation?;
    private releaseMotion?;
    private removeExit?;
    constructor(options: StatusFeedbackPopoverOptions);
    get collapsed(): boolean;
    readonly anchorRef: (element?: HTMLElement | null) => void;
    readonly panelRef: (element?: HTMLElement | null) => void;
    setCollapsed(collapsed: boolean): void;
    /** Call after rendering items; sizing is measured after the renderer finishes its patch. */
    readonly refresh: () => void;
    hide(animate?: boolean): void;
    destroy(): void;
    private position;
    private stopWatching;
}
