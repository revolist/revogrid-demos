import { calculateAnchoredPopoverPosition as e } from "../core/anchored-popover.js";
import { hideTopLayerPopup as t, showTopLayerPopup as n } from "../core/top-layer-popup.js";
import { inheritUiMotion as r } from "../core/motion.js";
import { statusFeedbackSize as i } from "./placement.js";
import { animateStatusFeedback as a } from "./motion.js";
import { statusFeedbackExit as o } from "./exit-snapshot.js";
//#region src/status-feedback/popover.ts
var s = 0, c = class {
	options;
	id = `rv-status-popover-${++s}`;
	anchor = null;
	panel = null;
	window = null;
	observer;
	frame;
	mode;
	disposed = !1;
	isCollapsed;
	animation;
	releaseMotion;
	removeExit;
	constructor(e) {
		this.options = e, this.isCollapsed = e.collapsed ?? !1;
	}
	get collapsed() {
		return this.isCollapsed;
	}
	anchorRef = (e) => {
		let t = e ?? null;
		t !== this.anchor && (this.stopWatching(), this.releaseMotion?.(), this.releaseMotion = void 0), this.anchor = t, this.anchor ? this.refresh() : this.hide(!0);
	};
	panelRef = (e) => {
		let t = e ?? null;
		t !== this.panel && (this.hide(!0), this.panel = t), this.panel && this.refresh();
	};
	setCollapsed(e) {
		if (this.disposed || e === this.isCollapsed) return;
		let t = this.panel?.ownerDocument.activeElement;
		e && t && this.panel?.contains(t) && this.panel.querySelector(".rv-status-feedback__toggle")?.focus({ preventScroll: !0 }), this.animation?.cancel(), this.isCollapsed = e, this.options.onChange(), this.refresh();
	}
	refresh = () => {
		if (this.disposed || !this.panel || !this.anchor) return;
		let e = this.panel.ownerDocument.defaultView;
		e && (this.window !== e && (this.stopWatching(), this.window = e, e.addEventListener("resize", this.refresh), e.addEventListener("scroll", this.refresh, !0), typeof ResizeObserver < "u" && (this.observer = new ResizeObserver(this.refresh), this.observer.observe(this.panel), this.observer.observe(this.anchor), this.options.boundary && this.observer.observe(this.options.boundary))), this.frame === void 0 && (this.frame = e.requestAnimationFrame(() => {
			this.frame = void 0, this.position();
		})));
	};
	hide(e = !1) {
		(!e || this.mode) && (this.removeExit?.(), this.removeExit = void 0), e && this.panel?.isConnected && this.mode && (this.removeExit = o(this.panel)), this.animation?.cancel(), this.animation = void 0, this.releaseMotion?.(), this.releaseMotion = void 0, this.panel && this.mode && t(this.panel, this.mode), this.mode = void 0, this.stopWatching();
	}
	destroy() {
		this.hide(), this.disposed = !0, this.panel = null, this.anchor = null;
	}
	position() {
		let t = this.panel, o = this.anchor, s = this.window;
		if (!t?.isConnected || !o?.isConnected || !s || this.disposed) return;
		let c = this.options.boundary?.getBoundingClientRect(), l = i({
			width: s.innerWidth,
			height: s.innerHeight
		}, c, this.collapsed, this.options), u = l.width;
		t.style.width = `${u}px`, t.style.maxHeight = `${l.maxHeight}px`, this.releaseMotion ??= r(o, t);
		let d = !this.mode;
		d && (this.removeExit?.(), this.removeExit = void 0, this.mode = n(t));
		let f = o.getBoundingClientRect(), p = e({
			left: f.right - u,
			right: f.right,
			top: f.bottom,
			bottom: f.bottom
		}, {
			width: t.offsetWidth,
			height: t.offsetHeight
		}, {
			width: s.innerWidth,
			height: s.innerHeight
		}, 0);
		t.style.left = `${p.left}px`, t.style.top = `${p.top}px`, d && (this.animation?.cancel(), this.animation = a(t, [{ opacity: 0 }, { opacity: 1 }], "rv-status-enter"));
	}
	stopWatching() {
		this.frame !== void 0 && this.window?.cancelAnimationFrame(this.frame), this.frame = void 0, this.observer?.disconnect(), this.observer = void 0, this.window?.removeEventListener("resize", this.refresh), this.window?.removeEventListener("scroll", this.refresh, !0), this.window = null;
	}
};
//#endregion
export { c as StatusFeedbackPopoverController };
