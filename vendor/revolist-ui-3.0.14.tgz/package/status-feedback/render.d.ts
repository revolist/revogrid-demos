import { StatusBadgeProps, StatusFeedbackH, StatusFeedbackPanelProps } from './types';
export { renderStatusBadge } from './badge';
/** One shared activity surface, with divided rows rather than nested notice cards. */
export declare function renderStatusFeedbackPanel<T>(h: StatusFeedbackH<T>, props: StatusFeedbackPanelProps): T | null;
/** Preact adapters share the exact same presentation as RevoGrid template consumers. */
export declare function StatusFeedbackPanel(props: StatusFeedbackPanelProps): import('preact').VNode<import('preact').Attributes> | null;
export declare function StatusBadge(props: StatusBadgeProps): import('preact').VNode<import('preact').Attributes>;
