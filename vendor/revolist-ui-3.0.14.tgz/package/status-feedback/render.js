import { t as e } from "../_chunks/header-BbKV08Tn.js";
import { renderItem as t } from "./item.js";
import { renderStatusBadge as n } from "./badge.js";
import { h as r } from "preact";
//#region src/status-feedback/render.ts
function i(n, r) {
	let { title: i, items: a, ariaLabel: o, className: s, popover: c, onCollapsedChange: l } = r;
	if (!a.length) return c?.hide(!0), null;
	let u = c?.collapsed ?? r.collapsed ?? !1, d = !!(c || l), f = (e, t) => {
		if (e && !c) {
			let e = t.currentTarget.closest(".rv-status-feedback"), n = e?.ownerDocument.activeElement;
			n && e?.contains(n) && e.querySelector(".rv-status-feedback__toggle")?.focus({ preventScroll: !0 });
		}
		c?.setCollapsed(e), l?.(e);
	};
	return c?.refresh(), n("section", {
		onKeyDown: (e) => {
			e.key === "Escape" && d && !u && (e.preventDefault(), e.stopPropagation(), f(!0, e));
		},
		ref: c?.panelRef,
		id: c?.id,
		class: [
			"rv-status-feedback",
			s,
			c ? "rv-status-feedback--popover" : "",
			u ? "rv-status-feedback--collapsed" : ""
		].filter(Boolean).join(" "),
		"aria-label": o ?? i,
		"data-collapsed": String(u)
	}, [e(n, r, u, d, f), n("div", {
		id: c ? `${c.id}-items` : void 0,
		class: "rv-status-feedback__items",
		hidden: u
	}, a.map((e) => t(n, e)))]);
}
function a(e) {
	return i(r, e);
}
function o(e) {
	return n(r, e);
}
//#endregion
export { o as StatusBadge, a as StatusFeedbackPanel, n as renderStatusBadge, i as renderStatusFeedbackPanel };
