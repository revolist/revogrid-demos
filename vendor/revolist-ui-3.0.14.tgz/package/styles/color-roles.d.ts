/** Semantic color catalog. Values belong exclusively to the Sass theme. */
export declare const colorRoles: readonly [{
    readonly token: "--rv-ui-canvas";
    readonly group: "Surfaces";
    readonly usage: "Application background.";
}, {
    readonly token: "--rv-ui-surface";
    readonly group: "Surfaces";
    readonly usage: "Default panels and controls.";
}, {
    readonly token: "--rv-ui-surface-elevated";
    readonly group: "Surfaces";
    readonly usage: "Floating menus and dialogs.";
}, {
    readonly token: "--rv-ui-surface-sunken";
    readonly group: "Surfaces";
    readonly usage: "Inset content areas.";
}, {
    readonly token: "--rv-ui-surface-hover";
    readonly group: "Surfaces";
    readonly usage: "Hovered neutral rows and controls.";
}, {
    readonly token: "--rv-ui-overlay";
    readonly group: "Surfaces";
    readonly usage: "Modal backdrop and content scrim.";
}, {
    readonly token: "--rv-ui-shadow";
    readonly group: "Surfaces";
    readonly usage: "Elevation shadow color.";
}, {
    readonly token: "--rv-ui-text";
    readonly group: "Content";
    readonly usage: "Primary readable content.";
}, {
    readonly token: "--rv-ui-text-muted";
    readonly group: "Content";
    readonly usage: "Supporting descriptions and labels.";
}, {
    readonly token: "--rv-ui-text-subtle";
    readonly group: "Content";
    readonly usage: "Low emphasis decorative content; verify contrast before using for text.";
}, {
    readonly token: "--rv-ui-border";
    readonly group: "Content";
    readonly usage: "Default control and panel boundaries.";
}, {
    readonly token: "--rv-ui-border-strong";
    readonly group: "Content";
    readonly usage: "Emphasized boundaries.";
}, {
    readonly token: "--rv-ui-accent";
    readonly group: "Interaction";
    readonly usage: "Primary actions and active indicators.";
}, {
    readonly token: "--rv-ui-accent-hover";
    readonly group: "Interaction";
    readonly usage: "Hovered primary actions.";
}, {
    readonly token: "--rv-ui-accent-fg";
    readonly group: "Interaction";
    readonly usage: "Content on accent fills.";
}, {
    readonly token: "--rv-ui-accent-text";
    readonly group: "Interaction";
    readonly usage: "Accent text on neutral surfaces.";
}, {
    readonly token: "--rv-ui-focus-ring";
    readonly group: "Interaction";
    readonly usage: "Keyboard focus indicator.";
}, {
    readonly token: "--rv-ui-selected-bg";
    readonly group: "Interaction";
    readonly usage: "Shared selection background for calendars, lists and choices.";
}, {
    readonly token: "--rv-ui-selected-fg";
    readonly group: "Interaction";
    readonly usage: "Content on shared selection backgrounds.";
}, {
    readonly token: "--rv-ui-selected-accent-fg";
    readonly group: "Interaction";
    readonly usage: "Emphasized selection text in choices, tabs and formatting controls.";
}, {
    readonly token: "--rv-ui-disabled-bg";
    readonly group: "Interaction";
    readonly usage: "Disabled control background.";
}, {
    readonly token: "--rv-ui-disabled-fg";
    readonly group: "Interaction";
    readonly usage: "Disabled control content.";
}, {
    readonly token: "--rv-ui-danger";
    readonly group: "Feedback";
    readonly usage: "Errors and destructive actions.";
}, {
    readonly token: "--rv-ui-danger-surface";
    readonly group: "Feedback";
    readonly usage: "Error feedback background.";
}, {
    readonly token: "--rv-ui-warning";
    readonly group: "Feedback";
    readonly usage: "Warnings needing attention.";
}, {
    readonly token: "--rv-ui-warning-surface";
    readonly group: "Feedback";
    readonly usage: "Warning feedback background.";
}, {
    readonly token: "--rv-ui-success";
    readonly group: "Feedback";
    readonly usage: "Successful outcomes.";
}, {
    readonly token: "--rv-ui-success-surface";
    readonly group: "Feedback";
    readonly usage: "Success feedback background.";
}, {
    readonly token: "--rv-ui-field-muted";
    readonly group: "Fields";
    readonly usage: "Muted inline field content.";
}, {
    readonly token: "--rv-ui-field-accent-text";
    readonly group: "Fields";
    readonly usage: "Accent content within fields.";
}, {
    readonly token: "--rv-ui-field-surface";
    readonly group: "Fields";
    readonly usage: "Inline field background.";
}, {
    readonly token: "--rv-ui-field-text";
    readonly group: "Fields";
    readonly usage: "Inline field content.";
}];
