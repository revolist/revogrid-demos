import { calculateAnchoredPopoverPosition as e } from "./core/anchored-popover.js";
import { hideTopLayerPopup as t, showTopLayerPopup as n } from "./core/top-layer-popup.js";
import { createControlId as r } from "./core/control-id.js";
import { createPreactElement as i, releasePreactElement as a } from "./preact-mount.js";
import { createDialogElements as o, getDialogFocusableElements as s, trapDialogFocus as c } from "./dialog/dialog.dom.js";
import { attachDialogDrag as l } from "./dialog/dialog.drag.js";
import { inheritUiMotion as u } from "./core/motion.js";
import { jsx as d } from "preact/jsx-runtime";
//#region src/surfaces.view.tsx
var f = /* @__PURE__ */ new WeakMap(), p = /* @__PURE__ */ new WeakMap(), m = class {
	document;
	environment;
	active;
	constructor(e, t = {}) {
		this.document = e, this.environment = t;
	}
	get isOpen() {
		return !!this.active;
	}
	open(e) {
		this.close();
		let t = this.document, n = t.activeElement, r = !1, i, d, f = p.get(t) ?? [];
		p.set(t, f);
		let m = () => {
			if (r) return;
			r = !0, i?.(), d?.(), a(h.root);
			let t = f.indexOf(h.root), o = t === f.length - 1;
			t !== -1 && f.splice(t, 1), this.active?.root === h.root && (this.active = void 0);
			try {
				e.onClose?.();
			} finally {
				o && (this.environment.restoreFocus ? this.environment.restoreFocus(e.returnFocus, n ?? void 0) : [e.returnFocus, n].find((e) => e?.isConnected)?.focus?.({ preventScroll: !0 }));
			}
		}, h = o(t, e, m), g = {
			...h,
			close: m
		};
		return this.environment.beforeMount?.(h.root), d = u(e.returnFocus ?? n, h.root), h.root.addEventListener("mousedown", (e) => {
			e.target === h.root && f.at(-1) === h.root && m();
		}), h.root.addEventListener("keydown", (e) => {
			f.at(-1) === h.root && (e.key === "Escape" ? (e.preventDefault(), e.stopPropagation(), m()) : e.key === "Tab" && c(h.root, e));
		}), t.body.append(h.root), f.push(h.root), e.draggable !== !1 && (i = l({
			target: h.surface,
			handle: h.header
		})), this.active = g, this.environment.onOpen?.(e), queueMicrotask(() => {
			!r && f.at(-1) === h.root && (s(h.root)[0] ?? h.root).focus({ preventScroll: !0 });
		}), g;
	}
	close(e) {
		(!e || this.active?.root === e) && this.active?.close();
	}
	destroy() {
		this.close();
	}
}, h = class {
	active;
	get isOpen() {
		return !!this.active;
	}
	open(r) {
		this.close(!1);
		let { anchor: i, content: a } = r, o = i.ownerDocument, s = o.defaultView, c = f.get(o) ?? [];
		f.set(o, c);
		let l = a.parentNode, d = a.nextSibling, p = a.hidden, m = a.getAttribute("style"), h = a.getAttribute("popover"), g = u(i, a), _ = () => {
			if (!i.isConnected) {
				b(!1);
				return;
			}
			let t = e(i.getBoundingClientRect(), a.getBoundingClientRect(), {
				width: s?.innerWidth ?? 0,
				height: s?.innerHeight ?? 0
			});
			Object.assign(a.style, {
				left: `${t.left}px`,
				top: `${t.top}px`
			});
		}, v, y = !1, b = (e = r.restoreFocus !== !1) => {
			if (y) return;
			y = !0, o.removeEventListener("pointerdown", x, !0), o.removeEventListener("keydown", S), s?.removeEventListener("resize", _), o.removeEventListener("scroll", _, !0), C?.disconnect();
			let n = c.indexOf(a);
			n !== -1 && c.splice(n, 1), t(a, v), g(), l?.isConnected ? l.insertBefore(a, d?.parentNode === l ? d : null) : a.remove(), m === null ? a.removeAttribute("style") : a.setAttribute("style", m), a.hidden = p, h === null ? a.removeAttribute("popover") : a.setAttribute("popover", h), this.active?.content === a && (this.active = void 0), e && i.isConnected && i.focus({ preventScroll: !0 }), r.onClose?.();
		}, x = (e) => {
			if (c.at(-1) !== a) return;
			let t = e.composedPath();
			r.closeOnOutside !== !1 && !t.includes(i) && !t.includes(a) && b(!1);
		}, S = (e) => {
			c.at(-1) === a && e.key === "Escape" && r.closeOnEscape !== !1 && !e.defaultPrevented && (e.preventDefault(), e.stopPropagation(), b());
		};
		(r.appendTo ?? o.body).append(a), a.hidden = !1, Object.assign(a.style, {
			position: "fixed",
			inset: "auto",
			margin: "0"
		}), v = n(a, r.display ?? "block");
		let C = s?.ResizeObserver ? new s.ResizeObserver(_) : void 0;
		return C?.observe(i), C?.observe(a), this.active = {
			content: a,
			close: b,
			position: _
		}, c.push(a), o.addEventListener("pointerdown", x, !0), o.addEventListener("keydown", S), s?.addEventListener("resize", _), o.addEventListener("scroll", _, !0), _(), {
			close: b,
			refresh: _
		};
	}
	refresh() {
		this.active?.position();
	}
	close(e) {
		this.active?.close(e);
	}
	destroy() {
		this.close(!1);
	}
};
function g(e, t = "grid-tooltip") {
	return i(e, /* @__PURE__ */ d("div", {
		id: r("rv-tooltip"),
		class: t,
		role: "tooltip",
		hidden: !0
	}));
}
var _ = class {
	popover = new h();
	release;
	bind(e, t, n = {}) {
		this.destroy();
		let r = g(e.ownerDocument, "rv-tooltip");
		r.textContent = t;
		let i = () => {
			this.popover.close(!1), r.hidden = !0, e.setAttribute("aria-describedby", o ?? ""), o === null && e.removeAttribute("aria-describedby");
		}, o = e.getAttribute("aria-describedby"), s = n.trigger === "click", c = e.getAttribute("aria-expanded");
		s && e.setAttribute("aria-expanded", "false");
		let l = () => {
			this.popover.isOpen || (r.hidden = !1, s && e.setAttribute("aria-expanded", "true"), e.setAttribute("aria-describedby", [o, r.id].filter(Boolean).join(" ")), this.popover.open({
				anchor: e,
				content: r,
				restoreFocus: !1,
				onClose: () => {
					r.hidden = !0, s && e.setAttribute("aria-expanded", "false"), o === null ? e.removeAttribute("aria-describedby") : e.setAttribute("aria-describedby", o);
				}
			}));
		}, u = () => this.popover.isOpen ? i() : l();
		return s ? e.addEventListener("click", u) : (e.addEventListener("pointerenter", l), e.addEventListener("pointerleave", i), e.addEventListener("focus", l), e.addEventListener("blur", i)), this.release = () => {
			i(), e.removeEventListener("click", u), s && (c === null ? e.removeAttribute("aria-expanded") : e.setAttribute("aria-expanded", c)), e.removeEventListener("pointerenter", l), e.removeEventListener("pointerleave", i), e.removeEventListener("focus", l), e.removeEventListener("blur", i), a(r);
		}, () => this.destroy();
	}
	destroy() {
		this.release?.(), this.release = void 0, this.popover.destroy();
	}
};
function v(e, t = () => {}) {
	let n = (n) => {
		let r = Array.from(e.querySelectorAll("[role=\"menuitem\"], [role=\"menuitemcheckbox\"], [role=\"menuitemradio\"]")).filter((t) => t.closest("[role=\"menu\"]") === e && t.getAttribute("aria-disabled") !== "true" && !t.hasAttribute("disabled") && !t.hidden), i = r.indexOf(e.ownerDocument.activeElement);
		[
			"ArrowDown",
			"ArrowUp",
			"Home",
			"End"
		].includes(n.key) && r.length ? (n.preventDefault(), n.stopPropagation(), r[n.key === "Home" ? 0 : n.key === "End" ? r.length - 1 : (i + (n.key === "ArrowUp" ? -1 : 1) + r.length) % r.length]?.focus()) : n.key === "Escape" && (n.preventDefault(), n.stopPropagation(), t());
	};
	return e.addEventListener("keydown", n), () => e.removeEventListener("keydown", n);
}
function y(e, t) {
	let n = typeof t == "function" ? t : () => t, r = n().value, i = r, a = () => {
		let e = n();
		return e.value !== i && (i = e.value, r = e.value), e;
	}, o = () => {}, s = (t) => {
		let n = a();
		r = Math.min(n.max ?? Infinity, Math.max(n.min ?? 0, t)), e.setAttribute("aria-valuenow", String(r)), n.onChange(r);
	}, c = n();
	e.setAttribute("role", "separator"), e.setAttribute("aria-orientation", "vertical"), e.setAttribute("aria-label", c.label), e.tabIndex = 0, e.setAttribute("aria-valuenow", String(r)), c.min !== void 0 && e.setAttribute("aria-valuemin", String(c.min)), c.max !== void 0 && e.setAttribute("aria-valuemax", String(c.max));
	let l = (e) => {
		let t = a(), n = t.direction === "rtl" ? -1 : 1;
		e.key === "ArrowLeft" || e.key === "ArrowRight" ? (e.preventDefault(), s(r + (e.key === "ArrowLeft" ? -1 : 1) * n * (t.step ?? 10))) : e.key === "Home" && t.min !== void 0 ? (e.preventDefault(), s(t.min)) : e.key === "End" && t.max !== void 0 && (e.preventDefault(), s(t.max));
	}, u = (t) => {
		if (t.button !== 0) return;
		t.preventDefault(), o();
		let n = a().direction === "rtl" ? -1 : 1;
		e.focus({ preventScroll: !0 });
		let i = t.clientX, c = r, l = e.ownerDocument, u = (e) => {
			e.pointerId === t.pointerId && s(c + (e.clientX - i) * n);
		}, d = (e) => {
			e.pointerId === t.pointerId && o();
		};
		l.addEventListener("pointermove", u), l.addEventListener("pointerup", d), l.addEventListener("pointercancel", d);
		let f = () => o();
		l.defaultView?.addEventListener("blur", f), o = () => {
			l.removeEventListener("pointermove", u), l.removeEventListener("pointerup", d), l.removeEventListener("pointercancel", d), l.defaultView?.removeEventListener("blur", f);
		};
	};
	return e.addEventListener("keydown", l), e.addEventListener("pointerdown", u), () => {
		o(), e.removeEventListener("keydown", l), e.removeEventListener("pointerdown", u);
	};
}
//#endregion
export { m as DialogController, h as PopoverController, _ as TooltipController, v as attachMenuKeyboard, y as attachResizeHandle, g as createTooltipElement };
