import { DialogHandle, DialogOpenOptions } from './dialog/dialog.types';
export interface DialogEnvironment {
    beforeMount?: (root: HTMLElement) => void;
    onOpen?: (options: DialogOpenOptions) => void;
    restoreFocus?: (explicit?: HTMLElement, previous?: HTMLElement) => void;
}
/** Standalone modal lifecycle. Integration hooks belong to the host application. */
export declare class DialogController {
    private readonly document;
    private readonly environment;
    private active?;
    constructor(document: Document, environment?: DialogEnvironment);
    get isOpen(): boolean;
    open(options: DialogOpenOptions): DialogHandle;
    close(root?: HTMLElement): void;
    destroy(): void;
}
export interface PopoverOptions {
    anchor: HTMLElement;
    content: HTMLElement;
    /** Defaults to the document body. */
    appendTo?: HTMLElement;
    onClose?: () => void;
    restoreFocus?: boolean;
    closeOnOutside?: boolean;
    closeOnEscape?: boolean;
    display?: string;
}
/** One owner for native top-layer promotion, viewport positioning and disposal. */
export declare class PopoverController {
    private active?;
    get isOpen(): boolean;
    open(options: PopoverOptions): {
        close: (restoreFocus?: boolean) => void;
        refresh: () => void;
    };
    refresh(): void;
    close(restoreFocus?: boolean): void;
    destroy(): void;
}
export declare function createTooltipElement(document: Document, className?: string): HTMLDivElement;
/** Plain text tooltip with keyboard, pointer and explicit teardown support. */
export declare class TooltipController {
    private readonly popover;
    private release?;
    bind(anchor: HTMLElement, text: string, options?: {
        trigger?: 'hover' | 'click';
    }): () => void;
    destroy(): void;
}
/** Keyboard behavior for menu surfaces; activation stays on native buttons. */
export declare function attachMenuKeyboard(menu: HTMLElement, onClose?: () => void): () => void;
export interface ResizeOptions {
    value: number;
    min?: number;
    max?: number;
    step?: number;
    label: string;
    onChange: (value: number) => void;
    direction?: 'ltr' | 'rtl';
}
/** Width resize controller. An options reader keeps controlled updates from interrupting a drag. */
export declare function attachResizeHandle(handle: HTMLElement, options: ResizeOptions | (() => ResizeOptions)): () => void;
