/** A transparent Svelte action: native bindings, refs and events stay on the
 * consumer's element, while shared UI owns presentation and button defaults. */
export declare function rvControl(element: HTMLElement): {
    destroy(): void;
};
