import { controlAttributes as e } from "./control-presentation.js";
//#region src/svelte-control.ts
function t(t) {
	let n = [], r = () => {
		let r = t.localName, i = e(r, { ...r === "input" ? { type: t.type } : {} }), a = i.class.split(/\s+/).filter(Boolean);
		for (let e of n) a.includes(e) || t.classList.remove(e);
		for (let e of a) t.classList.contains(e) || t.classList.add(e);
		n = a, r === "button" && !t.hasAttribute("type") && t.setAttribute("type", i.type);
	};
	r();
	let i = new t.ownerDocument.defaultView.MutationObserver(r);
	return i.observe(t, {
		attributes: !0,
		attributeFilter: ["class", "type"]
	}), { destroy: () => i.disconnect() };
}
//#endregion
export { t as rvControl };
