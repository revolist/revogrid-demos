export type SwitchRenderable = any;
export type SwitchProps = {
    checked: boolean;
    onChange: (checked: boolean) => void;
    label: SwitchRenderable;
    ariaLabel?: string;
    className?: string;
    disabled?: boolean;
    labelPosition?: 'before' | 'after';
    title?: string;
    testId?: string;
};
/** Shared compact binary control for Pro UI. */
export declare function Switch({ checked, onChange, label, ariaLabel, className, disabled, labelPosition, title, testId, }: SwitchProps): any;
