import { jsx as e, jsxs as t } from "preact/jsx-runtime";
//#region src/switch/index.tsx
function n({ checked: n, onChange: r, label: i, ariaLabel: a, className: o = "", disabled: s = !1, labelPosition: c = "before", title: l, testId: u }) {
	let d = /* @__PURE__ */ e("span", {
		class: "rv-switch-label",
		children: i
	}), f = /* @__PURE__ */ e("span", {
		class: "rv-switch-track",
		"aria-hidden": "true",
		children: /* @__PURE__ */ e("span", { class: "rv-switch-thumb" })
	});
	return /* @__PURE__ */ t("button", {
		type: "button",
		class: `rv-switch ${o}`.trim(),
		role: "switch",
		"aria-checked": n,
		"aria-label": a ?? (typeof i == "string" ? i : void 0),
		disabled: s,
		title: l,
		"data-testid": u,
		onClick: () => r(!n),
		children: [c === "before" ? d : f, c === "before" ? f : d]
	});
}
//#endregion
export { n as Switch };
