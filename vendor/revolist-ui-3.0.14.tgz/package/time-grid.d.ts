import { h, RefObject } from 'preact';
export interface TimeGridWorkingHours {
    readonly startHour: number;
    readonly endHour: number;
}
export declare const timeGridCellKey: (weekday: number, hour: number) => string;
export interface TimeGridDayLabel {
    readonly weekday: number;
    readonly short: string;
    readonly long: string;
}
export interface TimeGridProps {
    readonly disabled?: boolean;
    readonly legacyClassPrefix?: string;
    readonly days: readonly TimeGridDayLabel[];
    readonly cells: ReadonlySet<string>;
    readonly focused: string;
    readonly weekendDays: readonly number[];
    readonly workingHours?: TimeGridWorkingHours;
    readonly gridLabel: string;
    readonly hourLabel: (hour: number) => string;
    readonly cellLabel: (day: TimeGridDayLabel, start: string, end: string, selected: boolean) => string;
    readonly matrixRef: RefObject<HTMLDivElement>;
    readonly onFocus: (key: string) => void;
    readonly onKeyDown: (event: h.JSX.TargetedKeyboardEvent<HTMLButtonElement>, weekday: number, hour: number) => void;
    readonly onClick: (event: h.JSX.TargetedMouseEvent<HTMLButtonElement>, weekday: number, hour: number, selected: boolean) => void;
    readonly onPointerDown: (event: h.JSX.TargetedPointerEvent<HTMLButtonElement>, weekday: number, hour: number, selected: boolean) => void;
    readonly onPointerEnter: (weekday: number, hour: number) => void;
}
export declare function TimeGrid(props: TimeGridProps): h.JSX.Element;
/** Shared native focus, paint gesture and teardown; consumers own selected values. */
export declare function useTimeGridInteraction(options: {
    days: readonly TimeGridDayLabel[];
    matrixRef: RefObject<HTMLDivElement>;
    onFocus: (key: string) => void;
    onPaint: (weekday: number, hour: number, selected: boolean) => void;
    onCommit: () => void;
    disabled?: boolean;
}): {
    onKeyDown: (event: h.JSX.TargetedKeyboardEvent<HTMLButtonElement>, weekday: number, hour: number) => void;
    onClick: (event: h.JSX.TargetedMouseEvent<HTMLButtonElement>, weekday: number, hour: number, selected: boolean) => void;
    onPointerDown: (event: h.JSX.TargetedPointerEvent<HTMLButtonElement>, weekday: number, hour: number, selected: boolean) => void;
    onPointerEnter: (weekday: number, hour: number) => void;
};
