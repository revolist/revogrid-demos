import { ButtonControl as e } from "./native-control.js";
import { jsx as t, jsxs as n } from "preact/jsx-runtime";
import { useLayoutEffect as r, useRef as i } from "preact/hooks";
//#region src/time-grid.tsx
var a = (e, t) => `${e}:${t}`;
function o(e) {
	return [
		"rv-time-grid__cell",
		e.weekend && "is-weekend",
		e.outsideWorkHours && "is-outside-work-hours"
	].filter(Boolean).join(" ");
}
function s(r) {
	let i = (e) => `rv-time-grid__${e}${r.legacyClassPrefix ? ` ${r.legacyClassPrefix}__${e}` : ""}`, s = Array.from({ length: 12 }, (e, t) => t * 2);
	return /* @__PURE__ */ n("div", {
		class: i("schedule"),
		children: [/* @__PURE__ */ n("div", {
			class: i("hours"),
			"aria-hidden": "true",
			children: [/* @__PURE__ */ t("span", {}), s.map((e) => /* @__PURE__ */ t("span", {
				class: i("hour"),
				children: r.hourLabel(e)
			}, e))]
		}), /* @__PURE__ */ t("div", {
			ref: r.matrixRef,
			class: i("matrix"),
			role: "grid",
			"aria-label": r.gridLabel,
			"aria-rowcount": r.days.length,
			"aria-colcount": 12,
			children: r.days.map((c) => {
				let { weekday: l, short: u, long: d } = c, f = r.weekendDays.includes(l);
				return /* @__PURE__ */ n("div", {
					class: `${i("row")}${f ? " is-weekend" : ""}`,
					role: "row",
					children: [/* @__PURE__ */ t("span", {
						class: i("weekday"),
						role: "rowheader",
						title: d,
						children: u
					}), s.map((n) => {
						let i = a(l, n), s = r.cells.has(i) || r.cells.has(a(l, n + 1)), u = r.workingHours ? n < r.workingHours.startHour || n + 2 > r.workingHours.endHour : !1;
						return /* @__PURE__ */ t(e, {
							type: "button",
							disabled: r.disabled,
							role: "gridcell",
							"data-time-cell": i,
							class: `${o({
								weekend: f,
								outsideWorkHours: u
							})} ${r.legacyClassPrefix ? `${r.legacyClassPrefix}__cell` : ""}`,
							"aria-selected": s,
							"aria-label": r.cellLabel(c, r.hourLabel(n), r.hourLabel(n + 2), s),
							tabIndex: r.focused === i ? 0 : -1,
							onFocus: () => r.onFocus(i),
							onKeyDown: (e) => r.onKeyDown(e, l, n),
							onClick: (e) => r.onClick(e, l, n, s),
							onPointerDown: (e) => r.onPointerDown(e, l, n, s),
							onPointerEnter: () => r.onPointerEnter(l, n)
						}, i);
					})]
				}, l);
			})
		})]
	});
}
function c(e) {
	let t = i(e);
	t.current = e;
	let n = i(), o = i(), s = i(), c = () => {
		o.current?.(), o.current = void 0;
	};
	r(() => () => {
		n.current = void 0, c(), s.current !== void 0 && cancelAnimationFrame(s.current);
	}, []);
	let l = (e, n) => {
		let r = a(e, n);
		t.current.onFocus(r), s.current !== void 0 && cancelAnimationFrame(s.current), s.current = requestAnimationFrame(() => t.current.matrixRef.current?.querySelector(`[data-time-cell="${r}"]`)?.focus());
	};
	return {
		onKeyDown: (e, n, r) => {
			if (t.current.disabled) return;
			let i = t.current.days, a = i.findIndex((e) => e.weekday === n);
			if (!(!i.length || a < 0)) {
				if (e.key === "ArrowLeft") l(n, (r + 22) % 24);
				else if (e.key === "ArrowRight") l(n, (r + 2) % 24);
				else if (e.key === "ArrowUp") l(i[(a + i.length - 1) % i.length].weekday, r);
				else if (e.key === "ArrowDown") l(i[(a + 1) % i.length].weekday, r);
				else if (e.key === "Home") l(n, 0);
				else if (e.key === "End") l(n, 22);
				else return;
				e.preventDefault();
			}
		},
		onClick: (e, n, r, i) => {
			t.current.disabled || e.detail !== 0 || (t.current.onPaint(n, r, !i), t.current.onCommit());
		},
		onPointerDown: (e, r, i, s) => {
			if (t.current.disabled || e.button !== 0) return;
			e.preventDefault(), c(), n.current = { selected: !s };
			let l = e.currentTarget.ownerDocument, u = () => {
				n.current && (n.current = void 0, c(), t.current.onCommit());
			};
			l.addEventListener("pointerup", u), l.addEventListener("pointercancel", u), o.current = () => {
				l.removeEventListener("pointerup", u), l.removeEventListener("pointercancel", u);
			}, t.current.onPaint(r, i, !s), t.current.onFocus(a(r, i));
		},
		onPointerEnter: (e, r) => {
			n.current && !t.current.disabled && t.current.onPaint(e, r, n.current.selected);
		}
	};
}
//#endregion
export { s as TimeGrid, a as timeGridCellKey, c as useTimeGridInteraction };
