import { TimelineTrackEvent, TimelineTrackRange } from './model';
export type TimelineTrackPointerMode = 'move' | 'start' | 'end';
export interface TimelineTrackItem<T extends TimelineTrackEvent> {
    readonly id: string | number;
    readonly event: T;
}
export interface TimelineTrackLabels {
    readonly preview: string;
    readonly moveEvent: (index: number) => string;
    readonly resizeStart: (label: string) => string;
    readonly resizeEnd: (label: string) => string;
}
export interface TimelineTrackProps<T extends TimelineTrackEvent> {
    readonly rows: readonly TimelineTrackItem<T>[];
    readonly selected?: string | number;
    /** Finite bounds with end greater than start. */
    readonly range: TimelineTrackRange;
    readonly labels?: Partial<TimelineTrackLabels>;
    readonly onSelect: (id: string | number) => void;
    readonly onEventChange: (id: string | number, event: T) => void;
}
/** Controlled numeric timeline. Changes preserve event metadata; consumers own commits. */
export declare function TimelineTrack<T extends TimelineTrackEvent>({ rows, selected, range, labels, onSelect, onEventChange, }: TimelineTrackProps<T>): import("preact").JSX.Element;
