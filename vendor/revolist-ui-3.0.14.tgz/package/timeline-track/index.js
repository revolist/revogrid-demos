import { ButtonControl as e } from "../native-control.js";
import { eventOutsideRange as t, moveTimelineEvent as n, niceTimelineStep as r, resizeTimelineEvent as i, timelineGeometry as a } from "./model.js";
import { jsx as o, jsxs as s } from "preact/jsx-runtime";
import { useRef as c } from "preact/hooks";
//#region src/timeline-track/component.tsx
var l = {
	preview: "Timeline preview",
	moveEvent: (e) => `Move event ${e}`,
	resizeStart: (e) => `Resize start of ${e}`,
	resizeEnd: (e) => `Resize end of ${e}`
};
function u({ rows: u, selected: d, range: f, labels: p, onSelect: m, onEventChange: h }) {
	let g = {
		...l,
		...p
	}, _ = c(), v = (e, t, n) => {
		let r = e.currentTarget.closest(".rv-timeline-control__track");
		r && (e.preventDefault(), e.currentTarget.setPointerCapture?.(e.pointerId), _.current = {
			id: t.id,
			mode: n,
			clientX: e.clientX,
			event: t.event,
			width: r.getBoundingClientRect().width
		}, m(t.id));
	}, y = (e) => {
		let t = _.current;
		if (!t) return;
		let a = r(f), o = (e.clientX - t.clientX) / Math.max(1, t.width) * (f.end - f.start), s = Math.round(o / a) * a, c = t.mode === "move" ? n(t.event, s, f) : i(t.event, t.mode, s, f);
		h(t.id, c);
	}, b = () => {
		_.current = void 0;
	}, x = (e, t, a) => {
		if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
		e.preventDefault();
		let o = r(f) * (e.key === "ArrowLeft" ? -1 : 1);
		h(t.id, a === "move" ? n(t.event, o, f) : i(t.event, a, o, f));
	};
	return /* @__PURE__ */ s("div", {
		class: "rv-timeline-editor__track rv-timeline-control__track",
		role: "group",
		"aria-label": g.preview,
		children: [
			/* @__PURE__ */ o("span", {
				class: "rv-timeline-editor__range rv-timeline-editor__range--start rv-timeline-control__range rv-timeline-control__range--start",
				children: f.start
			}),
			/* @__PURE__ */ o("span", {
				class: "rv-timeline-editor__range rv-timeline-editor__range--end rv-timeline-control__range rv-timeline-control__range--end",
				children: f.end
			}),
			u.map((e, t) => ({
				row: e,
				index: t
			})).filter(({ row: e }) => Number.isFinite(e.event.start) && Number.isFinite(e.event.end) && e.event.end >= e.event.start).map(({ row: n, index: r }) => {
				let i = a(n.event, f), c = t(n.event, f), l = n.event.label || g.moveEvent(r + 1);
				return /* @__PURE__ */ s("div", {
					class: [
						"rv-timeline-editor__bar rv-timeline-control__bar",
						d === n.id ? "rv-timeline-editor__bar--selected rv-timeline-control__bar--selected" : "",
						n.event.start === n.event.end ? "rv-timeline-editor__bar--milestone rv-timeline-control__bar--milestone" : "",
						c ? "rv-timeline-editor__bar--outside rv-timeline-control__bar--outside" : ""
					].filter(Boolean).join(" "),
					style: {
						left: `${i.left}%`,
						width: `${i.width}%`
					},
					role: "group",
					"aria-label": l,
					children: [
						/* @__PURE__ */ o(e, {
							unstyled: !0,
							type: "button",
							class: "rv-timeline-editor__bar-move rv-timeline-control__bar-move",
							"data-autofocus": r === 0 ? "" : void 0,
							"aria-label": n.event.label ? `${g.moveEvent(r + 1)}: ${n.event.label}` : g.moveEvent(r + 1),
							"aria-keyshortcuts": "ArrowLeft ArrowRight",
							onFocus: () => m(n.id),
							onPointerDown: (e) => v(e, n, "move"),
							onPointerMove: y,
							onPointerUp: b,
							onPointerCancel: b,
							onKeyDown: (e) => x(e, n, "move"),
							children: /* @__PURE__ */ o("span", {
								class: "rv-timeline-editor__bar-label rv-timeline-control__bar-label",
								children: n.event.label
							})
						}),
						/* @__PURE__ */ o(e, {
							unstyled: !0,
							type: "button",
							class: "rv-timeline-editor__handle rv-timeline-editor__handle--start rv-timeline-control__handle rv-timeline-control__handle--start",
							role: "slider",
							"aria-orientation": "horizontal",
							"aria-label": g.resizeStart(l),
							"aria-valuemin": Math.min(f.start, n.event.start),
							"aria-valuemax": n.event.end,
							"aria-valuenow": n.event.start,
							"aria-keyshortcuts": "ArrowLeft ArrowRight",
							onFocus: () => m(n.id),
							onPointerDown: (e) => {
								e.stopPropagation(), v(e, n, "start");
							},
							onPointerMove: y,
							onPointerUp: b,
							onPointerCancel: b,
							onKeyDown: (e) => {
								e.stopPropagation(), x(e, n, "start");
							}
						}),
						/* @__PURE__ */ o(e, {
							unstyled: !0,
							type: "button",
							class: "rv-timeline-editor__handle rv-timeline-editor__handle--end rv-timeline-control__handle rv-timeline-control__handle--end",
							role: "slider",
							"aria-orientation": "horizontal",
							"aria-label": g.resizeEnd(l),
							"aria-valuemin": n.event.start,
							"aria-valuemax": Math.max(f.end, n.event.end),
							"aria-valuenow": n.event.end,
							"aria-keyshortcuts": "ArrowLeft ArrowRight",
							onFocus: () => m(n.id),
							onPointerDown: (e) => {
								e.stopPropagation(), v(e, n, "end");
							},
							onPointerMove: y,
							onPointerUp: b,
							onPointerCancel: b,
							onKeyDown: (e) => {
								e.stopPropagation(), x(e, n, "end");
							}
						})
					]
				}, n.id);
			})
		]
	});
}
//#endregion
export { u as TimelineTrack, t as eventOutsideRange, n as moveTimelineEvent, r as niceTimelineStep, i as resizeTimelineEvent, a as timelineGeometry };
