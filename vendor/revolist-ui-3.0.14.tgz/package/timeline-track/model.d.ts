export interface TimelineTrackEvent {
    readonly start: number;
    readonly end: number;
    readonly label?: string;
}
export interface TimelineTrackRange {
    readonly start: number;
    readonly end: number;
}
export declare function eventOutsideRange(event: TimelineTrackEvent, range: TimelineTrackRange): boolean;
export declare function timelineGeometry(event: TimelineTrackEvent, range: TimelineTrackRange): {
    readonly left: number;
    readonly width: number;
};
export declare function niceTimelineStep(range: TimelineTrackRange): number;
export declare function moveTimelineEvent<T extends TimelineTrackEvent>(event: T, delta: number, range: TimelineTrackRange): T;
export declare function resizeTimelineEvent<T extends TimelineTrackEvent>(event: T, edge: 'start' | 'end', delta: number, range: TimelineTrackRange): T;
