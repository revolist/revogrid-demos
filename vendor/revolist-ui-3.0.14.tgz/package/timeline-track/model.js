//#region src/timeline-track/model.ts
function e(e, t) {
	return e.start < t.start || e.end > t.end;
}
function t(e, t) {
	let n = t.end - t.start, r = Math.max(t.start, Math.min(t.end, e.start)), i = Math.max(t.start, Math.min(t.end, e.end)), a = (r - t.start) / n * 100, o = (i - r) / n * 100;
	return {
		left: Math.min(99, a),
		width: Math.max(e.start === e.end ? .8 : 0, o)
	};
}
function n(e) {
	let t = Math.abs(e.end - e.start) / 24;
	if (!Number.isFinite(t) || t <= 0) return 1;
	let n = 10 ** Math.floor(Math.log10(t)), r = t / n;
	return (r <= 1 ? 1 : r <= 2 ? 2 : r <= 5 ? 5 : 10) * n;
}
function r(e, t, n) {
	let r = e.end - e.start;
	if (r > n.end - n.start) return { ...e };
	let i = e.start + t;
	return i = Math.max(n.start, Math.min(n.end - r, i)), {
		...e,
		start: i,
		end: i + r
	};
}
function i(e, t, n, r) {
	return t === "start" ? {
		...e,
		start: Math.max(r.start, Math.min(e.end, e.start + n))
	} : {
		...e,
		end: Math.min(r.end, Math.max(e.start, e.end + n))
	};
}
//#endregion
export { e as eventOutsideRange, r as moveTimelineEvent, n as niceTimelineStep, i as resizeTimelineEvent, t as timelineGeometry };
