import { ObjectDirective } from 'vue';
/** Native controls keep Vue's v-model, DOM refs and events. Shared UI owns their
 * presentation; reapply after Vue patches dynamic classes or input types. */
export declare const vRvControl: ObjectDirective<HTMLElement>;
