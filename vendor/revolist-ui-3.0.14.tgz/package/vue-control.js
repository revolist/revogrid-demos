import { controlAttributes as e } from "./control-presentation.js";
//#region src/vue-control.ts
var t = /* @__PURE__ */ new WeakMap();
function n(n) {
	for (let e of t.get(n) ?? []) n.classList.remove(e);
	let r = n.localName, i = e(r, { ...r === "input" ? { type: n.type } : {} }), a = i.class.split(/\s+/).filter(Boolean);
	n.classList.add(...a), t.set(n, a), r === "button" && !n.hasAttribute("type") && n.setAttribute("type", i.type);
}
var r = {
	beforeMount: n,
	updated: n,
	unmounted(e) {
		t.delete(e);
	}
};
//#endregion
export { r as vRvControl };
